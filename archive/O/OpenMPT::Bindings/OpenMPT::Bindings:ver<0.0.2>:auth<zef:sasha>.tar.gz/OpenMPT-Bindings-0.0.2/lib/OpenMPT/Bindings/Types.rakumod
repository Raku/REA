use NativeCall;

unit module OpenMPT::Bindings::Types;

enum OpenMPTError is export (
    OPENMPT_ERROR_OK                     => 0,
    OPENMPT_ERROR_UNKNOWN                => 257,
    OPENMPT_ERROR_EXCEPTION              => 267,
    OPENMPT_ERROR_OUT_OF_MEMORY          => 277,
    OPENMPT_ERROR_RUNTIME                => 286,
    OPENMPT_ERROR_RANGE                  => 287,
    OPENMPT_ERROR_OVERFLOW               => 288,
    OPENMPT_ERROR_UNDERFLOW              => 289,
    OPENMPT_ERROR_LOGIC                  => 296,
    OPENMPT_ERROR_DOMAIN                 => 297,
    OPENMPT_ERROR_LENGTH                 => 298,
    OPENMPT_ERROR_OUT_OF_RANGE           => 299,
    OPENMPT_ERROR_INVALID_ARGUMENT       => 300,
    OPENMPT_ERROR_GENERAL                => 357,
    OPENMPT_ERROR_INVALID_MODULE_POINTER => 358,
    OPENMPT_ERROR_ARGUMENT_NULL_POINTER  => 359,
);

enum OpenMPTRenderParam is export (
    OPENMPT_MODULE_RENDER_MASTERGAIN_MILLIBEL        => 1,
    OPENMPT_MODULE_RENDER_STEREOSEPARATION_PERCENT   => 2,
    OPENMPT_MODULE_RENDER_INTERPOLATIONFILTER_LENGTH => 3,
    OPENMPT_MODULE_RENDER_VOLUMERAMPING_STRENGTH     => 4,
);

enum OpenMPTProbeFlags is export (
    OPENMPT_PROBE_FILE_HEADER_FLAGS_MODULES    => 0x01,
    OPENMPT_PROBE_FILE_HEADER_FLAGS_CONTAINERS => 0x02,
    OPENMPT_PROBE_FILE_HEADER_FLAGS_DEFAULT    => 0x03,
    OPENMPT_PROBE_FILE_HEADER_FLAGS_NONE       => 0x00,
);

enum OpenMPTProbeResult is export (
    OPENMPT_PROBE_FILE_HEADER_RESULT_SUCCESS     => 1,
    OPENMPT_PROBE_FILE_HEADER_RESULT_FAILURE     => 0,
    OPENMPT_PROBE_FILE_HEADER_RESULT_WANTMOREDATA => -1,
    OPENMPT_PROBE_FILE_HEADER_RESULT_ERROR       => -255,
);

enum OpenMPTErrorFuncResult is export (
    OPENMPT_ERROR_FUNC_RESULT_NONE    => 0,
    OPENMPT_ERROR_FUNC_RESULT_LOG     => 1,
    OPENMPT_ERROR_FUNC_RESULT_STORE   => 2,
    OPENMPT_ERROR_FUNC_RESULT_DEFAULT => 3,
);

enum OpenMPTCommandIndex is export (
    OPENMPT_MODULE_COMMAND_NOTE      => 0,
    OPENMPT_MODULE_COMMAND_INSTRUMENT => 1,
    OPENMPT_MODULE_COMMAND_VOLUMEEFFECT => 2,
    OPENMPT_MODULE_COMMAND_EFFECT    => 3,
    OPENMPT_MODULE_COMMAND_VOLUME    => 4,
    OPENMPT_MODULE_COMMAND_PARAMETER => 5,
);

# ============================================================================
# libopenmpt_ext interface structs
# ============================================================================

class ExtInterfacePatternVis is repr('CStruct') is export {
    has Pointer[void] $.get_pattern_row_channel_volume_effect_type;
    has Pointer[void] $.get_pattern_row_channel_effect_type;
}

class ExtInterfaceInteractive is repr('CStruct') is export {
    has Pointer[void] $.set_current_speed;
    has Pointer[void] $.set_current_tempo;
    has Pointer[void] $.set_tempo_factor;
    has Pointer[void] $.get_tempo_factor;
    has Pointer[void] $.set_pitch_factor;
    has Pointer[void] $.get_pitch_factor;
    has Pointer[void] $.set_global_volume;
    has Pointer[void] $.get_global_volume;
    has Pointer[void] $.set_channel_volume;
    has Pointer[void] $.get_channel_volume;
    has Pointer[void] $.set_channel_mute_status;
    has Pointer[void] $.get_channel_mute_status;
    has Pointer[void] $.set_instrument_mute_status;
    has Pointer[void] $.get_instrument_mute_status;
    has Pointer[void] $.play_note;
    has Pointer[void] $.stop_note;
}

class ExtInterfaceInteractive2 is repr('CStruct') is export {
    has Pointer[void] $.note_off;
    has Pointer[void] $.note_fade;
    has Pointer[void] $.set_channel_panning;
    has Pointer[void] $.get_channel_panning;
    has Pointer[void] $.set_note_finetune;
    has Pointer[void] $.get_note_finetune;
}

class ExtInterfaceInteractive3 is repr('CStruct') is export {
    has Pointer[void] $.set_current_tempo2;
}

=begin pod

=head1 NAME

OpenMPT::Bindings::Types - Enums and CStruct types for libopenmpt bindings

=head1 DESCRIPTION

Defines the enums and C-compatible structures used across the bindings.

=head1 ENUMS

=head2 OpenMPTError

Error codes returned by libopenmpt C API functions.

=item OPENMPT_ERROR_OK (0)
=item OPENMPT_ERROR_UNKNOWN (257)
=item OPENMPT_ERROR_EXCEPTION (267)
=item OPENMPT_ERROR_OUT_OF_MEMORY (277)
=item OPENMPT_ERROR_RUNTIME (286)
=item OPENMPT_ERROR_RANGE (287)
=item OPENMPT_ERROR_OVERFLOW (288)
=item OPENMPT_ERROR_UNDERFLOW (289)
=item OPENMPT_ERROR_LOGIC (296)
=item OPENMPT_ERROR_DOMAIN (297)
=item OPENMPT_ERROR_LENGTH (298)
=item OPENMPT_ERROR_OUT_OF_RANGE (299)
=item OPENMPT_ERROR_INVALID_ARGUMENT (300)
=item OPENMPT_ERROR_GENERAL (357)
=item OPENMPT_ERROR_INVALID_MODULE_POINTER (358)
=item OPENMPT_ERROR_ARGUMENT_NULL_POINTER (359)

=head2 OpenMPTRenderParam

Render parameter identifiers for C<openmpt_module_get/set_render_param>.

=item OPENMPT_MODULE_RENDER_MASTERGAIN_MILLIBEL (1)
=item OPENMPT_MODULE_RENDER_STEREOSEPARATION_PERCENT (2)
=item OPENMPT_MODULE_RENDER_INTERPOLATIONFILTER_LENGTH (3)
=item OPENMPT_MODULE_RENDER_VOLUMERAMPING_STRENGTH (4)

=head2 OpenMPTProbeFlags

Flags for C<openmpt_probe_file_header>.

=item OPENMPT_PROBE_FILE_HEADER_FLAGS_MODULES (0x01)
=item OPENMPT_PROBE_FILE_HEADER_FLAGS_CONTAINERS (0x02)
=item OPENMPT_PROBE_FILE_HEADER_FLAGS_DEFAULT (0x03)
=item OPENMPT_PROBE_FILE_HEADER_FLAGS_NONE (0x00)

=head2 OpenMPTProbeResult

Return values from C<openmpt_probe_file_header>.

=item OPENMPT_PROBE_FILE_HEADER_RESULT_SUCCESS (1)
=item OPENMPT_PROBE_FILE_HEADER_RESULT_FAILURE (0)
=item OPENMPT_PROBE_FILE_HEADER_RESULT_WANTMOREDATA (-1)
=item OPENMPT_PROBE_FILE_HEADER_RESULT_ERROR (-255)

=head2 OpenMPTErrorFuncResult

Return values from error callback functions.

=item OPENMPT_ERROR_FUNC_RESULT_NONE (0)
=item OPENMPT_ERROR_FUNC_RESULT_LOG (1)
=item OPENMPT_ERROR_FUNC_RESULT_STORE (2)
=item OPENMPT_ERROR_FUNC_RESULT_DEFAULT (3)

=end pod
