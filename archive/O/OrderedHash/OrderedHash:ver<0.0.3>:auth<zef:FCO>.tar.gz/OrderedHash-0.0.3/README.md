[![Build Status](https://travis-ci.org/FCO/OrderedHash.svg?branch=master)](https://travis-ci.org/FCO/OrderedHash)



