---
name: Bug report or feature request
about: Create a report to help us improve
title: ''
labels: docs
assignees: ''

---

## Problem or new feature

A clear and concise description of what the bug is, including links to the page where you have found it.

## Suggestions

If applicable, suggest something towards the solution.
