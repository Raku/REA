# Cro::HTTP [![Build Status](https://travis-ci.org/croservices/cro-http.svg?branch=master)](https://travis-ci.org/croservices/cro-http)

This is part of the Cro libraries for implementing services and distributed
systems in Perl 6. See the [Cro website](http://cro.services/) for further
information and documentation.
