NAME
Test::Diehard

AUTHOR
Mose Schmiedel <mose.schmiedel@web.de>

VERSION
0.0.0

Description

Test suite for PRNGs.

Installation

Install this module through zef:

    zef install Test::Diehard


License

This module is distributed under the terms of the AGPL-3.0.
