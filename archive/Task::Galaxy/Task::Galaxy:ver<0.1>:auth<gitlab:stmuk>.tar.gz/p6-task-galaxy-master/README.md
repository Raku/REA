# Task::Galaxy

Another meta-package for modules with tests (fatter than Task::Star) and
intended for test purposes.

Selected more or less randomly from http://modules.perl6.org/ the main criteria
being 100% test pass (at time of adding), number of github stars and
"usefulness".

One notable current omission is Inline::Perl5 since this is dependent on Perl
5 built with particular cc flags.

If I've missed your favourite module please submit a Pull Request.

Note this is currently hosted on gitlab.com rather than github as an
experiment.

steve.mynott@github.com 20160402
