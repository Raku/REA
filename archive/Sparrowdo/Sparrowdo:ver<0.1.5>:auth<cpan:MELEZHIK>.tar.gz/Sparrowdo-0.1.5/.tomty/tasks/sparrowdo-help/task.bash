sparrowdo --help
