sparrowdo --localhost --no_sudo
