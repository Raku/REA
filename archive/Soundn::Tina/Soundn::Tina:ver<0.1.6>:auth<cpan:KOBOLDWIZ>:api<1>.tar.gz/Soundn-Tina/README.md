A WAVE file parsing system with sample pattern classification.

Written in raku. 
