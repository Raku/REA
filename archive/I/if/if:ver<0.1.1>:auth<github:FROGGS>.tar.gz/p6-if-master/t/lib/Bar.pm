sub EXPORT (|) {
    $*PACKAGE_LOADED++;
    {}
}
