package HasAutoload;
sub AUTOLOAD {
    return 'autoload';
}
1;
