unit class X::Inline::Perl5::NoMultiplicity is Exception;
method message() {
    "You need to compile perl with -Dusemultiplicity for running multiple interpreters."
}
