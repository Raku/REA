package TestPerl5Package::Sub;

use base qw(TestPerl5Package);

1;
