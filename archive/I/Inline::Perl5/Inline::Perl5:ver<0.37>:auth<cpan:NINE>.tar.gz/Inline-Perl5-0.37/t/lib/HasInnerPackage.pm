package HasInnerPackage; sub func { return 'has-inner-package' }
package InnerPackage;    sub func { return 'inner-package' }
1;

