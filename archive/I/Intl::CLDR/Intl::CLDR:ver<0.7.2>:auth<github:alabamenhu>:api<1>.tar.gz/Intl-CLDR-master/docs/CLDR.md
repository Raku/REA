> *¿Cómo se diz na vuestra, na nuestra llingua, la palabra futuru?*  
— Lecciones de gramática (Berta Piñán)

# CLDR

The CLDR is designed