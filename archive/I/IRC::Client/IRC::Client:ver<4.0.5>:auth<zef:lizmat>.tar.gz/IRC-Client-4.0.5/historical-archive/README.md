The documents in this directory are kept for historical reasons.

Their contents do not represent what the module does or should do.
