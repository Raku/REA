
# Specs

* [Numerics and other awesome info](https://www.alien.net.au/irc/)
* [RFC 1459](https://tools.ietf.org/html/rfc1459)
* [RFC 2810](https://tools.ietf.org/html/rfc2810)
* [RFC 2811](https://tools.ietf.org/html/rfc2811)
* [RFC 2812](https://tools.ietf.org/html/rfc2812)
* [RFC 2813](https://tools.ietf.org/html/rfc2813)
* [WebIRC](https://irc.wiki/WebIRC)
* [CTCP SPEC](http://cpansearch.perl.org/src/HINRIK/POE-Component-IRC-6.78/docs/ctcpspec.html)
* [DCC Description](http://www.irchelp.org/irchelp/rfc/dccspec.html)
* [DCC2](https://tools.ietf.org/id/draft-smith-irc-dcc2-negotiation-00.txt)

# Future

IRCv3 group: http://ircv3.net/
