[[back to main docs]](../README.md)

# Documentation Map

* [Blog Post](http://perl6.party/post/IRC-Client-Perl-6-Multi-Server-IRC-Module)
* [Basics Tutorial](01-basics.md)
* [Event Reference](02-event-reference.md)
* [Method Reference](03-method-reference.md)
* [Big-Picture Behaviour](04-big-picture-behaviour.md)
* [Examples](../examples/)
