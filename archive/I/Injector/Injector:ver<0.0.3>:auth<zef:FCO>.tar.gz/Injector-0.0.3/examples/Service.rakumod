role Service {
	method name {…}
}

