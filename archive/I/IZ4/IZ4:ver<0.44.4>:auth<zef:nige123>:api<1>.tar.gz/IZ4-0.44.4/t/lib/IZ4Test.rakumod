unit module IZ4Test;

# A hermetic Git for every test: the machine's own global configuration,
# a core.hooksPath that runs the iz4 gate on every commit say, must never
# reach a test's temporary repositories.
INIT {
    my $cfg = $*TMPDIR.add("iz4-test-gitconfig-{$*PID}");
    $cfg.spurt('') unless $cfg.e;
    %*ENV<GIT_CONFIG_GLOBAL>   = $cfg.Str;
    %*ENV<GIT_CONFIG_NOSYSTEM> = '1';
    # No test reaches the network or a real 321 by accident: the step that
    # follows a change of intent (ensure the driver, activate enforcement)
    # is off unless a test turns it on against a stand-in.
    %*ENV<IZ4_ENFORCE> = '0';
    # and no test signs with a real person's key: approve looks here for keys, and finds none
    %*ENV<IZ4_SSH_DIR> = $*TMPDIR.add("iz4-test-no-keys-{$*PID}").Str;
    %*ENV<IZ4_APPROVERS>:delete;
    # and an identity, so a test's commits work on a machine with none set
    %*ENV<GIT_AUTHOR_NAME>  = %*ENV<GIT_COMMITTER_NAME>  = 'iz4 test';
    %*ENV<GIT_AUTHOR_EMAIL> = %*ENV<GIT_COMMITTER_EMAIL> = 't@test';
    END { try $cfg.unlink }
}

use IZ4::Document;
use IZ4;

#| A fresh temporary directory; removed at process exit.
sub temp-dir(--> IO::Path) is export {
    my $dir = $*TMPDIR.add("iz4-test-{$*PID}-{(^1_000_000).pick}");
    $dir.mkdir;
    END rm-rf($dir);
    $dir;
}

sub rm-rf(IO::Path $path) is export {
    return unless $path.e;
    if $path.d && !$path.l {
        rm-rf($_) for $path.dir;
        $path.rmdir;
    }
    else {
        $path.unlink;
    }
}

#| Run bin/iz4 in $cwd; returns (exit-code, stdout, stderr).
sub iz4(IO::Path $cwd, *@args, :%env) is export {
    my $root = $?FILE.IO.resolve.parent(3);
    # IZ4_TEST_BIN points the suite at a compiled iz4 (a Raku++ binary),
    # so CI tests the executable it ships, not the source it came from.
    my @cmd = %*ENV<IZ4_TEST_BIN>
        ?? (%*ENV<IZ4_TEST_BIN>,)
        !! ($*EXECUTABLE, '-I', $root.add('lib').Str, $root.add('bin/iz4').Str);
    my %e = %*ENV, %env;
    my $proc = run |@cmd, |@args, :cwd($cwd.Str), :out, :err, :env(%e);
    my $out = $proc.out.slurp(:close);
    my $err = $proc.err.slurp(:close);
    $proc.exitcode, $out, $err;
}

#| Run bin/iz4 in $cwd with $input on standard input, as a person would
#| answer its questions (IZ4_INTERACTIVE=1 turns coaching on without a
#| terminal).  'iz4 approve' takes a real terminal and nothing else, so
#| that one goes through t/lib/at-terminal.py.  Returns (exit-code, stdout, stderr).
sub iz4-talk(IO::Path $cwd, Str $input, *@args, :%env) is export {
    my $root = $?FILE.IO.resolve.parent(3);
    my @cmd = %*ENV<IZ4_TEST_BIN>
        ?? (%*ENV<IZ4_TEST_BIN>,)
        !! ($*EXECUTABLE, '-I', $root.add('lib').Str, $root.add('bin/iz4').Str);
    my %e = %*ENV, %env;
    %e<IZ4_INTERACTIVE> = '1';
    if @args && @args[0] eq 'approve' {
        %e<IZ4_INTERACTIVE>:delete;
        %e<NO_COLOR> = '1';
        @cmd = ('python3', $root.add('t/lib/at-terminal.py').Str, |@cmd);
    }
    my $proc = run |@cmd, |@args, :cwd($cwd.Str), :in, :out, :err, :env(%e);
    $proc.in.print($input);
    my $ = $proc.in.close;         # sunk, a refusing exit would throw here; the code is read below
    my $out = $proc.out.slurp(:close);
    my $err = $proc.err.slurp(:close);
    $proc.exitcode, $out, $err;
}

#| A minimal current-format IZ4 in a fresh directory.
sub minimal-iz4(IO::Path :$dir = temp-dir(), Str :$extra = '', Str :$domain = 'example.com' --> IO::Path) is export {
    my $path = $dir.add('IZ4');
    $path.spurt("IZ4 $domain\n\nIS FOR WHAT?  Helping people find work they love to do.\n\n"
        ~ "IS FOR WHO?   People looking for work.\n\n" ~ foundation-block() ~ $extra);
    $path;
}

#| The digest of a foundation promise, by its card.
sub foundation-digest-of(Str $id --> Str) is export {
    my %f = FOUNDATION-CARD.first({ .<id> eq $id });
    sha256-text(canonical-card(%f<id>, %f<when>, %f<always>.list, %f<protects>.list));
}

#| The digest of a promise's words, iz4-invariant/5, as a test states them.
sub invariant-digest(Str $name, Str $always, Str $protects, Str :$when = 'it applies' --> Str) is export {
    sha256-text(canonical-card($name, $when, ($always,), ($protects,)));
}

#| One promise as a card, for a test's fixture.  Established unless :exploring.
sub card(Str $name, Str $always, Str $protects = 'People relying on it.', Str :$when = 'the software runs',
         Bool :$exploring = False --> Str) is export {
    card-lines('PROMISE', $name, $when, ($always,), ($protects,), $exploring ?? CHANGE-FREE !! CHANGE-SIGNED).join("\n") ~ "\n";
}

#| An independent system digest for cross-checking sha256-file, using
#| whichever tool this platform has.
sub sha256-hex(IO::Path $f --> Str) is export {
    for ('sha256sum',), ('shasum', '-a', '256'), ('openssl', 'dgst', '-sha256', '-r') -> @tool {
        my $hex = try {
            my $p = run |@tool.map(*.Str), $f.Str, :out, :err;
            my $o = $p.out.slurp(:close);
            $p.err.slurp(:close);
            $p.exitcode == 0 ?? $o.words.head.Str !! Str;
        };
        return $hex.lc if $hex.defined && $hex.chars == 64;
    }
    Str;
}

#| Can we run git here?  (Tests that need it skip otherwise.)
sub have-git(--> Bool) is export {
    my $p = try run 'git', '--version', :out, :err;
    $p.defined && $p.exitcode == 0;
}
