# The iz4 command line: every command, as a module so a runtime can
# compile it once.  bin/iz4 only loads it.
unit module IZ4::CLI;

# The core: intent, its evidence, the gate, a person's agreement, and the
# machine interface a driver calls.  It knows no agent harness and never
# runs 321.
use IZ4;
use IZ4::Document;
use IZ4::Register;
use IZ4::Git;
use IZ4::Gate;
use IZ4::Agent;
use IZ4::Coach;
use IZ4::Help;
use IZ4::Pack;
use IZ4::Screen;
use IZ4::Review;
use IZ4::Evidence;
use IZ4::Machine;
# The conveniences: they may ask 321, the environment driver and agent
# launcher, and are the only things here that do.
use IZ4::Launcher;
use IZ4::Assist;
use IZ4::Integrations;
# Compatibility for wiring an earlier iz4 left behind; deprecated.
use IZ4::LegacyHook;


#| A row of air above and below everything iz4 says to a person: the first
#| write is preceded by a blank line unless it brings its own, and the
#| last is followed by one.  Only on a terminal (or IZ4_COLOR=1, which
#| asks for the terminal's dress anywhere); a pipe gets the words alone.
class Air is IO::Handle {
    has IO::Handle $.inner is required;
    has Bool $!started = False;
    has Str  $!tail = '';
    method WRITE(Blob:D $data --> True) {
        my $s = $data.decode;
        # a live line that is wiped again leaves nothing on the screen: it starts no chunk
        if !$!started && $s.starts-with("\r") { $!inner.print($s); return True }
        unless $!started { $!started = True; $!inner.print("\n") unless $s.starts-with("\n") }
        $!tail = ($!tail ~ $s).substr(* - 2 max 0);
        $!inner.print($s);
        True;
    }
    method settle() { $!inner.print("\n") if $!started && !$!tail.ends-with("\n\n"); $!inner.flush }
    method flush() { $!inner.flush }
    method t() { $!inner.t }
}
sub air-on(--> Bool) {
    return True  if (%*ENV<IZ4_COLOR> // '') eq '1';
    return False if (%*ENV<IZ4_COLOR> // '') eq '0';
    $*OUT.t && (%*ENV<TERM> // '') ne 'dumb';
}
my $air;
#| Called once by the program before a command runs: unbuffered output, and
#| the air round what a person reads.
sub cli-start() is export {
    $*OUT.out-buffer = False;   # a closed pipe fails at the write, leaving nothing to flush at exit
    if air-on() { $air = Air.new(:inner($*OUT)); $air.encoding('utf8'); $*OUT = $air }
}
END { .settle with $air }

proto MAIN(|) is export {*}

#| What is shown when a command line is not understood, or --help is
#| given.  Short on purpose: the command's own help when it names one,
#| and otherwise the first screen.
sub USAGE() is export {
    my @words = @*ARGS.grep({ !.starts-with('-') });
    my $wanted = so @*ARGS.grep('--help' | '-h' | '-?');
    # the longest leading run of words that names a command
    my $t;
    for (2, 1) -> $n { last if $t.defined; $t = topic(@words.head($n).join(' ')) if @words >= $n }
    if $wanted { print $t.defined ?? help-topic($t) !! help-index(); return }
    my $json = so @*ARGS.grep('--json');
    # a program that asked for JSON gets JSON, failure included
    my sub machine(Str $message, Str $next) {
        say json-encode(%( schema => 'iz4-error/1', outcome => 'usage',
                           error => %( code => 'usage', message => $message, next => $next ) ));
    }
    if $t.defined {
        # the flags its help never mentions: name them, since they are what it did not understand
        my $usage = $t.usage.join(' ');
        my @odd = @*ARGS.grep(*.starts-with('-')).map({ .subst(/ '=' .* /, '') })
                        .grep({ $_ ne '--json' && !$usage.contains(.subst(/ ^ '--' ['/' | 'no-'] /, '--')) });
        my $what = @odd ?? "iz4 {$t.name} did not understand {@odd.join(', ')}"
                        !! "iz4 {$t.name} was not given what it needs";
        return machine($what, "iz4 help {$t.name}") if $json;
        note "$what. Here is how it is called:";
        note help-topic($t).trim-trailing;
    }
    elsif @words {
        my $text = help-for([@words[0]], :command)[0];
        return machine($text.lines.head, 'iz4 help') if $json;
        note $text;
    }
    else { print help-index() }
}

#| The pipeline form: --brief on the command line, or IZ4_BRIEF=1.  Stdout
#| is the result alone, one tab-separated record per line, no title,
#| colour or next; a failure is one line on stderr and the exit code.
sub brief-wanted(Bool $flag --> Bool) { $flag || (%*ENV<IZ4_BRIEF> // '') eq '1' }
sub brief-mode(--> Bool) { brief-wanted(so @*ARGS.grep('--brief')) }
sub two-machine-forms() { note 'iz4: --json and --brief are two machine forms: choose one'; exit 2 }

# Run a command body; user errors become one-line messages and exit 1.
constant INACTIVE-NOTE = 'The IZ4 intent is recorded, but harness enforcement is currently inactive.';

sub attempt(&body, Bool :$intent = False) {
    # A command that changes intent is followed, when it succeeded and
    # really changed something, by making sure enforcement is in place.
    my $*IZ4-INTENT-CHANGED = False;
    my $before = $intent ?? intent-digest() !! '';
    my $rc = body() // 0;
    if $intent && $rc == 0 && ($*IZ4-INTENT-CHANGED || intent-digest() ne $before) {
        try { activate-enforcement(); CATCH { default { note "enforcement: {.message.lines.head}"; note INACTIVE-NOTE } } }
    }
    exit $rc;
    CATCH {
        when X::IZ4 {
            my $message = .message.trim-trailing;
            # a command that writes the IZ4 says what became of it, as far as the file shows
            if $intent {
                my $after = intent-digest();
                my $creating = (@*ARGS[0] // '') eq 'init';
                $message ~= $before eq '' && $after eq '' ?? ($creating ?? "\nNo IZ4 was written." !! '')
                          !! $after eq $before ?? "\nThe IZ4 is unchanged."
                          !! "\nThe IZ4 changed before this stopped: 'git diff IZ4' shows how.";
            }
            note brief-mode() ?? $message.lines.join(' ') !! $message;
            exit 1;
        }
        # A closed pipe (iz4 ... | head) is normal, never a stack trace.
        when *.message.contains('Broken pipe') { try $*OUT.close; exit 0 }
    }
}

# ------------------------------------------------------------ enforcement

#| The nearest IZ4's content identity, or '' when there is none: how a
#| command that may or may not have changed the file is told apart.
sub intent-digest(--> Str) {
    my $path = try resolve-target(Str);
    return '' without $path;
    $path.f ?? (try sha256-file($path)) // '' !! '';
}

#| After a successful change of intent: make sure the environment driver
#| is there (installing the official 321 when it is not), ask it to
#| activate enforcement, and report what is really in place.  Nothing
#| here can undo the change that was just made, and nothing is called
#| active until 321 has wired it and read it back.
sub activate-enforcement() {
    return if enforcement-disabled();
    my $path = try resolve-target(Str);
    return without $path;
    my $root = $path.parent;
    my %r = ensure-enforcement(:$root);
    my %d = %r<driver>;
    given %d<state> {
        when 'installed' { say "321 {%d<version>} installed at {%d<path>}: the environment driver iz4 uses to activate enforcement." }
        when 'updated'   { say "321 updated from {%d<from>} to {%d<version>} at {%d<path>}." }
    }
    if %d<state> eq any(<failed too-old foreign>) {
        my $why = %d<state> eq 'failed'  ?? "321 could not be installed ({%d<note>})"
               !! %d<state> eq 'too-old' ?? "{%d<note>}"
               !!                           "321 was left alone ({%d<note>})";
        quiet("$why, so agent enforcement could not be activated.");
        quiet(INACTIVE-NOTE);
        return;
    }
    with %r<error> {
        quiet("321 {%d<version>} could not activate enforcement ($_).");
        quiet(INACTIVE-NOTE);
        return;
    }
    if !%r<detected> {
        say "enforcement: 321 {%d<version>} found no agent harness here, so there is nothing to wire.";
        return;
    }
    # wiring that was already in place and stayed so is nothing to tell a person
    my @h = @(%r<report><harnesses> // []).grep(*.<detected>);
    return if %d<state> eq 'ready' && %r<active> && @h
           && !@h.grep({ (.<action> // '') ne 'unchanged' || (.<error> // '') ne '' });
    say '';
    say "enforcement, as 321 {%d<version>} wired it and read it back:";
    say "  $_" for driver-lines(%r<report>);
    note INACTIVE-NOTE if !%r<active>;
}

# ------------------------------------------------------------ conversation

#| Coaching needs a person: a terminal on both ends, or IZ4_INTERACTIVE=1
#| (tests script the answers).  Scripts and CI never get a question.
#| Agreement is stricter: see person-here.
sub interactive(--> Bool) {
    with %*ENV<IZ4_INTERACTIVE> { return $_ ne '0' && $_ ne '' }
    $*IN.t && $*OUT.t;
}

#| Agreeing to a change of intent takes a real terminal on both ends, and
#| no setting says otherwise: a pipe is never a person.  A program can
#| still open a terminal of its own, so this raises the bar and proves
#| nobody's presence; only a key that needs a person's touch would.
sub person-here(--> Bool) { $*IN.t && $*OUT.t }

sub ask(Str $prompt --> Str) {
    print $prompt;
    my $line = read-line();
    print "\n" unless $*IN.t;     # keep scripted transcripts readable
    $line // Str;                 # end of input: no answer
}

#| One line from standard input, read a character at a time: under Raku++
#| a second $*IN.get on a pipe returns nothing and .lines reads to the end
#| before answering, and a coach must answer as the person types.
sub read-line(--> Str) {
    my $s = '';
    loop {
        my $c = $*IN.getc;
        without $c { return $s ne '' ?? $s !! Str }
        last if $c eq "\n";
        $s ~= $c;
    }
    $s.subst(/ \r $ /, '');
}

sub tell(Str $line) { say pretty($line) }

#| A short block a person can take in at a glance: a title under the icon,
#| a sentence or two, and the one command that comes next.  The shape every
#| human-facing command answers in, so nothing is a wall.
sub calm(Str $title, *@body, :@next, Str :$command) {
    my $sc = $command.defined ?? Screen.new(:$command, :context($title)) !! Screen.new(:heading($title));
    $sc.lines(|wrap(@body.join(' '), 72).map({ "  $_" })) if @body;
    $sc.lines(|@next.map({ pretty(sprintf('  iz4 %-14s %s', .key, .value)) })) if @next;
    print $sc.screen;
}

#| A command's answer for a person: its title, then each chunk (a list of
#| lines, or a string of them) with a blank row between, so every command
#| opens the same way and nothing arrives as a wall.
sub answer(Str $command, Str $context, **@chunks) {
    my $sc = Screen.new(:$command, :$context);
    for @chunks.grep(*.so) -> $c { $sc.lines(|($c ~~ Str ?? $c.lines !! $c.list)) }
    print $sc.screen;
}

#| The title alone, for a command whose answer arrives in stages (questions,
#| a run of tests): the screen still begins with it.
sub head(Str $command, Str $context = '') {
    say Screen.new(:$command, :$context).title-line;
    say '';
}

#| Body text, wrapped and indented under a title.
sub para(*@s --> List) { wrap(@s.join(' '), 74).map({ "  $_" }).List }

#| The one next step, with why, as every screen ends.
sub next-line(Str $cmd, Str $why = '' --> Str) { pretty("next:  $cmd" ~ ($why ne '' ?? "   ($why)" !! '')) }

#| A note to standard error that a person can read past: dimmed on a terminal.
sub quiet(Str $text) { note pretty-on() && $*ERR.t ?? "\e[2m$text\e[0m" !! $text }

#| Show a drafted answer and let the person keep it with Enter or type
#| their own.  The words that go in the file are the ones they chose.
sub keep-or-type(Str $lead, Str $draft, Str $what --> Str) {
    say '';
    say $lead;
    say "  $draft";
    my $said = ask("Enter keeps that; or type your own.\n> ");
    user-error("iz4 init needs $what") without $said;
    $said.trim eq '' ?? $draft !! $said.trim;
}

sub ask-required(Str $prompt, Str $what --> Str) {
    for ^3 {
        my $answer = (ask($prompt) // user-error("$what: no answer")).trim;
        return $answer if $answer ne '';
        say 'One plain sentence is plenty.';
    }
    user-error("$what: no answer");
}

#| Coach one promise into $path.  Always exit 0: deciding not to add
#| something is a good outcome, not an error.
sub coach-into(IO::Path $path, Str :$candidate, Str :$suggested-because, Str :$name, Str :$namespace --> Int) {
    my $doc = cards-of($path);
    my %r = coach-invariant(
        :&ask, :&tell, :$candidate, :$suggested-because,
        for-what => $doc.for-what, for-who => $doc.for-who);
    given %r<outcome> {
        when 'add' {
            my ($id, $ns) = choose-identity($path, $name, :$namespace, :text(%r<text>));
            add-invariant($path, %r<text>, :name($id), :because(%r<because>), :reach(%r<reach>));
            say '';
            say pretty("  ✓ Added PROMISE $id to {display-name($path)}, exploring: anyone may change its words while it settles.");
            say '';
            say "  Your intention is recorded. A test that names it is what checks it.";
            say '';
            say next-line("iz4 test {$id.split('.')[0]}", 'a test that would fail if it stopped being true');
            say "then:  iz4 establish {$id.split('.')[0]}   (when its words are agreed)";
        }
        when 'skipped' { say ''; say '  · Nothing added.' }
    }
    0;
}

#| The namespace a project's invariants are named under: from the file's
#| first line, or the option.  It is never asked for: every IZ4 says it.
sub choose-namespace(IO::Path $path, Str :$namespace --> Str) {
    my $ns = project-namespace($path, :given($namespace));
    user-error("the first line of {display-name($path)} names your domain: IZ4 your.domain") without $ns;
    with namespace-problem($ns) -> $why { user-error("'$ns' cannot be a namespace: $why") if $why }
    $ns;
}

#| The domain a new IZ4's header names: the one given, IZ4_NAMESPACE, the
#| directory's own name when it reads as a domain; else a person is asked,
#| once.  A script must say it: a domain is one a project answers for, and
#| is never made up.
#| Where init keeps the answers given so far: in the Git directory, outside
#| every tree, so nothing is staged or committed by it.  None without Git.
sub init-draft-file(--> IO::Path) {
    my ($rc, $out, $) = git($*CWD.add('IZ4'), 'rev-parse', '--absolute-git-dir');
    $rc == 0 && $out.trim ne '' ?? $out.trim.IO.add('iz4-init.json') !! IO::Path;
}

sub init-namespace(Str $given, Str :$step = '' --> Str) {
    my $ns = ($given // '').trim.lc || (%*ENV<IZ4_NAMESPACE> // '').trim.lc;
    my $guess = suggested-namespace($*CWD.add('IZ4'));
    if $ns eq '' {
        user-error("iz4 init needs the domain your project answers for, which its invariants are named under: --namespace=your.domain"
            ~ ($guess ?? " (perhaps $guess)" !! '')) unless interactive();
        say "{$step}Which domain does this project answer for? Its invariants are named under it, like honeywillow.com.";
        for ^3 {
            my $answer = (ask("Which domain?" ~ ($guess ?? " [$guess]" !! '') ~ "\n> ") // user-error('no domain given')).trim.lc;
            $answer ||= $guess // '';
            if $answer ne '' && namespace-problem($answer) eq '' { $ns = $answer; last }
            say $answer eq '' ?? 'A domain, like honeywillow.com.' !! "'$answer' cannot be used: {namespace-problem($answer)}";
        }
        user-error('no domain given') if $ns eq '';
    }
    with namespace-problem($ns) -> $why { user-error("'$ns' cannot be this project's domain: $why") if $why }
    $ns;
}

#| The full identity for a new invariant: the name a person gave, under
#| the project's namespace.  A name that is already whole is taken as it
#| is.  On a terminal a missing name is asked for; a script must give it:
#| a name is a person's choice and is never made up here.
sub choose-identity(IO::Path $path, Str $name? is copy, Str :$namespace, Str :$text = '', Str :$for = 'it' --> List) {
    my $known = project-namespace($path, :given($namespace));
    without $name {
        user-error("an invariant needs a name: --name=a-few-words (lower case, joined by hyphens), which is how people and tools will refer to it")
            unless interactive();
        say "Name $for: a few lower-case words joined by hyphens, like owner-adjusted.";
        say "The name is how people, tests and tools refer to it, and it never changes.";
        for ^3 {
            my $answer = (ask("> ") // user-error('no name given')).trim;
            my $trial = is-identity($answer) ?? $answer !! $answer ~ '.' ~ ($known // 'example.com');
            if $answer ne '' && identity-problem($trial) eq '' { $name = $answer; last }
            say $answer eq '' ?? 'A name, like owner-adjusted.' !! "'$answer' cannot be used: {identity-problem($trial)}";
        }
        user-error('no name given') without $name;
    }
    $name = $name.trim;
    return ($name, $known) if is-identity($name) && (!$known || $name.ends-with(".$known"));
    if is-identity($name) && $known {
        note "note: $name is outside this project's namespace ($known); taken as the whole name";
        return ($name, Str);
    }
    my $ns = choose-namespace($path, :$namespace);
    (full-identity($name, $ns), $ns);
}

# ------------------------------------------------------------ help

#| 'iz4' alone, and 'iz4 help': the first screen.  'iz4 help add': one
#| command.  'iz4 help more': the rest.  Always short.
multi MAIN() { print pretty(help-index()); exit 0 }
multi MAIN('help', *@words) {
    my ($text, $known) = help-for(@words);
    if $known { print pretty($text); exit 0 }
    note $text;
    exit 1;
}
multi MAIN(Bool :h($h)!) { print pretty(help-index()); exit 0 }
# people type this out of habit; it is the same as 'iz4 version'
multi MAIN(Bool :$version!) { MAIN('version') }

# ------------------------------------------------------------ init

multi MAIN('init', Str :$for-what, Str :$for-who, Str :$namespace, Bool :$agent, Bool :$agents) {
    attempt :intent, {
        user-error("IZ4 already exists here; not overwriting. 'iz4 status' shows where it stands.") if $*CWD.add('IZ4').e;
        # the title first, then one breath on what is about to happen, so the
        # questions that follow arrive with their reason
        say pretty((pretty-on() ?? diamond() ~ ' ' !! '') ~ "iz4 init: starting the IZ4 for {$*CWD.basename}");
        say '';
        say "  $_" for wrap('An IZ4 says what this software is for, who it is for, and the few promises that must stay true as it changes. Two answers start it, in your own words; the file is plain text, kept beside the code, and yours to edit.', 72);
        say '';
        note "init no longer drafts a specification from the repository; after init, 'iz4 suggest' proposes a few candidate invariants"
            if $agent === True;
        my $talk = interactive();
        my $what = $for-what;
        my $who  = $for-who;
        # the answers so far, kept in the Git directory (never in the tree) so a stopped init picks up where it left off
        my $draft = init-draft-file();
        my %saved = $talk && $draft.defined && $draft.f ?? ((try Rakudo::Internals::JSON.from-json($draft.slurp)) // %()) !! %();
        my sub keep() { .spurt(json-encode(%( |(:for-what($what) if $what.defined), |(:for-who($who) if $who.defined) ))) with $draft }
        if %saved && (!$what.defined || !$who.defined) {
            say "Picking up where you stopped: your answers so far are below.";
            $what //= keep-or-type('Step 1 of 3. This is for:', %saved<for-what>, 'what it is for') if %saved<for-what>;
            keep();
            $who  //= keep-or-type('Step 2 of 3. And it is for:', %saved<for-who>, 'who it is for') if %saved<for-who>;
            keep();
        }
        if !$talk && (!$what.defined || !$who.defined) {
            user-error("iz4 init needs two answers: what this is for, and who it is for.\n"
                ~ "On a terminal it asks; in a script pass --for-what=... --for-who=...");
        }
        if $talk && (!$what.defined || !$who.defined) {
            # Whatever agent is on this machine drafts it with them: 321 is made
            # sure of first, since it is what reaches one.  Nothing is written
            # until the person has seen each answer and kept it or typed their own.
            my %d = (try ensure-driver()) // %();
            say "321 {%d<version>} installed at {%d<path>}: it is how iz4 reaches the agent you already use." if (%d<state> // '') eq 'installed';
            if agent-reachable() && (!$what.defined || !$who.defined) {
                say "Reading this repository with {agent-label()} to draft the IZ4 with you ...";
                my %p = (try agent-purpose($*CWD)) // %();
                if %p {
                    $what //= keep-or-type('Step 1 of 3. It looks like this is for:', %p<for-what>, 'what it is for');
                    keep();
                    $who  //= keep-or-type('Step 2 of 3. And it is for:', %p<for-who>, 'who it is for');
                    keep();
                }
                else { say "No draft came back, so two questions instead." }
            }
        }
        $what //= ask-required("Step 1 of 3. What is this for?\n> ", 'what it is for');
        keep() if $talk;
        $who  //= ask-required("Step 2 of 3. Who is it for?\n> ", 'who it is for');
        keep() if $talk;
        my $ns = init-namespace($namespace, :step('Step 3 of 3. '));
        my $path = init(:for-what($what), :for-who($who), :namespace($ns));
        try .unlink with $draft;
        # what is now in place, as a checklist, so the person sees each milestone land
        say '' if $talk;
        say pretty("  ✓ Created {$path.basename} for $ns.");

        # Agent entry points install themselves - don't make the user think.
        # AGENTS.md always; CLAUDE.md and the skill where the repository
        # shows Claude use.  --agents forces all three; --/agents skips.
        if $agents !=== False {
            CATCH { when X::IZ4 { note "agent entry points not installed: {.message}" } }
            my $root      = $*CWD;
            my $claudeish = $root.add('CLAUDE.md').e || $root.add('.claude').d;
            my @sections  = 'AGENTS.md', |(($agents === True || $claudeish) ?? 'CLAUDE.md' !! Empty);
            say pretty("  ✓ $_: {install-agent-section($root.add($_), :$root)}") for @sections;
            say pretty("  ✓ {SKILL-PATH}: {install-skill(:$root)}") if $agents === True || $root.add('.claude').d;
        }

        # The commit hook installs itself too, where this is a Git repository:
        # it is what notices a change to what the software promises and asks
        # the person about it there and then.  IZ4_ENFORCE=0 leaves it out.
        if (%*ENV<IZ4_ENFORCE> // '') ne '0' && git($path, 'rev-parse', '--git-dir')[0] == 0 {
            my $state = try install-hook($path, :hook<pre-commit>, :text(gate-hook-text(:enforce)),
                                         :mark(GATE-HOOK-MARK), :manual('iz4 gate --staged'));
            say $state.defined
                ?? pretty("  ✓ Commit hook: $state. When a commit changes what this software promises, it asks you about it there and then.")
                !! "  · Commit hook left alone: {$!.message.lines.head}";
        }

        say '';
        calm("What every IZ4 carries",
             'The foundation, word for word, beginning with Invariant Zero: humans first.',
             'Your own promises say when they apply (WHEN), what must remain true (ALWAYS), whose what they protect (PROTECTS), what a change to them requires and how they are checked.',
             :next(['add' => 'one promise, one question at a time',
                    'establish NAME' => 'when a promise is agreed: a change to it then waits for your yes',
                    'foundation' => 'the words every IZ4 carries']));
        if $talk {
            say '';
            if yes-no(ask('Add an invariant now? [Y/n] '), :default) {
                # with an agent here, it reads the code for the few things worth keeping; else one question at a time
                return agent-reachable() && review-suggestions($path, :quiet) ?? 0 !! coach-into($path);
            }
        }
        0;
    }
}

# ------------------------------------------------------------ add

multi MAIN('add', Str $kind?, Str $text?, Str :$file, Str :$because, Str :$name, Str :$namespace,
           Str :$where, Str :$when, Str :$protects, Bool :$replace = False, Bool :$force = False, Bool :$established = False) {
    attempt :intent, {
        my $path = resolve-target($file);
        my $k = ($kind // 'promise').lc;
        given $k {
            when 'invariant' | 'invariants' | 'promise' | 'promises' {
                if interactive() && !$because.defined && !$name.defined && !$where.defined && !$when.defined && !$protects.defined {
                    head('add', 'one promise, a question at a time');
                    return coach-into($path, :candidate($text), :$namespace);
                }
                user-error("iz4 add coaches you on a terminal; in a script use:\n"
                    ~ "  iz4 add promise 'what must remain true' --when='the situation it applies in' --protects='whose what it protects' --name=a-few-words [--established]")
                    without $text;
                fast-add($path, $text, :because($protects // $because), :$name, :$namespace, :$force, :reach($when // $where), :$established);
            }
            when 'for-what' | 'what' | 'is-for-what' {
                user-error('iz4 add for-what needs the answer: what is this for?') without $text;
                set-is-for($path, 'IS FOR WHAT', $text, :$replace);
                answer('add', 'IS FOR WHAT', [pretty('  ✓ Set IS FOR WHAT.')], [next-line('iz4 check')]);
            }
            when 'for-who' | 'who' | 'is-for-who' {
                user-error('iz4 add for-who needs the answer: who is this for?') without $text;
                set-is-for($path, 'IS FOR WHO', $text, :$replace);
                answer('add', 'IS FOR WHO', [pretty('  ✓ Set IS FOR WHO.')], [next-line('iz4 check')]);
            }
            default {
                my $singular = $k.subst(/ 's' $/, '');
                with %ELSEWHERE-FOR{$singular} { user-error($_) }
                user-error("unknown kind '$kind'; IZ4 holds promise, for-what and for-who");
            }
        }
        0;
    }
}

#| The fast path: no questions, but the same challenges as the coach, as
#| a refusal the person can overrule with --force.  They decide.
sub fast-add(IO::Path $path, Str $text, Str :$because, Str :$name, Str :$namespace, Bool :$force, Str :$reach, Bool :$established = False) {
    cards-of($path);
    user-error("not added: say when it applies with --when='the situation', as WHEN is the first field of a promise") if ($reach // '').trim eq '';
    user-error("not added: say whose what it protects with --protects='a customer\'s money', as PROTECTS is the third field. {NOTHING-PROTECTED}") if ($because // '').trim eq '';
    unless $force {
        my %a = assess-candidate($text);
        my $why = do given %a<kind> {
            when 'implementation' { "that sounds like an implementation choice ({%a<signal>}), not an invariant. If it were replaced tomorrow, could it still serve the same people and purpose? If so, record it in an ADR or developer docs instead." }
            when 'mechanism'      { "{%a<signal>} sounds like how it is done today. What must remain true if it is replaced? Add that instead." }
            when 'requirement'    { "that reads like a requirement or setting ({%a<signal>}), not enduring intent. Pin it with a test, or say what would let people down if it changed." }
            when 'task'           { "that reads like work to do. Track it in your issues; IZ4 records what must stay true." }
            default               { Str }
        }
        user-error("not added: $why\n(--force adds it anyway, if you have judged that it must remain true)") with $why;
        if ($because // '').trim && assess-because($text, $because) eq 'circular' {
            user-error("not added: PROTECTS restates ALWAYS. What must not be defeated: which person, and what of theirs?\n(--force adds it anyway)");
        }
    }
    my ($id, $ns) = choose-identity($path, $name, :$namespace, :$text);
    add-invariant($path, $text, :name($id), :$because, :$reach, :$established);
    my $short = $id.split('.')[0];
    answer('add', 'a promise',
        [pretty("  ✓ Added PROMISE $id, {$established ?? 'established' !! 'exploring'}."),
         |para($established ?? 'A change to its words waits for your yes, and a failing linked test holds the commit.'
                             !! 'Anyone may change its words while it settles, and a failing linked test warns.'),
         '  Your intention is recorded. A test that names it is what checks it.'],
        [next-line("iz4 test $short", 'a test that would fail if it stopped being true'),
         |("then:  iz4 establish $short   (when its words are agreed)" unless $established)]);
}

# ------------------------------------------------------------ protects

#| Say whose what a promise protects: its PROTECTS.
multi MAIN('protects', Str $which?, Str $text?, Str :$file, Bool :$replace = False) {
    attempt :intent, {
        my $path = resolve-target($file);
        cards-of($path);
        my $name = display-name($path);
        user-error("iz4 protects needs a promise's name and whose what it protects: iz4 protects owner-adjusted 'a customer\'s money'")
            unless $which.defined && $text.defined;
        my $id = which-invariant($path, $which);
        user-error("no invariant '$which' in $name; 'iz4 invariants --brief' lists the names")
            unless is-foundation-id($id) || check-doc($path).invariant($id).defined;
        if assess-because(check-doc($path).invariant($id).?text // '', $text) eq 'circular' && !$replace {
            user-error("that restates ALWAYS. What must not be defeated: which person, and what of theirs?\n(--replace sets it anyway)");
        }
        set-because($path, $id, $text, :$replace);
        answer('protects', $id, [pretty("  ✓ PROMISE $id now protects: $text")], [next-line('iz4 show invariant ' ~ $id.split('.')[0])]);
        0;
    }
}

#| The heading a project's own invariant has in this file: PROMISE on a
#| card.
sub heading-of(IZ4::Document $doc --> Str) { 'PROMISE' }

#| The identity a person means, or what they typed when nothing matches:
#| the command that uses it says what is wrong.
sub which-invariant(IO::Path $path, Str $ref --> Str) {
    resolve-identity(check-doc($path), $ref) // $ref.trim;
}

# ---------------------------------------------------------- withdraw

#| Take a project invariant out, on a person's say-so.  The name is
#| retired for good; Git keeps the words.  The foundation cannot be
#| withdrawn.  Scripts pass --force in place of the question.
multi MAIN('withdraw', Str $which, Str :$file, Bool :$force = False, Bool :$keep-tests = False) {
    attempt :intent, {
        my $path = resolve-target($file);
        my $name = display-name($path);
        my $id   = which-invariant($path, $which);
        my $h    = heading-of(check-doc($path));
        # what cannot happen is said first, before anything is shown
        my $known = is-foundation-id($id) || check-doc($path).invariant($id).defined;
        user-error("withdrawing an invariant needs a person: run this on a terminal (a script passes --force)")
            if $known && !is-foundation-id($id) && !$force && !interactive();
        withdraw-invariant($path, $id) if is-foundation-id($id);   # refuses, saying why, and writes nothing
        head('withdraw', $id);
        mark-held($path);
        print pretty(invariant-text($path, $id)) unless is-foundation-id($id);   # the refusal below says why for the foundation
        # What goes with it is worked out, and shown, before anyone is asked.
        my $present = !is-foundation-id($id) && check-doc($path).invariant($id).defined;
        my %tests = $present ?? withdrawal-tests($path, check-doc($path), $id) !! %( remove => [], shared => [], unsaved => [] );
        my @remove = $keep-tests ?? () !! @(%tests<remove>);
        my @kept   = $keep-tests ?? @(%tests<remove>) !! ();
        unless $force || !$present {
            user-error("withdrawing an invariant needs a person: run this on a terminal (a script passes --force)")
                unless interactive();
            say "Withdrawing retires the name $id for good (never reused) and takes the words out of $name; Git keeps them.";
            if @remove {
                say "Its tests go with it: a test for an invariant that is gone protects nothing. Git keeps these too:";
                say "  $_" for @remove;
            }
            my $answer = yes-no(ask("Withdraw $h $id" ~ (@remove ?? " and remove {+@remove == 1 ?? 'that test' !! "those {+@remove} tests"}" !! '') ~ "? [y/N] ") // '', :default(False));
            unless $answer { say "$h $id stays" ~ (@remove ?? ', and so do its tests.' !! '.'); return 0 }
        }
        my $inv = withdraw-invariant($path, $id);
        say '';
        say pretty("  ✓ Withdrew $h $id from $name: {$inv.text}");
        my @gone = remove-tests($path.parent, @remove);
        if @gone {
            say "  Removed {+@gone == 1 ?? 'the test' !! "the {+@gone} tests"} that existed only for it:";
            say "    $_" for @gone;
        }
        my @next;
        for @(%tests<shared>) -> ($f, @also) {
            say "  Left $f: it also names {@also.join(', ')}.";
            @next.push("take what was about $id out of $f; the rest of it still protects {@also.join(', ')}");
        }
        for @(%tests<unsaved>) -> $f {
            say "  Left $f: Git does not hold it as it is, so removing it would lose it for good.";
            @next.push("delete $f yourself if it was only for $id, or commit it first");
        }
        @next.push("delete or re-home $_: it was only for $id (kept because of --keep-tests)") for @kept;
        @next.push("git add -A && git commit -m 'Withdraw $id: ...'  (say why, so the history explains it)");
        say '';
        say-next(@next, :then('iz4 check'));
        0;
    }
}

# ------------------------------------------------------- establish

#| One of the project's own promises, by its full name, its short name
#| (without the domain) or the start of either where that is unambiguous.
sub pick-invariant(IZ4::Document $doc, Str $which) {
    my @own = $doc.invariants.grep(*.id.defined);
    my $tail = '.' ~ ($doc.domain // '');
    my sub short($id) { $doc.domain && $id.ends-with($tail) ?? $id.substr(0, * - $tail.chars) !! $id }
    my @exact = @own.grep({ .id eq $which || short(.id) eq $which });
    return @exact[0] if @exact == 1;
    my @pre = @own.grep({ .id.starts-with($which) || short(.id).starts-with($which) });
    return @pre[0] if @pre == 1;
    user-error(@pre > 1 ?? "'$which' could be any of {@pre.map({ short(.id) }).join(', ')}: say more of the name" !! "no promise of this project is named '$which'");
}

#| What each promise requires of a change, and with it what is checked.
#| 'iz4 establish NAME' when its words are agreed: from then on a change
#| waits for a signed yes and a failing linked test holds the commit.
#| 'iz4 explore NAME' lets its words move again while it settles; lowering
#| is itself a change the gate asks about at commit time.  With no name,
#| each says where every invariant stands.
sub governance-command(Str $stage, Str $which, Str $file) {
    my $path = resolve-target($file);
    my $doc  = check-doc($path);
    my $name = display-name($path);
    user-error("$name: {$doc.errors[0].message}") if $doc.form eq 'earlier';
    my @own = $doc.invariants.grep(*.id.defined);
    without $which {
        my @x = @own.grep(*.exploring); my @e = @own.grep({ !.exploring });
        calm(:command($stage eq 'established' ?? 'establish' !! 'explore'), "$name, " ~ (!@own ?? 'no promises of its own yet' !! @own == 1 ?? (@e ?? 'its one promise established' !! 'its one promise exploring') !! @e == @own ?? "all {+@own} established" !! @x == @own ?? "all {+@own} exploring" !! "{+@e} established, {+@x} exploring"),
             |(@x ?? ("Exploring, so a change to its words waits for nobody and a failing linked test warns: {@x.map(*.id).join(', ')}.",) !! ()),
             |(@e ?? ("Established, so a change waits for your signed yes and a failing linked test holds the commit: {@e.map(*.id).join(', ')}.",) !! ()),
             :next([|(@x ?? ('establish NAME' => 'when a promise is agreed',) !! ()), |(@e ?? ('explore NAME' => 'to let one move again while it settles',) !! ())]));
        return 0;
    }
    my $inv = pick-invariant($doc, $which);
    my $now = set-governance($path, $inv.id, $stage);
    my $cmd = $stage eq 'established' ?? 'establish' !! 'explore';
    if $now eq 'unchanged' { calm("{$inv.id} is already $stage", :command($cmd), :next(['status' => 'where everything stands'])); return 0 }
    if $stage eq 'established' {
        calm("{$inv.id} is established", :command<establish>,
             'From now on a change to its words waits for your signed yes, and a failing linked test holds the commit.',
             'Its card says so: CHANGES REQUIRE signed human approval for the exact change; CHECKED WITH linked tests; failures block commit.',
             :next(['test' => 'writes the test that is missing, if any', 'status' => 'where everything stands']));
    }
    else {
        calm("{$inv.id} is exploring", :command<explore>,
             'Its words may change without approval while it settles, and a failing linked test warns rather than holds. The promise as written still applies.',
             'Asking less of an invariant is itself a change: commit it, and the gate asks you once.',
             :next(['establish ' ~ $which => 'when its words are agreed']));
    }
    0;
}

multi MAIN('establish', Str $which?, Str :$file) { attempt :intent, { governance-command('established', $which, $file) } }
multi MAIN('explore',   Str $which?, Str :$file) { attempt :intent, { governance-command('exploring',   $which, $file) } }

# ------------------------------------------------------------ words for actions
#
# An action is a word.  Each of these is the same command as the flag
# beside it, which still works: hooks and scripts written before call it.

multi MAIN('foundation', 'restore', Str $file?) { MAIN('foundation', |($file // Empty), :restore) }
multi MAIN('test', 'list', Str :$file) { MAIN('test', :list, |(:$file if $file.defined)) }
multi MAIN('update', 'check') { MAIN('update', :check) }
multi MAIN('report', 'preview', Str :$file, Str :$release, Str :$run-id, Bool :$json = False) {
    MAIN('report', :dry-run, :$json, |(:$file if $file.defined), |(:$release if $release.defined), |(:$run-id if $run-id.defined));
}
multi MAIN('gate', 'install', Bool :$enforce = False, Bool :$force = False, Str :$file) {
    MAIN('gate', :install-hook, :$enforce, :$force, |(:$file if $file.defined));
}
multi MAIN('review', 'install', Bool :$force = False, Str :$file) {
    MAIN('review', :install-hook, :$force, |(:$file if $file.defined));
}
#| 'iz4 agent install claude skill hooks': what to install, as words.
multi MAIN('agent', 'install', *@what where { .elems > 0 }, Bool :$strict = False, Str :$file) {
    my @known = <claude skill hooks>;
    my @bad = @what.grep({ $_ ne any(@known) });
    if @bad { note "iz4 agent install takes {@known.join(', ')}; not '{@bad[0]}'."; note help-topic(topic('agent install')).trim-trailing; exit 1 }
    MAIN('agent', 'install', :claude(so @what.grep('claude')), :skill(so @what.grep('skill')),
         |(:hooks if @what.grep('hooks')), :$strict, |(:$file if $file.defined));
}

# ------------------------------------------------------------ read

#| The foundation as every file carries it; 'restore' writes it into
#| the file when it is missing or altered.
multi MAIN('foundation', Str $file?, Bool :$restore = False) {
    attempt {
        unless $restore {
            head('foundation', 'the words every IZ4 carries') if pretty-on();
            mark-solid(%( |FOUNDATION-CARD.map({ .<id> => 'held' }) ));   # the foundation is always held: a closed diamond, never the title's mark
            say 'The foundation:';
            for (FOUNDATION-CARD) -> %f {
                say sprintf('  %d  %-26s%s', %f<legacy>, %f<id>, %f<id> eq INVARIANT-ZERO ?? 'Invariant Zero: the foundation of the foundation' !! '').trim-trailing;
            }
            say '';
            print pretty(foundation-block());
            say '';
            say "(sha256 of the foundation text: {FOUNDATION-CARD-DIGEST.substr(0, 12)}; every IZ4 carries it word for word, and no project can change it)";
            return 0;
        }
        my $path = resolve-target($file);
        my $what = do given restore-foundation($path) {
            when 'unchanged' { "  · {display-name($path)}: the foundation is already there, word for word" }
            when 'written'   { "  ✓ {display-name($path)}: wrote the foundation after IS FOR WHO?" }
            when 'replaced'  { "  ✓ {display-name($path)}: replaced the foundation with its current words" }
            when 'tidied'    { "  ✓ {display-name($path)}: the foundation was right; the comments around it are brought up to date" }
        };
        my $doc = check-doc($path);
        answer('foundation restore', display-name($path), [pretty($what), "    now: {$doc.foundation-status}"],
               [$doc.foundation-intact ?? pretty('The foundation holds, word for word.') !! next-line('iz4 check')]);
        $doc.foundation-intact ?? 0 !! 1;
    }
}

#| Tell the renderer which invariants are held, so the diamond before each
#| name is closed (a test names it, or it is the foundation) or open.
#| Where the last run of the protecting tests is kept: beside the
#| repository's own data, outside every tree, so a candidate cannot write it.
sub checks-record(IO::Path $root --> IO::Path) {
    my ($rc, $out, $) = git($root.add(ROOT-NAME), 'rev-parse', '--git-dir');
    return IO::Path if $rc != 0;
    my $dir = $out.trim.IO; $dir = $root.add($dir) unless $dir.is-absolute;
    $dir.add('iz4').add('checks.json');
}

#| What the working tree is, as one id: HEAD's tree, plus every path Git
#| sees as changed or untracked with the content it has now.  Two trees
#| with the same id have the same files, so a test run on one speaks for
#| the other.
sub tree-id(IO::Path $root --> Str) {
    my ($rc, $head, $) = git($root.add(ROOT-NAME), 'rev-parse', 'HEAD^{tree}');
    return '' if $rc != 0 && git($root.add(ROOT-NAME), 'rev-parse', '--git-dir')[0] != 0;
    my ($, $st, $) = git($root.add(ROOT-NAME), 'status', '--porcelain', '--untracked-files=all');
    my @parts = ($rc == 0 ?? $head.trim !! 'no-head');
    # every changed or untracked path with its content id, in one git call
    my @paths = $st.lines.map({ .substr(3).subst(/^ .* ' -> ' /, '') }).grep({ $root.add($_).f }).sort;
    if @paths {
        my $h = run 'git', '-C', $root.Str, 'hash-object', '--stdin-paths', :in, :out, :err;
        $h.in.print(@paths.join("\n") ~ "\n"); $h.in.close;
        my @ids = $h.out.slurp(:close).lines; $h.err.slurp(:close);
        @parts.push: "{@paths[$_]}={@ids[$_] // ''}" for ^@paths;
    }
    @parts.push: "$_=gone" for $st.lines.map({ .substr(3).subst(/^ .* ' -> ' /, '') }).grep({ !$root.add($_).f }).sort;
    my $p = run 'git', '-C', $root.Str, 'hash-object', '--stdin', :in, :out, :err;
    $p.in.print(@parts.join("\n")); $p.in.close;
    my $id = $p.out.slurp(:close).trim; $p.err.slurp(:close);
    $id || @parts.join("\n");
}

#| Remember what 'iz4 status' just ran: the outcome of each test that names
#| an invariant, and the id of the tree it ran against.
sub record-checks(IO::Path $root, @checks, Str :$tree = tree-id($root), :%enforcement, Str :$launcher, Str :$cmd = '') {
    my $f = checks-record($root) // return;
    $f.parent.mkdir;
    $f.spurt(json-encode(%( schema => 'iz4-checks/2', at => DateTime.now.utc.Str, tree => $tree, checks => @checks.List,
                             enforcement => %enforcement, launcher => ($launcher // ''), cmd => $cmd )));
}

#| The content id Git would give a file as it is now; '' when it is gone.
sub blob-of(IO::Path $f --> Str) {
    return '' unless $f.f;
    my ($rc, $out, $) = git($f, 'hash-object', '--', $f.Str);
    $rc == 0 ?? $out.trim !! '';
}

#| The last run, if it still speaks for this tree: the tree is the same,
#| file for file.  Returns the record (checks and when), else nothing.
sub last-run(IO::Path $root, Str :$tree = tree-id($root) --> Hash) {
    my $f = checks-record($root);
    return %() unless $f.defined && $f.f;
    my %rec = (try Rakudo::Internals::JSON.from-json($f.slurp)) // return %();
    return %() unless (%rec<tree> // '') eq $tree && $tree ne '';
    %rec;
}
sub recorded-checks(IO::Path $root --> List) { (last-run($root)<checks> // ()).list }

#| How long ago, in a person's words.
sub ago(Str $iso --> Str) {
    my $then = try DateTime.new($iso); return 'earlier' without $then;
    my $s = (DateTime.now - $then).Int;
    my sub n(Int $k, Str $unit) { "$k {$unit}{$k == 1 ?? '' !! 's'} ago" }
    $s < 60 ?? n($s, 'second') !! $s < 3600 ?? n(($s / 60).Int, 'minute') !! $s < 86400 ?? n(($s / 3600).Int, 'hour') !! n(($s / 86400).Int, 'day');
}

#| The map behind the marks: the foundation is held word for word; each of
#| the project's own is held or broken by the last run of a test that names
#| it, unknown when that run could not assess it, and otherwise a promise
#| nothing yet shows.  Names are mapped short and long, as the file writes
#| them.  Returns the map; the checks come from the caller or the record.
sub mark-states(IZ4::Document $doc, IO::Path $root, :@checks = recorded-checks($root) --> Hash) {
    my %state = |foundation-ids().map(* => 'held');
    my %by-id;
    for @checks -> %c { %by-id{$_}.push(%c<outcome>) for |(%c<invariants> // ()) }
    my $tail = '.' ~ ($doc.domain // '');
    for $doc.invariants.grep(*.id.defined) -> $inv {
        my @o = |(%by-id{$inv.id} // ());
        my $s = !@o ?? 'promised' !! @o.grep(* eq 'failed') ?? 'broken' !! @o.all eq 'passed' ?? 'held' !! 'unknown';
        %state{$inv.id} = $s;
        %state{$inv.id.substr(0, * - $tail.chars)} = $s if $doc.domain && $inv.id.ends-with($tail);
    }
    %state;
}

sub mark-held(IO::Path $path) {
    my $doc = check-doc($path);
    return unless $doc.ok;
    mark-solid(mark-states($doc, $path.parent));
}

# ------------------------------------------------------------ status

#| One screen: where things stand.  The foundation, each invariant with its
#| mark, what is staged and whether it changes a commitment, how agents are
#| wired, and the one command that comes next.  It runs the tests that
#| name invariants (the one slow part; --no-checks reads the last run) and
#| says what it checked, which is file facts and test results, never that
#| the software is safe.
multi MAIN('status', Bool :$json = False, Bool :$checks is copy = True, Bool :$no-checks = False, Bool :$recheck = False, Int :$timeout = 300,
           Str :$check-cmd = %*ENV<IZ4_CHECK_CMD> // Str, Str :$file, Bool :brief($brief-flag) = False) {
    attempt {
        my $brief = brief-wanted($brief-flag) && !$json;
        two-machine-forms() if $json && $brief-flag;
        $checks = False if $no-checks;   # --no-checks reads as a person writes it; --/checks is Raku's spelling
        my IO::Path $path = (try resolve-target($file)) // IO::Path;
        without $path {
            if $brief { note "iz4 status: no IZ4 here; 'iz4 init' starts one"; return 0 }
            if $json { say json-encode(%( schema => 'iz4-status/1', iz4 => %( present => False ), next => ('iz4 init',).List )) }
            else { calm('No IZ4 here', 'Nothing in this directory or its parents says what the software is for.', :next(['init' => 'start one'])) }
            return 0;
        }
        my $root = $path.parent;
        my $doc  = check-doc($path);
        my $name = display-name($path);
        my $t0   = now;
        my @own = $doc.ok ?? $doc.invariants.grep(*.id.defined) !! ();
        my $standing = !@own ?? 'no promises of its own yet' !! @own.grep(*.exploring) == @own ?? 'exploring' !! !@own.grep(*.exploring) ?? 'established' !! "{+@own.grep({ !.exploring })} of {+@own} established";
        # the title first, so the screen begins with it; the tests report under it while they run and clear the line when done
        my $sc = Screen.new(:command<status>, :context("$name, $standing"));
        unless $json || $brief {
            say $sc.title-line;
            say '';
        }
        # agents: the level a driver reports, asked for now and read later, so it overlaps the tests
        my $driver = driver-binary();
        my $bin    = launcher-binary();
        my $launcher-version = $bin.defined ?? launcher-version($bin) !! Str;
        # the checks: the last run while the tree is unchanged, else run now; --no-checks never runs.
        # The driver's answer about the wiring rides with the run: same tree, same 321, same answer.
        my @checks; my $ran = False; my $recorded = False; my $when = '';
        my $tree = $doc.ok ?? tree-id($root) !! '';
        my $cmd = $check-cmd // do { my ($rc, $out, $) = git($path, 'config', '--get', 'iz4.checkCmd'); $rc == 0 && $out.trim ne '' ?? $out.trim !! Str };
        my %last = $doc.ok ?? last-run($root, :$tree) !! %();
        %last = %() if %last && (%last<cmd> // '') ne ($cmd // '');
        my %enf;
        my $cached-enf = %last && !$recheck && (%last<launcher> // '') eq ($launcher-version // '') && (%last<enforcement>:exists);
        my $enf-p = $cached-enf ?? Promise.kept(%last<enforcement> // %())
                 !! $driver.defined ?? start { (try driver($driver, 'status', :$root)) // %() } !! Promise.kept(%());
        if %last && !$recheck { @checks = %last<checks>.list; $recorded = True; $when = ago(%last<at> // '') }
        elsif $checks && $doc.ok {
            # status is interactive and advisory: the tests run eight at a time unless IZ4_JOBS or the
            # repository's 'git config iz4.jobs' says otherwise, and a failure is run again alone before
            # it is called broken; the gate, which holds commits, keeps the runtime's safe default of one
            @checks = run-checks($doc, $root, :$timeout, :$cmd, :jobs(check-jobs(:$root, :default(8))), # a hook at a terminal shows the one wiped line while tests run; a pipe gets nothing
                          :progress($json || ($brief && !$*OUT.t) ?? Callable !! check-progress()));
            $ran = True;
        }
        my $secs = (now - $t0).round(0.1);
        my %state = $doc.ok ?? mark-states($doc, $root, :@checks) !! %();
        mark-solid(%state);
        my %ev = $doc.ok ?? evidence-for($doc, $root) !! %();
        my %by-id; for @checks -> %c { %by-id{$_}.push(%c) for |(%c<invariants> // ()) }
        my %count; %count{%state{.id}}++ for @own;
        my @inv = @own.map(-> $inv {
            my @c = |(%by-id{$inv.id} // ());
            my $note = do if @c { @c.map({ "{.<file>} " ~ (.<outcome> eq 'passed' ?? ((.<alongside> // '') eq 'failed' ?? 'passed alone, failed beside the others' !! 'passed') !! .<outcome> eq 'failed' ?? 'FAILED' !! "not run ({.<outcome>})") }).join(', ') }
                          elsif (%ev<state>{$inv.id} // 'none') eq 'named' { ($checks ?? 'named by ' !! 'not checked; named by ') ~ (%ev<files>{$inv.id} // ()).join(', ') }
                          elsif (%ev<state>{$inv.id} // 'none') ne 'none' { "a {%ev<state>{$inv.id}} test, not yet real" }
                          else { 'no test yet' };
            %( id => $inv.id, mark => %state{$inv.id}, evidence => $note ~ ($inv.card ?? ($inv.exploring ?? '; exploring' !! '') !! ($inv.protection ?? "; {$inv.protection}" !! '')), protection => $doc.protection-of($inv.id), stage => ($inv.card ?? stage-of($inv.change // CHANGE-SIGNED) !! $doc.protection-of($inv.id)), checks => @c.List );
        });
        # this change: what is staged, and whether it touches a commitment
        my %change;
        if git($path, 'rev-parse', '--git-dir')[0] == 0 {
            my ($rc, $out, $) = git($path, 'diff', '--cached', '--name-only');
            my @staged = $out.lines;
            %change<staged> = @staged.elems;
            if @staged {
                my %g = try run-gate($root, :staged, :!checks);
                if %g { %change<outcome> = %g<outcome>; %change<changes> = %g<changes>.elems; %change<protections> = %g<protections>.elems;
                       %change<touches> = %g<touches>.List; %change<approval> = %g<approval><status> }
            }
        }
        # agents: the level a driver reports, else what an earlier iz4 wired
        %enf = await $enf-p;
        record-checks($root, @checks, :$tree, :enforcement(%enf), :launcher($launcher-version), :cmd($cmd // '')) if $ran;
        my @legacy = legacy-hooks(:$root);
        my $level = %enf ?? driver-level(%enf) !! @legacy ?? 'aware' !! 'none';
        my %agents = level => $level, launcher => $launcher-version;
        # the one next step, in the order that clears the most
        my @next;
        @next.push('iz4 check') unless $doc.ok;
        # a failing test is never a reason to send anyone to approve: the promise stands as written until a person changes it
        @next.push("make {.<file>} pass   ({.<invariants>.join(', ')} is broken; the promise stands as written)") for @checks.grep({ .<outcome> eq 'failed' }).head(1);
        my @collided = @checks.grep({ (.<alongside> // '') eq 'failed' });
        @next.push("git config iz4.jobs 1   ({+@collided} test{+@collided == 1 ?? '' !! 's'} failed beside the others and passed alone: run them one at a time)") if @collided;
        @next.push('iz4 approve --staged') if (%change<outcome> // '') eq 'agreement-required';
        @next.push('iz4 status') if !$checks && !$recorded && @own;
        @next.push('iz4 test') if @own.grep({ (%ev<state>{.id} // 'none') eq 'none' });
        @next.push('321 iz4 install') if $driver.defined && $level ne 'guarded' && %enf && so @(%enf<harnesses> // []).grep({ .<detected> });
        my @unseen = unseen-of($path.parent)<items>.keys.sort;
        @next.push('iz4 seen') if @unseen;
        my $held-pct = @own ?? (100 * (%count<held> // 0) / @own).round !! 0;
        my $hook = commit-hook-state($path.parent);
        my %s = schema => 'iz4-status/1', iz4 => %( present => True, file => $path.Str, valid => $doc.ok, form => $doc.form, mode => $doc.mode, standing => $standing ),
                foundation => %( intact => $doc.foundation-intact, status => $doc.foundation-status ),
                invariants => @inv.List, counts => %count, held_percent => $held-pct, change => %change, agents => %agents,
                checks => %( ran => $ran, recorded => $recorded, at => (%last<at> // Str), count => @checks.elems, seconds => $secs ),
                unseen => @unseen.List, next => @next.List, commits => %( hook => $hook );
        # one result, three forms: the document, the records (pinned by t/29), the screen under the title already shown
        $sc.doc = %s;
        $sc.record('foundation', $doc.foundation-intact ?? 'held' !! 'changed');
        $sc.record('invariant', .<id>, .<mark> // 'unknown', .<evidence>) for @inv;
        $sc.record('unseen', $_) for @unseen;
        $sc.record('next', @next[0]) if @next;
        $sc.rows(['foundation' => $doc.foundation-intact ?? 'held, word for word' !! "CHANGED: {$doc.foundation-status}; iz4 foundation restore puts it back"]);
        if !$doc.ok { $sc.rows(['file' => "{+$doc.errors} errors; iz4 check lists them"]) }
        elsif !@own { $sc.rows(['invariants' => 'none of your own yet']) }
        else {
            my $w = @own.map({ .id.subst('.' ~ ($doc.domain // ''), '') }).map(*.chars).max;
            $sc.lines(pretty(sprintf('%-13s %s', 'invariants', "{+@own} of your own: $held-pct% held ({%count<held> // 0})" ~ <promised broken unknown>.grep({ %count{$_} }).map({ ", {%count{$_}} $_" }).join)),
                      |@inv.map({ sprintf('  %s %-*s  %s', mark-shown(.<id>), $w, .<id>.subst('.' ~ ($doc.domain // ''), ''), .<evidence>) }));
            # the key to the marks, right under the rows that use them
            $sc.lines(pretty('  ' ~ marks-legend())) if pretty-on();
        }
        $sc.rows(['unseen' => "{+@unseen} exploring change{@unseen == 1 ?? '' !! 's'} no person has seen yet"]) if @unseen;
        # the standing of the work, as a table: what, where it stands, and the detail
        my @rows;
        if %change {
            @rows.push: ['this change', !%change<staged> ?? 'nothing staged' !! "{%change<staged>} file{%change<staged> == 1 ?? '' !! 's'} staged",
                        !%change<staged> || !%change<outcome> ?? ''
                        !! %change<changes> || %change<protections>
                            ?? "{%change<changes>} change{%change<changes> == 1 ?? '' !! 's'} to what it promises, {%change<protections>} to a protection: {%change<outcome>}"
                            !! 'no commitment changed' ~ do given +%change<touches> {
                                   # by name when a few, else how many: iz4 review --offline --staged lists them
                                   when 0      { '' }
                                   when 1..3   { "; touches {%change<touches>.map(*.<id>.subst('.' ~ ($doc.domain // ''), '')).join(', ')}" }
                                   default     { "; touches $_ by their words" }
                               }];
        }
        # what is actually enforced at a commit, as a fact about the hook Git would run
        given $hook {
            when 'enforce'  { @rows.push: ['commits', 'checked', 'the commit hook asks you before a promise changes'] }
            when 'advisory' { @rows.push: ['commits', 'reported, not held', 'iz4 gate install --enforce makes the hook wait for you'] }
            when 'none'     { @rows.push: ['commits', 'not checked', 'no commit hook runs the gate here: iz4 gate install --enforce'] }
        }
        @rows.push: ['agents', $level eq 'none' ?? 'nothing wired' !! "$level" ~ (%agents<launcher> ?? ", via 321 {%agents<launcher>}" !! ', hooks an earlier iz4 wrote'),
                     $level eq 'none' ?? ($bin.defined ?? "321 {%agents<launcher>} is installed: 321 iz4 install" !! '321 is not installed') !! 'iz4 agent status has the detail'];
        my $tests = "{+@checks} test{+@checks == 1 ?? '' !! 's'}";
        @rows.push: ['checked', $ran ?? "$tests just now, {$secs}s" !! $recorded ?? "$tests, $when" !! 'nothing ran',
                     $ran ?? '' !! $recorded ?? 'nothing has changed since; --recheck runs them again' !! '--no-checks'];
        $sc.table(@rows);
        $sc.note('file facts and test results, never that the software is safe');
        $sc.next(@next);
        # when every one of them held, say so plainly, last
        if @own && (%count<held> // 0) == @own && $doc.foundation-intact && (%change<outcome> // 'pass') eq 'pass' {
            $sc.note("All held: {+@own} of {+@own} invariants by their tests" ~ ($ran ?? ' just now' !! ' at the last run') ~ ', and the foundation word for word.');
        }
        print $sc.render(form-of(:$json, :$brief), :!title);
        0;
    }
}

multi MAIN('invariants', Str $file?, Bool :brief($brief-flag) = False) {
    attempt {
        my $path = resolve-target($file);
        if brief-wanted($brief-flag) {
            # the names, the foundation first: foundation NAME / promise NAME established|exploring
            my $doc = check-doc($path);
            my $sc = Screen.new(:command<invariants>);
            $sc.record('foundation', .<id>) for FOUNDATION-CARD;
            $sc.record('promise', .id, .exploring ?? 'exploring' !! 'established') for $doc.invariants.grep(*.id.defined);
            print $sc.brief;
            return 0;
        }
        mark-held($path);
        head('invariants', display-name($path)) if pretty-on();
        print pretty(effective-text(check-doc($path), :name(display-name($path))));
        0;
    }
}

multi MAIN('show', 'invariant', Str $which, Str :$file, Bool :brief($brief-flag) = False) {
    attempt {
        if brief-wanted($brief-flag) {
            # one record: NAME, WHEN, ALWAYS, PROTECTS
            my $path = resolve-target($file);
            my $doc  = check-doc($path);
            my $id   = resolve-identity($doc, $which) // user-error("no invariant '$which' in {$path.basename}; 'iz4 invariants --brief' lists the names");
            my $sc = Screen.new(:command<show>);
            with FOUNDATION-CARD.first({ .<id> eq $id }) { $sc.record($id, .<when>, .<always>.join('; '), .<protects>.join('; ')) }
            orwith $doc.invariant($id) { $sc.record($id, .reach, .text, .because) }
            else { user-error("'$id' was withdrawn; its name is retired") }
            print $sc.brief;
            return 0;
        }
        mark-held(resolve-target($file));
        my $text = invariant-text(resolve-target($file), $which);
        head('show', $which) if pretty-on();
        print pretty($text);
        0;
    }
}

multi MAIN('show', Str $a?, Str $b?, Bool :brief($brief-flag) = False) {
    attempt {
        my ($file, $part) = $a.defined && looks-like-file($a) ?? ($a, $b) !! (Str, $a);
        user-error("too many arguments") if $b.defined && !$file.defined;
        # the pipeline form is the text itself, never dressed
        return print(show-text(resolve-target($file), $part)) && 0 if brief-wanted($brief-flag);
        mark-held(resolve-target($file));
        head('show', $part // display-name(resolve-target($file))) if pretty-on();
        print pretty(show-text(resolve-target($file), $part));
        0;
    }
}

# ------------------------------------------------------------ check

multi MAIN('check', Str $file?, Bool :$strict = False, Bool :brief($brief-flag) = False) {
    attempt {
        my $brief = brief-wanted($brief-flag);
        my $path = resolve-target($file);
        my $name = display-name($path);
        my $doc  = check-doc($path);
        my $sc   = Screen.new(:command<check>, :context($name));
        $sc.lines(|$doc.report(:$name));

        # A checklist of file facts: a tick for what is true, a cross with
        # its remedy for what is not, and for every cross the next step
        # that clears it, listed in order at the end.  Whether the software
        # keeps its invariants is never a tick: a checker cannot know, so it
        # says so.
        my @rows;                      # (glyph, line, next step or '')
        my @next = $doc.fixes;         # the structural fixes come first, in line order
        my $errors = +$doc.errors;
        my $warns  = +$doc.warnings;
        @rows.push: ($errors == 0 ?? '✓' !! '✗',
            $errors == 0
                ?? "structure: valid" ~ ($warns ?? " ($warns warning{$warns == 1 ?? '' !! 's'} above)" !! '')
                !! "structure: $errors error{$errors == 1 ?? '' !! 's'} above - fix each line listed", '');
        @rows.push: $doc.for-what.defined && $doc.for-what ne ''
            ?? ('✓', "IS FOR WHAT: {short($doc.for-what)}", '')
            !! ('✗', "IS FOR WHAT: missing - what is this for? ('iz4 add for-what ...')", 'iz4 add for-what "what it is for"');
        @rows.push: $doc.for-who.defined && $doc.for-who ne ''
            ?? ('✓', "IS FOR WHO: {short($doc.for-who)}", '')
            !! ('✗', "IS FOR WHO: missing - who is this for? ('iz4 add for-who ...')", 'iz4 add for-who "who it is for"');
        @rows.push: ($doc.foundation-intact ?? '✓' !! '✗', $doc.foundation-status, $doc.foundation-intact ?? '' !! 'iz4 foundation restore');

        my sub lbl($id) { $id }
        my sub lbls(@ids) { @ids.join(', ') }

        my $count = $doc.invariants.elems;
        my $unnamed = +$doc.unnamed-invariants;
        if $unnamed {
            @rows.push: ('✗', "invariants: $unnamed of $count unnamed - every invariant has a name", '');
        }
        elsif $count {
            my $ns = $doc.namespace;
            @rows.push: ('✓', "invariants: $count of your own, named" ~ ($ns ?? " under $ns" !! ''), '');
        }
        else {
            @rows.push: ('✓', "invariants: none of your own yet, which is a fine start ('iz4 add' helps you find one)", '');
        }
        if $count && $doc.vibe {
            # still settling: say where things stand in a line, and ask for nothing
            my %ev    = evidence-for($doc, $path.parent);
            my $named = $doc.invariants.grep({ .id.defined && (%ev<state>{.id} // '') eq 'named' }).elems;
            @rows.push: ('✓', "exploring: $count settling, $named with a test. Nothing waits on you; 'iz4 establish NAME' when a promise is agreed.", '');
        }
        elsif $count {
            # evidence: a test that names the invariant.  Named is a test;
            # scaffolded is the born-red placeholder; none is none.
            my %ev = evidence-for($doc, $path.parent);
            my sub in-order(@ids) { @ids.sort({ $_ ~~ /^ \d+ $/ ?? (0, +$_, '') !! (1, 0, $_) }) }
            my @none = in-order(%ev<state>.pairs.grep(*.value eq 'none').map(*.key));
            my @scaf = in-order(%ev<state>.pairs.grep(*.value eq 'scaffolded').map(*.key));
            my $named = %ev<state>.values.grep(* eq 'named').elems;
            my @draft = in-order(%ev<state>.pairs.grep(*.value eq 'drafted').map(*.key));
            @rows.push: ('✗', "evidence: {lbls(@scaf)} ha{@scaf == 1 ?? 's' !! 've'} only a scaffold - write the assertion in {%ev<files>{@scaf[0]}[0]}" ~ (@scaf > 1 ?? ' and the others' !! ''),
                @scaf.map({ "write the assertion for {lbl($_)} in {%ev<files>{$_}[0]}" }).join("\n"))
                if @scaf;
            @rows.push: ('✗', "evidence: {lbls(@draft)} ha{@draft == 1 ?? 's' !! 've'} an agent-drafted test awaiting review - read {%ev<files>{@draft[0]}[0]}" ~ (@draft > 1 ?? ' and the others' !! '') ~ ", run it, make sure it can fail, then delete its first line",
                @draft.map({ "review {%ev<files>{$_}[0]} ({lbl($_)}): run it, make sure it can fail, then delete its first line" }).join("\n"))
                if @draft;
            @rows.push: ('✗', "evidence: {lbls(@none)} ha{@none == 1 ?? 's' !! 've'} no test naming {@none == 1 ?? 'it' !! 'them'}" ~ (" - 'iz4 test' scaffolds one"),
                "iz4 test {@none.join(' ')}")
                if @none;
            @rows.push: ('✓', "evidence: every invariant is named by a test ($named of $count)", '') unless @none || @scaf || @draft;
        }

        if $path.basename eq (ROOT-NAME) {
            my $root = $path.parent;
            my %s    = agent-status($path, :$root);
            for expected-integrations(:$root) -> $i {
                my $status = %s<integrations>{$i};
                @rows.push: ($status eq 'current' ?? '✓' !! '✗',
                    integration-line($i, $status, :reason($status eq 'stale' ?? stale-reason($root.add($i)) !! '')),
                    $status eq 'current' ?? '' !! integration-next($i, $status));
            }
        }

        @rows.push: ('?', "the system keeps its invariants (the foundation" ~ ($count ?? " and its own $count" !! '') ~ "): uncertain - a checker cannot verify "
            ~ "natural-language invariants; review consequential changes against 'iz4 invariants'", '');

        $sc.lines(|@rows.map({ pretty(mark(.[0]) ~ ' ' ~ .[1]) }));   # at the margin: t/invariant-9 reads each tick as a line
        $sc.note('checked: file facts only; a passing check never means the system is safe, '
          ~ 'harmless, or keeps its invariants');
        my $crosses = @rows.grep({ .[0] eq '✗' }).elems;

        # The next steps, each once, in the order that clears the most first:
        # structure, then each cross in checklist order, then a check again.
        for @rows.grep({ .[0] eq '✗' && .[2] ne '' }).map({ .[2].lines }).flat -> $step {
            @next.push($step) unless @next.first(* eq $step).defined;
        }
        $sc.steps(@next, :then($strict ?? 'iz4 check --strict' !! 'iz4 check'));
        # the records: pass|fail|uncertain, what, the detail; then each next step
        for @rows -> ($g, $line, $) {
            my ($what, $detail) = $line.split(': ', 2);
            $sc.record($g eq '✓' ?? 'pass' !! $g eq '✗' ?? 'fail' !! 'uncertain', $what, $detail // '');
        }
        $sc.record('next', $_) for @next;
        my $form = form-of(:brief($brief));
        if $doc.ok && !($strict && $crosses) {
            $sc.note("OK $name" ~ ($crosses ?? " ($crosses to remedy above)" !! ''));
            print $sc.render($form);
            0;
        }
        elsif $doc.ok {
            # --strict, for a gate: a cross is a failure, and the verdict says so last
            $sc.note("NOT YET $name: $crosses to remedy above (--strict) - do the next steps above, then 'iz4 check --strict' again");
            print $sc.render($form);
            1;
        }
        else {
            $sc.lines("NOT YET $name: $errors error{$errors == 1 ?? '' !! 's'} - do the next steps above, then 'iz4 check' again");
            print $sc.render($form);
            1;
        }
    }
}

#| The numbered next steps that clear what a command found, and the one
#| that confirms it.  A step is a command to run or, where iz4 must not
#| touch a person's words, what to change by hand.
sub say-next(@steps, Str :$then) {
    say pretty('next:');
    my $n = 0;
    say "  {++$n}. $_" for @steps;
    say "  then: $then again" with $then;
}

sub short(Str $s --> Str) { $s.chars > 60 ?? $s.substr(0, 57).trim-trailing ~ '...' !! $s }

#| What a person sees while the protecting tests run, so a slow test is
#| movement and not silence: one line as the run begins, the file under
#| test while it runs (overwritten by its result where tests run one at
#| a time), and each result as it lands with its time.  Only on a
#| terminal (or with IZ4_PROGRESS=1); into a pipe, nothing: what a tool
#| reads is byte for byte what it always was.  Callable when there is
#| nobody to tell.
#| What a person waiting on the protecting tests sees.  On a terminal,
#| one line, rewritten as the run moves and wiped when it ends, so the
#| screen that follows starts clean and nothing reads like a log.
#| IZ4_PROGRESS=1 asks instead for one line per test, left where it is,
#| for a pipe that wants the record.  Into a pipe with nothing asked,
#| nothing: what a tool reads is unchanged.
#| A live line cut to the terminal's width, so rewriting it in place
#| clears all of it: a line that wraps leaves its first row behind.
#| What is kept (a timer) stays whole; the rest gives way.
sub fit-line(Str $s, Str :$keep = '' --> Str) {
    state $cols = do {
        my $p = try run 'sh', '-c', 'stty size </dev/tty 2>/dev/null', :out, :err;
        my $w = ($p.defined ?? ($p.out.slurp(:close).words[1] // '') !! '');
        my $env = %*ENV<COLUMNS> // '';
        $w ~~ /^ \d+ $/ && $w >= 20 ?? +$w !! $env ~~ /^ \d+ $/ && $env >= 20 ?? +$env !! 80;
    };
    my $room = $cols - 1 - $keep.chars;
    ($s.chars <= $room ?? $s !! $s.substr(0, $room - 1) ~ '…') ~ $keep;
}

sub check-progress(--> Callable) {
    my $lines = (%*ENV<IZ4_PROGRESS> // '') eq '1';
    return Callable unless $lines || $*OUT.t;
    my ($total, $done, $t0) = 0, 0, now;
    my $full = diamond() eq '◈';
    my sub live(Str $s) { print "\r\e[2K" ~ $s; $*OUT.flush }
    my sub tests(Int $n) { "$n protecting test" ~ ($n == 1 ?? '' !! 's') }
    # a bar for work of known size: how much is done, of how much, and for how long
    my sub bar(Str $tail = '') {
        my $w = 20;
        my $f = $total ?? ($w * $done / $total).floor min $w !! 0;
        my $s = (now - $t0).Int;
        live(pretty(fit-line("  {($full ?? '█' !! '#') x $f}{($full ?? '░' !! '-') x ($w - $f)}  $done/{tests($total)}  {sprintf('%d:%02d', $s div 60, $s mod 60)}" ~ ($tail ?? "  $tail" !! ''))));
    }
    sub (%e) {
        given %e<kind> {
            when 'begin' {
                $total = %e<files>; $done = 0; $t0 = now;
                if $lines { say ''; say pretty("checking {tests($total)} from the candidate tree ...") }
                else { bar() }
            }
            when 'start' { bar("{%e<file>} running") unless $lines }
            when 'retry' {
                $total += %e<files>;
                my $what = "{%e<files>} failed beside the others: running {%e<files> == 1 ?? 'it' !! 'them'} alone ...";
                if $lines { say pretty("  $what") } else { bar($what) }
            }
            when 'done' {
                $done++;
                if $lines {
                    my $glyph = %e<outcome> eq 'passed' ?? '✓' !! %e<outcome> eq 'failed' ?? '✗' !! '?';
                    say pretty("  $glyph {%e<file>}  ({%e<invariants>.join(', ')})  {%e<outcome>}, {sprintf('%.1f', %e<seconds>)}s");
                }
                elsif $done >= $total { print "\r\e[2K"; $*OUT.flush }
                else { bar() }
            }
        }
    }
}

#| Who answers, in a word: the person's own command or 321.
sub agent-short(--> Str) { (%*ENV<IZ4_AGENT_CMD> // '').trim ?? 'IZ4_AGENT_CMD' !! '321' }

#| What a person waiting on an agent sees.  Its answer takes as long as
#| it takes, so there is no bar: one line under the title, a spinner,
#| what is asked and how long it has been, rewritten in place and wiped
#| when the answer comes.  Into a pipe, nothing: the work just runs.
sub while-waiting(Str $what, &work) {
    return work() unless $*OUT.t;
    my @frames = diamond() eq '◈' ?? <⠋ ⠙ ⠹ ⠸ ⠼ ⠴ ⠦ ⠧ ⠇ ⠏> !! < | / - \\ >;
    my ($t0, $i) = now, 0;
    my $p = start { work() };
    while $p.status ~~ Planned {
        my $s = (now - $t0).Int;
        print "\r\e[2K" ~ pretty(fit-line("  {@frames[$i++ % @frames]} $what", :keep("  {sprintf('%d:%02d', $s div 60, $s mod 60)}")));
        $*OUT.flush;
        sleep 0.1;
    }
    print "\r\e[2K"; $*OUT.flush;
    $p.result;    # a failure is thrown here, as if the work had run in place
}

#| One plain glyph: green tick, red cross, yellow question; coloured only
#| on a terminal that has not asked for no colour.
sub mark(Str $glyph --> Str) {
    return $glyph if %*ENV<NO_COLOR> || !$*OUT.t;
    my $colour = do given $glyph { when '✓' { 32 }; when '✗' { 31 }; default { 33 } };
    "\e[{$colour}m$glyph\e[0m";
}

# ------------------------------------------------------------ test

multi MAIN('test', *@which, Str :$file, Str :$lang, Bool :$list = False, Bool :$draft = True) {
    attempt {
        my $path = resolve-target($file);
        my $root = $path.parent;
        my $doc  = check-doc($path);
        user-error("fix the errors 'iz4 check' reports first") if $doc.errors;
        my %ev = evidence-for($doc, $root);
        if $list || !$doc.invariants {
            my @own = $doc.invariants.grep(*.id.defined);
            my $w = (@own.map(*.id.chars).max // 0);
            answer('test list', display-name($path),
                @own ?? [@own.map({ sprintf('  %-10s %-*s  %s', %ev<state>{.id}, $w, .id, (%ev<files>{.id} // ()).join(', ')).trim-trailing })]
                     !! ["  No project invariants yet; 'iz4 add' finds one."],
                [|para("named: a reviewed test names it; drafted: an agent's draft awaiting review; scaffolded: the born-red placeholder; none: nothing."),
                 |para("Evidence that an invariant holds is a test that would fail if it stopped being true; a name alone is not that.")],
                [@own.grep({ %ev<state>{.id} eq 'none' }) ?? next-line('iz4 test', 'a test for each invariant that has none') !! next-line('nothing waits on you')]);
            return 0;
        }
        my @only = @which.map({ resolve-identity($doc, $_) // user-error("no invariant '$_' in {display-name($path)}; 'iz4 test list' shows the names") });
        for @only { user-error("no invariant $_ in {display-name($path)} of its own to test") unless $doc.invariant($_) }
        my $language = $lang // detect-language($root);
        user-error("no scaffold for language '$language'; --lang takes one of {LANGUAGES.join(', ')}")
            unless so $language eq any(LANGUAGES);
        head('test', display-name($path));
        my $said = False;
        my sub gap() { say '' if $said; $said = True }

        # With an agent and a person present, draft the real test and ask;
        # a draft is written only on a yes, and is marked for review.
        my @drafted;
        my $drafting = 0;
        if $draft && interactive() && !agent-reachable() { gap(); say "  No agent to draft with (321, or your own IZ4_AGENT_CMD): writing scaffolds for you to fill in." }
        if $draft && interactive() && agent-reachable() {
            my $layout = gather-context($root);
            my @todo = $doc.invariants.grep({ .id.defined && (!@only || .id eq any(@only)) && %ev<state>{.id} eq 'none'
                                              && !$root.add(scaffold($language, $_)[0]).e });
            for @todo.kv -> $k, $inv {
                my $n = $inv.id;
                my ($rel, $) = scaffold($language, $inv);
                gap();
                say "{heading-of($doc)} $n: {$inv.text}";
                my $t0 = now;
                my $d = try while-waiting("your agent ({agent-short()}) is drafting $rel" ~ (@todo > 1 ?? ", {$k + 1} of {+@todo}" !! ''),
                    { agent-draft($doc, $inv, $root, :lang($language), :path($rel), :$layout) });
                $drafting += now - $t0;
                without $d { say "  no draft: {$!.message.lines.head}; a scaffold will be written instead"; next }
                with $d<cannot> { say "  the agent declined: $_"; say "  a scaffold will be written instead"; next }
                say '';
                say $d<text>.lines.map({ "    $_" }).join("\n");
                say '';
                my $answer = (ask("Write it to $rel, marked for your review? [Y/n/q] ") // 'q').trim.lc;
                last if $answer.starts-with('q');
                next if $answer.starts-with('n');
                $root.add($rel).parent.mkdir;
                $root.add($rel).spurt(marked-draft($language, $d<text>));
                @drafted.push: ($rel, $n);
            }
            %ev = evidence-for($doc, $root);
        }
        my @done = write-scaffolds($doc, $root, :lang($language), :@only);
        if @drafted {
            gap();
            say "  Drafted {+@drafted} test{+@drafted == 1 ?? '' !! 's'} ($language) in {sprintf('%d:%02d', $drafting.Int div 60, $drafting.Int mod 60)}, each marked for review on its first line:";
            say "    $_[0]  ($_[1])" for @drafted;
            say "  A draft is not evidence until you have read it, run it, seen that it can fail, and deleted that line.";
        }
        if @done {
            gap();
            say "  Scaffolded {+@done} test{+@done == 1 ?? '' !! 's'} ($language), each failing until you write the assertion:";
            say "    $_[0]  ($_[1])" for @done;
            say "  A scaffold is not evidence: 'iz4 check' counts it only once its placeholder is gone.";
            say "  On a terminal with an agent (IZ4_AGENT_CMD), 'iz4 test' drafts the real test for you to approve." unless $draft && interactive();
        }
        unless @drafted || @done {
            gap();
            say '  ' ~ @only
                ?? "Nothing to write: {@only.join(', ')} already ha{@only == 1 ?? 's' !! 've'} a test naming it (or its file exists)."
                !! "Nothing to write: every invariant already has a test naming it, or its file exists ('iz4 test list').";
        }
        # the one next step: the first file that still needs its assertion, or a draft to read
        say '';
        say @drafted ?? next-line("read {@drafted[0][0]}", 'run it, see that it can fail, then delete its first line')
                     !! @done ?? next-line("write the assertion in {@done[0][0]}", 'until then it fails, on purpose')
                     !! next-line('iz4 status');
        0;
    }
}

# ------------------------------------------------------------ when

#| Say when a promise applies: its WHEN.
multi MAIN('when', Str $which, Str $text, Str :$file) {
    attempt :intent, {
        my $path = resolve-target($file);
        my $id = set-reach($path, $which, $text);
        answer('when', $id, [pretty("  ✓ $id now applies when: $text")], [next-line('iz4 show invariant ' ~ $id.split('.')[0])]);
        0;
    }
}

# ------------------------------------------------------------ review

multi MAIN('review', *@range, Str :$file, Bool :$staged = False, Bool :$for-push = False,
           Bool :$offline = False, Bool :$strict = False, Bool :$install-hook = False, Bool :$force = False) {
    attempt {
        my $path = resolve-target($file);
        if $install-hook {
            say "pre-push hook: {install-hook($path, :$force)} (advisory; set IZ4_REVIEW_STRICT=1 to make it block on a conflict)";
            return 0;
        }
        my $doc = check-doc($path);
        user-error("fix the errors 'iz4 check' reports before reviewing") if $doc.errors;
        my ($diff, $what) = change-diff($path, |($for-push ?? (push-range($path),) !! @range), :$staged);
        head('review', $what);
        say "  $_" for offline-report($doc, $diff, :$what);
        return 0 unless $diff.trim;
        return 0 if $offline;

        my $review = try while-waiting("your agent ({agent-short()}) is reviewing $what", { agent-review($path, :$diff, :$what) });
        without $review {
            say '';
            say "  · No agent review: {$!.message.lines.head} (IZ4_AGENT_CMD names your agent; --offline skips this).";
            say '';
            say next-line('nothing waits on you', 'the touches above are for you to look at');
            return 0;
        }
        say '';
        .say for assessment-lines($review, $doc);
        my $conflicts = $review<assessments>.grep(*<level> eq 'conflicting').elems;

        if $review<candidates> {
            for $review<candidates>.list -> %c {
                say '';
                say "Candidate invariant ({%c<class>.lc}): {%c<text>}";
                say "  PROTECTS {%c<because>}" if %c<because>;
                say "  Evidence that would show it holds: {%c<evidence>}" if %c<evidence>;
                if interactive() {
                    my $answer = (ask('Consider it? [Y/n/q] ') // 'q').trim.lc;
                    last if $answer.starts-with('q');
                    next if $answer.starts-with('n');
                    coach-into($path, :candidate(%c<text>), :suggested-because(%c<because>));
                }
            }
            say "Nothing was added. Add one with 'iz4 add' if you agree." unless interactive();
        }
        say '';
        say $conflicts
            ?? "A conflict is the agent's reading of the diff, with its evidence above; you decide."
            !! "No conflict reported. That is one reading of the diff, not a proof.";
        $strict && $conflicts ?? 1 !! 0;
    }
}

# ------------------------------------------------------------ suggest

multi MAIN('suggest', Str :$file) {
    attempt {
        my $path = try resolve-target($file);
        my $dir  = $path.defined ?? $path.parent !! $*CWD;
        my $reply = try while-waiting("your agent ({agent-short()}) is looking for candidate invariants", { agent-suggest($dir, current => ($path.defined ?? $path.slurp !! '')) });
        user-error("agent suggestion failed: {$!.message.lines.head}; nothing was added") without $reply;
        head('suggest', 'a few candidates, for you to decide') if pretty-on();
        show-suggestions(%$reply, $path);
        0;
    }
}

#| A starter pack, read aloud: ideas to think with.  It only suggests, so it
#| writes nothing, and it needs no IZ4 and no agent.
multi MAIN('suggest', 'saas', Bool :$json = False, Bool :$brief = False, Str :$file) {
    attempt {
        two-machine-forms() if $json && brief-wanted($brief);
        my @pack = SAAS-ESSENTIALS.list;
        if $json {
            say json-encode(%( schema => 'iz4-pack/1', pack => 'saas-essentials', adds_nothing => True,
                               suggestions => @pack.map({ %$_ }).Array ));
            return 0;
        }
        if brief-wanted($brief) {
            say (.<title>, .<when>, .<always>, .<protects>).join("\t") for @pack;
            return 0;
        }
        my $path = try resolve-target($file);
        my @chunks = para('Seven promises most software people pay for should keep. None is added for you.'),
                     |@pack.map({ ("  {.<title>}", |para("When {.<when>}, {.<always>}."), |para("It protects {.<protects>}."), |para(.<ask>)).List }),
                     para('A promise you keep is worth more than seven you copied.'),
                     ($path.defined ?? next-line('iz4 add', 'say the ones that fit, in your own words')
                                    !! next-line('iz4 init', 'start an IZ4, then add the ones that fit'));
        my $sc = Screen.new(:command('suggest saas'), :context('SaaS Essentials, ideas to think with'));
        for @chunks -> $c { $sc.lines(|($c ~~ Str ?? $c.lines !! $c.list)) }
        print $sc.screen;
        0;
    }
}

#| From init: ask the agent for candidates and go through them.  False
#| when the agent could not be asked, so the caller can coach instead.
sub review-suggestions(IO::Path $path, Bool :$quiet = False --> Bool) {
    my $reply = try while-waiting("your agent ({agent-short()}) is looking for candidate invariants", { agent-suggest($path.parent, current => $path.slurp) });
    without $reply {
        say "The agent could not be asked ({$!.message.lines.head}), so one question at a time instead." unless $quiet && !$!.message;
        return False;
    }
    show-suggestions(%$reply, $path);
    True;
}

#| Said beside a draft that still runs long, so the person cuts it
#| rather than keeping words nobody will read.
sub long-note(Str $text --> Str) {
    "That is {draft-words($text)} words, which is long to read before every change. Say it shorter if you keep it.";
}

sub show-suggestions(%s, $path) {
        my ($strong, $possible) = %s<found><strong possible>;
        my $left = %s<implementation> + %s<not-iz4>;
        say 'Analysed repository.';
        say "I found $strong strong candidate invariant{$strong == 1 ?? '' !! 's'} and $possible "
          ~ "thing{$possible == 1 ?? '' !! 's'} that may depend on product intent.";
        if $strong > %s<strong> || $possible > %s<possible> {
            say "Showing the strongest {+%s<strong>} and {+%s<possible>}: fewer, stronger invariants beat apparent completeness.";
        }
        say "Left out $left as implementation or not IZ4 (for example: {%s<implementation>[0]<text> // %s<not-iz4>[0]<text>})." if $left;
        unless %s<strong> || %s<possible> {
            say "Nothing stood out as enduring intent. That is a fine answer; 'iz4 add' when something does.";
            return;
        }

        if !$path.defined || !interactive() {
            for %s<strong>.list -> %c {
                say "\nStrong candidate: {%c<text>}";
                say "  {long-note(%c<text>)}" if too-long(%c<text>);
                say "  PROTECTS: {%c<because>}" if %c<because>;
            }
            for %s<possible>.list -> %c {
                say "\nPossible, needs your intent: {%c<text>}";
                say "  {long-note(%c<text>)}" if too-long(%c<text>);
                say "  Only you can say: {%c<question>}" if %c<question>;
            }
            say '';
            say $path.defined
                ?? "Nothing was added. Review them on a terminal with 'iz4 suggest', or add one with 'iz4 add'."
                !! "Nothing was added. Run 'iz4 init' first, then 'iz4 suggest' again.";
            return;
        }

        say "Let's review the strongest one first.";
        my @queue = |%s<strong>.map({ %( |$_, kind => 'strong' ) }),
                    |%s<possible>.map({ %( |$_, kind => 'possible' ) });
        my $before = +check-doc($path).invariants;
        my $seen = 0;
        for @queue -> %c {
            say '';
            say %c<kind> eq 'strong' ?? "Candidate: {%c<text>}" !! "Possible: {%c<text>}";
            say long-note(%c<text>) if too-long(%c<text>);
            say "Only you can say: {%c<question>}" if %c<question>;
            my $answer = (ask('Consider it? [Y/n/q] ') // 'q').trim.lc;
            last if $answer.starts-with('q');
            $seen++;
            next if $answer.starts-with('n');
            coach-into($path, :candidate(%c<text>), :suggested-because(%c<because>));
        }
        my $added = +check-doc($path).invariants - $before;
        say '';
        say "Added $added, left out {$seen - $added}, not reached {+@queue - $seen}. What went in is in your words.";
        say next-line('iz4 test', 'give what you added its test') if $added > 0;
}

multi MAIN('log', Str $file?, Bool :brief($brief-flag) = False) {
    attempt {
        # the pipeline form: date, revision, subject, tab-separated
        return print(log-text(resolve-target($file)).lines.map({ .split('  ', 3).join("\t") ~ "\n" }).join) && 0 if brief-wanted($brief-flag);
        my $text = log-text(resolve-target($file));
        head('log', 'the history of the IZ4') if pretty-on();
        print $text;
        0;
    }
}

multi MAIN('diff', *@args) {
    attempt {
        my $file = @args && looks-like-file(@args[0]) ?? @args.shift !! Str;
        user-error("diff takes at most two revisions") if @args > 2;
        my ($rc, $out, $err) = diff-result(resolve-target($file), |@args);
        if $rc == 127 { say $err.trim; return 0 }      # no Git: informational, like log
        # a revision Git does not know is said in iz4's words, with where to find one
        user-error("{@args.map({ "'$_'" }).join(' or ')} is not a revision here; 'iz4 log' lists the IZ4's") if $rc == 128;
        head('diff', 'what changed in the IZ4') if pretty-on();
        print $out;
        note $err.trim if $err.trim ne '';
        $rc;
    }
}

multi MAIN('version', Bool :brief($brief-flag) = False) {
    return say VERSION if brief-wanted($brief-flag);
    # a script reads 'iz4 X.Y.Z (rev)' from a pipe; a person gets the title's dress
    my $v = "iz4 {VERSION}" ~ (own-revision() andthen " ($_)" orelse '');
    say pretty-on() ?? Screen.new(:heading($v)).title-line !! $v;
}

# ------------------------------------------------------------ completion

multi MAIN('completion', Str $shell) {
    attempt {
        user-error("iz4 completion knows bash, zsh and fish, not '$shell'") unless $shell eq any(<bash zsh fish>);
        print completion-script($shell);
        0;
    }
}

multi MAIN('update', Bool :$check = False) {
    attempt {
        head('update', $check ?? 'is there a newer iz4?' !! 'bring iz4 up to date');
        my %u = self-update(:$check);
        my sub commits() { say "    $_" for %u<commits>.head(8); say "    ..." if %u<commits> > 8 }
        my $rc = do given %u<state> {
            when 'current'  { say pretty("  ✓ iz4 is up to date ({VERSION}, {%u<from>})."); 0 }
            when 'behind'   { say "  iz4 is {%u<n>} commit{%u<n> == 1 ?? '' !! 's'} behind; 'iz4 update' fetches:"; commits(); say ''; say next-line('iz4 update'); 0 }
            when 'updated'  { say pretty("  ✓ Updated iz4 from {%u<from>} to {%u<to>} ({%u<n>} commit{%u<n> == 1 ?? '' !! 's'}):"); commits(); 0 }
            when 'managed'  { say %u<note>; 0 }
            default         { note %u<note>; 1 }
        };
        # 321, when iz4 installed it, is kept current too; one someone else installed is left alone.
        # A source install runs the checkout's bin/iz4 through a launcher script on PATH, so
        # the marker is looked for beside that script as well as beside the program itself.
        my $bin-dir = launcher-owner-dir();
        if $bin-dir.defined {
            my %l = launcher-install(:$bin-dir, :$check);
            given %l<state> {
                when 'current' { say "321.do, an agent launcher, is up to date ({%l<version>})." }
                when 'behind'  { say "321.do, an agent launcher, is behind: {%l<version>} installed, {%l<tag>} published; 'iz4 update' fetches it." }
                when 'updated' { say "Updated 321.do, an agent launcher, from {%l<from>} to {%l<version>}." }
                when 'installed' { say "Installed 321.do, an agent launcher ({%l<version>}) at {%l<path>}." }
                default        { note "321.do: {%l<note>}" }
            }
        }
        $rc;
    }
}

multi MAIN('agent', Bool :$json = False, Str :$file) {
    attempt {
        my %p = agent-packet(resolve-target($file));
        print $json ?? json-encode(%p) ~ "\n" !! packet-text(%p);
        0;
    }
}

multi MAIN('agent', 'install', Bool :$claude = False, Bool :$skill = False, Bool :$hooks,
           Bool :$strict = False, Str :$file) {
    attempt {
        my $root = resolve-target($file).parent;
        head('agent install', 'tell agents here about the IZ4');
        my sub landed(Str $what, Str $state) { say pretty("  {$state eq 'unchanged' ?? '·' !! '✓'} $what: $state") }
        landed($_, install-agent-section($root.add($_), :$root)) for 'AGENTS.md', |($claude ?? 'CLAUDE.md' !! Empty);
        landed(SKILL-PATH, install-skill(:$root)) if $skill;
        # Hooks are wired by an environment driver: something that knows
        # the agent harness.  iz4 knows none, and writes into none.  By
        # default, where the driver finds a harness here with nothing wired,
        # it is asked for the advisory set, which delivers the context and
        # refuses nothing.  Wiring already there is never replaced or
        # downgraded by a default run; --hooks asks outright, --strict asks
        # for everything the harness can enforce, --/hooks leaves it alone.
        # Asked for hooks outright, iz4 first makes sure its environment
        # driver is there, installing the official 321 when it is not.
        if (($hooks // False) || $strict) && !driver-binary().defined {
            my %d = ensure-driver();
            given %d<state> {
                when 'installed' { say "321 {%d<version>} installed at {%d<path>}: the environment driver iz4 uses to wire a harness." }
                when 'updated'   { say "321 updated from {%d<from>} to {%d<version>} at {%d<path>}." }
                when 'failed' | 'too-old' | 'foreign' { note "321: {%d<note>}" }
            }
        }
        my $driver = driver-binary();
        my %before = $driver.defined ?? ((try driver($driver, 'status', :$root)) // %()) !! %();
        my $here   = so @(%before<harnesses> // []).grep({ .<detected> });
        my $by-default = !$hooks.defined && !$strict && $here && driver-level(%before) eq 'none';
        my $hooks-now = $hooks // ($strict || $by-default);
        say "hooks: installing the advisory set by default, since an agent harness is in use here (--/hooks to skip, --strict to add the gates)"
            if $by-default;
        my $failed = False;
        # A plain install with no driver wires nothing; where the repository
        # is set up for an agent, one line says whose job that is.
        if !$hooks-now && !$hooks.defined && !$driver.defined {
            my @legacy = legacy-hooks(:$root);
            if @legacy { say "hooks: the Claude Code hooks an earlier iz4 wrote ({@legacy.join(', ')}) are untouched and still active; 321 {DRIVER-MIN-VERSION} or later can adopt them (321 iz4 install)" }
            elsif expected-integrations(:$root).elems > 1 { say "hooks: none installed. Driving an agent harness is 321's job: with 321 {DRIVER-MIN-VERSION} or later ({LAUNCHER-RELEASES}), run 321 iz4 install" }
        }
        if $hooks-now {
            with $driver -> $bin {
                my %h = driver($bin, 'install', :$root, :advisory(!$strict));
                say "hooks via 321 {launcher-version($bin)}, for every harness it knows:";
                say "  $_" for driver-lines(%h);
                $failed = so @(%h<harnesses> // []).grep({ (.<action> // '') eq 'failed' });
            }
            else {
                # Nothing here knows a harness.  Asked with --strict that is a
                # failure; asked without, it is a warning and the rest stands.
                $failed = $strict;
                note no-driver-lines(:$root).join("\n");
            }
        }
        say '';
        say "These integrations only encourage adherence in tools that load them"
          ~ ($hooks-now && $driver.defined ?? '; a hook can prove the packet was delivered and a report written, never that an invariant was honoured.' !! '.');
        $failed ?? 1 !! 0;
    }
}

#| What is said when hooks are asked for and nothing here knows a harness.
sub no-driver-lines(IO::Path :$root! --> List) {
    my $bin = launcher-binary();
    my @legacy = legacy-hooks(:$root);
    my @l = "hooks: not installed.",
            "  IZ4 defines the invariant checks but does not install agent-environment hooks directly.",
            ($bin.defined
                ?? "  No environment driver is available: the 321 here is {launcher-version($bin)}, and wiring a harness needs {DRIVER-MIN-VERSION} or later."
                !! "  No environment driver is available."),
            "  Install 321 {DRIVER-MIN-VERSION} or later ({LAUNCHER-RELEASES}), then run: 321 iz4 install",
            "  Any other environment can call iz4 itself: iz4 context, iz4 check action, iz4 check change, iz4 verify (docs/drivers.md).";
    @l.push("  The Claude Code hooks an earlier iz4 wrote here ({@legacy.join(', ')}) are untouched and still active.") if @legacy;
    @l.List;
}

#| How the hooks an earlier iz4 wrote can be handed to a driver, given
#| what is installed here.
sub legacy-migration(--> Str) {
    my $bin = launcher-binary();
    return "321 {launcher-version(driver-binary())} can adopt this wiring: 321 iz4 install" if driver-binary().defined;
    return "321 {DRIVER-MIN-VERSION} or later can adopt this wiring; the 321 here is {launcher-version($bin)}. Nothing needs doing until then." if $bin.defined;
    "321 {DRIVER-MIN-VERSION} or later can adopt this wiring; no 321 is installed. Nothing needs doing until then.";
}

# ------------------------------------------------------------ hook

#| The harness-neutral hook contract: JSON in, text for the model out,
#| exit 2 with a reason on standard error to refuse.
multi MAIN('hook', Str $event where 'session-start' | 'pre-edit' | 'stop', Str :$file) {
    my %input = read-input($*IN.slurp);
    my $path = try resolve-target($file);
    without $path { exit ALLOW }                # no IZ4 here: nothing to insist on
    my ($exit, $out, $err) = do given $event {
        when 'session-start' { on-session-start($path, %input) }
        when 'pre-edit'      { on-pre-edit($path, %input) }
        when 'stop'          { on-stop($path, %input) }
    };
    print $out if $out;
    note $err.trim-trailing if $err;
    exit $exit;
}

multi MAIN('agent', 'status', Bool :$json = False, Bool :$strict = False, Str :$file) {
    attempt {
        my IO::Path $path = (try resolve-target($file)) // IO::Path;   # no IZ4 here is a status, not an error
        my $root = $path.defined ?? $path.parent !! $*CWD;
        my %s    = agent-status($path, :$root);
        my $bin = launcher-binary();
        with $bin { %s<launcher> = %( binary => $_, version => launcher-version($_) ) }
        # What is wired into a harness is the driver's to say; iz4 reads no
        # harness's configuration.
        my $driver = driver-binary();
        my %enf = $driver.defined ?? ((try driver($driver, 'status', :$root)) // %()) !! %();
        # The one thing iz4 does read is wiring an earlier iz4 wrote itself,
        # so that hooks still firing are never reported as absent.
        my @legacy = legacy-hooks(:$root);
        %s<hooks> = %enf ?? driver-level(%enf) !! @legacy ?? 'aware' !! 'unknown';
        %s<legacy_hooks> = %( harness => 'claude_code', file => LEGACY-SETTINGS, events => [ |@legacy ],
            managed_by => 'legacy iz4 wiring', enforcement => 'aware', migration => legacy-migration() ) if @legacy;
        %s<enforcement> = %enf if %enf;
        if $json { say json-encode(%s) }
        else {
            head('agent status', %s<iz4><present> ?? display-name($path) !! 'no IZ4 here');
            if %s<iz4><present> {
                say "  IZ4: {display-name($path)} - " ~ (%s<iz4><valid>
                    ?? 'valid'
                    !! "INVALID ({%s<iz4><errors>} errors - run 'iz4 check')");
                say "  {%s<iz4><binding>}";
            }
            else { say '  IZ4: none found in this directory or its parents' }
            say '';
            for 'AGENTS.md', 'CLAUDE.md', (SKILL-PATH) -> $i {
                my $status = %s<integrations>{$i};
                say pretty("  {$status eq 'current' ?? '✓' !! '✗'} " ~ integration-line($i, $status, :reason($status eq 'stale' ?? stale-reason($root.add($i)) !! '')));
            }
            say '';
            if %enf {
                say "321 {%s<launcher><version>}, an agent launcher, is installed: agent runs, suggest, review and test drafting go through it,";
                say "and it drives iz4 in every harness it knows and says how strongly it is enforced:";
                say "  $_" for driver-lines(%enf);
            }
            elsif $driver.defined { say "321 is installed at $driver but '321 iz4 status' failed" }
            elsif $bin.defined {
                say "321 {%s<launcher><version>} is installed, but wiring a harness needs {DRIVER-MIN-VERSION} or later"
                  ~ (@legacy ?? '' !! ": iz4 finds no hooks of its own here, and wires none itself");
            }
            else {
                say "  321, an agent launcher, is not installed: "
                  ~ (%*ENV<IZ4_AGENT_CMD> ?? "agent prompts go to your IZ4_AGENT_CMD ({%*ENV<IZ4_AGENT_CMD>})"
                                          !! "suggest, review and test drafting need it, or your own IZ4_AGENT_CMD")
                  ~ (@legacy ?? '' !! ", and iz4 finds no hooks of its own here (iz4 leaves agent environments to a driver: docs/drivers.md)");
            }
            if @legacy { .say for legacy-hooks-lines(@legacy, :migration(legacy-migration())) }
            say '';
            say %s<note>;
            # the next steps for whatever is not in place, in the order that
            # clears the most first: a file to work on, then the hooks, which
            # are the one step that enforces anything, then the wording
            my @next;
            my $want-hooks = $driver.defined && %s<hooks> ne 'guarded' && so @(%enf<harnesses> // []).grep({ .<detected> });
            # With no driver nothing can be enforced; where the repository is
            # set up for an agent, getting one is the first step.
            my $want-driver = !$driver.defined && expected-integrations(:$root).elems > 1;
            my $driver-step = "install 321 {DRIVER-MIN-VERSION} or later (the environment driver), then: 321 iz4 install";
            @next.push('iz4 init') unless %s<iz4><present>;
            @next.push('iz4 check') if %s<iz4><present> && !%s<iz4><valid>;
            @next.push('321 iz4 install') if $want-hooks && %s<iz4><present>;
            @next.push($driver-step) if $want-driver && %s<iz4><present>;
            for expected-integrations(:$root) -> $i {          # the Claude entry points only where Claude is used
                @next.push(integration-next($i, %s<integrations>{$i})) unless %s<integrations>{$i} eq 'current';
            }
            @next.push('321 iz4 install') if $want-hooks && !%s<iz4><present>;
            say '';
            if @next { say-next(@next, :then('iz4 agent status')) } else { say next-line('nothing waits on you') }
        }
        my $fail = !%s<iz4><present> || !%s<iz4><valid>
                || ?%s<integrations>.values.grep(* eq 'stale' | 'malformed');
        ($strict && $fail) ?? 1 !! 0;
    }
}

multi MAIN('register', Str :$url, Str :$token, Str :$file,
           Bool :$github = False, Bool :$force = False) {
    attempt {
        my $path = resolve-target($file);
        my $name = display-name($path);
        head('register', 'connect this IZ4 to iz4.you');
        with $url {
            my $f = save-register-url($path, $url);
            say "Register URL saved to {display-name($f)}";
        }
        with $token {
            my $u = register-url($path)
                // user-error("save the reports URL first: iz4 register --url=<reports URL>");
            save-token($u, $token);
            say "Token saved to {token-store()} - outside the repository; do not commit it.";
        }
        if $github {
            my $u = register-url($path)
                // user-error("save the reports URL first: iz4 register --url=<reports URL> --github");
            say install-github-workflow($path, :$force) eq 'unchanged'
                ?? '.github/workflows/iz4.yml is already set up'
                !! 'Wrote .github/workflows/iz4.yml: every push installs iz4 (runtime cached) and runs iz4 report';
            my $t = $token // token-for($u);
            if $t.defined {
                given set-github-secret($path, $t) {
                    when 'set'   { say 'Stored the token as the repository secret S2R_TOKEN (GitHub CLI).' }
                    when 'no-gh' { say 'No GitHub CLI found. Add a repository secret named S2R_TOKEN with your token (Settings > Secrets and variables > Actions).' }
                    default      { user-error("the GitHub CLI could not set the secret ($_). Sign in with: gh auth login, then run: iz4 register --github") }
                }
                say "Next: commit and push {display-name(register-file($path))} and .github/workflows/iz4.yml; every push then reports.";
            }
            else {
                say 'No reporting token yet. Mint one on the Connect CI page, then: iz4 register --token=<token> --github';
            }
        }
        my $rc = 0;
        if !$url.defined && !$token.defined && !$github {
            with register-url($path) -> $u {
                say "$name reports to $u";
                with token-for($u) -> $t {
                    $rc = record-checkpoint($path, $u, $t);
                }
                else {
                    say "No reporting token yet. Mint one on the project's Connect CI page, then:\n  iz4 register --token=<token>";
                }
            }
            else {
                print qq:to/END/;
                $name is not connected to a register yet.

                To make it discoverable on the IZ4 register:
                  1. Sign up first (email passcode): {REGISTER-START}
                  2. Create a project there and mint a reporting token (shown once)
                  3. Connect this IZ4 (add --github to set up GitHub Actions too):
                       iz4 register --url=<the project's reports URL> --token=<the token>
                  4. Submit evidence: iz4 report
                  5. Publish the card on iz4.you, then record a checkpoint: iz4 register

                A report carries presence, digest, counts and check outcomes -
                never the text of your IZ4. Only register and report, and the
                agent behind suggest, reach the network; every other iz4
                command stays offline.
                END
            }
        }
        say '';
        say trademark-licence-note();
        $rc;
    }
}

#| A connected 'iz4 register' records a registration checkpoint: this exact
#| declaration, at this revision, mattered now. Evidence for HEAD goes
#| first, so the register has something to bind; then the checkpoint, which
#| the register chains to its predecessor. Every report is evidence for one
#| revision; only this is a registration. Returns the exit code.
sub record-checkpoint(IO::Path $path, Str $url, Str $token --> Int) {
    my ($dirty, $, $) = git($path, 'diff', '--quiet', 'HEAD', '--', $path.basename);
    if $dirty == 1 {
        note "{display-name($path)} has uncommitted changes. A checkpoint records the committed declaration, so commit it first, then: iz4 register";
        return 1;
    }
    my %report = collect-report($path);
    my $rev    = %report<revision>.substr(0, 12);
    my ($code, $reply) = submit-report($url, $token, json-encode(%report));
    unless 200 <= $code < 300 {
        note $code == 0
            ?? "register unreachable: $reply"
            !! "register answered $code to the report: {$reply.substr(0, 300)}";
        note 'No checkpoint recorded: the register needs evidence for this revision first.';
        return 1;
    }
    say "submitted {%report<report_id>} ({display-name($path)} at $rev)";

    ($code, $reply) = submit-checkpoint(registrations-url($url), $token, checkpoint-body(%report));
    my $seq  = json-field($reply, 'sequence');
    my $card = json-field($reply, 'card');
    if $code == 201 {
        my $pred = json-field($reply, 'predecessor');
        say "Registered declaration: checkpoint $seq (revision $rev"
            ~ ($pred.defined ?? ", follows checkpoint $pred)" !! ", the first)");
        say "card: $card" with $card;
        return 0;
    }
    if $code == 200 {
        say "Registered declaration: checkpoint $seq already records this declaration; nothing new to record.";
        say "card: $card" with $card;
        return 0;
    }
    if $code == 0 {
        note "register unreachable: $reply";
        note 'No checkpoint recorded. The report went through; run iz4 register again when the register is reachable.';
        return 1;
    }
    my $error = json-field($reply, 'error') // '';
    my $msg   = json-field($reply, 'message') // $reply.substr(0, 300);
    note "register answered $code: $msg";
    note do given $error {
        when 'not_registered'  { "No checkpoint recorded. Publish the project's card on iz4.you first (the IZ4 Trademark Licence is accepted there, never here), then: iz4 register" }
        when 'no_evidence'     { "No checkpoint recorded: the register holds no report for revision $rev. Run: iz4 report, then: iz4 register" }
        when 'no_declaration'  { "No checkpoint recorded: the register's report for this revision carries no declaration digest. Make sure {display-name($path)} is committed, then: iz4 report, then: iz4 register" }
        when 'digest_mismatch' { "No checkpoint recorded: the register's evidence for revision $rev carries a different digest from this file. Commit the file as it is, then: iz4 report, then: iz4 register" }
        when 'unauthorized'    { "No checkpoint recorded: the register rejected the token. Mint a new one on the project's Connect CI page, then: iz4 register --token=<token>" }
        default                { 'No checkpoint recorded.' }
    }
    1;
}

# Printed by every 'iz4 register': what registering includes, and that the
# acceptance happens on the site. Nothing here is a prompt, and no command
# is gated on it.
sub trademark-licence-note(--> Str) {
    qq:to/END/.chomp;
    Registering a project on iz4.you includes the IZ4 Trademark Licence
    ({TRADEMARK-LICENCE}): permission to use the IZ4 name and
    badge while the project keeps the foundation intact.
    You accept it on iz4.you when you publish the card, not here. Your
    rights under the Apache License 2.0 are unchanged, and nothing in iz4
    needs registration.
      {TRADEMARK-LICENCE-URL}
    END
}

# ------------------------------------------------------------------ gate

sub gate-root(Str $file --> IO::Path) {
    my $path = try resolve-target($file);
    without $path {
        # no IZ4 here: if this is a repository whose HEAD has one, the gate's answer is that it is gone
        my ($rc, $out, $) = git($*CWD.add(ROOT-NAME), 'rev-parse', '--show-toplevel');
        my $root = $rc == 0 ?? $out.trim.IO !! IO::Path;
        return $root if $root.defined && git($root.add(ROOT-NAME), 'cat-file', '-e', 'HEAD:' ~ ROOT-NAME)[0] == 0;
        $!.rethrow;
    }
    user-error("the gate works on a repository root IZ4; {display-name($path)} is not named {ROOT-NAME}") unless $path.basename eq ROOT-NAME;
    my ($rc, $out, $) = git($path, 'rev-parse', '--show-toplevel');
    user-error('not in a Git repository; the gate compares Git trees') if $rc != 0;
    my $root = $out.trim.IO;
    user-error("{display-name($path)} is not at the repository root ({$root})") unless $path.parent.resolve eq $root.resolve;
    $root;
}

#| A pass, as a commit hears it: nothing at all, unless a line would be
#| welcome.  A failing test that holds nobody yet is one line with its fix;
#| a yes that was given is confirmed.  Nothing else is worth an interruption.
sub brief-line(%r --> Str) {
    if (%r<vibe> // %r<settling> // {})<failing> {
        my @failed = %r<checks>.grep({ .<outcome> eq 'failed' });
        return @failed.map({
            "✕ {(.<invariants> || ['an invariant']).join(', ')} may be broken: {.<file>} failed. Nothing is held while it is exploring. To fix: make {.<file>} pass."
        }).join("\n") if @failed;
    }
    (%r<approval><status> // '') eq 'valid'
        ?? "✓ iz4: the change to what this promises is agreed, by {%r<approval><approved_by>}."
        !! '';
}

#| A held commit, said short: what was protected, in the promise's own
#| words, and the step that puts it right.  'iz4 gate' has the whole table.
sub hold-screen(%r, $doc --> Screen) {
    my $enforced = %r<mode> eq 'enforce';
    my $domain = ($doc andthen .domain) // '';
    my sub short(Str $id) { $domain ne '' && $id.ends-with(".$domain") ?? $id.substr(0, * - $domain.chars - 1) !! $id }
    my @failed = %r<checks>.grep({ .<outcome> eq 'failed' });
    my @unrun  = %r<checks>.grep({ .<outcome> eq any(<timeout unassessed>) });
    my @words  = proposal-lines(%( changes => %r<changes>, protections => %r<protections>.grep({ .<kind> ∉ @QUIET-PROTECTION-KINDS }).List ));
    my ($why, @body);
    given %r<outcome> {
        when 'blocked' {
            if @failed {
                my @ids = @failed.map({ |.<invariants> }).unique;
                $why = @ids == 1 ?? "the test for {short(@ids[0])} failed" !! "the tests for {+@ids} promises failed";
                mark-solid(%( @ids.map({ $_ => 'broken' }) ));
                my $w = @ids.map({ short($_).chars }).max // 0;
                for @failed -> %c {
                    for |(%c<invariants> || ['(no invariant named)']) -> $id {
                        my $inv = $doc.defined ?? (try $doc.invariant($id)) !! Nil;
                        @body.push: sprintf('  %s %-*s  %s', mark-shown($id), $w, short($id), ($inv andthen .text) // '');
                        @body.push: ' ' x ($w + 6) ~ "{%c<file>} failed" ~ (%c<detail> ?? ": {%c<detail>}" !! '');
                    }
                }
            }
            else { $why = 'the IZ4 itself needs putting right'; @body = @words.map({ "  $_" }) }
        }
        when 'agreement-required' {
            $why = ($enforced ?? 'it changes ' !! 'this changes ')
                ~ (%r<changes> ?? 'what the software promises, and that is yours to decide'
                               !! 'a test that protects a promise, and whether it still protects is yours to say');
            @body = @words.map({ "  $_" });
            @body.push: "  the approval on file does not cover it: {%r<approval><reasons>.join('; ')}" if (%r<approval><status> // '') eq 'invalid';
        }
        default {
            $why = 'a check could not run, so nothing can be said to hold';
            @body = @unrun.map({ "  ? {.<file>} {.<outcome>}" ~ (.<detail> ?? ": {.<detail>}" !! '') });
            @body.append: %r<notes>.map({ "  $_" });
        }
    }
    my $sc = Screen.new(:heading(($enforced ?? 'iz4 kept this commit back: ' !! 'iz4 noticed: ') ~ $why ~ '.'));
    $sc.lines(|@body) if @body;
    # one step is one line: the reason in brackets was said above
    my @steps = %r<next>.map({ .split(/\h ** 3..*/)[0] });
    @steps[0] ~= '   (a person, at a terminal)' if @steps && @steps[0] eq 'iz4 approve';
    if @steps == 1 { $sc.lines(pretty("next:  @steps[0]"), |('       then commit again' if $enforced)) }
    elsif @steps   { $sc.steps(@steps, |(:then('commit') if $enforced)) }
    $sc.doc = %r;
    $sc;
}

#| The gate's answer for a person, on the screen layer: the outcome in the
#| title; each protected invariant by name with its mark, then the test
#| that showed it; what changed, the approval and the mode as a table;
#| the next steps; and, when everything held, a line that says so.
sub gate-screen(%r, Str :$again, Str :$domain = '', :@order, Str :$what = 'the staged change' --> Screen) {
    my %why =
        pass => 'no commitment or protection changed, and every check that could run passed',
        'agreement-required' => 'this changes what the software promises, so it waits for your yes',
        blocked => 'something here needs putting right first; a yes cannot stand in for it',
        unassessed => 'a check could not be run, so this is not a pass';
    my $sc = Screen.new(:command<gate>, :context($what));
    my $present = %r<iz4><candidate_present> || %r<iz4><base_present>;
    if $present && %r<checks> {
        # one row per invariant, the name first, then the test that showed it
        # in the order the IZ4 writes them, as status shows them
        my %at = @order.antipairs;
        my @rows = %r<checks>.map(-> %c { |(%c<invariants> || ['(no invariant named)']).map({ %( id => $_, check => %c ) }) })
                             .sort({ %at{.<id>} // Inf });
        my %state = @rows.map({ .<id> => (.<check><outcome> eq 'passed' ?? 'held' !! .<check><outcome> eq 'failed' ?? 'broken' !! 'unknown') });
        mark-solid(%state);
        my sub short(Str $id) { $domain ne '' && $id.ends-with(".$domain") ?? $id.substr(0, * - $domain.chars - 1) !! $id }
        my $w = @rows.map({ short(.<id>).chars }).max;
        $sc.lines(|@rows.map(-> %row {
            my %c = %row<check>;
            sprintf('  %s %-*s  %s', mark-shown(%row<id>), $w, short(%row<id>), "{%c<file>} {%c<outcome>}" ~ (%c<detail> ?? ": {%c<detail>}" !! ''))
        }));
        $sc.lines(pretty('  ' ~ marks-legend())) if pretty-on();
    }
    elsif $present { $sc.lines('  · no test names an invariant, so no check was run') }
    my @table;
    # a pass with changes is a pass because what changed is exploring: say that, never 'nothing changed'
    my $changed = so (%r<changes> || %r<protections>.grep({ .<kind> ∉ @QUIET-PROTECTION-KINDS }));
    my $because = %r<outcome> eq 'pass' && $changed
        ?? 'what changed is exploring, so nothing waits for a yes, and every check that could run passed'
        !! %why{%r<outcome>} // '';
    @table.push: ['outcome', "{%r<outcome>}: $because"];
    if $present {
        my %p = changes => %r<changes>, protections => %r<protections>.grep({ .<kind> ∉ @QUIET-PROTECTION-KINDS }).List;
        my @pl = proposal-lines(%p);
        my $nc = +%r<changes>; my $np = +%r<protections>.grep({ .<kind> ∉ @QUIET-PROTECTION-KINDS });
        @table.push: ['commitments', $nc || $np ?? "{$nc} change{$nc == 1 ?? '' !! 's'} to what it promises, {$np} to a protection" !! 'unchanged'];
        given %r<approval><status> {
            when 'valid'   { @table.push: ['approval', "valid ({%r<approval><level>}) by {%r<approval><approved_by>} at {%r<approval><approved_at>}" ~ (%r<approval><reasons> ?? "; {%r<approval><reasons>.join('; ')}" !! '')] }
            when 'invalid' { @table.push: ['approval', "invalid - {%r<approval><reasons>.join('; ')}"] }
            when 'missing' { @table.push: ['approval', 'none for this candidate tree'] }
        }
        @table.push: ['touches', "{%r<touches>.map(*.<id>).join(', ')} (by their own words, for a person to look at, not a finding)"] if %r<touches>;
        my $b = %r<base> eq 'none' ?? 'no base (initial)' !! "{%r<base_ref>} {%r<base>.substr(0, 12)}";
        @table.push: ['compared', "{%r<candidate_ref>} {%r<candidate>.substr(0, 12)} against $b"];
        @table.push: ['mode', %r<mode> eq 'enforce' ?? "enforce: exit {%r<exit_code>}" !! 'advisory: refuses nothing; --enforce makes the outcome the exit code'];
        $sc.rows(@table.map({ .[0] => .[1] }));
        # what each change is, under the table that counts them
        $sc.lines(|@pl.map({ "  $_" }), |%r<protections>.grep({ .<kind> ∈ @QUIET-PROTECTION-KINDS }).map({ "  ({.<detail>})" }).unique);
    }
    else { $sc.rows(@table.map({ .[0] => .[1] })) }
    my @notes = |%r<notes>.map({ "note: $_" });
    with %r<vibe> { @notes.push: "exploring: every invariant of the project's own may still change freely, so nothing here waits for a yes ({.<changes>} changed, {.<failing>} test{.<failing> == 1 ?? '' !! 's'} failing). 'iz4 establish NAME' when one is agreed." }
    $sc.lines(|@notes.map({ pretty($_) })) if @notes;
    $sc.steps(%r<next>, :then($again)) if %r<next>;
    # when every check held and nothing it promises changed, say so plainly, last
    my @c = |(%r<checks> // ());
    if %r<outcome> eq 'pass' && @c && @c.all<outcome> eq 'passed' && !%r<vibe> {
        $sc.note("All held: {+@c} of {+@c} protecting test{@c == 1 ?? '' !! 's'} passed, and no commitment changed.");
    }
    $sc.doc = %r;
    $sc;
}

# ------------------------------------------------- the machine interface
# What an environment driver calls.  iz4 knows no harness: a driver (321,
# a native hook, a Git hook, CI) knows its environment and calls these.

multi MAIN('discover', Bool :$json = False, Str :$dir) {
    attempt {
        my %d = discover($dir.defined ?? $dir.IO !! $*CWD);
        if $json { say json-encode(%d) }
        elsif !%d<present> { say 'no IZ4 governs this directory' }
        else {
            say "IZ4: {%d<file>}";
            say "sha256: {%d<sha256>}";
            say %d<valid> ?? 'valid' !! "invalid: {%d<errors>.join('; ')}";
            say "invariants ({%d<format>}): {%d<invariants>.map(*<id>).join(', ')}";
        }
        0;
    }
}

#| The questions that help a person write an invariant, as data, so a page
#| that is not a terminal can ask them.
multi MAIN('draft', 'questions') {
    attempt { say json-encode(draft-questions()); 0 }
}

#| Questions about a draft, as data.  With a name and a file, also whether
#| the name can be used there, and the digest the promise would have.
multi MAIN('draft', 'check', Str :$when = '', Str :$always = '', Str :$protects = '', Str :$name, Str :$file) {
    attempt {
        my $rule = $always;
        my %r = draft-check(:reach($when), :$rule, :because($protects));
        with $name {
            my $path = resolve-target($file);
            my $doc = check-doc($path);
            my $id = clauses-identity($name, $doc.domain // 'example.com');
            %r<identity> = $id;
            try {
                check-new-name($path, $doc, $id);
                CATCH { when X::IZ4 { %r<findings>.push: %( clause => 'NAME', code => 'name', level => 'ask', message => .message ); %r<ok> = False } }
            }
            %r<digest> = sha256-text(canonical-card($id, $when.trim, ($rule.trim,), ($protects.trim,)))
                if $rule.trim ne '' && $when.trim ne '';
        }
        say json-encode(%r);
        0;
    }
}

multi MAIN('context', Bool :$json = False, Str :$file) {
    attempt {
        my %c = context(resolve-target($file));
        print $json ?? json-encode(%c) ~ "\n" !! %c<text>;
        0;
    }
}

sub say-check(%r, Bool $json --> Int) {
    if $json { say json-encode(%r) } else { .say for check-lines(%r) }
    %r<exit_code>;
}

multi MAIN('check', 'action', Bool :$json = False, Str :$action, Str :$dir) {
    attempt {
        my $text = $action // $*IN.slurp;
        my $parsed = try Rakudo::Internals::JSON.from-json($text);
        user-error('check action reads one JSON object describing the action: operation, target, and optionally parameters, resource, repository, recipient, context')
            unless $parsed ~~ Associative;
        say-check(check-action(%$parsed, :dir($dir.defined ?? $dir.IO !! $*CWD)), $json);
    }
}

sub change-options(Bool :$staged, Bool :$worktree, Str :$base, Str :$candidate, Bool :$checks, Int :$timeout, Str :$check-cmd,
                   Str :$approval, Str :$approvers --> Hash) {
    user-error('choose one of --worktree, --staged or --candidate=REV') if ($worktree, $staged, $candidate.defined).grep(?*).elems > 1;
    # the command that runs one linked test: the flag or IZ4_CHECK_CMD, else this
    # repository's own 'git config iz4.checkCmd', exactly as the gate reads it
    my $cmd = $check-cmd // do {
        my $root = try gate-root(Str);
        my ($rc, $out, $) = $root.defined ?? git($root.add(ROOT-NAME), 'config', '--get', 'iz4.checkCmd') !! (1, '', '');
        $rc == 0 && $out.trim ne '' ?? $out.trim !! Str;
    };
    %( staged => $staged, worktree => $worktree, base => $base, candidate => $candidate, checks => $checks, timeout => $timeout,
       check-cmd => $cmd, approval-file => ($approval.defined ?? $approval.IO !! IO::Path),
       approvers => ($approvers.defined ?? $approvers.IO !! IO::Path) );
}

multi MAIN('check', 'change', Bool :$staged = False, Bool :$worktree = False, Str :$base, Str :$candidate, Bool :$json = False,
           Bool :$checks = True, Int :$timeout = 300, Str :$check-cmd = %*ENV<IZ4_CHECK_CMD> // Str,
           Str :$approval, Str :$approvers = %*ENV<IZ4_APPROVERS> // Str, Str :$file) {
    attempt {
        my %o = change-options(:$staged, :$worktree, :$base, :$candidate, :$checks, :$timeout, :$check-cmd, :$approval, :$approvers);
        say-check(check-change(gate-root($file), |%o), $json);
    }
}

multi MAIN('verify', Bool :$staged = False, Bool :$worktree = False, Str :$base, Str :$candidate, Str :$summary,
           Bool :$json = False, Bool :$checks = True, Int :$timeout = 300, Str :$check-cmd = %*ENV<IZ4_CHECK_CMD> // Str,
           Str :$approval, Str :$approvers = %*ENV<IZ4_APPROVERS> // Str, Str :$file) {
    attempt {
        my %o = change-options(:$staged, :$worktree, :$base, :$candidate, :$checks, :$timeout, :$check-cmd, :$approval, :$approvers);
        my $root = gate-root($file);
        my %v = verify($root, :$summary, |%o);
        with %v<evidence><gate> -> %g {
            note-unseen($root, $_) for @(%g<settled> // []).grep(*.<approval> eq 'not-needed');
            note-unseen($root, %g);
        }
        record-last($root, %v);
        say-check(%v, $json);
    }
}

#| Exploring changes need no approval, but a change nobody has seen is how a
#| promise drifts.  This small record, beside the checks record and outside
#| every tree, holds each one from the words a person last saw to the words
#| now, until they have seen it.  Seen is awareness, never authority: nothing
#| here lets a change through that the gate would hold.
sub unseen-file(IO::Path $root --> IO::Path) { (checks-record($root) // return IO::Path).parent.add('unseen.json') }
sub unseen-of(IO::Path $root --> Hash) {
    my $f = unseen-file($root);
    my $d = $f.defined && $f.f ?? (try Rakudo::Internals::JSON.from-json($f.slurp)) !! Nil;
    my %d = $d ~~ Associative ?? %$d !! %();
    %( items => %( |(%d<items> // {}) ), seen => %( |(%d<seen> // {}) ) );
}
sub keep-unseen(IO::Path $root, %d) {
    my $f = unseen-file($root) // return;
    try { $f.parent.mkdir; $f.spurt(json-encode(%( schema => 'iz4-unseen/1', items => %d<items>, seen => %d<seen> )) ~ "\n") }
}

#| Take what a gate found that it let through.  A change held for a person
#| is shown to them there, so only a pass or a warning is noted here.  The
#| earliest words are kept when the wording moves again; going back to them
#| clears the entry; and words already seen are not raised twice.
sub note-unseen(IO::Path $root, %g) {
    return unless (%g<outcome> // '') ~~ /^ [pass|warn] /;
    my @changes = @(%g<changes> // []).grep({ .<id>.defined && .<kind> eq any(<revised added removed>) });
    return unless @changes;
    my %d = unseen-of($root);
    for @changes -> %c {
        my $id = %c<id>;
        my $after = %c<after_digest> // %c<digest> // 'gone';
        next if (%d<seen>{$id} // '') eq $after && !(%d<items>{$id}:exists);
        with %d<items>{$id} -> %was {
            if (%was<before_digest> // '') eq $after { %d<items>{$id}:delete; next }
            %d<items>{$id} = %( |%was, after => (%c<after> // ''), after_digest => $after, kind => (%was<kind> eq 'added' ?? 'added' !! %c<kind>) );
        }
        else {
            %d<items>{$id} = %( kind => %c<kind>, before => (%c<before> // ''), after => (%c<after> // ''),
                                before_digest => (%c<before_digest> // ''), after_digest => $after,
                                at => DateTime.now.utc.truncated-to('second').Str );
        }
        # a walk over old commits can pass through words a person has since seen
        %d<items>{$id}:delete if (%d<items>{$id} // {})<after_digest> eq (%d<seen>{$id} // '');
    }
    keep-unseen($root, %d);
}

#| One unseen change, in the words themselves: they are the evidence.
sub unseen-lines(Str $id, %i --> List) {
    my $short = $id.split('.').head;
    my @l = "  $short ({%i<kind> eq 'revised' ?? 'reworded' !! %i<kind>})";
    @l.append: para("was:  {%i<before>}") if %i<before> ne '';
    @l.append: para("now:  {%i<after>}")  if %i<after> ne '';
    @l.List;
}

multi MAIN('seen', Bool :$json = False, Str :$file) {
    attempt {
        my $root = gate-root($file);
        my %d = unseen-of($root);
        my @ids = %d<items>.keys.sort;
        if $json {
            say json-encode(%( schema => 'iz4-unseen/1', items => %d<items>, note => 'seen records awareness, never approval' ));
            return 0;
        }
        unless @ids {
            calm('iz4 seen', 'Every exploring change has been seen.');
            return 0;
        }
        head('seen', 'exploring changes not yet seen');
        unless interactive() {
            for @ids -> $id { .say for unseen-lines($id, %d<items>{$id}); say '' }
            say next-line('iz4 seen', 'at a terminal: marking these takes a person; nothing was marked');
            return 0;
        }
        my ($marked, $done) = 0, 0;
        for @ids -> $id {
            .say for unseen-lines($id, %d<items>{$id});
            my $answer = (ask('  Seen? [y/n/q] ') // 'q').trim.lc;
            say '';
            last if $answer.starts-with('q');
            $done++;
            next unless $answer.starts-with('y');
            %d<seen>{$id} = %d<items>{$id}<after_digest>;
            %d<items>{$id}:delete;
            $marked++;
        }
        keep-unseen($root, %d);
        say "Seen $marked, left {+@ids - $marked}. Seeing a change records that you know, not that it is agreed.";
        say next-line("iz4 establish NAME", 'when a promise is agreed') if $marked;
        0;
    }
}

#| Keep what the last verify said, beside the checks record, for any reader
#| that shows it between turns (a status line, a mission control screen):
#| iz4's own words, so no driver rewrites them.  A record that cannot be
#| written never changes the result.
sub record-last(IO::Path $root, %v) {
    my $f = (checks-record($root) // return).parent.add('last.json');
    my $mark = %( pass => '◈', warn => '!', block => '◇', needs_human => '?' ){%v<result>} // '?';
    try {
        $f.parent.mkdir;
        $f.spurt(json-encode(%( schema => 'iz4-last/1', at => DateTime.now.utc.truncated-to('second').Str, tool => %v<tool>,
                                 check => 'verify', result => %v<result>, reason => %v<reason>, mark => $mark,
                                 line => "$mark IZ4: %v<reason>", unseen => +unseen-of($root)<items>.keys,
                                 tree => ((%v<evidence><gate> // {})<candidate> // '') )) ~ "\n");
    }
}

multi MAIN('gate', Bool :$install-hook!, Bool :$enforce = False, Bool :$force = False, Str :$file) {
    attempt {
        my $path = resolve-target($file);
        my $state = install-hook($path, :$force, :hook<pre-commit>, :text(gate-hook-text(:$enforce)),
                                 :mark(GATE-HOOK-MARK), :manual('iz4 gate --staged'));
        say "pre-commit hook: $state (" ~ ($enforce
            ?? 'it asks you at the terminal when a commit changes what the software promises, and holds a commit made by a script or an agent until you have answered'
            !! 'advisory: it tells you what a commit changes and never holds one; --enforce makes it wait for your answer') ~ ')';
        0;
    }
}

multi MAIN('gate', Str :$base, Str :$candidate, Bool :$staged = False, Bool :$enforce = False, Bool :$json = False,
           Bool :$checks = True, Int :$timeout = 300, Str :$check-cmd = %*ENV<IZ4_CHECK_CMD> // Str,
           Str :$approval, Str :$approvers = %*ENV<IZ4_APPROVERS> // Str, Str :$file, Bool :$brief = False, Bool :$ask = False) {
    attempt { gate-command(:$base, :$candidate, :$enforce, :$json, :$checks, :$timeout, :$check-cmd, :$approval, :$approvers, :$file, :$brief, :$ask) }
}

sub gate-command(Str :$base, Str :$candidate, Bool :$enforce, Bool :$json, Bool :$checks, Int :$timeout, Str :$check-cmd,
                 Str :$approval, Str :$approvers, Str :$file, Bool :brief($asked-brief) = False, Bool :$ask = False --> Int) {
    {
        my $root = gate-root($file);
        # Run by Git as a commit hook, the gate speaks as a hook does whatever
        # the hook's own text asks for: silent when nothing needs a person,
        # short when something does.  Git sets GIT_INDEX_FILE for a hook.
        my $brief = $asked-brief || ($enforce && !$json && !$candidate.defined && (%*ENV<GIT_INDEX_FILE> // '') ne '');
        # the command that runs one linked test: the flag, then IZ4_CHECK_CMD,
        # then this repository's own 'git config iz4.checkCmd' (in .git/config,
        # outside every tree, so a candidate cannot set it), then the default
        # for the repository's test language
        my $cmd = $check-cmd // do {
            my ($rc, $out, $) = git($root.add(ROOT-NAME), 'config', '--get', 'iz4.checkCmd');
            $rc == 0 && $out.trim ne '' ?? $out.trim !! Str;
        };
        my %r;
        my $failure = Nil;
        # the title first, so the screen begins with it and the tests' bar runs under it
        my $titled = !$json && !$brief && pretty-on();
        my $what = $candidate.defined ?? "candidate $candidate" !! 'the staged change';
        if $titled { say Screen.new(:command<gate>, :context($what)).title-line; say '' }
        try {
            %r = run-gate($root, :staged(!$candidate.defined), :$base, :$candidate, :$enforce, :$checks, :$timeout,
                          :check-cmd($cmd), :approval-file($approval.defined ?? $approval.IO !! IO::Path),
                          :approvers($approvers.defined ?? $approvers.IO !! IO::Path),
                          # a hook at a terminal shows the one wiped line while tests run; a pipe gets nothing
                          :progress($json || ($brief && !$*OUT.t) ?? Callable !! check-progress()));
            CATCH { default { $failure = $_ } }
        }
        note-unseen($root, %r) if %r && !$candidate.defined;
        with $failure {
            %r = schema => GATE-SCHEMA, outcome => 'error', mode => ($enforce ?? 'enforce' !! 'advisory'),
                 detail => .message, exit_code => 1, next => ('fix the cause above, then run iz4 gate again',).List;
            if $json { say json-encode(%r) } else { note "gate: error - {.message}"; note 'outcome: error - the check could not complete, so this is not a pass' }
            return 1;
        }
        if $json { say json-encode(%r) }
        elsif $brief && %r<outcome> eq 'pass' {
            # nothing for a person to do, so nothing is said, unless something is worth a line
            my $line = brief-line(%r);
            say $line if $line ne '';
        }
        elsif $brief && $ask && $enforce && %r<outcome> eq any(<agreement-required blocked>) && $*ERR.t && '/dev/tty'.IO.r {
            # a person is at the terminal and the hook asks them next: 'iz4 approve' shows the change once
        }
        elsif $brief {
            print hold-screen(%r, (try check-doc($root.add(ROOT-NAME)))).screen;
        }
        else {
            my $again = 'iz4 gate' ~ ($candidate.defined ?? " --candidate=$candidate" !! ' --staged') ~ ($enforce ?? ' --enforce' !! '');
            my $doc = try check-doc($root.add(ROOT-NAME));
            # on a terminal the title went first, so the outcome opens the body; in a pipe the title carries it
            my $sc = gate-screen(%r, :$again, :$what, :domain(($doc andthen .domain) // ''), :order(($doc andthen .invariants.map(*.id).grep(*.defined)) // ()));
            print $sc.screen(:title(!$titled));
        }
        %r<exit_code>;
    }
}

multi MAIN('approve', Str :$base, Str :$candidate, Bool :$staged = False, Str :$sign, Str :$by, Str :$out, Str :$note = '', Str :$file) {
    attempt :intent, { approve-command(:$base, :$candidate, :$sign, :$by, :$out, :$note, :$file) }
}

sub approve-command(Str :$base, Str :$candidate, Str :$sign, Str :$by, Str :$out, Str :$note = '', Str :$file, Bool :$resolved = False --> Int) {
    {
        my $root = gate-root($file);
        user-error("--sign needs --by=YOU, the name the gate knows your key by. Once is enough: it is remembered.") if $sign.defined && !$by.defined;
        # the checks run here too: a person is only ever shown a proposal for a tree that is not blocked
        # the same command the gate runs a linked test with, so both see the same result
        my $cmd = %*ENV<IZ4_CHECK_CMD> // do {
            my ($rc, $o, $) = git($root.add(ROOT-NAME), 'config', '--get', 'iz4.checkCmd');
            $rc == 0 && $o.trim ne '' ?? $o.trim !! Str;
        };
        head('approve', $candidate.defined ?? "candidate $candidate" !! 'the staged change') unless $resolved;
        my %r = run-gate($root, :staged(!$candidate.defined), :$base, :$candidate, :check-cmd($cmd), :progress($resolved ?? Callable !! check-progress()));
        my %p = changes => %r<changes>, protections => %r<protections>;
        if %r<outcome> eq 'blocked' {
            # An invariant whose test fails is not a wall: it is a question for the
            # person, and they can answer it here.  Anything else blocked is shown.
            my @failed  = %r<checks>.grep({ .<outcome> eq 'failed' });
            my $only-tests = !%r<changes>.grep({ .<kind> eq any(<invalid foundation reused-name format-regressed>) });
            if @failed && $only-tests && person-here() && !$candidate.defined && !$resolved {
                return %EXIT-CODE<blocked> unless settle-failed($root, @failed);
                return approve-command(:$base, :$candidate, :$sign, :$by, :$out, :$note, :$file, :resolved);
            }
            say "  $_" for proposal-lines(%p);
            say "  ✗ {.<file>} ({.<invariants>.join(', ')}) failed" ~ (.<detail> ?? ": {.<detail>}" !! '') for @failed;
            say @failed && $only-tests
                ?? "Nothing to agree to yet: an invariant no longer holds. At a terminal, 'iz4 approve' asks which is right, the software or the invariant."
                !! 'Nothing to approve: a blocked finding is not a proposal. Fix it first.';
            return %EXIT-CODE<blocked>;
        }
        unless needs-agreement(%p) {
            say "Nothing needs agreement for candidate tree {%r<candidate>.substr(0, 12)}: no commitment or protection changed.";
            return 0;
        }
        # one thing at a time: each change is its own small question
        my @items = |%r<changes>.map({ %( changes => ($_,), protections => () ) }),
                    |%r<protections>.map({ %( changes => (), protections => ($_,) ) });
        say "$_\n" with behind-main($root, $candidate);
        unless person-here() {
            say "This change alters what the software promises:";
            say "  $_" for proposal-lines(%p);
            say '';
            say 'pending: agreement needs a person. At a terminal, they run:   iz4 approve';
            say 'Nothing was recorded.';
            return %EXIT-CODE<agreement-required>;
        }
        # who signs, found for them: said outright, last time's, or the key of theirs the gate here already trusts
        my %signer = $sign.defined ?? %( key => home-path($sign), by => $by, found => 'as you said' ) !! find-signer($root);
        user-error("there is no key at {%signer<key>}") if %signer && !%signer<key>.f;

        say @items == 1
            ?? 'This change alters what the software promises. Is it what you mean?'
            !! "This change alters what the software promises in {+@items} ways. One at a time:";
        for @items.kv -> $i, %item {
            say '';
            say "{$i + 1} of {+@items}" if @items > 1;
            say "  $_" for proposal-lines(%item);
            my $yes = Bool;
            for ^3 {
                my $said = ask('Is that right? [y/n] ');
                last without $said;                         # end of input: no answer
                my $a = $said.trim.lc;
                $yes = True  if $a.starts-with('y') || $a.starts-with('a');
                $yes = False if $a.starts-with('n') || $a.starts-with('r') || $a.starts-with('v');
                last if $yes.defined;
                say 'Type y if that is what you mean, n if it is not.';
            }
            unless $yes {
                say '';
                say $yes.defined
                    ?? 'Then nothing is agreed and nothing was recorded. Put the IZ4 or its tests the way you mean them, and commit again.'
                    !! 'No answer, so nothing was recorded.';
                return %EXIT-CODE<agreement-required>;
            }
        }
        my $who = %signer<by> // $by // do {
            my ($rc, $o, $) = git($root.add(ROOT-NAME), 'config', 'user.email');
            $rc == 0 && $o.trim ne '' ?? $o.trim !! (%*ENV<USER> // 'someone at this terminal');
        };
        my %snap = repository => %r<repository>, base => (%r<base> eq 'none' ?? Str !! %r<base>), candidate => %r<candidate>;
        my %a = approval-body(%snap, %r<proposal_digest>, :by($who), :method(%signer ?? 'ssh-signature' !! 'terminal'), :$note);
        %a<signature> = sign-approval(%a, %signer<key>) if %signer;
        my $ref = store-approval($root, %a);
        if $out.defined { $out.IO.spurt(json-encode(%a) ~ "\n"); say "approval written to $out" }
        say '';
        if %signer {
            my $how = %signer<found> eq 'as last time' ?? 'the key you used last time'
                   !! %signer<found> eq 'as you said'  ?? 'the key you named'
                   !!                                     "the key {%signer<found>}";
            say pretty("✓ Your yes is recorded, signed by $who with {%signer<key>.subst($*HOME.Str, '~')}, $how.");
        }
        else {
            say pretty("✓ Your yes is recorded by $who, unsigned.");
        }
        say "  It covers this exact change. If the change is edited, you will be asked again.";
        say "  Kept in Git as $ref.";
        $*IZ4-INTENT-CHANGED = True;      # a person agreed to a change of intent: enforcement is made sure of
        unless %signer {
            say '';
            say 'An unsigned yes counts on this machine only. To sign it, say once which key is yours:';
            say '  iz4 approve --sign=KEY --by=YOU      (remembered after that)';
            return 0;
        }
        remember-signer($root, %signer<key>, $who) if %signer<found> eq 'as you said';
        send-approval($root, $ref);
        0;
    }
}

#| A line for a change that main has moved past, or nothing.  An approval
#| covers one exact tree, so agreeing before a rebase means agreeing again
#| after it.  It reads the refs already here and never fetches: a person
#| offline still gets to agree, and a stale ref only makes this say less.
sub behind-main(IO::Path $root, Str $candidate --> Str) {
    my $path = $root.add(ROOT-NAME);
    for <origin/HEAD origin/main main> -> $ref {
        my ($rc, $out, $) = git($path, 'rev-list', '--count', "{$candidate // 'HEAD'}..$ref");
        next unless $rc == 0;
        my $n = $out.trim.Int;
        return Str unless $n;
        return pretty("This change is $n commit{$n == 1 ?? '' !! 's'} behind $ref, and an approval covers this exact tree. Rebase first, or you will be asked again.");
    }
    Str;
}

#| An invariant's test fails: the software and the IZ4 disagree, and only
#| the person knows which is right.  One invariant at a time, one question
#| at a time.  True when the IZ4 was brought into line and staged, so the
#| change can be put to them; False when they will fix the software, or
#| gave no answer.  Nothing is decided for them.
sub settle-failed(IO::Path $root, @failed --> Bool) {
    my $path = $root.add(ROOT-NAME);
    my $changed = False;
    for @failed -> %c {
        my $doc = check-doc($path);
        my @own = %c<invariants>.grep({ $doc.invariant($_).defined });
        unless @own {
            say "{%c<file>} fails, and it stands for the foundation ({%c<invariants>.join(', ')}): that part is the software's to put right.";
            return False;
        }
        for @own -> $id {
            my $inv = $doc.invariant($id);
            say '';
            say pretty("The software and the IZ4 disagree about $id.");
            say '';
            # the promise as its card says it: the heading and the three fields of intention
            my @card = invariant-text($path, $id).lines;
            my $cut  = @card.elems;                   # up to the blank line after PROTECTS: what it requires is not the question here
            my $seen-protects = False;
            for @card.kv -> $i, $l {
                $seen-protects = True if $l ~~ / ^ \h* 'PROTECTS' /;
                if $seen-protects && $l.trim eq '' { $cut = $i; last }
            }
            print pretty(@card[0 ..^ $cut].join("\n") ~ "\n");
            say '';
            say pretty("✗ {%c<file>} fails");
            # what the test said, one line each; its 'not ok' lines first
            my @said = (%c<detail> // '').split(' | ').map(*.trim).grep(* ne '');
            my @loud = @said.grep({ .starts-with('not ok') || .contains('Failed test') });
            say "    $_" for (@loud || @said).head(4);
            say '';
            say 'Which is right?';
            say '  s  the promise: the software should keep it, and I will fix the software';
            say '  i  the software: bring the promise up to date';
            say '  w  neither needs it any more: withdraw the promise';
            my $a = '';
            for ^3 {
                my $said = ask('[s/i/w] ');
                last without $said;
                $a = $said.trim.lc.substr(0, 1);
                last if $a eq any(<s i w>);
                say 'Type s, i or w.';
            }
            given $a {
                when 'i' {
                    my $draft = agent-reachable()
                        ?? (try { say "Asking {agent-label()} what is true of the software now ..."; agent-reword($root, :$id, text => $inv.text, because => ($inv.because // ''), failure => (%c<detail> // '')) })
                        !! Str;
                    say '';
                    if $draft.defined { say 'It could say:'; say "  $draft" }
                    my $said = ask($draft.defined ?? "Enter keeps that; or type the words you mean.\n> " !! "What should it say now?\n> ");
                    return False without $said;
                    my $words = $said.trim eq '' ?? ($draft // '') !! $said.trim;
                    if $words eq '' { say 'No words, so nothing changed.'; return False }
                    revise-invariant($path, $id, $words);
                    git($path, 'add', '--', ROOT-NAME);
                    say '';
                    say pretty("✓ $id now says: $words");
                    # its test checked the old words
                    my $only-this = !$doc.invariants.grep({ .id.defined && .id ne $id && names-identity(($root.add(%c<file>).slurp), .id) });
                    if $only-this && yes-no(ask("{%c<file>} checks the old words. Take it out, so a new one can be written ('iz4 test')? [Y/n] "), :default) {
                        git($path, 'rm', '-q', '-f', '--', %c<file>);
                        say "Removed {%c<file>}.";
                    }
                    $changed = True;
                }
                when 'w' {
                    my %t = withdrawal-tests($path, $doc, $id);
                    withdraw-invariant($path, $id);
                    git($path, 'add', '--', ROOT-NAME);
                    for remove-tests($root, %t<remove>) { git($path, 'add', '-A', '--', $_); say "Removed $_." }
                    say '';
                    say pretty("✓ $id is withdrawn; its name is retired, and Git keeps its words.");
                    $changed = True;
                }
                when 's' {
                    # the one answer that keeps a promise: say so, and say plainly that the software has not caught up yet
                    say '';
                    say pretty("✓ You kept $id. The promise stands; the software has to catch up.");
                    say "  Fix it and commit again: {%c<file>} will say when it holds.";
                    return False;
                }
                default { say 'No answer, so nothing changed.'; return False }
            }
        }
    }
    $changed;
}

#| A signed approval is no use to the gate on the far side until it is
#| there.  Offer to send it, so a person has no second command to find.
sub send-approval(IO::Path $root, Str $ref) {
    my $anchor = $root.add(ROOT-NAME);
    my ($rc, $remotes, $) = git($anchor, 'remote');
    my @remotes = $rc == 0 ?? $remotes.lines.grep(*.trim ne '') !! ();
    return unless @remotes;                       # nowhere to send it: the local gate has it already
    my $remote = @remotes.first('origin') // @remotes[0];
    say '';
    my $said = ask("Send your yes to $remote too, so the check there accepts it? [Y/n] ");
    if !$said.defined || $said.trim.lc.starts-with('n') {
        say "Not sent. When you want it there: git push $remote $ref";
        return;
    }
    my ($prc, $, $perr) = git($anchor, 'push', $remote, $ref);
    say $prc == 0
        ?? pretty("✓ Sent to $remote. Nothing more to do: the commit can go ahead.")
        !! "Could not send it ({$perr.trim.lines.tail // 'git push failed'}). When you can: git push $remote $ref";
}

multi MAIN('badge', Str :$file) {
    attempt {
        my %b = badge-info(resolve-target($file));
        head('badge', 'the card link and badge for your README');
        say "card:  {%b<card>}";
        say "badge: {%b<badge>}";
        say '';
        say 'Markdown (paste into README.md):';
        say %b<markdown>;
        say '';
        say 'HTML:';
        say %b<html>;
        say '';
        say 'The badge is served live by the register and renders the card\'s';
        say 'current evidence; embedding it claims nothing the card cannot back.';
        0;
    }
}

multi MAIN('report', Str :$file, Str :$release, Str :$run-id,
           Bool :$dry-run = False, Bool :$strict = False, Bool :$json = False) {
    attempt {
        my $path   = resolve-target($file);
        my %report = collect-report($path, :$release, :$run-id);
        my $body   = json-encode(%report);
        # the preview for a person names what goes; the document itself is what a program reads (--json)
        if $dry-run {
            return say($body) && 0 if $json || !pretty-on();
            answer('report preview', display-name($path),
                   [pretty(sprintf('%-13s %s', 'revision', %report<revision>.substr(0, 12))),
                    pretty(sprintf('%-13s %s', 'invariants', %report<declaration><invariant_count> // 0)),
                    pretty(sprintf('%-13s %s', 'checks', %report<checks>.pairs.sort.map({ "{.key} {.value<outcome>}" }).join(', '))),
                    pretty(sprintf('%-13s %s', 'digest', (%report<declaration><digest> // '').substr(0, 12)))],
                   para('Evidence only: digests, counts and check outcomes. The text of the IZ4 is never sent.'),
                   [next-line('iz4 report', 'sends it, once registered'), "  iz4 report preview --json   the document itself"]);
            return 0;
        }

        my $url = register-url($path)
            // user-error("not connected to a register; run 'iz4 register' for the steps");
        my $token = token-for($url)
            // user-error("no reporting token; run 'iz4 register' for the steps");

        my ($code, $reply) = submit-report($url, $token, $body);
        if 200 <= $code < 300 {
            say "submitted {%report<report_id>} ({display-name($path)} at {%report<revision>.substr(0, 12)})";
            return 0;
        }
        note $code == 0
            ?? "register unreachable: $reply"
            !! "register answered $code: {$reply.substr(0, 300)}";
        $strict ?? 1 !! 0;   # advisory by design: never blocks a pipeline
    }
}

sub user-error(Str $message) { X::IZ4.new(:$message).throw }
