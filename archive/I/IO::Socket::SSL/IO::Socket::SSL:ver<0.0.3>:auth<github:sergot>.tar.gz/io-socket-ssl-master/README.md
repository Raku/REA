IO::Socket::SSL [![test](https://github.com/sergot/io-socket-ssl/actions/workflows/test.yml/badge.svg)](https://github.com/sergot/io-socket-ssl/actions/workflows/test.yml)
=============

IO::Socket::SSL for Perl 6 using OpenSSL
