IO::Socket::SSL [![Build Status](https://travis-ci.org/sergot/io-socket-ssl.svg)](https://travis-ci.org/sergot/io-socket-ssl)
=============

IO::Socket::SSL for Perl 6 using OpenSSL
