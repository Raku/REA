# Environment Examples

## Table of contents

  * [Nginx + LDAP](#nginx--ldap)

## Nginx + LDAP

Start the environment:

    platform --environment=nginx-ldap.yml run

And now you should have working environment with nginx and ldap authentication. 

Browse to address http://nginx.localhost and use these credentials:

    u: test
    p: t3st


