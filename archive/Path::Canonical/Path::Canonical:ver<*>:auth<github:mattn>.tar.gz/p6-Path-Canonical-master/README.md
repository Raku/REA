[![Build Status](https://travis-ci.org/mattn/p6-Path-Canonical.svg?branch=master)](https://travis-ci.org/mattn/p6-Path-Canonical)

NAME
====

Path::Canonical - blah blah blah

SYNOPSIS
========

    use Path::Canonical;

DESCRIPTION
===========

Path::Canonical is ...

COPYRIGHT AND LICENSE
=====================

Copyright 2015 Yasuhiro Matsumoto <mattn.jp@gmail.com>

This library is free software; you can redistribute it and/or modify it under the Artistic License 2.0.
