#ifndef __FT6_BITMAP_H
#define __FT6_BITMAP_H

#include "ft6.h"
#include FT_BITMAP_H
#include FT_IMAGE_H

#endif /* __FT6_BITMAP_H */
