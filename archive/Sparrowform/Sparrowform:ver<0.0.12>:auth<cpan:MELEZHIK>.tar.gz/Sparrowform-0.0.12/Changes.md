# 0.0.12

Prettifying reports using Perl6 sprintf, part2

# 0.0.11

Prettifying reports using Perl6 sprintf ( this one is cool BTW :)

# 0.0.10

Add seconds elapsed to reports

# 0.0.9

Better path for sparrow root

# 0.0.8

Occasional sleep in the end of the main program is removed

# 0.0.7

Colorful dynamic reports using Terminal::Print and Terminal::ANSIColor

# 0.0.6

Bugfix for multihosts provisioning 

# 0.0.5

Run in "async" mode. Perl6 "promises" are cool, however sparrowdo stdout breaks terminal, so I am forced to go with polling instead 

# 0.0.4

Default Sparrowdo scenario

# 0.0.3

Doc - improved examples

# 0.0.2

Sparrowdo one liners support

# 0.0.1

Just a first version



