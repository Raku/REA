# 0.0.5

Run in "async" mode. Perl6 "promises" are cool, however sparrowdo stdout breaks terminal, so I am forced to go with polling instead 

# 0.0.4

Default Sparrowdo scenario

# 0.0.3

Doc - improved examples

# 0.0.2

Sparrowdo one liners support

# 0.0.1

Just a first version



