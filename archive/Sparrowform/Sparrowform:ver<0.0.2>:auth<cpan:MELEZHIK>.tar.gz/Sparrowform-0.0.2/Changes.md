# 0.0.2

Sparrowdo one liners support

# 0.0.1

Just a first version



