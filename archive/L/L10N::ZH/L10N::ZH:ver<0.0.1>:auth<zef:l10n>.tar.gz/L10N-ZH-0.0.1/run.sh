#!/usr/bin/env bash

# 用该脚本来执行 example/ 中的例子

raku ./bin/taoyuan -Ilib $*
