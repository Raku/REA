[![Actions Status](https://github.com/Raku-L10N/ZH/actions/workflows/linux.yml/badge.svg)](https://github.com/Raku-L10N/ZH/actions) [![Actions Status](https://github.com/Raku-L10N/ZH/actions/workflows/macos.yml/badge.svg)](https://github.com/Raku-L10N/ZH/actions) [![Actions Status](https://github.com/Raku-L10N/ZH/actions/workflows/windows.yml/badge.svg)](https://github.com/Raku-L10N/ZH/actions)

桃源语
===

**桃源语**

用中文惬意地与计算机对话

<br>

安装
==

  * 安装 [Rakudo](https://rakudo.org)

  * 安装 `L10N::ZH` 模块

        $ zef install L10N::ZH

<br>

使用
==

立即执行：

    $ taoyuan -e '述 q/你好，桃源!/'

执行代码文件：

    $ taoyuan ./example/README.taoyuan

代码：

```raku
#!/usr/bin/env taoyuan

类 程序员 {

  属性 $.姓名 = '卡美丽雅';
  属性 @.使用的语言 = <桃源 Raku>;

  方法 主语言 { @.使用的语言[0] }
}

局部 $我 = 程序员.诞生;

输出 Q:c/{$我.姓名}的主力编程语言是: /, $我.主语言;

如果 真 {
  对每个 1..3 -> $几 {
    述 "第{$几}次：你好，世外桃源！";
  }
} 否则 {
    崩溃 "咱们的程序似乎出了点问题";
}
```

<br>

描述
==

`L10N::ZH` 这个包为 Raku 提供了中文支持，具体来说，是桃源语的支持。它会安装一个可执行文件: `taoyuan` ，用户通过它来运行以 桃园语 (中文) 编写的 Raku 代码。

`L10N::ZH` 翻译核心准则
=================

  * 翻译力求本土化，严格遵循中文表达习惯，**摒弃生硬的单词直译**

    比如 `die` 翻译为 **崩溃** 而非 **死**，体现了中文语境下的自然表达

  * 翻译讲究配套连贯，从整体语义考量，确保多个关键词能够形成流畅的表达链

    比如 `when` 直译为 **当**，但在实际使用中，它后面总是跟随具体的值或类型判断，因此翻译为 **若是** 更符合中文的条件判断表达。

    `default` 本意为 **默认**，但在语法结构中它紧跟一串 **若是** 之后，翻译为 **其他情况** 能与前文形成完整的逻辑呼应。

    这种整体性翻译虽然完全摆脱了逐词对译，却达到了出色的本土化表达效果：

    ```raku
    针对 $value {
      若是 "Raku" { " say  'Hi'; " }
      若是 "Ruby" { " puts 'Hi'  " }
      若是 "桃源" { " 述    'Hi'; " }
      其他情况    { "Console.WriteLine('Hi');" }
    }
    ```

  * 翻译力求保持语言的趣味性

    Raku 本身就是一门充满趣味的语言，其英文表达方式处处体现着编程的乐趣。桃源语也应当延续这种特质，让代码读起来生动有趣，而不是拘泥于死板的字面翻译，失去桃源语应有的灵动与活力。

  * 请通过编写测试用例和实际代码示例来验证和完善翻译用语的准确性与实用性

<br>

作者
==

Aoran Zeng <ccmywish@qq.com>

版权和许可协议
=======

Copyright 2025, 2026 Raku Localization Team

该库为自由软件，您可以根据 Artistic License 2.0 对其进行重新分发和修改。

