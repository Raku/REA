# P6-LCS-All
Calculate all possible LCSs (Longest Common Subsequences)
