# P6-LCS-BV
Longest Common Subsequence implemented with Bit-Vectors
