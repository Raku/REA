#ifndef __XSLT6_GBL_H
#define __XSLT6_GBL_H

DLLEXPORT void xslt6_gbl_set_max_depth(int val);
DLLEXPORT void xslt6_gbl_set_max_vars(int val);

#endif /* __XSLT6_GBL_H */
