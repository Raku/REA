#ifndef __XSLT6_CONFIG_H
#define __XSLT6_CONFIG_H

DLLEXPORT int xslt6_config_have_exslt(void);

DLLEXPORT char* xslt6_config_version(void);

#endif /* __XSLT6_CONFIG_H */
