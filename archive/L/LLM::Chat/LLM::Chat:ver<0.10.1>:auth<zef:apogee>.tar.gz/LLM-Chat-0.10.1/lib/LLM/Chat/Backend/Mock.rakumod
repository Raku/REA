=begin pod

=head1 NAME

LLM::Chat::Backend::Mock - Canned-response backend for tests

=head1 SYNOPSIS

=begin code :lang<raku>

use LLM::Chat::Backend::Mock;
use LLM::Chat::Backend::Settings;

# Single canned response
my $mock = LLM::Chat::Backend::Mock.new(
    settings => LLM::Chat::Backend::Settings.new,
    responses => ['hello from the mock backend'],
);

# A sequence — each call pops the next one
my $mock2 = LLM::Chat::Backend::Mock.new(
    settings  => LLM::Chat::Backend::Settings.new,
    responses => [
        'first answer',
        'second answer',
        'third answer',
    ],
);

# Streaming: tokens arrive split by whitespace (default).
# Customise with :token-splitter if you want per-character streaming or
# a specific token boundary.
my $stream = $mock2.chat-completion-stream(@messages);
react {
    whenever $stream.supply -> $token {
        print $token;
    }
    whenever $stream.supply.done { say "done" }
}

=end code

=head1 DESCRIPTION

Non-network backend for use in tests. Returns pre-configured responses
in order — one response per C<chat-completion>/C<text-completion> call.
When the queue is exhausted, subsequent calls either repeat the last
response (default) or fail (C<:fail-on-empty>).

For streaming calls, the response is split into tokens and emitted
through the normal C<Supplier> path. By default each whitespace-
separated word becomes a token; override C<:token-splitter> for
finer-grained control (per-character streaming, specific tokenisation,
etc.).

B<Not safe for production use.> Doesn't talk to any real model; any
parameter in C<Settings> is ignored (temperature, top_p, stop, etc.).
Only the raw text in C<responses> gets returned.

=head1 ATTRIBUTES

=item C<@.responses> — array of Str, one per expected call.
=item C<$.fail-on-empty> — when True, calling beyond the queue fails instead of repeating the last response. Default False.
=item C<$.stream-delay> — seconds between tokens in streaming mode. Default 0 (emit as fast as possible).
=item C<&.token-splitter> — sub that takes a Str and returns a list of tokens. Default splits on whitespace and preserves spacing by re-appending a space after each token except the last.
=item C<&.error-producer> — optional C<(Int $call-index --> Hash)> callback. When it returns a defined hash, that call is scripted to fail. Used to exercise the Task fallback policy. See L</SIMULATING FAILURES>.
=item C<&.finish-reason-producer> — optional C<(Int $call-index --> Str)> callback. A defined Str return is stamped on the Response as its C<finish-reason> while the call still succeeds — the way a real blocking completion reports C<'length'>. See L</SIMULATING TRUNCATION>.
=item C<$.call-index> — monotonically-increasing per-backend call count, bumped on every completion call whether it succeeded or failed. Distinct from the internal response cursor — tests can read this to assert call counts without reasoning about the response queue.
=item C<$.response-class> — class minted for non-streaming completion calls. Defaults to L<LLM::Chat::Backend::Response>; pass L<LLM::Chat::Backend::Response::OpenRouter> to exercise the OR-flavoured Response shape.
=item C<$.stream-response-class> — streaming counterpart to C<$.response-class>. Pair with L<LLM::Chat::Backend::Response::OpenRouter::Stream>.
=item C<%.fake-usage> — per-call usage payload. OAI-spec keys (C<prompt>, C<completion>, C<total>, C<model>, C<reasoning>) flow into C<._set-usage>; OR-specific keys (C<cost>, C<generation-id>, C<provider-name>, C<is-byok>) flow into C<._set-or-usage> when the configured response class consumes the OR Augment role.
=item C<$.fake-reasoning> — optional thinking trace put on every response's C<reasoning-text> (never its content), as a reasoning model's C<reasoning_content> would be.
=item C<%.server-limits> — what C<probe-server-limits> answers (a copy). Empty by default, which answers like a backend that cannot ask its server: C<{source => 'none', note => ...}>.

=head1 SIMULATING FAILURES

Pass C<&.error-producer> to script per-call failures. Every
C<chat-completion> invocation calls it with the 0-based call index.
Returning a defined hash fails the call; returning C<Nil> (or an
undefined value) lets the call proceed normally through the
C<@.responses> queue.

=begin code :lang<raku>

# Fail the first two calls with retryable errors, succeed on the third
my $mock = LLM::Chat::Backend::Mock.new(
    settings  => LLM::Chat::Backend::Settings.new,
    responses => ['finally'],
    error-producer => -> $i {
        when $i == 0 { { class => 'connection', message => 'ECONNRESET' } }
        when $i == 1 { { class => 'http', status => 503, message => 'bad gateway' } }
        default      { Nil }
    },
);

=end code

Recognised C<class> values match the Response error classification:
C<'http'> (with numeric C<status>), C<'timeout'>, C<'connection'>,
C<'response'> (malformed / empty body / finish-reason failure), and
C<'unknown'>. Failed calls DO NOT consume a slot from C<@.responses>,
so the queue addresses only the successful calls regardless of where
failures fire.

=head1 SIMULATING TRUNCATION

A real B<blocking> completion that runs out of completion budget does
not fail: it returns HTTP 200 with a perfectly well-formed body, a
partial C<content>, and C<finish_reason> C<'length'>. Callers only
learn the output was cut off by reading C<$response.finish-reason>.
C<&.finish-reason-producer> reproduces exactly that shape.

The callback receives the 0-based per-backend call index (the same
index C<&.error-producer> sees) and returns either a Str — stamped on
the Response via C<_set-finish-reason> before the emission task starts,
so it is readable the instant the caller has the Response — or an
undefined value, which leaves C<finish-reason> unset (the historical
Mock shape).

=begin code :lang<raku>

# First call comes back truncated, second one is clean.
my $mock = LLM::Chat::Backend::Mock.new(
    settings  => LLM::Chat::Backend::Settings.new,
    responses => ['{"beats": [{"first": 0,', '{"beats": []}'],
    finish-reason-producer => -> $i { $i == 0 ?? 'length' !! Str },
);

my $first = $mock.chat-completion(@messages);
await $first.supply;                 # succeeds — 200 with a partial body
is $first.finish-reason, 'length';   # ... but the body was cut off

=end code

Two deliberate limits:

=item The truncated call still B<succeeds>. C<is-success> stays True and C<.msg> holds whatever C<@.responses> supplied — that is the point, since it is what a real backend does. Use C<&.error-producer> when you want the call to fail outright.
=item C<&.error-producer> B<wins>. When both callbacks fire on the same index the call is scripted to fail and no finish reason is stamped, because a failed call never produced a body to have a finish reason for.

The knob is wired into the non-streaming paths only
(C<chat-completion>, and C<text-completion> through its delegation).
The streaming paths already surface finish reasons the way the real
backends do — a C<'length'> chunk quits the stream with error class
C<'response'> — so scripting one there would contradict the transport
being modelled. Tests that need a truncated B<stream> should exercise
C<LLM::Chat::Backend::OpenAICommon> against a canned SSE body instead
(see C<t/19-length-finish-stream.rakutest>).

=head1 RECORDING CALLS

Every completion call is appended to C<@.recorded-calls> as a hash with:

=item C<kind> — 'chat-completion', 'chat-completion-stream', 'text-completion', or 'text-completion-stream'
=item C<messages> — the C<@messages> array that was passed in
=item C<tools> — the C<@tools> array (empty if none were passed)
=item C<continuation> — for text-completion only, the flag value
=item C<response> — the Str that was returned
=item C<at> — Instant when the call was made

Tests can assert on what reached the backend rather than just what came
back. Typical pattern:

=begin code :lang<raku>

my $mock = LLM::Chat::Backend::Mock.new(
    settings  => LLM::Chat::Backend::Settings.new,
    responses => ['ok'],
);

# ... code under test calls $mock.chat-completion-stream(@msgs) ...

is $mock.recorded-calls.elems, 1, 'one call';
is $mock.recorded-calls[0]<kind>, 'chat-completion-stream';
is $mock.recorded-calls[0]<messages>[0].role, 'system', 'first message is system prompt';
is $mock.recorded-calls[0]<messages>[*-1].content, 'hello', 'last message is user turn';

=end code

Use C<clear-recorded-calls> to reset the log between phases of a test.

=end pod

use LLM::Chat::Backend;
use LLM::Chat::Backend::Response;
use LLM::Chat::Backend::Response::Stream;
use LLM::Chat::Backend::Response::OpenRouter;
use LLM::Chat::Backend::Response::OpenRouter::Stream;
use LLM::Chat::Conversation::Message;

use UUID::V4;

unit class LLM::Chat::Backend::Mock is LLM::Chat::Backend;

has Str @.responses is rw;
has Bool $.fail-on-empty = False;
has Numeric $.stream-delay = 0;

#|( Response class minted for non-streaming completion calls. Defaults
    to the base C<LLM::Chat::Backend::Response>; pass
    C<:response-class(LLM::Chat::Backend::Response::OpenRouter)> to
    exercise the OpenRouter-flavoured Response shape (cost,
    generation-id, provider-name, is-byok) end-to-end in tests. )
has Mu $.response-class = LLM::Chat::Backend::Response;

#|( Streaming counterpart to C<$.response-class>. Defaults to
    C<LLM::Chat::Backend::Response::Stream>; pair with
    C<LLM::Chat::Backend::Response::OpenRouter::Stream> when testing
    OR-flavoured streaming. )
has Mu $.stream-response-class = LLM::Chat::Backend::Response::Stream;

#|( Optional per-call usage payload. When non-empty, every
    completion call applies it to the freshly-minted Response so
    telemetry tests can assert on a concrete shape.

    OAI-spec keys (C<prompt>, C<completion>, C<total>, C<model>,
    C<reasoning>) flow into C<Response._set-usage>. OR-specific keys (C<cost>,
    C<generation-id>, C<provider-name>, C<is-byok>) flow into
    C<Response::OpenRouter::Augment._set-or-usage> when
    C<$.response-class> is OR-typed and are silently ignored
    otherwise. Left empty by default so non-telemetry tests
    don't drift. )
has %.fake-usage;

#|( What C<probe-server-limits> answers, verbatim (a copy). Empty (the
    default) answers like a backend that cannot ask its server. )
has %.server-limits;

#|( Optional thinking trace attached to every successful response, as a
    reasoning model's C<reasoning_content> would be: readable on
    C<reasoning-text>, never part of the emitted content. )
has Str $.fake-reasoning;

#|( Optional prompt-aware responder. When set, each call invokes
    C<&responder(@messages)>; a defined Str return value is used
    as the response, while an undefined return falls through to
    the FIFO C<@.responses> cursor path. Lets tests mix the two
    modes: intercept specific call shapes (e.g. a per-kind LoreScan
    dispatch arriving in non-deterministic order) while letting
    the rest of the pipeline consume canned responses positionally. )
has &.responder;

#|( Optional failure-producer for fallback / retry tests. Called with
    the 0-based per-backend call index (C<$.call-index> before the
    increment). A defined Hash return flags this call as failed; an
    undefined return proceeds normally. Expected hash shape:
      * C<class>   — one of 'http', 'timeout', 'connection', 'response',
                     'unknown'. Required. Stored on the Response via
                     C<_set-error-info>.
      * C<status>  — Int HTTP status code. Optional (relevant when
                     C<class eq 'http'>).
      * C<message> — Str failure message passed to C<$response.quit>.
                     Optional; defaults to "Mock error".
    Failed calls DO NOT consume a slot from C<@.responses>, so tests
    can cleanly interleave scripted errors with scripted successes. )
has &.error-producer;

#|( Optional finish-reason producer for truncation tests. Called with
    the same 0-based per-backend call index C<&.error-producer> sees.
    A defined Str return is stamped on the Response via
    C<_set-finish-reason> BEFORE the emission task is started, so a
    caller holding the Response can read it without racing the
    emission; an undefined return leaves C<finish-reason> unset.

    Unlike C<&.error-producer> this does NOT fail the call — it
    reproduces the shape of a real blocking completion that ran out of
    completion budget: HTTP 200, a well-formed but partial body, and
    C<finish_reason> 'length'. The canned response slot is consumed
    exactly as it would be for any other success, so the queue keeps
    addressing calls positionally.

    A scripted error WINS over a scripted finish reason: when both
    producers fire on the same index the call fails and no reason is
    stamped, because a failed call never produced a body. Wired into
    the non-streaming paths only — see the SIMULATING TRUNCATION
    section of the POD for why. )
has &.finish-reason-producer;

# Serialises cursor advancement + recorded-calls appends so concurrent
# callers (e.g. a WorkerPool hitting the mock from N threads) can't race
# on the SELECT-MAX-then-INSERT-style sequence in !next-response or
# produce interleaved @!recorded-calls entries.
has Lock $!mock-lock = Lock.new;

#| Log of every completion call this backend handled. Inspect in tests
#| to assert on what the code under test sent to inference. See the
#| RECORDING CALLS section of the POD for the hash shape.
has @.recorded-calls;
#| Delay before the first emission, in seconds. Default 10ms — gives
#| async callers time to attach their taps before tokens start flowing,
#| mirroring the network latency a real backend introduces. Set to 0
#| for tests that consume .msg after waiting for done, where tap
#| attachment order doesn't matter.
has Numeric $.initial-delay = 0.01;
has &.token-splitter = &default-splitter;

# Track which canned response is next.
has UInt $!cursor = 0;
# Monotonically-increasing call index (0-based), incremented on every
# completion call regardless of whether it succeeds, fails, or is
# intercepted by the responder. Distinct from C<$!cursor>, which only
# advances on successful canned-response consumption — that split lets
# C<&.error-producer> address specific call numbers without the
# response queue shifting underneath it.
has UInt $.call-index = 0;
# Remember cancellations so late-emitting streams skip.
has %!cancelled;

sub default-splitter(Str $text --> List) {
	return ('',) unless $text.chars;
	# Split on whitespace, keep the trailing space on each token so the
	# reassembled stream is character-identical to the input.
	my @words = $text.split(/\s+/, :skip-empty);
	my @out;
	for @words.kv -> $i, $w {
		@out.push: $w ~ (($i == @words.end) ?? '' !! ' ');
	}
	@out.List;
}

method !next-response(--> Str) {
	$!mock-lock.protect: {
		if $!cursor >= @!responses.elems {
			die 'Mock backend: canned responses exhausted' if $!fail-on-empty;
			# Repeat last
			return @!responses ?? @!responses[*-1] !! '';
		}
		my $r = @!responses[$!cursor];
		$!cursor++;
		$r;
	}
}

#| The raw text that will be returned by the next completion call.
#| Useful for assertions in tests that want to know "what's about to
#| be returned" without popping the queue.
method peek-next-response(--> Str) {
	return @!responses[$!cursor] if $!cursor < @!responses.elems;
	@!responses ?? @!responses[*-1] !! '';
}

#| Reset the response cursor to the start of the queue.
method reset() { $!cursor = 0 }

#| C<%.server-limits> when set, else the base "reports nothing" answer.
#| No network: the mock has no server to ask.
method probe-server-limits(--> Hash:D) {
	return callsame() unless %!server-limits.elems;
	%!server-limits.Hash.clone;
}

# OAI-spec keys go to base Response._set-usage; everything else is
# treated as an OR-augment key. Centralised so chat / stream paths
# both apply fake-usage identically.
my constant @OAI-USAGE-KEYS = <prompt completion total model reasoning>;

#|( Apply C<%.fake-usage> to a freshly-minted Response. Splits keys:
    OAI-spec into C<._set-usage>, OR extras into C<._set-or-usage>
    when the Response consumes the OR Augment role. Anything that
    doesn't match either bucket is silently dropped. )
method !apply-fake-usage($resp) {
	$resp._append-reasoning($!fake-reasoning) if $!fake-reasoning.defined && $!fake-reasoning.chars;
	return unless %!fake-usage.elems;
	my %oai;
	my %or;
	for %!fake-usage.kv -> $k, $v {
		if $k eq any(@OAI-USAGE-KEYS) {
			%oai{$k} = $v;
		} else {
			%or{$k} = $v;
		}
	}
	$resp._set-usage(|%oai) if %oai.elems;
	if %or.elems && $resp ~~ LLM::Chat::Backend::Response::OpenRouter::Augment {
		$resp._set-or-usage(|%or);
	}
}

#| Empty the recorded-calls log. Call between test phases when you
#| want to assert on calls from a specific window of activity.
method clear-recorded-calls() { @!recorded-calls = () }

# --- Non-streaming: emit whole response, mark done --------------------

method chat-completion(
	@messages where all(@messages) ~~ LLM::Chat::Conversation::Message,
	:@tools,
	--> LLM::Chat::Backend::Response
) {
	my $id = uuid-v4;
	my $resp = $!response-class.new(:$id, supplier => Supplier.new);
	self!apply-fake-usage($resp);

	# Capture the call index BEFORE running the error-producer so
	# the producer sees the same index the recorded-calls entry
	# will carry. Incremented unconditionally so failed calls still
	# bump the counter.
	my $this-index;
	$!mock-lock.protect: {
		$this-index = $!call-index;
		$!call-index++;
	}

	my $err-info;
	if &!error-producer.defined {
		$err-info = &!error-producer($this-index);
	}

	if $err-info.defined && ($err-info<class>:exists) {
		# Scripted failure. Match OpenAICommon's pattern: populate
		# structured error info before quitting the supplier so the
		# Task fallback policy can classify the failure.
		my $cls = $err-info<class>;
		my $sts = $err-info<status>:exists ?? $err-info<status>.Int !! Int;
		my $msg = $err-info<message>:exists ?? $err-info<message> !! 'Mock error';
		$resp._set-error-info(class => $cls, status => $sts);

		$!mock-lock.protect: {
			@!recorded-calls.push: {
				kind       => 'chat-completion',
				messages   => @messages.clone,
				tools      => @tools.clone,
				response   => Nil,
				error      => { class => $cls, status => $sts, message => $msg },
				call-index => $this-index,
				at         => now,
			};
		}

		my $delay = $!initial-delay;
		start {
			sleep $delay if $delay > 0;
			$resp.supplier.quit($msg);
		}

		return $resp;
	}

	# Not an error: a real blocking completion that exhausts its
	# completion budget returns 200 with a partial body and
	# finish_reason 'length'. Stamped before the emission task starts
	# so callers can read it the moment they hold the Response. Only
	# reached when the error-producer declined this call — a scripted
	# failure wins.
	if &!finish-reason-producer.defined {
		my $reason = &!finish-reason-producer($this-index);
		$resp._set-finish-reason($reason) if $reason.defined;
	}

	my $text;
	if &!responder.defined {
		$text = &!responder(@messages);
	}
	$text //= self!next-response;

	$!mock-lock.protect: {
		@!recorded-calls.push: {
			kind       => 'chat-completion',
			messages   => @messages.clone,
			tools      => @tools.clone,
			response   => $text,
			call-index => $this-index,
			at         => now,
		};
	}

	# Emit asynchronously after a short delay so consumers have time
	# to attach taps — mirrors network latency in real backends.
	my $delay = $!initial-delay;
	start {
		sleep $delay if $delay > 0;
		$resp.supplier.emit($text);
		$resp.supplier.done;
	}

	$resp;
}

method text-completion(
	@messages where all(@messages) ~~ LLM::Chat::Conversation::Message,
	Bool $continuation = False,
	--> LLM::Chat::Backend::Response
) {
	# Delegate to chat-completion for the emission mechanics, but
	# overwrite the recorded-call kind so tests can distinguish the
	# two code paths.
	my $resp = self.chat-completion(@messages);
	@!recorded-calls[*-1]<kind>         = 'text-completion';
	@!recorded-calls[*-1]<continuation> = $continuation;
	$resp;
}

# --- Streaming: tokenise response and emit with optional delay --------

method chat-completion-stream(
	@messages where all(@messages) ~~ LLM::Chat::Conversation::Message,
	:@tools,
	--> LLM::Chat::Backend::Response::Stream
) {
	my $id = uuid-v4;
	my $resp = $!stream-response-class.new(:$id, supplier => Supplier.new);
	self!apply-fake-usage($resp);
	my $text;
	if &!responder.defined {
		$text = &!responder(@messages);
	}
	$text //= self!next-response;
	my @tokens = &!token-splitter($text);
	my $delay  = $!stream-delay;
	my %cancelled := %!cancelled;

	$!mock-lock.protect: {
		@!recorded-calls.push: {
			kind     => 'chat-completion-stream',
			messages => @messages.clone,
			tools    => @tools.clone,
			response => $text,
			at       => now,
		};
	}

	my $initial = $!initial-delay;
	start {
		sleep $initial if $initial > 0;
		for @tokens -> $tok {
			last if %cancelled{$id};
			$resp.supplier.emit($tok);
			sleep $delay if $delay > 0;
		}
		# If we were cancelled, the caller's cancel() path closes the
		# supplier with quit(). Don't also call done() — that'd be a
		# double-close and the supplier would throw on the second one.
		$resp.supplier.done unless %cancelled{$id};
	}

	$resp;
}

method text-completion-stream(
	@messages where all(@messages) ~~ LLM::Chat::Conversation::Message,
	Bool $continuation = False,
	--> LLM::Chat::Backend::Response::Stream
) {
	my $resp = self.chat-completion-stream(@messages);
	@!recorded-calls[*-1]<kind>         = 'text-completion-stream';
	@!recorded-calls[*-1]<continuation> = $continuation;
	$resp;
}

method cancel(LLM::Chat::Backend::Response $resp) {
	%!cancelled{$resp.id} = True;
	$resp.cancel;
}
