[![Actions Status](https://github.com/Raku-L10N/L10N-Complete/actions/workflows/linux.yml/badge.svg)](https://github.com/Raku-L10N/L10N-Complete/actions) [![Actions Status](https://github.com/Raku-L10N/L10N-Complete/actions/workflows/macos.yml/badge.svg)](https://github.com/Raku-L10N/L10N-Complete/actions) [![Actions Status](https://github.com/Raku-L10N/L10N-Complete/actions/workflows/windows.yml/badge.svg)](https://github.com/Raku-L10N/L10N-Complete/actions)

NAME
====

L10N-Complete - All official localizations of Raku

SYNOPSIS
========

```raku
# There is no specific code to execute
```

DESCRIPTION
===========

L10N::Complete is a distribution that, when installed, will install all official localizations of the Raku Programming Language, as well as any support distributions, as its dependencies.

It will not install anything else.

LOCALIZATIONS
=============

These most up-to-date localizations will be installed:

  * [Afrikaans](https://raku.land/zef:habere-et-dispertire/L10N::AF)

  * [Dutch](https://raku.land/zef:l10n/L10N::NL)

  * [Esbelando, Esperanto](https://raku.land/zef:l10n/L10N::EO)

  * [French](https://raku.land/zef:l10n/L10N::FR)

  * [German](https://raku.land/zef:l10n/L10N::DE)

  * [Hungarian](https://raku.land/zef:l10n/L10N::HU)

  * [Italian](https://raku.land/zef:l10n/L10N::IT)

  * [Japanese](https://raku.land/zef:l10n/L10N::JA)

  * [Latvian](https://raku.land/zef:ash/L10N::LV)

  * [Portuguese](https://raku.land/zef:l10n/L10N::PT)

  * [Russian](https://raku.land/zef:ash/L10N::RU)

  * [Spanish](https://raku.land/zef:l10n/L10N::ES)

  * [TaoYuan, Chinese](https://raku.land/zef:l10n/L10N::ZH)

  * [Ukrainian](https://raku.land/zef:ash/L10N::UK)

  * [Welsh](https://raku.land/zef:l10n/L10N::CY)

AUTHOR
======

Elizabeth Mattijsen <liz@raku.rocks>

COPYRIGHT AND LICENSE
=====================

Copyright 2025, 2026 Raku Localization Team

This library is free software; you can redistribute it and/or modify it under the Artistic License 2.0.

