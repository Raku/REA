#ifndef __XML6_CONFIG_H
#define __XML6_CONFIG_H

#include <libxml/xmlversion.h>

DLLEXPORT char* xml6_config_version(void);

#endif /* __XML6_CONFIG_H */
