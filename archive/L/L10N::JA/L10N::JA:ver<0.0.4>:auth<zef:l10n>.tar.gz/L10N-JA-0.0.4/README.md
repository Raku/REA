[![Actions Status](https://github.com/Raku-L10N/JA/actions/workflows/linux.yml/badge.svg)](https://github.com/Raku-L10N/JA/actions) [![Actions Status](https://github.com/Raku-L10N/JA/actions/workflows/macos.yml/badge.svg)](https://github.com/Raku-L10N/JA/actions) [![Actions Status](https://github.com/Raku-L10N/JA/actions/workflows/windows.yml/badge.svg)](https://github.com/Raku-L10N/JA/actions)

NAME
====

L10N::JA - Japanese localization of Raku

SYNOPSIS
========

    $ ryuu -e '言う "こんにちは世界"'
    こんにちは世界

```raku
# Must have RAKUDO_RAKUAST=1 environment variable set
# when running a Rakudo older than the 2026.09 release
use L10N::JA;
言う "こんにちは世界";
```

DESCRIPTION
===========

The `L10N::JA` distribution contains the logic to provide a Japanese localization of the Raku Programming Language. It installs a `ryuu` executable that will automatically activate the Japanese localization. And it allows one to use the Japanese localization in selected programs with a `use L10N::JA` statement.

REFERENCES
==========

[Ryuu - a Japanese dragon](https://dev.to/finanalyst/ryuu-a-japanese-dragon-2e7m)

AUTHORS
=======

Richard Hainsworth <rnhainsworth@gmail.com>

COPYRIGHT AND LICENSE
=====================

Copyright 2024, 2025, 2026 Raku Localization Team

This library is free software; you can redistribute it and/or modify it under the Artistic License 2.0.

