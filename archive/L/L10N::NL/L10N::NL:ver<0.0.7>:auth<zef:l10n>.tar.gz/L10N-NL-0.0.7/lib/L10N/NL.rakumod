# This file contains the Dutch Slang of the Raku Programming Language

#- start of generated part of localization ------------------------------------
#- Generated on 2026-09-26T09:08:58+02:00 by update-localization.raku
#- PLEASE DON'T CHANGE ANYTHING BELOW THIS LINE

role L10N::NL {
    use experimental :rakuast;
    token block-default { standaard}
    token block-else { anders}
    token block-elsif { andersals}
    token block-for { vooralle}
    token block-given { gegeven}
    token block-if { als}
    token block-loop { lus}
    token block-orwith { ofmet}
    token block-repeat { herhaal}
    token block-unless { tenzij}
    token block-until { totdat}
    token block-when { indien}
    token block-whenever { zodra}
    token block-while { zolang}
    token block-with { met}
    token block-without { zonder}
    token constraint-where { waarbij}
    token enum-BigEndian { BigEndian}
    token enum-Broken { Gebroken}
    token enum-False { Onwaar}
    token enum-FileChanged { BestandVeranderd}
    token enum-FileRenamed { BestandHernoemd}
    token enum-Kept { Gehouden}
    token enum-Less { Minder}
    token enum-LittleEndian { LittleEndian}
    token enum-More { Meer}
    token enum-NativeEndian { NativeEndian}
    token enum-Planned { Beloofd}
    token enum-Same { Zelfde}
    token enum-SeekFromBeginning { SeekFromBeginning}
    token enum-SeekFromCurrent { SeekFromCurrent}
    token enum-SeekFromEnd { SeekFromEnd}
    token enum-True { Waar}
    token infix-pcontp { "(bevat)"}
    token infix-pelemp { "(element)"}
    token infix-cff { "^ff"}
    token infix-cffc { "^ff^"}
    token infix-cfff { "^fff"}
    token infix-cfffc { "^fff^"}
    token infix-after { na}
    token infix-and { en}
    token infix-andthen { endan}
    token infix-before { voor}
    token infix-but { maar}
    token infix-cmp { vergelijk}
    token infix-coll { coll}
    token infix-div { deel}
    token infix-does { doet}
    token infix-eq { ge}
    token infix-eqv { eqv}
    token infix-ff { ff}
    token infix-ffc { "ff^"}
    token infix-fff { fff}
    token infix-fffc { "fff^"}
    token infix-gcd { gcd}
    token infix-ge { gg}
    token infix-gt { gt}
    token infix-lcm { lcm}
    token infix-le { kg}
    token infix-leg { kgg}
    token infix-lt { kn}
    token infix-max { max}
    token infix-min { min}
    token infix-minmax { minmax}
    token infix-mod { modulo}
    token infix-ne { ongelijk}
    token infix-notandthen { nietendan}
    token infix-o { o}
    token infix-or { of}
    token infix-orelse { ofanders}
    token infix-unicmp { unicmp}
    token infix-x { x}
    token infix-X { X}
    token infix-xor { xor}
    token infix-xx { xx}
    token infix-Z { R}
    token meta-R { O}
    token meta-X { X}
    token meta-Z { R}
    token modifier-for { vooralle}
    token modifier-given { gegeven}
    token modifier-if { als}
    token modifier-unless { tenzij}
    token modifier-until { tot}
    token modifier-when { indien}
    token modifier-while { terwijl}
    token modifier-with { met}
    token modifier-without { zonder}
    token multi-multi { multi}
    token multi-only { alleen}
    token multi-proto { proto}
    token package-class { klasse}
    token package-grammar { grammatica}
    token package-module { module}
    token package-package { pakket}
    token package-role { rol}
    token phaser-BEGIN { BEGIN}
    token phaser-CATCH { VANGFOUT}
    token phaser-CHECK { CHECK}
    token phaser-CLOSE { CLOSE}
    token phaser-CONTROL { VANGBERICHT}
    token phaser-DOC { DOC}
    token phaser-END { EINDE}
    token phaser-ENTER { BINNENKOMST}
    token phaser-FIRST { EERSTE}
    token phaser-INIT { INITIALISATIE}
    token phaser-KEEP { ACCEPTEER}
    token phaser-LAST { LAATSTE}
    token phaser-LEAVE { AFSCHEID}
    token phaser-NEXT { VOLGENDE}
    token phaser-POST { ACHTERAF}
    token phaser-PRE { VOORAF}
    token phaser-QUIT { STOP}
    token phaser-UNDO { NEGEER}
    token prefix-not { niet}
    token prefix-so { wel}
    token quote-lang-m { m}
    token quote-lang-ms { ms}
    token quote-lang-q { q}
    token quote-lang-Q { Q}
    token quote-lang-qq { dq}
    token quote-lang-rx { rx}
    token quote-lang-s { s}
    token quote-lang-S { S}
    token quote-lang-ss { ss}
    token quote-lang-Ss { Ss}
    token routine-method { methode}
    token routine-regex { regex}
    token routine-rule { regel}
    token routine-sub { functie}
    token routine-submethod { submethode}
    token routine-token { token}
    token scope-anon { anoniem}
    token scope-augment { verbeter}
    token scope-constant { constant}
    token scope-has { heeft}
    token scope-HAS { HEEFT}
    token scope-my { mijn}
    token scope-our { onze}
    token scope-state { steeds}
    token scope-unit { eenheid}
    token stmt-prefix-also { eveneens}
    token stmt-prefix-do { doe}
    token stmt-prefix-eager { vlijtig}
    token stmt-prefix-gather { verzamel}
    token stmt-prefix-hyper { hyper}
    token stmt-prefix-lazy { lui}
    token stmt-prefix-quietly { stilletjes}
    token stmt-prefix-race { race}
    token stmt-prefix-react { reageer}
    token stmt-prefix-sink { zink}
    token stmt-prefix-start { start}
    token stmt-prefix-supply { lever}
    token stmt-prefix-try { probeer}
    token term-nano { nano}
    token term-now { nu}
    token term-pi { pi}
    token term-rand { willekeurig}
    token term-self { zelf}
    token term-tau { tau}
    token term-time { tijd}
    token traitmod-does { doet}
    token traitmod-handles { begrijpt}
    token traitmod-hides { verbergt}
    token traitmod-is { is}
    token traitmod-of { netals}
    token traitmod-returns { "geeft-terug"}
    token traitmod-trusts { vertrouwt}
    token typer-enum { enum}
    token typer-subset { subset}
    token use-import { importeer}
    token use-need { "heeft-nodig"}
    token use-no { geen}
    token use-require { vereist}
    token use-use { gebruik}
    method core2ast {
        my constant %mapping = "bekeken", "accessed", "acties", "actions", "voeg-toe", "add", "alle", "all", "antipaar", "antipair", "antiparen", "antipairs", "elke", "any", "voeg-achteraan", "append", "wacht-op", "await", "tas", "bag", "geef-op", "bail-out", "basis", "base", "zegen", "bless", "kan-ok", "can-ok", "categoriseer", "categorize", "plafond", "ceiling", "letters", "chars", "kap-regeleinde", "chomp", "kap", "chop", "als-letter", "chr", "als-letters", "chrs", "classificeer", "classify", "sluit", "close", "kam", "comb", "combinaties", "combinations", "bevat", "contains", "kruis", "cross", "dag-van-week", "day-of-week", "dag-van-jaar", "day-of-year", "dagen-in-maand", "days-in-month", "dagen-in-jaar", "days-in-year", "dd-mm-jjjj", "dd-mm-yyyy", "decodeer", "decode", "diep-arrangeer", "deepmap", "gedefinieerd", "defined", "sterf", "die", "sterft-ok", "dies-ok", "doet-ok", "does-ok", "klaar", "done", "duik-arrangeer", "duckmap", "gretig", "eager", "eerder", "earlier", "elementen", "elems", "zend", "emit", "codeer", "encode", "einde", "end", "eindigt-met", "ends-with", "eval-sterft-ok", "eval-dies-ok", "eval-leeft-ok", "eval-lives-ok", "verlaat", "exit", "extensie", "extension", "faal", "fail", "faalt-als", "fails-like", "vouw-kast", "fc", "eerste", "first", "plat", "flat", "draaiom", "flip", "vloer", "floor", "gezakt", "flunk", "formatteer", "fmt", "van", "from", "pak", "get", "pakc", "getc", "kern", "gist", "grijp", "grab", "grijp-paren", "grabpairs", "filter", "grep", "hoofd", "head", "indenteer", "indent", "inverteer", "invert", "is-ongeveer", "is-approx", "is-helemaal", "is-deeply", "is-priem", "is-prime", "is-een-ok", "isa-ok", "isniet", "isnt", "plak", "join", "sleutel", "key", "sleutels", "keys", "sw", "kv", "laatste", "last", "laatste-aanroep", "lastcall", "onder-kast", "lc", "lijkt-op", "like", "regels", "lines", "koppeling", "link", "lijst", "list", "leeft-ok", "lives-ok", "minst-significante-bit", "lsb", "gemaakt", "made", "maak", "make", "arrangeer", "map", "maak-map", "mkdir", "mm-dd-jjjj", "mm-dd-yyyy", "verplaats", "move", "meest-significante-bit", "msb", "nieuw", "new", "volgende", "next", "niet-ok", "nok", "geen", "none", "niet", "not", "merk-op", "note", "één", "one", "als-getal", "ord", "als-getallen", "ords", "paar", "pair", "paren", "pairs", "ouder", "parent", "ontleed", "parse", "ontleed-nummer", "parse-base", "geslaagd", "pass", "pad", "path", "permutaties", "permutations", "kies", "pick", "verwacht", "plan", "floep", "pop", "voeg-voor", "prepend", "druk-af", "print", "druk-af-formaat", "printf", "ga-door", "proceed", "produceer", "produce", "vraag", "prompt", "stapel-op", "push", "zeg-het", "put", "willekeurig", "rand", "nog-eens", "redo", "reduceer", "reduce", "relatief", "relative", "herhaaldelijk", "repeated", "hervat", "resume", "knal-opnieuw", "rethrow", "geef-terug", "return", "geef-terug-rw", "return-rw", "keer-om", "reverse", "index-vanaf-einde", "rindex", "verwijder-map", "rmdir", "gooi", "roll", "wortels", "roots", "draai", "rotate", "rond-af", "round", "ieder-een", "roundrobin", "voer-uit", "run", "zelfde-kast", "samecase", "zelfde-accent", "samemark", "zelfde-met", "samewith", "zeg", "say", "verzameling", "set", "onderuit", "shift", "teken", "sign", "signaal", "signal", "zink", "sink", "sla-over", "skip", "sla-rest-over", "skip-rest", "slaap", "sleep", "wekker", "sleep-timer", "slaap-tot", "sleep-until", "glip", "slip", "knip", "snip", "spiek", "snitch", "dus", "so", "sorteer", "sort", "splits-lijst", "splice", "splits-letters", "split", "formatteer", "sprintf", "spuit", "spurt", "vierkantswortel", "sqrt", "plet", "squish", "zo-willekeurig", "srand", "begint-met", "starts-with", "ontleed-deel", "subparse", "substitueer", "subst", "substr-gelijk", "substr-eq", "slaag", "succeed", "sommeer", "sum", "symbolische-koppeling", "symlink", "staart", "tail", "neem", "take", "neem-rw", "take-rw", "doel", "target", "titel-kast", "tc", "titel-onder-kast", "tclc", "tijdelijk", "temp", "knal", "throw", "knalt-als", "throws-like", "tot", "to", "vandaag", "today", "tedoen", "todo", "vertaal", "trans", "trim-vooraan", "trim-leading", "trim-achteraan", "trim-trailing", "kap-af", "truncate", "boven-kast", "uc", "uniek", "unique", "lijkt-niet-op", "unlike", "ontkoppel", "unlink", "onderin", "unshift", "gebruik-ok", "use-ok", "als-nummers", "val", "waarde", "value", "waardes", "values", "waarschuw", "warn", "bespied", "watch", "week-nummer", "week-number", "week-jaar", "week-year", "weekdag-van-maand", "weekday-of-month", "woord-kast", "wordcase", "woorden", "words", "jjjj-mm-dd", "yyyy-mm-dd", "rits", "zip";
        my $ast := self.ast;
        my $name := $ast ?? $ast.simple-identifier !! self.Str;
        if %mapping{$name} -> $original {
            RakuAST::Name.from-identifier($original)
        }
        else {
            $ast // RakuAST::Name.from-identifier($name)
        }
    }
    method trait-is2ast {
        my constant %mapping = "kopie", "copy", "standaard", "default", "VEROUDERD", "DEPRECATED", "equivalent", "equiv", "implementatie-detail", "implementation-detail", "losser", "looser", "puur", "pure", "rauw", "raw", "lezen-schrijven", "rw", "test-assertie", "test-assertion", "strakker", "tighter";
        my $ast := self.ast;
        my $name := $ast ?? $ast.simple-identifier !! self.Str;
        if %mapping{$name} -> $original {
            RakuAST::Name.from-identifier($original)
        }
        else {
            $ast // RakuAST::Name.from-identifier($name)
        }
    }
    method adverb-pc2str (str $key) {
        my constant %mapping = "verwijder", "delete", "bestaat", "exists", "s", "k", "sw", "kv", "w", "v";
        %mapping{$key} // $key
    }
    method adverb-q2str (str $key) {
        my constant %mapping = "dubbel", "double", "voer-uit", "exec", "functies", "function", "tot-teken", "heredoc", "enkel", "single", "tot", "to", "allomorf", "val", "woorden", "words";
        %mapping{$key} // $key
    }
    method adverb-rx2str (str $key) {
        my constant %mapping = "continueer", "continue", "ui", "ex", "uitputtend", "exhaustive", "globaal", "global", "nk", "i", "negeerkast", "ignorecase", "negeeraccent", "ignoremark", "zk", "ii", "na", "m", "za", "mm", "de", "nd", "de", "nth", "ratel", "ratchet", "de", "rd", "zelfdekast", "samecase", "zelfdeaccent", "samemark", "zelfdespatie", "samespace", "sigspatie", "sigspace", "zs", "ss", "ste", "st", "tot", "to", "keer", "x";
        %mapping{$key} // $key
    }
    method named2str (str $key) {
        my constant %mapping = "absoluut", "absolute", "acties", "actions", "voegtoe", "append", "vangfout", "catch", "kap-regeleinde", "chomp", "sluit", "close", "commando", "command", "volledig", "completely", "continueer", "continue", "controle", "control", "aantal", "count", "maak-aan", "create", "maak-nieuw-aan", "createonly", "datum", "date", "dag", "day", "vrijheidsgraad", "degree", "verwijder", "delete", "elementen", "elems", "cod", "enc", "codering", "encoding", "vaneinde", "end", "elke", "every", "ui", "ex", "exclusief", "exclusive", "uitputtend", "exhaustive", "verloopt", "expires", "familie", "family", "bestandsnaam", "filename", "globaal", "global", "uur", "hour", "nk", "i", "negeerkast", "ignorecase", "negeeraccent", "ignoremark", "zk", "ii", "s", "k", "sleutel", "key", "sw", "kv", "luister", "listen", "minuut", "minute", "za", "mm", "maand", "month", "naam", "name", "de", "nd", "de", "nth", "uit", "off", "gedeeltelijk", "partial", "gedeelten", "parts", "poort", "port", "eerste", "primary", "vierde", "quaternary", "de", "rd", "vervanging", "replacement", "zelfde-kast", "samecase", "zelfde-accent", "samemark", "zelfde-spatie", "samespace", "seconde", "second", "tweede", "secondary", "seconden", "seconds", "grootte", "size", "drukplat", "squash", "zs", "ss", "ste", "st", "derde", "tertiary", "de", "th", "herhalingen", "times", "tijdzone", "timezone", "kap-af", "truncate", "w", "v", "waarde", "value", "waarbij", "where", "keer", "x", "jaar", "year";
        %mapping{$key} // $key
    }
    method pragma2str (str $key) {
        my constant %mapping = "dynamische-ruimte", "dynamic-scope", "fataal", "fatal", "interne-functies", "internals", "aanroeper", "invocant", "bibliotheek", "lib", "compilatie-vooraf", "precompilation", "zacht", "soft", "strikt", "strict", "verloop", "trace", "variabelen", "variables", "zorgen", "worries";
        %mapping{$key} // $key
    }
    method system2str (str $key) {
        my constant %mapping = "ACCEPTEERT", "ACCEPTS", "BOUW", "BUILD", "AANROEP", "CALL-ME", "VERANDER-IN", "COERCE", "WIJK-UIT", "FALLBACK", "HOOFD", "MAIN", "VERFIJN", "TWEAK", "VERBETER-RAT", "UPGRADE-RAT";
        %mapping{$key} // $key
    }
}

# The EXPORT sub that actually does the slanging
my sub EXPORT($dontslang?) {
    unless $dontslang {
        my $LANG := $*LANG;
        $LANG.define_slang('MAIN',
          $LANG.slang_grammar('MAIN').^mixin(L10N::NL)
        );
    }

    BEGIN Map.new
}

#- PLEASE DON'T CHANGE ANYTHING ABOVE THIS LINE
#- end of generated part of localization --------------------------------------

# vim: expandtab shiftwidth=4
