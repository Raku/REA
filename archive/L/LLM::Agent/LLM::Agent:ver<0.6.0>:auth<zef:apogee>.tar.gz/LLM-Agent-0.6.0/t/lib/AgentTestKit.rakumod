=begin pod

=head1 NAME

AgentTestKit - scripted backends, scripted tools, and settled-run helpers

=head1 SYNOPSIS

=begin code :lang<raku>

use lib 'lib', 't/lib';
use AgentTestKit;

my $backend = scripted-backend(steps => [
    # round 1: the model asks for a tool
    { chunks => ['Let me look. '], tool-calls => [tool-call('c1', 'fs_read', '{"path":"a"}')] },
    # round 2: it answers, and the provider says what it was billed
    { chunks => ['The file says hello.'], usage => { prompt => 812, completion => 9 } },
]);

my $provider = ScriptedProvider.new(
    tools   => [tool-decl('fs_read', 'Read a file', { path => { type => 'string' } })],
    results => { fs_read => 'hello' },
);

my $run = $loop.run([msg('user', 'what is in a?')]);
run-settled($run, 'the scripted run');
my @events = drain-events($run);

is $backend.recorded-calls.elems, 2, 'two round trips';
is $provider.recorded-calls.elems, 1, 'one tool call';

=end code

=head1 DESCRIPTION

Everything the agent tests need in order to drive a loop without a
network, a model, or a clock they do not control.

It is deliberately B<not> C<LLM::Chat::Backend::Mock>: that mock exists to
prove LLM::Chat's own behaviour and widening it to script mid-stream
failures, stalls and per-attempt usage would be changing one dist's test
surface to suit another's. This kit is free to be as strict and as
purpose-built as the agent tests need.

=head2 ScriptedBackend

A real C<LLM::Chat::Backend> subclass driven by a list of B<steps>: one
step is consumed per call, in order, by both C<chat-completion-stream> and
C<chat-completion>. Every step key is optional.

=begin table

Key                 | Effect
====================|=====================================================================
chunks              | List of fragments to emit, in order
content             | Shorthand for a single-fragment C<chunks>
tool-calls          | List of wire-shaped calls; also sets finish-reason to 'tool_calls' — applied to a FAILING step too, without the implied reason
finish-reason       | Overrides the finish reason ('stop', or 'tool_calls' with tool-calls) — stamped on a FAILING step too
usage               | C<< { prompt, completion, total, model, cached, cost, generation-id, provider-name } >>, any subset
error               | Message the call fails with, AFTER emitting whatever chunks it had
error-class         | 'http' / 'timeout' / 'connection' / 'response' (default 'unknown')
error-status        | HTTP status, for error-class 'http'
delay               | Seconds to wait before the first fragment
chunk-delay         | Seconds to wait between fragments
fail-after-chunks   | Emit only this many fragments, then fail
stall               | Emit the fragments and then go silent — no done, no quit, ever

=end table

C<cached> is a base-Response field, set through the same C<_set-usage>
call as C<prompt>/C<completion>/C<total> — it does B<not> select the
OpenRouter subclass on its own. The last three C<usage> keys are the
B<provider-specific> ones, and a step that scripts any of them gets an
C<LLM::Chat::Backend::Response::OpenRouter> (or its C<::Stream>) instead
of a plain Response — the real subclass, set through the real
C<_set-or-usage>, because what the loop does with them is probe with
C<.?cost>. A step that scripts none of them gets exactly the Response
every other test here was written against, so both sides of that probe
are covered by ordinary use.

C<model> is what C<< model-of($backend) >> answers, and it is the key a
C<LLM::Agent::RequestBudget> profile and a
C<LLM::Agent::TokenCount::Usage> calibration are both stored under — so a
test that wants two backends with B<different> profiles has to give them
different models. It defaults to C<scripted-model>, which means two
default backends B<share> a profile, which is occasionally the thing
being tested and occasionally a surprise.

C<stall> is what an inactivity timeout is tested against: the response
never reaches a terminal state on its own, C<last-activity-at> stops
advancing, and the loop is expected to notice, call C<cancel> (which the
backend records) and move on. It is streaming-only; a blocking call on a
stalled step throws rather than hanging the suite forever.

=head3 One step, one trailing comma

C<steps => [{ chunks => ['hi'] }]> is B<not> a one-step script: Raku's
single-argument rule flattens a lone Hash in a list into its Pairs, so
that reads as three steps of one key each and the failure surfaces
somewhere else entirely. Write C<steps => [{ chunks => ['hi'] },]> — the
trailing comma is the whole fix. The same applies to a step's
C<tool-calls> and to a provider's C<tools>.

The kit checks for it rather than letting it happen: a list of Pairs where
hashes were expected dies immediately, with that advice.

=head3 Scripting the failures a provider reports through the finish reason

C<finish-reason> and C<usage> are applied on the B<failure> path as well as
the success one, because some failures are not transport failures at all:

=begin code :lang<raku>

# The provider took the prompt, cut the answer off, and said so. This is
# what a real streaming backend produces for `finish_reason: 'length'` —
# fragments, then a quit whose Response still carries the reason and the
# tokens it billed.
{ chunks => ['I will start by ', 'reading the'],
  'finish-reason' => 'length',
  error => 'Hit max tokens', 'error-class' => 'response',
  usage => { prompt => 198_000, completion => 590 } }

=end code

The order the kit applies them in is the order L<LLM::Chat>'s own backends
use — calls, then reason, then usage, then the error info, then the quit
— so a consumer reading the settled Response sees a truncated completion
rather than an anonymous stream failure. It works with
C<fail-after-chunks> too, which is the more faithful shape when the point
of the test is that the fragments really were emitted before the cut.

C<tool-calls> is scriptable on the failure path for the round a provider
that is B<honest> about a cut still produces: fragments, a partial
argument list, C<finish_reason: 'length'>, quit.

=begin code :lang<raku>

# A truthful length that had already assembled a call. The loop is
# expected to read the LENGTH, not the call — nothing is dispatched.
{ chunks => ['Spawning: '],
  tool-calls => [tool-call('c1', 'task', '{"prompt":"do the'),],
  'finish-reason' => 'length',
  error => 'Hit max tokens', 'error-class' => 'response' }

=end code

Unlike the success path, a failing step's C<tool-calls> do B<not> imply a
finish reason: the quit is the terminal there, and what the provider said
about it is whatever the step scripted.

Running out of steps is an B<error>, not an empty response: the backend
answers with an C<error-class> of 'response' saying which call it was.
A test whose loop went round more times than it scripted should say so
rather than quietly pass.

Everything is recorded: C<.recorded-calls> (messages, tools, the step
used, and whether it was streaming), and C<.cancelled-responses> (the
Responses C<cancel> was called on, in order).

=head2 ScriptedProvider

The duck-typed tool provider — C<tools-for-llm> and C<execute-tool-calls>,
the same pair C<MCP::Client>, C<MCP::Client::Registry> and
C<MCP::Client::Policy> present, so a scripted provider can be dropped
under a real Policy in an integration test.

Like the real ones, C<execute-tool-calls> B<never throws>: a malformed
call, an unknown tool and a responder that died all come back as
C<is_error> results, one per call, in the caller's order.

C<block-on> is a Promise the batch waits on before returning — a blocked
tool round (a permission prompt nobody has answered yet) without needing a
real one.

Two more knobs are B<per call> rather than per batch, which is what makes
a per-operation loop testable at all: with one call dispatched at a time,
"gate the first of three" is a thing a test needs to be able to say.

=begin table

Knob       | What it is
===========|=========================================================
latency    | seconds this call sleeps before answering
block-call | a Promise this call waits on before answering

=end table

Both are hashes looked up by B<call id first, then tool name>, so a test
can slow down one specific call (C<< latency => { c2 => 0.4 } >>) or every
call of a tool (C<< latency => { fs_read => 0.4 } >>). C<block-call> is
awaited B<inside> the per-call answer, so a batch of three with only the
first gated returns nothing until the gate opens — which is exactly what a
sequential dispatcher does anyway.

C<latency> is how a tool deadline is tested without a clock seam: a
deadline of 0.15s against a call that takes 0.5s fires, deterministically,
in well under a second.

C<grants> is deliberately absent from C<ScriptedProvider> and present on
C<ScriptedProviderWithGrants>, because the loop decides whether to
synchronise grants with C<.can('grants')>. A single class with an
always-present method could not test both sides of that branch.

=head2 test-session / reopen-session / close-test-sessions

C<LLM::Agent::Session> holds an open append handle for its whole life
(C<JSONL::Writer> in handle mode with C<:flush> — see its Pod), and
C<.close> is the only thing that lets go of it. A test that creates one
and never closes it is therefore holding a file open when its C<END>
block unlinks the temp directory, and on B<Windows> that unlink fails
with "resource busy or locked": POSIX hides the bug by allowing the
unlink of an open file, so it only ever showed up on one platform's CI.

So sessions in tests go through here:

=begin code :lang<raku>

my $session = test-session(path => $path, meta => {});    # .create
my $again   = reopen-session(path => $path);              # .load

END {
    close-test-sessions();          # BEFORE the unlink, always
    if $tmp.e { .unlink for $tmp.dir; $tmp.rmdir }
}

=end code

Both track the session they hand back, and C<close-test-sessions> closes
every one of them — on the success path, the failure path and the
cancel path alike, because an C<END> block runs whatever happened.
C<Session.close> is idempotent and never throws, so a test that closes
its own session (several here do, because reopening one is the thing
being tested) is unaffected; the sweep just finds it already shut. It
answers how many it closed, and clears the register, so it is safe to
call more than once.

Nothing here swallows the unlink error: the point is that the handles
really are closed by then.

=head2 run-settled / drained-settled / drain-events

C<run-settled> B<polls> C<is-done> rather than awaiting the result
Promise, and C<drain-events> taps the event Supply exactly B<once>. Both
follow the lesson recorded in LLM-Chat's ChatTestKit: a scripted run can
finish before the test gets to it, and a fresh tap on an
already-finished stream never receives the C<done> it is waiting for. So:
poll for completion, tap once, and give up loudly after
C<TIMEOUT> seconds instead of hanging the suite.

C<drained-settled> is the same shape for C<$run.drained>: it waits for
the run to stop B<producing>, which on a cancelled run is later than
C<run-settled> — a detached tool batch keeps a run undrained long after
its result was kept. Use it when the assertion afterwards is about what
did B<not> happen (no stray event, no cancelled response), because
"nothing else arrived" is only worth asserting once nothing else can.

=end pod

use JSON::Fast;

use LLM::Chat::Backend;
use LLM::Chat::Backend::Response;
use LLM::Chat::Backend::Response::OpenRouter;
use LLM::Chat::Backend::Response::OpenRouter::Stream;
use LLM::Chat::Backend::Response::Stream;
use LLM::Chat::Backend::Settings;
use LLM::Chat::Conversation::Message;

use LLM::Agent::Run;
use LLM::Agent::Session;

unit module AgentTestKit;

#| How long any wait here may take before it is called a failure rather
#| than a slow machine.
constant TIMEOUT is export = 30;

# Raku's single-argument rule turns `[ %h ]` into a list of that hash's
# PAIRS, so a one-step script (`steps => [{ chunks => [...] }]`) silently
# becomes several steps of one key each, and a one-call `tool-calls => [ %c ]`
# becomes three malformed calls. Both failures look like a bug in the code
# under test rather than in the script, so every list-of-hashes the kit
# accepts goes through here and says so instead.
my sub hashes-or-die(@items, Str:D $what --> List) {
	# NB: no braces in this message. A literal brace pair inside a
	# double-quoted Raku string is an interpolated BLOCK, and one
	# containing a yada throws "Stub code executed" from the error path
	# itself — which is a memorable way to lose an afternoon.
	die "AgentTestKit: $what contains Pairs, which means a single Hash hit "
		~ "Raku's single-argument rule: a lone hash inside square brackets "
		~ "flattens into that hash's pairs. Add a trailing comma - "
		~ 'steps => [ %step, ] - or pass a List of two or more hashes.'
		if @items.first({ $_ ~~ Pair });

	# :k, not the value — an undefined entry is exactly the kind of thing
	# worth catching, and it would test as "no match" by value.
	with @items.first({ $_ !~~ Associative }, :k) -> $index {
		die "AgentTestKit: every entry of $what must be a Hash; entry "
			~ "$index is a {@items[$index].^name}";
	}

	@items.List;
}

# A per-call knob: by call id first, then by tool name. Undefined when
# neither is set, which is what `with` at the call site tests.
my sub per-call(%knob, Str:D $id, Str:D $name) {
	# NB the parens: an `:exists` adverb after `&&` tries to adverb the
	# `&&` itself, and the file stops compiling several lines from here.
	return %knob{$id} if $id.chars && (%knob{$id}:exists);
	return %knob{$name} if $name.chars && (%knob{$name}:exists);
	Nil;
}

#| A Message, briefly. Extra named arguments (C<:sticky>, C<:sysprompt>,
#| C<:tool-call-id>, C<:tool-calls>) go straight through.
sub msg(Str:D $role, Str:D $content = '', *%extra) is export {
	LLM::Chat::Conversation::Message.new(:$role, :$content, |%extra);
}

#| One wire-shaped tool call, as a provider would receive it. C<$arguments>
#| is the JSON string models actually send.
sub tool-call(
	Str:D $id,
	Str:D $name,
	Str:D $arguments = '{}',
	--> Hash:D
) is export {
	{
		id => $id,
		type => 'function',
		function => { name => $name, arguments => $arguments },
	};
}

#| One tool declaration in C<tools-for-llm> shape.
sub tool-decl(
	Str:D $name,
	Str:D $description = '',
	%properties = {},
	:@required,
	--> Hash:D
) is export {
	{
		type => 'function',
		function => {
			name => $name,
			description => $description,
			parameters => {
				type => 'object',
				properties => %properties,
				|(@required ?? (required => @required.List) !! ()),
			},
		},
	};
}

#|( A backend that replays a script. See the step table in the module Pod.

    Both completion methods consume from the same C<@.steps> list, so a
    test that mixes streaming rounds with a blocking summarization call
    scripts them in one place, in the order they happen. )
class ScriptedBackend is LLM::Chat::Backend is export {
	#| What C<< try { $backend.model } >> finds — the name that ends up on
	#| AttemptStarted events and attempt records.
	has Str:D $.model = 'scripted-model';

	#| The remaining script. Mutable on purpose: a test can push a step
	#| mid-run to react to what the loop did.
	has @.steps is rw;

	#| One entry per completion call: C<< { messages, tools, step, kind,
	#| response-id } >>, where C<kind> is 'stream' or 'blocking'.
	has @.recorded-calls;

	#| The Responses C<cancel> was called on, in order.
	has @.cancelled-responses;

	has Lock:D $!lock .= new;
	has Int $!calls = 0;

	submethod TWEAK(*%) {
		hashes-or-die(@!steps, 'the step script');
	}

	# Consume the next step and record the call. One lock covers both, so
	# two concurrent calls cannot get the same step or record out of order.
	method !take-step(@messages, @tools, Str:D $kind, Str:D $response-id --> Hash:D) {
		$!lock.protect: {
			my $n = ++$!calls;
			# Re-checked here as well as in TWEAK: @.steps is rw, and a
			# test that pushes a step mid-run can hit the same trap.
			hashes-or-die(@!steps.head(1).List, 'the step script') if @!steps.elems;

			my %step = @!steps.elems
				?? @!steps.shift.Hash
				!! %(
					error => "ScriptedBackend: no step scripted for call $n "
						~ "(the loop made more round trips than the test expected)",
					error-class => 'response',
				);

			@!recorded-calls.push: {
				messages => @messages.clone,
				tools => @tools.clone,
				step => %step,
				kind => $kind,
				response-id => $response-id,
			};
			%step;
		};
	}

	# The keys of a step's `usage` that only an OpenRouter-flavoured
	# Response can carry. Their presence is what decides which Response
	# class a step gets — see `!response-class`.
	my constant OR-USAGE-KEYS = <cost generation-id provider-name>;

	my sub scripts-or-usage(%step --> Bool:D) {
		return False unless %step<usage> ~~ Associative;
		so OR-USAGE-KEYS.first({ %step<usage>{$_}.defined });
	}

	# Everything a step says about a finished call, applied in the order
	# the Response contract wants: metadata first, terminal state last.
	method !apply-outcome($resp, %step --> Nil) {
		if %step<tool-calls>:exists && %step<tool-calls>.defined {
			my @calls = %step<tool-calls> ~~ Associative
				?? (%step<tool-calls>,)
				!! %step<tool-calls>.list;
			$resp._set-tool-calls(hashes-or-die(@calls, "a step's tool-calls"));
		}

		$resp._set-finish-reason(
			%step<finish-reason>
				// (%step<tool-calls>.defined ?? 'tool_calls' !! 'stop')
		);

		if %step<usage> ~~ Associative {
			my %usage = %step<usage>;
			my %args;
			%args<prompt>     = %usage<prompt>.Int     if %usage<prompt>.defined;
			%args<completion> = %usage<completion>.Int if %usage<completion>.defined;
			%args<total>      = %usage<total>.Int      if %usage<total>.defined;
			%args<cached-prompt> = %usage<cached>.Int  if %usage<cached>.defined;
			%args<model>      = (%usage<model> // $!model).Str;
			$resp._set-usage(|%args);

			# The provider-specific half, through the real OpenRouter
			# setter on the real OpenRouter Response subclass — which is
			# what the loop probes for with `.?cost`. A step that scripts
			# none of these gets a plain Response, so both sides of that
			# probe are exercised by ordinary tests.
			if scripts-or-usage(%step) && $resp.can('_set-or-usage') {
				my %or;
				%or<cost>          = %usage<cost>.Num if %usage<cost>.defined;
				%or<generation-id> = %usage<generation-id>.Str
					if %usage<generation-id>.defined;
				%or<provider-name> = %usage<provider-name>.Str
					if %usage<provider-name>.defined;
				$resp._set-or-usage(|%or);
			}
		}
	}

	# The failure half of the same: the assembled tool calls and the finish
	# reason first, then structured error info, then the quit — the order
	# LLM::Chat's own backends use, so a consumer reading the finished
	# response sees all of it.
	#
	# The finish reason matters on the FAILURE path because of the failures
	# a provider reports through it rather than through a status: a
	# `finish_reason: 'length'` quit is a real completion the provider cut
	# off, and the loop reads `.finish-reason` off the quit Response to tell
	# it from an ordinary stream failure. A step that scripts `usage`
	# alongside `error` gets that too — that is the truncated response
	# which still billed for the prompt it consumed.
	#
	# `tool-calls` for the same reason one step further on: a provider that
	# streams tool call deltas and THEN reports a cut leaves both on the
	# response, and a consumer that reads the calls off a failed one is
	# reading a truncated argument list. Unlike the success path this does
	# not invent a finish reason — the quit is the terminal here, and what
	# the provider said about it is whatever the step scripted.
	method !apply-error($resp, %step --> Nil) {
		if %step<tool-calls>:exists && %step<tool-calls>.defined {
			my @calls = %step<tool-calls> ~~ Associative
				?? (%step<tool-calls>,)
				!! %step<tool-calls>.list;
			$resp._set-tool-calls(hashes-or-die(@calls, "a step's tool-calls"));
		}

		$resp._set-finish-reason(%step<finish-reason>.Str)
			if %step<finish-reason>.defined;

		if %step<usage> ~~ Associative {
			my %usage = %step<usage>;
			my %args;
			%args<prompt>     = %usage<prompt>.Int     if %usage<prompt>.defined;
			%args<completion> = %usage<completion>.Int if %usage<completion>.defined;
			%args<total>      = %usage<total>.Int      if %usage<total>.defined;
			%args<cached-prompt> = %usage<cached>.Int  if %usage<cached>.defined;
			%args<model>      = (%usage<model> // $!model).Str;
			$resp._set-usage(|%args);

			if scripts-or-usage(%step) && $resp.can('_set-or-usage') {
				my %or;
				%or<cost> = %usage<cost>.Num if %usage<cost>.defined;
				%or<generation-id> = %usage<generation-id>.Str
					if %usage<generation-id>.defined;
				%or<provider-name> = %usage<provider-name>.Str
					if %usage<provider-name>.defined;
				$resp._set-or-usage(|%or);
			}
		}

		my %info = class => (%step<error-class> // 'unknown').Str;
		%info<status> = %step<error-status>.Int if %step<error-status>.defined;
		$resp._set-error-info(|%info);
		$resp.quit(%step<error> // 'scripted failure');
	}

	# The fragments a step emits, as a list.
	method !chunks-of(%step --> List) {
		return %step<chunks>.list if %step<chunks>.defined;
		return (%step<content>.Str,) if %step<content>.defined;
		();
	}

	method chat-completion-stream(
		@messages where all(@messages) ~~ LLM::Chat::Conversation::Message,
		:@tools,
		--> LLM::Chat::Backend::Response::Stream
	) {
		my $id = 'scripted-stream-' ~ ($!calls + 1);
		my %step = self!take-step(@messages, @tools, 'stream', $id);
		# The OpenRouter-flavoured Response only when the step needs it:
		# a plain step must keep producing exactly the Response every
		# other test in this suite was written against.
		my $resp = scripts-or-usage(%step)
			?? LLM::Chat::Backend::Response::OpenRouter::Stream.new(:$id)
			!! LLM::Chat::Backend::Response::Stream.new(:$id);

		start {
			CATCH {
				# A broken script must fail the test, not vanish into a
				# start block nobody awaits.
				default {
					$resp._set-error-info(class => 'response');
					$resp.quit("ScriptedBackend: {.message}");
				}
			}

			sleep %step<delay> if %step<delay>.defined && %step<delay> > 0;

			my @chunks = self!chunks-of(%step);
			my $limit = %step<fail-after-chunks>.defined
				?? %step<fail-after-chunks>.Int
				!! @chunks.elems;

			my Bool $truncated = False;
			for @chunks.kv -> $i, $chunk {
				if $i >= $limit {
					$truncated = True;
					last;
				}
				$resp.emit($chunk.Str) if $chunk.defined && $chunk.Str.chars;
				sleep %step<chunk-delay>
					if %step<chunk-delay>.defined && %step<chunk-delay> > 0;
			}

			if $truncated || (%step<fail-after-chunks>.defined && $limit >= @chunks.elems) {
				self!apply-error($resp, %(
					error => %step<error> // 'scripted mid-stream failure',
					error-class => %step<error-class>,
					error-status => %step<error-status>,
					# Forwarded, not dropped: a provider that stops
					# mid-answer often says WHY through the finish reason and
					# still bills for what it read, and a mid-stream script
					# is the most faithful way to write that round. The calls
					# travel with them for the same reason: an argument list
					# assembled as far as the cut is what a consumer of a
					# failed response actually finds on it.
					'finish-reason' => %step<finish-reason>,
					usage => %step<usage>,
					'tool-calls' => %step<tool-calls>,
				));
			}
			elsif %step<stall> {
				# Deliberately nothing: no done, no quit. The response sits
				# there with a last-activity-at that stops advancing, which
				# is exactly what an inactivity timeout has to notice.
			}
			elsif %step<error>.defined {
				self!apply-error($resp, %step);
			}
			else {
				self!apply-outcome($resp, %step);
				$resp.done;
			}
		}

		$resp;
	}

	method chat-completion(
		@messages where all(@messages) ~~ LLM::Chat::Conversation::Message,
		:@tools,
		--> LLM::Chat::Backend::Response
	) {
		my $id = 'scripted-blocking-' ~ ($!calls + 1);
		my %step = self!take-step(@messages, @tools, 'blocking', $id);
		my $resp = scripts-or-usage(%step)
			?? LLM::Chat::Backend::Response::OpenRouter.new(:$id)
			!! LLM::Chat::Backend::Response.new(:$id);

		die 'ScriptedBackend: `stall` is a streaming-only step key — a '
			~ 'blocking call cannot stall without hanging the suite'
			if %step<stall>;

		sleep %step<delay> if %step<delay>.defined && %step<delay> > 0;

		if %step<error>.defined {
			self!apply-error($resp, %step);
			return $resp;
		}

		$resp.emit(self!chunks-of(%step).join);
		self!apply-outcome($resp, %step);
		$resp.done;
		$resp;
	}

	#| Records the Response, then cancels it for real — the cancelled
	#| stream ends up C<is-done> and not C<is-success>, as a live one does.
	method cancel(LLM::Chat::Backend::Response $resp) {
		$!lock.protect: { @!cancelled-responses.push: $resp };
		$resp.cancel;
	}
}

#| A ScriptedBackend with a Settings already built. Named arguments go
#| straight to the constructor.
sub scripted-backend(*%args --> ScriptedBackend) is export {
	ScriptedBackend.new(
		settings => LLM::Chat::Backend::Settings.new,
		|%args,
	);
}

#|( The duck-typed tool provider: C<tools-for-llm> plus
    C<execute-tool-calls>, never throwing, fully recorded. )
class ScriptedProvider is export {
	#| The declarations C<tools-for-llm> publishes.
	has @.tools;

	#|( Per tool name: a Str (the content of a successful result) or a
	    Hash merged into the result, so an error can be scripted as
	    C<< { fs_write => { content => 'nope', is_error => True } } >>. )
	has %.results;

	#| Consulted before C<%results> when present:
	#| C<< -> $name, $arguments, $id { ... } >> returning a Str or a Hash.
	#| A responder that throws becomes an is_error result, as a real
	#| provider's would.
	has &.responder;

	#| Awaited before each batch returns — a tool round blocked on
	#| something that has not happened yet.
	has Promise $.block-on;

	#|( Seconds a single call sleeps before answering, keyed by call id or
	    tool name (id wins). A tool that takes a while, without a clock
	    seam anywhere. )
	has %.latency;

	#|( A Promise a single call waits on before answering, keyed by call id
	    or tool name (id wins). C<block-on> gates a batch; this gates one
	    call inside it. )
	has %.block-call;

	#| One entry per batch, each the calls it received.
	has @.recorded-batches;
	#| Every call of every batch, flattened, in order.
	has @.recorded-calls;
	#| How many times the catalogue was asked for.
	has Int $.list-calls = 0;

	has Lock:D $!lock .= new;

	submethod TWEAK(*%) {
		hashes-or-die(@!tools, 'the tool catalogue');
	}

	method tools-for-llm(--> List) {
		$!lock.protect: { $!list-calls++ };
		@!tools.List;
	}

	#|( One result per call, in order, never throwing — the same contract
	    C<MCP::Client> and C<MCP::Client::Policy> have.

	    The single exception is a Pair, which no loop can produce and no
	    provider can answer: that is the single-argument rule again, and it
	    dies with the fix rather than coming back as three malformed
	    results. )
	method execute-tool-calls(@tool-calls --> List) {
		die 'AgentTestKit: execute-tool-calls was handed Pairs — a lone '
			~ 'call hash inside square brackets flattens into its pairs. '
			~ 'Add a trailing comma: [ %call, ]'
			if @tool-calls.first({ $_ ~~ Pair });

		$!lock.protect: {
			@!recorded-batches.push: @tool-calls.List;
			@!recorded-calls.append: @tool-calls.list;
		};

		await $!block-on with $!block-on;

		# `.eager`, deliberately: a `.map(...).List` is LAZY, and a lazy
		# provider does its work wherever the caller happens to reify it —
		# which for an agent loop is the one thread that was supposed to be
		# watching the clock. The real bridges are eager; so is this.
		@tool-calls.map({ self!answer($_) }).eager.List;
	}

	method !answer($call --> Hash:D) {
		return {
			role => 'tool', tool_call_id => '',
			content => 'Malformed tool call: not an object',
			is_error => True,
		} unless $call ~~ Associative;

		my $id = ($call<id> // '').Str;
		my $function = $call<function>;
		my $name = ($function ~~ Associative ?? ($function<name> // '') !! '').Str;
		my $arguments = $function ~~ Associative ?? $function<arguments> !! Str;

		return {
			role => 'tool', tool_call_id => $id,
			content => 'Malformed tool call: no function name',
			is_error => True,
		} unless $name.chars;

		# Per-call gate and per-call latency, in that order: a call that is
		# blocked has not started taking its time yet. Both are looked up
		# by id first so a test can single out one call of several that ask
		# for the same tool.
		with per-call(%!block-call, $id, $name) -> $gate {
			await $gate;
		}
		with per-call(%!latency, $id, $name) -> $seconds {
			sleep $seconds if $seconds > 0;
		}

		my $answer;
		my $threw;
		{
			CATCH { default { $threw = $_ } }
			$answer = &!responder.defined
				?? &!responder($name, $arguments, $id)
				!! (%!results{$name}:exists ?? %!results{$name} !! "ok: $name");
		}

		return {
			role => 'tool', tool_call_id => $id,
			content => "Tool '$name' failed: {$threw.message}",
			is_error => True,
		} if $threw.defined;

		my %result = role => 'tool', tool_call_id => $id,
			content => '', is_error => False;
		if $answer ~~ Associative {
			%result{$_} = $answer{$_} for $answer.keys;
			%result<content> = (%result<content> // '').Str;
			%result<is_error> = ?%result<is_error>;
		}
		else {
			%result<content> = ($answer // '').Str;
		}
		%result;
	}
}

#|( A ScriptedProvider that also has C<grants> — the optional method the
    loop probes for with C<.can('grants')>. Separate class so both sides
    of that branch are testable. )
class ScriptedProviderWithGrants is ScriptedProvider is export {
	has @!grants;
	has Lock:D $!grant-lock .= new;

	# NB: the *% is load-bearing — TWEAK is handed EVERY named argument
	# that reached .new, so an explicit signature without it rejects
	# `tools => ...` and every other attribute the parent takes.
	submethod TWEAK(:@grants, *%) {
		@!grants = @grants.map({ $_.Hash });
	}

	#| The grant snapshot, as a copy — the same contract
	#| C<MCP::Client::Policy.grants> has.
	method grants(--> List:D) {
		$!grant-lock.protect: { @!grants.map({ $_.Hash }).List };
	}

	#| Grow the snapshot mid-test, as answering a permission prompt would.
	method add-grant(%grant --> Nil) {
		$!grant-lock.protect: { @!grants.push: %grant.Hash };
	}

	#|( Swap the snapshot for a different one, as a policy narrowing or
	    replacing a rule does. The case worth having a method for is the
	    one where the C<elems> do not change: a loop that decided whether
	    to persist by counting would never notice it. )
	method replace-grants(@grants --> Nil) {
		$!grant-lock.protect: { @!grants = @grants.map({ $_.Hash }) };
	}
}

# === Sessions, and the handles they hold ===

# Every session this kit has opened. A Lock because a test may open one
# from a thread of its own, and END runs on whichever thread got there.
my Lock:D $session-lock .= new;
my @sessions;

my sub track(LLM::Agent::Session:D $session --> LLM::Agent::Session:D) {
	$session-lock.protect: { @sessions.push: $session };
	$session;
}

#|( C<LLM::Agent::Session.create>, with the handle registered for
    C<close-test-sessions>. See the module Pod: an unclosed session is an
    open file, and an open file is an unlink that fails on Windows. )
sub test-session(IO(Cool) :$path!, :%meta --> LLM::Agent::Session:D) is export {
	track(LLM::Agent::Session.create(:$path, :%meta));
}

#| C<LLM::Agent::Session.load>, registered the same way.
sub reopen-session(IO(Cool) :$path! --> LLM::Agent::Session:D) is export {
	track(LLM::Agent::Session.load(:$path));
}

#|( Close every session this kit opened, and forget them. Call it at the
    top of the C<END> block that unlinks the temp directory — B<before>
    the unlink, which is the whole point.

    Answers how many it closed. Idempotent, and safe on a session a test
    already closed itself: C<Session.close> is. )
sub close-test-sessions(--> Int) is export {
	my @open = $session-lock.protect: {
		my @taken = @sessions;
		@sessions = ();
		@taken.List;
	};

	my Int $closed = 0;
	for @open -> $session {
		# Shielded per session, not per sweep: one that somehow cannot be
		# closed must not leave the rest of them open behind it.
		try {
			$session.close;
			$closed++;
		}
	}
	$closed;
}

#|( Wait for a Run to finish, by POLLING C<is-done> — never by awaiting a
    fresh tap on a Supply that may already be finished. Dies after
    C<TIMEOUT> seconds rather than hanging the suite. Returns the Run. )
sub run-settled(LLM::Agent::Run:D $run, Str:D $what = 'the run') is export {
	my $deadline = now + TIMEOUT;
	until $run.is-done {
		die "Timed out after {TIMEOUT}s waiting for $what" if now > $deadline;
		sleep 0.002;
	}
	$run;
}

#|( Wait for a Run to go quiet — C<$run.drained>, polled the same way and
    for the same reason C<run-settled> polls C<is-done>. A cancelled run
    reaches C<is-done> while a detached tool batch is still running; this
    is what waits for that. Returns the Run. )
sub drained-settled(LLM::Agent::Run:D $run, Str:D $what = 'the run') is export {
	my $deadline = now + TIMEOUT;
	until $run.drained.status === Kept {
		die "Timed out after {TIMEOUT}s waiting for $what to drain" if now > $deadline;
		sleep 0.002;
	}
	$run;
}

#|( Collect every event of a Run, in order.

    Taps B<once>, which is the only thing that works: the Supply is
    C<Supplier::Preserving>, so the first tap replays the whole run — and
    a second tap on a finished run receives nothing at all, not even the
    C<done>. Call this once per Run, after C<run-settled>. )
sub drain-events(LLM::Agent::Run:D $run, Str:D $what = 'the event stream') is export {
	my @events;
	my $done = Promise.new;
	my $vow = $done.vow;

	my $tap = $run.events.tap(
		-> $event { @events.push: $event },
		done => { $vow.keep(True) },
		quit => -> $ex { $vow.break($ex) },
	);

	await Promise.anyof($done, Promise.in(TIMEOUT));
	if $done.status === Planned {
		$tap.close;
		die "Timed out after {TIMEOUT}s draining $what — either the run "
			~ 'never finished, or something had already tapped this Supply '
			~ '(a Supplier::Preserving delivers its buffer to the FIRST tap '
			~ 'only, and replays nothing to a second one)';
	}
	$tap.close;
	@events.List;
}

#| The events of C<@events> whose kind is C<$kind>, in order.
sub events-of(@events, Str:D $kind --> List) is export {
	@events.grep({ .kind eq $kind }).List;
}

#| Just the kind strings, for asserting whole sequences at a glance.
sub event-kinds(@events --> List) is export {
	@events.map({ .kind }).List;
}
