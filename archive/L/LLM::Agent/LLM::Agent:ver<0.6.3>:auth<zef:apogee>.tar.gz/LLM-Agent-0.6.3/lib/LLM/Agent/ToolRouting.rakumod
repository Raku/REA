=begin pod

=head1 NAME

LLM::Agent::ToolRouting - a tool call as a grammar-constrained choice: the
action schema, the parser, the result message and the capped backend

=head1 SYNOPSIS

=begin code :lang<raku>

use LLM::Agent::ToolRouting;

my @tools = $provider.tools-for-llm;   # the ordinary catalogue

# One JSON schema, one alternative per tool plus "no tool calls needed".
my %schema = route-schema(@tools);
route-choices(@tools);                 # ('memory_search', 'memory_read', 'none')

# What the model answered, checked against what it was offered.
my %action = parse-route('{"tool":"memory_search","arguments":{"query":"latch"}}',
    route-tool-names(@tools));
# { ok => True, tool => 'memory_search', arguments => { query => 'latch' },
#   text => '{"tool":"memory_search","arguments":{"query":"latch"}}' }

parse-route('{"tool":"none"}', route-tool-names(@tools));
# { ok => True, tool => 'none', text => '{"tool":"none"}' }

parse-route('Sure! Let me search.', route-tool-names(@tools));
# { ok => False, error => "the reply is not a JSON object" }

# The user message that answers a routed call.
routed-result-text('memory_search', routed-call-id(1), '{"records":[]}');
# "Tool result for memory_search (call route-1):\n{\"records\":[]}"

# The request backend: a clone carrying the schema and a low completion cap.
my $request = routed-backend($backend, %schema, routing-cap($backend, 512));

=end code

=head1 DESCRIPTION

L<LLM::Agent::Loop>'s C<< tool-routing => 'schema' >> mode asks the model
for its next action as a B<grammar-constrained JSON choice> rather than
through a backend's tool calling. This module is the part of that mode a
host can use on its own: to build the same schema the loop will send, to
record it, or to check a reply the way the loop checks it.

=head2 Why a choice, and not a tool call

Native tool calling has one branch nothing constrains: the reply that
calls no tool. A backend that emulates tools (KoboldCpp polls "is a tool
essential?" and, when the answer is no, hands the model a completely
unconstrained turn) lets that branch run for thousands of tokens — echoing
the prompt back until it happens to stop — and a real tool-calling
template still leaves it free text. A retrieval phase that only wanted
"search, read, or I am done" gets an essay it then has to throw away.

So every reply is one of a closed set of actions, and the set includes
the answer "no tool calls needed":

=begin code :lang<json>

{"tool": "memory_search", "arguments": {"query": "the latch"}}
{"tool": "memory_read",   "arguments": {"ids": ["M1", "M3"]}}
{"tool": "none"}

=end code

=head2 The schema

C<route-schema> turns a catalogue in C<tools-for-llm> shape
(C<< { type => 'function', function => { name, description?, parameters? } } >>)
into one JSON schema with an C<anyOf> alternative per tool, in catalogue
order, and the C<none> alternative last:

=begin code :lang<json>

{
  "type": "object",
  "anyOf": [
    { "type": "object",
      "description": "Search memories.",
      "properties": { "tool": { "const": "memory_search" },
                      "arguments": { ...that tool's parameters schema... } },
      "required": ["tool", "arguments"],
      "additionalProperties": false },
    { "type": "object",
      "properties": { "tool": { "const": "none" } },
      "required": ["tool"],
      "additionalProperties": false }
  ]
}

=end code

Three details are deliberate:

=item B<C<anyOf>, not C<oneOf>.> The alternatives are mutually exclusive
by their C<tool> constant, so the two mean the same thing here; grammar
compilers (llama.cpp, KoboldCpp) treat them identically, and C<anyOf> is
the one every structured-output implementation accepts.

=item B<C<tool> is required first.> Grammar-compiling servers write
properties in the order of C<required> (see L<LLM::Chat::Backend::Settings>),
so the model names its action before it writes a single argument.

=item B<The parameters schema is the tool's own,> copied verbatim (and
detached). A provider that wants a narrower grammar than its native
declaration — an C<enum> of the identifiers it has actually handed out,
say — narrows its catalogue; see L<LLM::Agent::Loop>'s "Schema tool
routing" for why the loop re-reads the catalogue for every routing request.

The catalogue is validated, and a bad one B<dies> with the index and the
reason: a declaration that is not C<type: function>, a missing or blank
name, a name used twice, a tool named C<none> (it would be
indistinguishable from the handoff), or C<parameters> that are not an
object schema. A tool with no C<parameters> takes an empty object.

=head2 Parsing a reply

C<parse-route($text, @names)> is strict, because a reply that needs
repairing is a reply the grammar did not constrain. The whole trimmed text
must be one JSON object, and:

=item C<tool> is a non-empty string;

=item C<none> carries no other key;

=item any other C<tool> is one of C<@names> and carries exactly C<tool> and
C<arguments>, where C<arguments> is an object with no non-finite number in
it (C<1e999> parses as infinity, and nothing downstream can render it).

No fence stripping, no "the JSON inside the prose", no key-case folding.
It answers C<< { ok => False, error => ... } >> rather than throwing; the
error text quotes at most 64 characters of what the model wrote.

=head2 The result message

A routed call is answered by a B<user> message, never a C<tool> message:
the action was an ordinary assistant message, so the conversation
alternates user and assistant and needs no tool template at all.
C<routed-result-text> is the one rendering of it, and the header names the
call:

=begin code :lang<text>

Tool result for memory_search (call route-2):
{"records":[{"id":"M1","title":"The latch"}]}

Tool error for memory_read (call route-3):
memory_read ids take the codes memory_search lists

=end code

C<routed-result-header($tool, $call-id, :is-error)> is that first line on
its own, and C<split-routed-result($text)> takes a result message apart
again — C<(header, content)>, or an empty list for any other text — for a
consumer that bounds or inspects the tool's content without the line the
loop put above it:

=begin code :lang<raku>

my ($header, $content) = split-routed-result($message.content);
die 'tool content too large' if $content.defined && $content.encode.bytes > 32768;

=end code

C<routed-call-id($round)> is the id the loop gives the call made in a
round (C<route-1>, C<route-2>, ...): one action per round, so it is unique
within a run and a pure function of it, which keeps a replayed run's bytes
identical to the original's.

=head2 The request backend

C<routed-backend($backend, %schema, $max-tokens)> clones the backend and
its settings, sets C<json_schema> (under the name C<tool_route>) and
C<max_tokens>, and leaves the original untouched — so a structured phase
built from the same backend keeps its own schema and its own completion
budget. C<routing-cap($backend, $max)> is the cap a routing request gets:
C<$max>, or the backend's own C<max_tokens> when that is lower, because a
routing cap only ever lowers a budget. C<can-route($backend)> is the
duck-typed test for a backend this works on: C<settings> (with
C<json_schema>, C<json_schema_name>, C<max_tokens> and C<clone>) and
C<clone>, which every L<LLM::Chat> backend has.

=head1 SEE ALSO

L<LLM::Agent::Loop> (the mode that uses all of this),
L<LLM::Chat::Backend::Settings> (C<json_schema> and property order).

=end pod

use JSON::Fast;

unit module LLM::Agent::ToolRouting;

# The `tool` value of the "no tool calls needed" action. A plain `#` comment
# on every constant here: a declarator block above a constant attaches to the
# next declaration instead.
our constant ROUTE-NONE is export = 'none';

# The name the routing schema goes out under in an OpenAI-style
# response_format (KoboldCpp ignores it).
our constant ROUTE-SCHEMA-NAME is export = 'tool_route';

# The completion cap a routing request gets when nothing else is said. An
# action is a few dozen tokens; 512 leaves room for a long query and a full
# id list while stopping a reply that has stopped being an action.
our constant DEFAULT-ROUTING-MAX-TOKENS is export = 512;

# The prefix of the call ids the loop mints for routed calls.
our constant ROUTED-CALL-PREFIX is export = 'route-';

# How much of a model-written value an error message quotes.
my constant MAX-QUOTED-CHARS = 64;

my sub quoted($value --> Str:D) {
	my Str $text = ($value // '').Str;
	$text = $text.subst(/<:Cc>/, ' ', :g);
	$text.chars > MAX-QUOTED-CHARS
		?? "'" ~ $text.substr(0, MAX-QUOTED-CHARS) ~ "…'"
		!! "'$text'";
}

# A detached copy of plain JSON data: nothing the caller holds can change
# the schema after it was built, and nothing that is not JSON gets in.
my sub detached($value, Str:D $what) {
	my $copy;
	{
		CATCH {
			default {
				die "LLM::Agent::ToolRouting: $what is not plain JSON data: "
					~ (.message.lines.head // .^name);
			}
		}
		$copy = from-json(to-json($value, :!pretty));
	}
	$copy;
}

# True when a parsed JSON value holds a number JSON cannot render: strict JSON
# text produces one only by overflow (1e999 is infinity).
my sub has-non-finite($value --> Bool:D) {
	return False without $value;
	return so $value.Hash.values.grep({ has-non-finite($_) }).elems
		if $value ~~ Associative;
	return so $value.list.grep({ has-non-finite($_) }).elems
		if $value ~~ Positional;
	return !(-Inf < $value < Inf) if $value ~~ Num;
	False;
}

#|( The catalogue, validated: one C<< { name, description, parameters } >>
    per declaration, in catalogue order, with C<parameters> detached and
    defaulted to an empty object schema. Dies on anything the module Pod
    lists as a bad catalogue. )
our sub route-tools(@tools --> List:D) is export {
	my %seen;
	my @out;
	for @tools.kv -> Int $index, $declaration {
		my Str $at = "tool declaration $index";
		die "LLM::Agent::ToolRouting: $at is a {$declaration.^name}, not a "
			~ '{ type => "function", function => { name, parameters } } hash'
			unless $declaration ~~ Associative:D;
		die "LLM::Agent::ToolRouting: $at has type "
			~ quoted($declaration<type>) ~ "; only 'function' tools can be routed"
			if $declaration<type>.defined && $declaration<type> ne 'function';

		my $function = $declaration<function>;
		die "LLM::Agent::ToolRouting: $at has no 'function' object"
			unless $function ~~ Associative:D;

		my $name = $function<name>;
		die "LLM::Agent::ToolRouting: $at has no name"
			unless $name ~~ Str:D && $name.trim.chars && $name !~~ /<:Cc>/;
		die "LLM::Agent::ToolRouting: $at is named '{ROUTE-NONE}', which is the "
			~ '"no tool calls needed" action — a tool by that name could never be '
			~ 'told apart from the handoff'
			if $name eq ROUTE-NONE;
		die "LLM::Agent::ToolRouting: $at is named {quoted($name)}, which tool "
			~ "declaration {%seen{$name}} already uses — a routed action names "
			~ 'its tool, so the names have to be unique'
			if %seen{$name}:exists;
		%seen{$name} = $index;

		my $parameters = $function<parameters>;
		my %parameters;
		if $parameters.defined {
			die "LLM::Agent::ToolRouting: the parameters of {quoted($name)} are a "
				~ "{$parameters.^name}, not a JSON schema object"
				unless $parameters ~~ Associative:D;
			die "LLM::Agent::ToolRouting: the parameters of {quoted($name)} have type "
				~ quoted($parameters<type>) ~ ', but a routed action\'s arguments '
				~ 'are always a JSON object'
				if $parameters<type>.defined && $parameters<type> ne 'object';
			%parameters = detached($parameters, "the parameters of {quoted($name)}").Hash;
		}
		else {
			%parameters = type => 'object', properties => {};
		}

		my $description = $function<description>;
		@out.push: %(
			:$name,
			description => ($description ~~ Str:D ?? $description !! ''),
			parameters  => %parameters,
		);
	}
	@out.List;
}

#| The names of the catalogue's tools, in order: what C<parse-route> checks
#| a reply's C<tool> against.
our sub route-tool-names(@tools --> List:D) is export {
	route-tools(@tools).map(*.<name>).List;
}

#| Every action a reply may take, in schema order: the tools, then C<none>.
our sub route-choices(@tools --> List:D) is export {
	(|route-tool-names(@tools), ROUTE-NONE).List;
}

#|( The routing schema for C<@tools>: an C<anyOf> of one alternative per
    tool and the C<none> alternative last. See the module Pod for the
    shape. Plain, detached JSON data; building it twice from the same
    catalogue gives two equal structures. )
our sub route-schema(@tools --> Hash:D) is export {
	my @alternatives = route-tools(@tools).map(-> %tool {
		%(
			type                 => 'object',
			|(%tool<description>.chars ?? (description => %tool<description>) !! ()),
			properties           => %(
				tool      => %( const => %tool<name> ),
				arguments => %tool<parameters>,
			),
			required             => ['tool', 'arguments'],
			additionalProperties => False,
		);
	});
	@alternatives.push: %(
		type                 => 'object',
		properties           => %( tool => %( const => ROUTE-NONE ) ),
		required             => ['tool'],
		additionalProperties => False,
	);
	%( type => 'object', anyOf => @alternatives.Array );
}

my sub refuse(Str:D $error --> Hash:D) { %( ok => False, :$error ) }

#|( Check a routing reply against the tools that were offered. Answers
    C<< { ok => True, tool, arguments?, text } >> — C<text> is the trimmed
    reply, C<arguments> is present for a tool — or C<< { ok => False,
    error } >>. Never throws. See the module Pod for the rules. )
our sub parse-route($text, @names --> Hash:D) is export {
	my Str $trimmed = ($text // '').Str.trim;
	return refuse('the reply is empty') unless $trimmed.chars;
	return refuse('the reply is not a JSON object')
		unless $trimmed.starts-with('{') && $trimmed.ends-with('}');

	my $parsed;
	my Str $problem;
	{
		CATCH { default { $problem = (.message.lines.head // .^name).Str } }
		$parsed = from-json($trimmed);
	}
	return refuse("the reply is not valid JSON ($problem)") if $problem.defined;
	return refuse('the reply is not a JSON object') unless $parsed ~~ Associative:D;

	my %action = $parsed.Hash;
	my $tool = %action<tool>;
	return refuse("the reply has no 'tool' string")
		unless $tool ~~ Str:D && $tool.chars;

	my Str $keys = %action.keys.sort.join(',');
	if $tool eq ROUTE-NONE {
		return refuse("the '{ROUTE-NONE}' action takes no other key, and this "
			~ "one also has " ~ %action.keys.grep(* ne 'tool').sort.map({ quoted($_) }).join(', '))
			unless $keys eq 'tool';
		return %( ok => True, tool => ROUTE-NONE, text => $trimmed );
	}

	return refuse(quoted($tool) ~ ' is not one of the offered actions ('
		~ (|@names, ROUTE-NONE).join(', ') ~ ')')
		unless @names.first({ $_ eq $tool }).defined;
	return refuse("the action {quoted($tool)} must carry exactly 'tool' and "
		~ "'arguments', and this one has " ~ %action.keys.sort.map({ quoted($_) }).join(', '))
		unless $keys eq 'arguments,tool';

	my $arguments = %action<arguments>;
	return refuse("the arguments of {quoted($tool)} are not a JSON object")
		unless $arguments ~~ Associative:D;
	return refuse("the arguments of {quoted($tool)} carry a number that is not finite")
		if has-non-finite($arguments);

	%( ok => True, :$tool, arguments => $arguments.Hash, text => $trimmed );
}

#| The id the loop gives the call routed in round C<$round>.
our sub routed-call-id(Int:D $round --> Str:D) is export {
	ROUTED-CALL-PREFIX ~ $round;
}

#|( The header line of a routed result, newline included:
    C<Tool result for $tool (call $call-id):> or, for an error,
    C<Tool error for ...>. )
our sub routed-result-header(
	Str:D $tool, Str:D $call-id, Bool :$is-error = False --> Str:D
) is export {
	($is-error ?? 'Tool error' !! 'Tool result') ~ " for $tool (call $call-id):\n";
}

#|( The user message that answers a routed call: a header naming the tool
    and the call, a newline, and the content exactly as the tool gave it
    (or the loop's own sentence, for a call that never answered). )
our sub routed-result-text(
	Str:D $tool, Str:D $call-id, Str:D $content, Bool :$is-error = False,
	--> Str:D
) is export {
	routed-result-header($tool, $call-id, :$is-error) ~ $content;
}

#|( Splits a routed result message back into its header and the content
    below it: a two-element list, or an empty one when C<$text> does not
    open with a routed result header. )
our sub split-routed-result(Str:D $text --> List:D) is export {
	return ()
		unless $text ~~ / ^ ( 'Tool ' [ 'result' | 'error' ] ' for ' \N+? ' (call ' <-[\n)]>+ '):' \n ) /;
	my Str:D $header = ~$0;
	($header, $text.substr($header.chars)).List;
}

#| True when C<$backend> can carry a routing request: see the module Pod.
our sub can-route($backend --> Bool:D) is export {
	return False unless $backend.defined && $backend.can('clone')
		&& $backend.can('settings');
	my $settings = try $backend.settings;
	so $settings.defined && $settings.can('clone')
		&& $settings.can('json_schema') && $settings.can('json_schema_name')
		&& $settings.can('max_tokens');
}

#|( The completion cap of a routing request on C<$backend>: C<$max>, or the
    backend's own C<max_tokens> when that is lower. )
our sub routing-cap($backend, Int:D $max --> Int:D) is export {
	die "LLM::Agent::ToolRouting: a routing cap must be positive, not $max"
		unless $max > 0;
	my $own = try $backend.settings.max_tokens;
	($own.defined && $own ~~ Numeric && $own > 0) ?? min($own.Int, $max) !! $max;
}

#|( A clone of C<$backend> whose settings carry C<%schema> (as
    C<tool_route>) and C<$max-tokens>. The original backend and its
    settings are not touched. Dies on a backend C<can-route> refuses. )
our sub routed-backend($backend, %schema, Int:D $max-tokens --> Mu) is export {
	die 'LLM::Agent::ToolRouting: this backend (a ' ~ $backend.^name
		~ ') cannot carry a routing request — it needs cloneable settings '
		~ 'with json_schema and max_tokens, as every LLM::Chat backend has'
		unless can-route($backend);
	die "LLM::Agent::ToolRouting: a routing cap must be positive, not $max-tokens"
		unless $max-tokens > 0;

	my $original = $backend.settings;
	my $settings = $original.clone(
		json_schema      => detached(%schema, 'the routing schema').Hash,
		json_schema_name => ROUTE-SCHEMA-NAME,
		max_tokens       => $max-tokens,
	);
	my $copy = $backend.clone(:$settings);
	die 'LLM::Agent::ToolRouting: cloning the backend did not give an '
		~ 'independent copy carrying the routing settings'
		unless $copy.defined && !($copy === $backend)
			&& $copy.settings === $settings
			&& $backend.settings === $original;
	$copy;
}
