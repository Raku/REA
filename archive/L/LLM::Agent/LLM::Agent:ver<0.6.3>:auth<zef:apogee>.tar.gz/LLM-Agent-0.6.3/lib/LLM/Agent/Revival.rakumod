=begin pod

=head1 NAME

LLM::Agent::Revival - bring an interrupted run back from its own transcript

=head1 SYNOPSIS

=begin code :lang<raku>

use LLM::Agent::Revival;

# Is there anything to revive here? Reads the file, writes nothing.
my %found = LLM::Agent::Revival.inspect(
    path => $child-path, max-revivals => 2,
);
say %found<reason> unless %found<revivable>;   # 'finished', 'revival-cap', ...

# Yes: repair the interrupted call, tell the run what happened, and hand
# back everything needed to start it again as ITSELF.
my %revived = LLM::Agent::Revival.revive(
    path => $child-path, agent-id => 'researcher-1', max-revivals => 2,
);

if %revived<ok> {
    my $loop = LLM::Agent::Loop.new(
        :@backends, :$provider, session => %revived<session>,
    );
    my $run = $loop.run([|%revived<messages>]);

    # ...and the composer takes it back under its ORIGINAL id, so the
    # parent's outstanding `task_wait` finds it rather than a stranger.
    $composer.revive-child(
        agent-id => %revived<agent-id>,
        agent-type => %revived<agent-type>,
        label      => %revived<label>,
        call-id    => $spawn-envelope<call-id>,
        run        => $run,
        session-path => %revived<path>.Str,
    );
}

=end code

=head1 DESCRIPTION

A process that dies does not stop being a conversation. Its transcript is
on disk, complete to the last line that returned (see
L<LLM::Agent::Session>), and everything needed to carry it on is in
there: the messages, the tool calls that were in flight, and — for a
child of a delegating agent — the C<session-meta> its host wrote when it
started it.

This class is the B<engine half> of picking that up: given one
transcript, it decides whether there is a run to revive, repairs what the
interruption left open, tells the run what happened to it, and hands back
the pieces. It deliberately does B<not> scan a directory, ask a human, or
build a loop. Which transcripts to look at is an application's question
(a child lives in C<< <session>.agents/ >> only because an app put it
there), whether to spend the tokens is a B<human's> — a crash that
reproduces would otherwise revive the same four agents for ever — and how
a run is wired is the app's own, exactly as it is for a first spawn.

=head2 The three things an interruption leaves behind

=head3 A tool call that was in flight

C<tool-dispatched> with no C<tool-settled> means the call was handed over
and the process died before it heard back (or heard back and died before
it could say so). It is answered as a B<failure>, in the conversation,
with a message that says what happened and what to do about it:

=begin code :lang<text>

The previous session ended while this tool call was in flight, so it was
interrupted. Whether it took effect is unknown, and it has NOT been
retried: check the state of anything it was changing — a file it was
writing may have been left half-written — before assuming either way.

=end code

B<It is never replayed>, and the C<idempotency> the dispatch envelope
records does not change that. A read-only call looks safe to run again
right up until the moment the thing it read has been changed by the half
of the batch that did land; more to the point, a model that is told "this
may have half-happened" can go and look, and a replay heuristic cannot.
One honest failure covers every case, and the model decides.

The operation itself settles C<failed> with C<< reason => 'interrupted' >>.
Two other shapes settle without a message, because the conversation
already accounts for them:

=begin table

What the transcript has              | Outcome         | Reason
=====================================|=================|======================
dispatch, no settle, no tool message | failed          | interrupted
dispatch, no settle, a tool message  | outcome-unknown | completed-unpersisted
dispatch for a call no turn still has| outcome-unknown | orphaned

=end table

The second is the loop's write order paying off (the tool message is
written B<before> the settle, so a crash between them is distinguishable
from a call still running); the third is a compaction having spliced the
turn away since.

=head3 A run that does not know any of this

Every revived run is B<told>, in the conversation, immediately before it
starts thinking again:

=begin code :lang<text>

[background event] Automated notification from the system, not the user
speaking. The previous session ended while this run was working, and the
run has been resumed: everything above is its own conversation, up to the
moment it stopped. Work it had not finished is still unfinished.

=end code

It opens with the same marker and the same first sentence as
L<LLM::Agent::Subagents>' C<BACKGROUND-FRAME>, and for the same reason: a
model that has learned what C<[background event]> means from one producer
must not have to learn it again from another, and a harness notification
a model has B<not> been taught about is a notification it treats as
injected content. It is an ordinary C<user> turn carrying
C<< injected => 'revival' >> in its transcript extras, which is the
durable marker the loop's own background deliverables use — so a second
pass over the file can tell a run that has already been told from one
that has not.

=head3 A parent that is still waiting

Nothing in here touches the parent. Its C<task_wait> calls stay
B<pending> rather than being settled as unknown, which is what
L<LLM::Agent::Loop>'s C<resume-tool-calls> exists to make possible: the
joins are answered by the children that are starting again, under the
call ids they were made with. See that class's "the three states of a
tool-call tail".

=head2 What counts as revivable

A transcript whose last message is an assistant turn asking for B<no>
tools is a run that B<finished>: it said its piece, and reviving it would
start a second run that had nothing to do. Everything else — a turn with
tool calls nothing answered, a tail of tool results the model never got
to read, a user turn that was still being thought about — is a run that
was interrupted mid-work, and is revivable.

=head2 The cap, and why it is a parameter

C<max-revivals> bounds how many times one transcript may be revived, and
it is counted from the transcript itself: every revival appends a
C<run-revived> envelope, so the count survives the process that made it.
A revival past the cap is refused with C<< reason => 'revival-cap' >> and
B<nothing is written>.

It is a parameter rather than a constant because the policy belongs to
the application: a harness that asks a human every time can afford a
generous cap, an unattended one cannot, and a crash that reproduces
exactly is otherwise an unbounded bill with nothing but a human's
attention between it and the card. C<< max-revivals => 0 >> refuses every
revival, which is how a host turns the whole mechanism off without
special-casing it.

=head2 Nothing throws

C<inspect> never writes and never throws: a transcript that cannot be
read is a fact to report (C<< reason => 'unreadable' >>), the same
posture L<LLM::Agent::Session>'s C<peek> takes, and for the same reason —
the caller is a repair, reading somebody else's file, possibly while it
is still being written.

C<revive> throws only for a caller that asked for something impossible (a
path and a session at once, neither, or a negative cap). Everything about
the transcript's own state — finished, capped, unreadable — comes back as
C<< ok => False >> with a C<reason>, because none of those are programmer
errors and all of them have to be shown to a human.

=head1 SEE ALSO

L<LLM::Agent::Session> (the transcript and its crash repair),
L<LLM::Agent::Loop> (C<resume-tool-calls>, the pending-again seed state),
L<LLM::Agent::Subagents> (C<revive-child>, which takes a revived run back
under its original id).

=end pod

use LLM::Agent::Session;
use LLM::Agent::Subagents;
use LLM::Chat::Conversation::Message;

unit class LLM::Agent::Revival;

my constant Message = LLM::Chat::Conversation::Message;

#|( How many times one transcript may be revived before the mechanism
    refuses. A default, not a policy: every entry point takes
    C<max-revivals>, because how much a reproducible crash is allowed to
    cost is the application's decision and not this class's. )
our constant DEFAULT-MAX-REVIVALS = 3;

#|( The envelope one revival appends, and therefore the line this class
    counts to enforce the cap. Payload:
    C<< { attempt, agent-id?, interrupted } >>. )
our constant REVIVAL-TYPE = 'run-revived';

#|( What the model is told about a tool call the previous session was in
    the middle of. Never a replay, whatever the recorded C<idempotency>
    says — see the module Pod. The wording is deliberately specific about
    the half-written file: a child killed mid-C<fs_edit> has to go and
    look. )
our constant INTERRUPTED-MESSAGE =
	'The previous session ended while this tool call was in flight, so it '
	~ 'was interrupted. Whether it took effect is unknown, and it has NOT '
	~ 'been retried: check the state of anything it was changing — a file '
	~ 'it was writing may have been left half-written — before assuming '
	~ 'either way.';

#| The settle reason that goes with C<INTERRUPTED-MESSAGE>.
our constant INTERRUPTED-REASON = 'interrupted';

#|( The same, for a call the conversation asked for and nothing ever
    dispatched — an assistant turn committed with no C<tool-dispatched>
    line behind it. That one really did not run, and saying so is
    stronger (and kinder) than saying it might have. There is no
    operation to settle: nothing ever opened one. )
our constant NOT-DISPATCHED-MESSAGE =
	'The previous session ended before this tool call was dispatched. It '
	~ 'did not run.';

#|( What every revived run is told, as the last turn before it thinks
    again (ruling: everything is told it was interrupted and resumed —
    never a silent continuation).

    Composed from L<LLM::Agent::Subagents>' C<BACKGROUND-HEAD> rather
    than re-typed: the marker and the "not the user speaking" sentence
    are one convention across every producer of harness turns, and a
    notification a model has not been taught about is one it treats as an
    injection attempt. )
our constant RESUME-NOTICE =
	LLM::Agent::Subagents::BACKGROUND-HEAD
	~ ' The previous session ended while this run was working, and the run '
	~ 'has been resumed: everything above is its own conversation, up to '
	~ 'the moment it stopped. Work it had not finished is still unfinished.';

#| The C<injected> extra the notice is recorded under — the same durable
#| delivery marker the loop's background deliverables carry.
our constant NOTICE-KIND = 'revival';

# === Reading a transcript's tail ===

#|( Did this run finish? Its last message being an assistant turn that
    asked for no tools is the whole of the test: that is a final answer,
    and a run with one has nothing left to do.

    A transcript with no messages at all has not finished — it has barely
    started — and is revivable like any other interrupted run. )
my sub run-finished(@messages --> Bool:D) {
	return False unless @messages.elems;
	my $last = @messages[*-1];
	so $last.role eq 'assistant' && !$last.tool-calls.elems;
}

# Every id a `tool` message in this conversation answers.
my sub answered-ids(@messages --> Set:D) {
	@messages
		.grep({ $_.role eq 'tool' && $_.tool-call-id.defined })
		.map({ $_.tool-call-id.Str })
		.Set;
}

# The envelopes of one peeked transcript, as { type => payload } work:
# how many revivals it has had, and what it left dispatched.
my sub revival-count(@envelopes --> Int:D) {
	@envelopes.grep({
		$_ ~~ Associative && ($_<type> // '').Str eq REVIVAL-TYPE
	}).elems;
}

#|( The dispatch envelopes nothing settled, in file order, as
    C<< { op-id, call-id, tool } >>. Computed from raw envelopes so that
    C<inspect> can answer it without opening the file for append —
    C<< Session.pending-tool-operations >> is the same question asked of
    a loaded one. )
my sub open-dispatches(@envelopes --> List:D) {
	my %settled;
	for @envelopes -> $envelope {
		next unless $envelope ~~ Associative;
		next unless ($envelope<type> // '').Str eq 'tool-settled';
		my %payload = ($envelope<payload> ~~ Associative
			?? $envelope<payload> !! {}).Hash;
		%settled{(%payload<op-id> // '').Str} = True;
	}

	my @open;
	for @envelopes -> $envelope {
		next unless $envelope ~~ Associative;
		next unless ($envelope<type> // '').Str eq 'tool-dispatched';
		my Str $id = ($envelope<id> // '').Str;
		next unless $id.chars && !%settled{$id};

		my %payload = ($envelope<payload> ~~ Associative
			?? $envelope<payload> !! {}).Hash;
		@open.push: %(
			'op-id'   => $id,
			'call-id' => (%payload<call-id> // '').Str,
			tool      => (%payload<tool> // '').Str,
		);
	}

	@open.List;
}

# One meta value as a Str, or an undefined Str. Deliberately total: a
# transcript written by another tool may have anything in there.
my sub meta-str(%meta, Str:D $key --> Str) {
	my $value = %meta{$key};
	($value ~~ Str:D && $value.chars) ?? $value.Str !! Str;
}

#|( What this transcript says about itself, B<without writing a byte>:
    C<< { path, revivable, reason, message, agent-id, agent-type, label,
    parent, model, cwd, revivals, max-revivals, finished, message-count,
    interrupted, warnings } >>.

    C<revivable> is the answer; C<reason> says why not when it is False —
    C<unreadable> (there is no transcript there, or none that parses),
    C<finished> (the run produced a final answer), C<revival-cap> (it has
    been revived as often as this caller allows). C<message> is the same
    thing in a sentence, for a host that has to show it to somebody.

    C<interrupted> is the calls a revival would answer as failures:
    C<< { op-id, call-id, tool } >> per open dispatch whose call nothing
    answered.

    C<agent-id> comes from the C<session-meta> when it is there and from
    the file's own stem when it is not — which is what an app that names
    a child's transcript after its agent id (the convention
    L<LLM::Agent::Subagents> documents) gets for free. Pass it to
    C<revive> explicitly when the file name is not the id: keeping the id
    is the whole point of a revival, because a parent's outstanding join
    matches on it.

    Never throws. )
method inspect(
	LLM::Agent::Revival:U:
	IO(Cool) :$path!,
	Int:D :$max-revivals = DEFAULT-MAX-REVIVALS,
	--> Hash:D
) {
	die 'LLM::Agent::Revival.inspect: max-revivals cannot be negative'
		if $max-revivals < 0;

	my %peeked = LLM::Agent::Session.peek(:$path);
	my %meta = (%peeked<meta> ~~ Associative ?? %peeked<meta> !! {}).Hash;
	my @messages = %peeked<messages>.list;
	my @envelopes = %peeked<envelopes>.list;

	my Int $revivals = revival-count(@envelopes);
	my Bool $finished = run-finished(@messages);
	my $answered = answered-ids(@messages);

	my %found =
		path         => $path.IO,
		revivable    => False,
		reason       => Str,
		message      => Str,
		'agent-id'   => (meta-str(%meta, 'agent-id')
			// stem-of($path.IO)),
		'agent-type' => meta-str(%meta, 'agent-type'),
		label        => meta-str(%meta, 'label'),
		parent       => meta-str(%meta, 'parent'),
		model        => meta-str(%meta, 'model'),
		cwd          => meta-str(%meta, 'cwd'),
		revivals     => $revivals,
		'max-revivals' => $max-revivals,
		finished     => $finished,
		'message-count' => @messages.elems,
		interrupted  => open-dispatches(@envelopes).grep({
			my Str $call = $_<call-id>;
			!($call.chars && $answered{$call});
		}).List,
		warnings     => %peeked<warnings>.list.List,
	;

	if %peeked<error>.defined || !@envelopes.elems {
		%found<reason> = 'unreadable';
		%found<message> = %peeked<error>.defined
			?? %peeked<error>.Str
			!! "there is nothing in $path to revive";
		return %found;
	}

	if $finished {
		%found<reason> = 'finished';
		%found<message> = 'this run answered before it stopped, so there '
			~ 'is nothing left for it to do';
		return %found;
	}

	if $revivals >= $max-revivals {
		%found<reason> = 'revival-cap';
		%found<message> = $max-revivals == 0
			?? 'revival is switched off here (max-revivals is 0)'
			!! "this run has already been revived $revivals "
				~ ($revivals == 1 ?? 'time' !! 'times')
				~ ", which is the limit ($max-revivals)";
		return %found;
	}

	%found<revivable> = True;
	%found;
}

# A path's basename without its extension: the agent id, for an app that
# names a child's transcript after it. NB not `.extension('')`, which
# would take a suffix off a name that has none.
my sub stem-of(IO::Path:D $path --> Str:D) {
	my Str $extension = $path.extension;
	$extension.chars
		?? $path.basename.substr(0, *-($extension.chars + 1))
		!! $path.basename;
}

#|( Bring one interrupted run back: repair what the interruption left
    open, tell it what happened, and hand back everything needed to start
    it again B<as itself>.

    Takes either C<:$path> or an already-open C<:$session> — exactly one
    of the two, because two writers on one transcript is how a
    conversation ends up interleaved with itself.

    B<A refusal never opens anything.> Whether there is a revival to be
    had is answered by the read-only pass first, so a capped or finished
    transcript is not opened for append, not repaired, and not written
    to. A C<:$path> revival that goes ahead opens the file with
    C<< Session.load >> and hands it back on C<session>, still open, for
    the caller to run and close; a C<:$session> one is never closed
    here, whatever the answer.

    On success: C<< { ok => True, session, path, messages, agent-id,
    agent-type, label, parent, model, cwd, revivals, attempt,
    interrupted } >> — C<session> open for append and already carrying
    the repair, C<messages> the conversation to hand
    C<< Loop.run >> (B<start from these>: they are the transcript, and
    the seed check compares them index by index), C<attempt> which
    revival this one is, C<interrupted> the calls that were answered as
    failures.

    On a refusal: C<< { ok => False, reason, message, ... } >> with the
    same reasons C<inspect> gives, and B<nothing appended> — a capped or
    finished transcript is left exactly as it was found.

    What it writes, in order, and all of it before the run starts:

    =item one C<tool> message per interrupted call, carrying
          C<INTERRUPTED-MESSAGE> and C<< is-error => True >>;
    =item one settle per open dispatch (C<failed>/C<interrupted>,
          C<outcome-unknown>/C<completed-unpersisted>, or
          C<outcome-unknown>/C<orphaned> — see the module Pod);
    =item the resume notice, as a C<user> turn marked
          C<< injected => 'revival' >>;
    =item one C<run-revived> envelope, which is what the cap counts.

    The notice goes B<after> the repair so the run reads the failures it
    has to act on before the sentence telling it why they are there. )
method revive(
	LLM::Agent::Revival:U:
	IO(Cool) :$path,
	:$session is copy,
	Str :$agent-id,
	Int:D :$max-revivals = DEFAULT-MAX-REVIVALS,
	--> Hash:D
) {
	die 'LLM::Agent::Revival.revive: pass either a path or an open '
		~ 'session, not both — one of them would be appending behind the '
		~ "other's back"
		if $path.defined && $session.defined;
	die 'LLM::Agent::Revival.revive: pass a path to a transcript, or an '
		~ 'open session'
		unless $path.defined || $session.defined;
	die 'LLM::Agent::Revival.revive: max-revivals cannot be negative'
		if $max-revivals < 0;

	my IO::Path $file = $path.defined
		?? $path.IO
		!! (($session.?path // '').IO);

	die 'LLM::Agent::Revival.revive: this session cannot say which file it '
		~ 'is — a revival is a repair OF a transcript, and one that cannot '
		~ 'be read cannot be counted, capped or repaired'
		unless $file.Str.chars;

	# The read-only pass first, and on the file rather than on the
	# session: it answers every refusal without opening anything for
	# append, so a capped transcript is never touched at all.
	my %found = self.inspect(path => $file, :$max-revivals);
	%found<agent-id> = $agent-id.trim
		if $agent-id ~~ Str:D && $agent-id.trim.chars;

	unless %found<revivable> {
		%found<ok> = False;
		return %found;
	}

	my Bool $ours = !$session.defined;
	my $threw;
	{
		CATCH { default { $threw = $_ } }
		$session = LLM::Agent::Session.load(path => $file) if $ours;
	}

	if $threw.defined {
		%found<ok>      = False;
		%found<reason>  = 'unreadable';
		%found<message> = 'the transcript could not be opened: '
			~ ($threw.message.lines.head // $threw.^name);
		return %found;
	}

	my @interrupted;
	my Int $attempt = %found<revivals> + 1;

	# SHIELDED, because everything from here is an append to somebody's
	# disk: a transcript that cannot take the repair is a revival that did
	# not happen, reported like every other refusal, rather than an
	# exception thrown through a resume. What is already written stays
	# written — an append-only transcript has no way to take it back — and
	# a second attempt is refused by the cap, not by damage.
	my $failed;
	{
		CATCH { default { $failed = $_ } }

		my @messages = $session.messages.list;
		my $answered = answered-ids(@messages);

		# Every call this conversation asked for, in the order it asked, and
		# every one of them that nothing answered. Not just the tail's: a
		# conversation with an unanswered call anywhere in it is one no
		# provider will take, and this method's whole promise is that what it
		# hands back can be sent.
		my @unanswered = @messages
			.grep({ $_.role eq 'assistant' })
			.map({ $_.tool-calls.list })
			.flat
			.map({ ($_ ~~ Associative ?? ($_<id> // '') !! '').Str })
			.grep({ .chars && !$answered{$_} })
			.List;

		# The open dispatch envelopes, by call id. A call with one was HANDED
		# OVER and may have taken effect; a call without one never left the
		# loop, and that is a different (and stronger) thing to be able to say.
		my %open;
		for $session.pending-tool-operations.list -> %op {
			my Str $call  = (%op<call-id> // '').Str;
			my Str $op-id = (%op<op-id> // '').Str;
			%open{$call} = %op.Hash if $call.chars && $op-id.chars;
		}

		for @unanswered -> Str $call {
			my %op = (%open{$call}:exists) ?? %open{$call} !! %();
			my Bool $dispatched = so %op.elems;

			# THE MESSAGE FIRST, THE SETTLE SECOND, which is the write order
			# every settle path in this ecosystem uses: a crash between the two
			# leaves a call whose answer is already in the conversation, which
			# is a recoverable state rather than an ambiguous one.
			$session.append-message(
				Message.new(
					# NB the UNQUOTED key: a quoted fat-arrow key in an
					# argument list is a positional Pair rather than a named
					# argument, and the constructor refuses it.
					role         => 'tool',
					content      => ($dispatched
						?? INTERRUPTED-MESSAGE
						!! NOT-DISPATCHED-MESSAGE),
					tool-call-id => $call,
				),
				extra => %( 'is-error' => True ),
			);

			next unless $dispatched;

			$session.resolve-tool-operation(
				(%op<op-id> // '').Str,
				outcome => 'failed',
				reason  => INTERRUPTED-REASON,
			);
			@interrupted.push: %(
				'op-id'   => (%op<op-id> // '').Str,
				'call-id' => $call,
				tool      => (%op<tool> // '').Str,
			);
		}

		# What is left open is open for one of the two reasons that need no
		# message: the answer is already in the conversation (the settle line
		# is the only thing missing), or the turn that asked has been
		# compacted away and there is nobody left to tell.
		for $session.pending-tool-operations.list -> %op {
			my Str $call = (%op<call-id> // '').Str;
			$session.resolve-tool-operation(
				(%op<op-id> // '').Str,
				outcome => 'outcome-unknown',
				reason  => ($call.chars && $answered{$call}
					?? 'completed-unpersisted'
					!! 'orphaned'),
			);
		}

		# THE NOTICE, after the repair: the run reads the failures it has to
		# act on, and then the sentence that says why they are there.
		$session.append-message(
			Message.new(role => 'user', content => RESUME-NOTICE),
			extra => %( injected => NOTICE-KIND ),
		);

		$session.append-event(
			type    => REVIVAL-TYPE,
			payload => %(
				attempt     => $attempt,
				'agent-id'  => (%found<agent-id> // '').Str,
				interrupted => @interrupted.map({ $_<call-id> }).List,
			),
		);

	}

	if $failed.defined {
		%found<ok>      = False;
		%found<reason>  = 'unwritable';
		%found<message> = 'the repair could not be written to the '
			~ 'transcript: ' ~ ($failed.message.lines.head // $failed.^name);
		return %found;
	}

	%found<ok>          = True;
	%found<session>     = $session;
	%found<messages>    = $session.messages.list.List;
	%found<attempt>     = $attempt;
	%found<interrupted> = @interrupted.List;
	%found<reason>      = Str;
	%found<message>     = Str;
	%found;
}
