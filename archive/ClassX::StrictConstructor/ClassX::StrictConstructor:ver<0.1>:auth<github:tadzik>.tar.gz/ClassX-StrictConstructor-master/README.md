ClassX::StrictConstructor
=========================

This is MooseX::StrictConstructor ported to Perl 6

The test suite is ported as well, except for the parts that don't make sense in Perl 6
anymore. So, tests using Moose's init_arg are gone, and also the entire t/t-instance.t file.

I had fun writing this. I hope you enjoy using it too.
