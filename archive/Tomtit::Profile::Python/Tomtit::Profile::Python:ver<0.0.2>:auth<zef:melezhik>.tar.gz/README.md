# Tomtit::Profile::Python

Tomtit scripts for Python development

# Install

    zef install Tomtit::Profile::Python

# Usage

    tom --list --profile Tomtit-Profile-Python
    tom  --profile Tomtit-Profile-Python

    # run new helpers
    tom python-pip-install-from-req

# Helpers doc

See ["python-helpers"](http://sparrowhub.io/search?q=%22python-helpers%22) Sparrow plugin.

# Author

Alexey Melezhik

