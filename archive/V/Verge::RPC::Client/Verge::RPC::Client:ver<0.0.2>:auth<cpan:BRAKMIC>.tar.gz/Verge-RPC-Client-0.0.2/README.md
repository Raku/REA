# Perl6 Verge Client

This is a client for accessing the Verge [REST API](https://vergecurrency.com/langs/en/#developers)

More info about available API calls can be found [here](https://chainquery.com/bitcoin-api).

## Installation

`zef install .`

## LICENSE

[Artistic License 2.0](https://github.com/brakmic/Perl6-Verge-Client/blob/master/LICENSE)
