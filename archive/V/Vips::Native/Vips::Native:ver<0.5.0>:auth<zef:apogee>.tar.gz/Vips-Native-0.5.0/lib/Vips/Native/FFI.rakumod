unit module Vips::Native::FFI;

use NativeCall;

# === Library resolution ===
#
# Resolve libvips and libgobject-2.0 in this order:
#
#   1. $VIPS_NATIVE_LIB_DIR env var — explicit override. Full path
#      to a directory containing both libs. Escape hatch for custom
#      vips builds; you take responsibility for ABI.
#   2. XDG-staged dir (Build.rakumod's prebuilt-download path) —
#      $XDG_DATA_HOME/Vips-Native/<binary-tag>/lib/. Filenames
#      preserved (libvips.42.dylib, libgobject-2.0.0.so, etc.) so
#      the inter-lib refs vips bakes in via @loader_path / $ORIGIN /
#      sibling-DLL all resolve correctly.
#   3. Bare library name — let the OS dynamic loader find it via
#      LD_LIBRARY_PATH / DYLD_FALLBACK_LIBRARY_PATH / Windows DLL
#      search order. This is the system-libvips fallback (matches
#      0.1.x behaviour for systems with libvips installed via
#      package manager).

constant $os = $*KERNEL.name.lc;
constant $ext = $os ~~ /darwin/ ?? 'dylib'
             !! $*DISTRO.is-win ?? 'dll'
             !! 'so';

sub _staged-lib-dir(--> IO::Path) {
    # %?RESOURCES<BINARY_TAG> can misbehave during zef's dep-
    # resolution compile pass — it sometimes returns the resources
    # directory itself (stringified-from-Any) when the resources
    # dict isn't fully populated. Insist on .f (regular file) and
    # try {} the slurp so a bad value falls through cleanly to the
    # system-libvips fallback instead of dying.
    my $res = %?RESOURCES<BINARY_TAG>;
    my Str $tag = '';
    if $res.defined && $res.IO.f {
        $tag = (try $res.IO.slurp.trim) // '';
    }
    return Nil unless $tag.chars;
    my Str $base = %*ENV<VIPS_NATIVE_DATA_DIR>
        // %*ENV<XDG_DATA_HOME>
        // ($*DISTRO.is-win
                ?? (%*ENV<LOCALAPPDATA>
                        // "{%*ENV<USERPROFILE> // '.'}\\AppData\\Local")
                !! "{%*ENV<HOME> // '.'}/.local/share");
    "$base/Vips-Native/$tag/lib".IO;
}

# Find a lib by basename (without ext) in $dir, accepting versioned
# variants since vips ships per-platform names like libvips.42.dylib,
# libvips.so.42, libvips-42.dll.
sub _find-in(IO::Path $dir, Str $name --> Str) {
    return Str unless $dir.defined && $dir.d;
    my $exact = $dir.add("$name.$ext");
    return $exact.Str if $exact.e;

    for $dir.dir -> $entry {
        next unless $entry.e;
        my $bn = $entry.basename;
        return $entry.Str if $bn.starts-with("$name.") && $bn.contains(".$ext");
        return $entry.Str if $bn.starts-with("$name-") && $bn.ends-with(".$ext");
    }
    Str;
}

#| Resolve a lib by name. Returns either an absolute path (env
#| override or XDG-staged) or the bare short name (system loader
#| fallback — e.g. 'vips', 'gobject-2.0' — which lets NativeCall
#| use the OS dynamic loader to find a system-installed libvips).
sub _resolve-lib(Str $name, Str $short-name --> Str) {
    if (my $override = %*ENV<VIPS_NATIVE_LIB_DIR>) && $override.IO.d {
        with _find-in($override.IO, $name) { return $_ }
    }
    with _find-in(_staged-lib-dir(), $name) { return $_ }
    $short-name;
}

#| Set an env var that will actually be visible to C `getenv()` in
#| the current process — not just to Raku's `%*ENV` view.
#|
#| Raku's `%*ENV<X> = Y` on macOS writes to a Raku-internal env
#| table and *doesn't* propagate to the Darwin C runtime's
#| `__environ` array; verified empirically by having libvips's
#| `g_getenv("VIPSHOME")` return NULL despite Raku reporting the
#| value set. Same class of issue as Windows' CRT-vs-kernel32
#| env split. Libvips / GLib / anything linked against libc reads
#| via `getenv(3)`, so we call `setenv(3)` directly via NativeCall.
#|
#| We still update `%*ENV` too: (a) Raku code and Raku tooling see
#| the value, (b) subprocess spawns via `run`/`shell` inherit a
#| correct environ.
#|
#| Windows has a separate `_putenv_s` CRT path and we don't use
#| env vars for DLL lookup there (SetDllDirectoryW handles it), so
#| this is a POSIX-only helper.
sub _setenv-c(Str $name, Str $value) {
    %*ENV{$name} = $value;
    return if $*DISTRO.is-win;
    use NativeCall;
    # POSIX setenv: int setenv(const char *name, const char *value, int overwrite);
    # overwrite=1 matches our "caller already checked existing value" contract.
    #
    # Library name varies by platform:
    #   macOS:  'c' → /usr/lib/libSystem.B.dylib (works)
    #   Linux:  'libc.so.6' → glibc. NativeCall's default 'c' lookup
    #           appends '.so' to get 'libc.so', which on Debian/Ubuntu
    #           is a *linker script* (GROUP ( /lib/.../libc.so.6 )),
    #           not a shared object — dlopen chokes on the ELF header
    #           check. The versioned SONAME bypasses that.
    my sub mac_setenv(Str, Str, int32 --> int32)
        is native('c') is symbol('setenv') { * };
    my sub linux_setenv(Str, Str, int32 --> int32)
        is native('libc.so.6') is symbol('setenv') { * };
    if $*KERNEL.name.lc ~~ /darwin/ {
        mac_setenv($name, $value, 1);
    }
    else {
        linux_setenv($name, $value, 1);
    }
}

#| Runtime env setup for the staged-bundle case. Must run before
#| NativeCall evaluates the `is native(...)` bindings below, since
#| the first call through any of them triggers `LoadLibrary` /
#| `dlopen` on libvips, which in turn resolves libvips's own
#| dependencies using the then-current environment.
#|
#| Two problems we fix here:
#|
#|   * Windows DLL search order: when NativeCall loads libvips-42.dll
#|     by absolute path, Windows resolves libvips's own dep DLLs
#|     (libglib-2.0-0.dll, libgobject-2.0-0.dll, libintl-8.dll, …)
#|     starting from the *loading process's* directory (raku.exe),
#|     not from libvips-42.dll's directory. Linux's `$ORIGIN` rpath
#|     has no equivalent here. Prepending the staged lib dir to
#|     PATH makes the sibling DLLs findable. (No-op on macOS/Linux
#|     — @loader_path / $ORIGIN handles sibling lookup natively.)
#|
#|   * libvips 8.15+ format loaders (pngload, jpegload, heifload, …)
#|     live as separately-dlopen'd modules under $VIPS_MODULEDIR.
#|     Homebrew and build-win64-mxe both ship the split layout;
#|     conda-forge's Linux build still has loaders baked into
#|     libvips.so.42, which is why Linux passes the full test suite
#|     without this env set. We point VIPS_MODULEDIR at the sibling
#|     vips-modules dir in the bundle — harmless on builds where it
#|     doesn't exist, load-bearing on the ones where it does.
sub _configure-runtime-env() {
    # Respect $VIPS_NATIVE_LIB_DIR override — user pointed us at a
    # custom vips install and takes responsibility for its env.
    return if %*ENV<VIPS_NATIVE_LIB_DIR>;

    my $lib-dir = _staged-lib-dir();
    return without $lib-dir;
    return unless $lib-dir.d;

    if $*DISTRO.is-win {
        my $lib-str = $lib-dir.Str;

        # Belt: prepend to PATH so any loader search that consults
        # it (including third-party tools / subprocess spawns) sees
        # the staged lib dir.
        my $current = %*ENV<PATH> // '';
        unless $current.starts-with("$lib-str;") || $current eq $lib-str {
            %*ENV<PATH> = "$lib-str;$current";
        }

        # Braces: Raku's `%*ENV` writes go through the CRT
        # (`_putenv`), which on some Windows + CRT combinations
        # doesn't propagate to `GetEnvironmentVariableW` — the
        # function the Win32 loader consults when resolving
        # dependent DLLs during LoadLibrary(absolute-path). Call
        # kernel32's SetDllDirectoryW directly so the loader
        # definitely sees our staged dir regardless of CRT state.
        #
        # kernel32.dll is pre-loaded in every Windows process, so
        # `is native('kernel32')` resolves cheaply without a
        # disk probe. Using the W (wide) variant because the CI
        # runner's home path is pure ASCII today, but end users'
        # paths (especially %LOCALAPPDATA%) routinely contain
        # non-ASCII when accounts have accented names.
        #
        # SetDllDirectory's semantics: it *replaces* the "extra"
        # DLL search entry (Win32 supports one at a time, not a
        # list). This module is the only thing in the process that
        # touches it, so replace is fine; if a future module also
        # wants to set it, switch to AddDllDirectory
        # (Windows 8+ only, additive, paired with
        # SetDefaultDllDirectories(LOAD_LIBRARY_SEARCH_USER_DIRS)).
        {
            use NativeCall;
            # NativeCall encoding name is `utf16` (no dash). The W
            # (wide) variant takes UTF-16LE on Windows — which is
            # what Raku's `utf16` marshals to on little-endian hosts
            # (every Windows target we support is LE).
            my sub SetDllDirectoryW(Str is encoded('utf16'))
                returns int32 is native('kernel32') { * };
            SetDllDirectoryW($lib-str);
        }
    }

    # Make libvips look at OUR bundle for its modules instead of
    # the builder's compile-time prefix.
    #
    # libvips has no VIPS_MODULEDIR env var (I assumed there was
    # one; there isn't). At init time it uses `vips_guess_prefix`,
    # which tries in order:
    #   1. $VIPSHOME env var
    #   2. Probe `argv[0]` on PATH to find the vips install tree
    #   3. Compile-time VIPS_PREFIX (baked at build)
    #
    # When the entry-point binary isn't `vips` (e.g. `raku`), the
    # argv[0] probe fails and libvips falls back to the compile-time
    # prefix — which on our Homebrew-bottle-sourced macOS bundle is
    # `/opt/homebrew/Cellar/vips/<ver>`. libvips then enumerates
    # Homebrew's vips-modules-<major>.<minor>/ and dlopens each
    # module; those modules have LC_LOAD_DYLIBs against Homebrew's
    # libgio / libglib / etc. — which drags Homebrew's libgio into
    # the process alongside our bundled one and lights up macOS's
    # duplicate-ObjC-class crash.
    #
    # Setting VIPSHOME shortcuts the argv[0] probe. libvips computes
    # the module dir as $VIPSHOME/lib/vips-modules-<M>.<m>/, which
    # is exactly where build-binaries.yml stages our bundled modules
    # (preserving Homebrew's / build-win64-mxe's versioned dir
    # name). Respects a user-set VIPSHOME so people pointing at a
    # custom vips install keep control.
    unless %*ENV<VIPSHOME> {
        _setenv-c('VIPSHOME', $lib-dir.parent.Str);
    }

    # Disable GIO extension-module loading entirely.
    #
    # Our bundled libgio was compiled with GIO_MODULE_DIR baked to
    # the builder's prefix (Homebrew's cellar on macOS, conda's
    # prefix on Linux). At g_type_init time, GIO scans that dir and
    # dlopens every .so — and those modules are linked against the
    # *builder's* libgio, not our bundled one. On macOS specifically
    # this ends with two libgio-2.0.0.dylibs loaded and ObjC classes
    # (GNotificationCenterDelegate, GCocoaNotificationBackend, etc.)
    # registered twice, which macOS treats as a duplicate-class
    # error and bails.
    #
    # libvips only needs GIO's core type system (GObject, GType),
    # which is statically linked into libgio — the extension modules
    # (GSettings backends, proxy resolvers, network monitors) aren't
    # touched. Pointing GIO_MODULE_DIR at a guaranteed-nonexistent
    # path makes GIO find nothing to load; g_dir_open returns NULL
    # silently without logging.
    #
    # /dev/null is a file on every POSIX system, so /dev/null/anything
    # can never be a valid directory path — safe portable sentinel.
    # Windows uses NUL; we gate the whole block on POSIX since the
    # duplicate-class crash is ObjC-specific and GIO's module system
    # doesn't present the same way on Windows.
    if $os ~~ /darwin|linux/ && !%*ENV<GIO_MODULE_DIR> {
        _setenv-c('GIO_MODULE_DIR', '/dev/null/vips-native-no-gio-modules');
    }
}
_configure-runtime-env();

constant $vips-lib    is export = _resolve-lib('libvips',         'vips');
constant $gobject-lib is export = _resolve-lib('libgobject-2.0',  'gobject-2.0');

# --- Varargs ABI shim ---
#
# libvips's public API is heavily variadic: every loader, saver,
# and operation takes a NULL-terminated (key, value, ...) option
# list. Raku's NativeCall can't mark a bound C function as
# variadic, so it marshals every declared argument according to
# the *non*-variadic ABI. On Apple arm64 specifically, that
# diverges from the variadic ABI — named args go in registers
# (x0–x7) for both, but unnamed / variadic args go on the stack
# for variadic calls and in registers for non-variadic. When our
# binding declares the NULL terminator as a fixed arg, NativeCall
# puts it in register x1, libvips reads the stack looking for the
# first vararg, finds random memory there, and fails with
# "pngload: no property named `<garbage>`".
#
# Linux x86_64 and Windows x64 happen not to exhibit the bug
# because their variadic ABIs reuse the same registers as
# non-variadic for the first several args, so our register-based
# marshal accidentally works. arm64 Apple is the platform that
# actually surfaces the ABI lie.
#
# The fix is a tiny C shim (src/vips_native_shim.c) with honest
# non-variadic signatures. On macOS, build-binaries.yml compiles
# it into libvips_shim.dylib and ships it in the staged bundle
# alongside libvips. When present, we bind the variadic entry
# points through the shim; when absent (other platforms, or a
# future macOS bundle pre-dating this fix), we fall back to the
# direct libvips bindings that happen to work there.
sub _resolve-shim-lib(--> Str) {
    with _staged-lib-dir() -> $dir {
        return Str unless $dir.d;
        with _find-in($dir, 'libvips_shim') { return $_ }
    }
    Str;
}
constant $shim-lib is export = _resolve-shim-lib();
# `.f` on a stale path (e.g. cached r7 path, r7 dir since deleted)
# returns a Failure rather than False. `so try ...` collapses both
# False and the absent-file Failure into a clean Bool.
my Bool $USE-SHIM = $shim-lib.defined && (so try $shim-lib.IO.f);

# VipsInteresting
constant VIPS_INTERESTING_NONE      is export = 0;
constant VIPS_INTERESTING_CENTRE    is export = 1;
constant VIPS_INTERESTING_ENTROPY   is export = 2;
constant VIPS_INTERESTING_ATTENTION is export = 3;
constant VIPS_INTERESTING_LOW       is export = 4;
constant VIPS_INTERESTING_HIGH      is export = 5;
constant VIPS_INTERESTING_ALL       is export = 6;

# VipsKernel
constant VIPS_KERNEL_NEAREST    is export = 0;
constant VIPS_KERNEL_LINEAR     is export = 1;
constant VIPS_KERNEL_CUBIC      is export = 2;
constant VIPS_KERNEL_MITCHELL   is export = 3;
constant VIPS_KERNEL_LANCZOS2   is export = 4;
constant VIPS_KERNEL_LANCZOS3   is export = 5;
constant VIPS_KERNEL_MKS2013    is export = 6;
constant VIPS_KERNEL_MKS2021    is export = 7;

# VIPS booleans (for gboolean)
constant VIPS_FALSE is export = 0;
constant VIPS_TRUE  is export = 1;

# VipsExtend — fill mode for vips_embed
constant VIPS_EXTEND_BLACK      is export = 0;
constant VIPS_EXTEND_COPY       is export = 1;
constant VIPS_EXTEND_REPEAT     is export = 2;
constant VIPS_EXTEND_MIRROR     is export = 3;
constant VIPS_EXTEND_WHITE      is export = 4;
constant VIPS_EXTEND_BACKGROUND is export = 5;

# vips_init
sub vips_init(Str --> int32) is native($vips-lib) is export { * }

# VipsImage* is just an OpaquePointer
class VipsImage is repr('CPointer') is export { }

# --- vips_image_new_from_file(const char *, ...) ---
# Shim: vips_shim_image_new_from_file(const char *) → VipsImage*
sub _vips-load-shim(Str --> VipsImage)
    is native($shim-lib // '')
    is symbol('vips_shim_image_new_from_file') { * };
sub _vips-load-direct(Str, Str --> VipsImage)
    is native($vips-lib)
    is symbol('vips_image_new_from_file') { * };
sub vips_image_new_from_file(Str $filename, Str $null = Str --> VipsImage) is export {
    $USE-SHIM ?? _vips-load-shim($filename)
              !! _vips-load-direct($filename, $null);
}

# Get dimensions — non-variadic, bind directly.
sub vips_image_get_width(VipsImage --> int32) is native($vips-lib) is export { * }
sub vips_image_get_height(VipsImage --> int32) is native($vips-lib) is export { * }

# --- vips_smartcrop(VipsImage*, VipsImage**, int, int, ...) ---
# Shim: vips_shim_smartcrop(in, out, w, h, interesting) → int
sub _vips-smartcrop-shim(
    VipsImage, CArray[VipsImage], int32, int32, int32 --> int32)
    is native($shim-lib // '')
    is symbol('vips_shim_smartcrop') { * };
sub _vips-smartcrop-direct(
    VipsImage, CArray[VipsImage], int32, int32,
    Str, int32, Str --> int32)
    is native($vips-lib)
    is symbol('vips_smartcrop') { * };
sub vips_smartcrop(
    VipsImage $in, CArray[VipsImage] $out,
    int32 $w, int32 $h,
    Str $key, int32 $interesting, Str $null --> int32
) is export {
    $USE-SHIM ?? _vips-smartcrop-shim($in, $out, $w, $h, $interesting)
              !! _vips-smartcrop-direct($in, $out, $w, $h, $key, $interesting, $null);
}

# --- vips_resize(VipsImage*, VipsImage**, double, ...) ---
# Shim: vips_shim_resize(in, out, scale, kernel) → int
sub _vips-resize-shim(
    VipsImage, CArray[VipsImage], num64, int32 --> int32)
    is native($shim-lib // '')
    is symbol('vips_shim_resize') { * };
sub _vips-resize-direct(
    VipsImage, CArray[VipsImage], num64, Str, int32, Str --> int32)
    is native($vips-lib)
    is symbol('vips_resize') { * };
sub vips_resize(
    VipsImage $in, CArray[VipsImage] $out,
    num64 $scale,
    Str $key, int32 $kernel, Str $null --> int32
) is export {
    $USE-SHIM ?? _vips-resize-shim($in, $out, $scale, $kernel)
              !! _vips-resize-direct($in, $out, $scale, $key, $kernel, $null);
}

# --- vips_pngsave(VipsImage*, const char *, ...) ---
# Shim: vips_shim_pngsave(in, filename) → int
sub _vips-pngsave-shim(VipsImage, Str --> int32)
    is native($shim-lib // '')
    is symbol('vips_shim_pngsave') { * };
sub _vips-pngsave-direct(VipsImage, Str, Str --> int32)
    is native($vips-lib)
    is symbol('vips_pngsave') { * };
sub vips_pngsave(VipsImage $in, Str $filename, Str $null --> int32) is export {
    $USE-SHIM ?? _vips-pngsave-shim($in, $filename)
              !! _vips-pngsave-direct($in, $filename, $null);
}

# --- vips_flatten(VipsImage*, VipsImage**, ...) ---
# Alpha-composite over a (R, G, B) background. The variadic option
# list takes a VipsArrayDouble * for `background`, which is awkward
# to construct from Raku, so this binding is shim-only — the direct
# variadic path would need separate bindings for vips_array_double_new
# / vips_area_unref. If the shim isn't compiled (no toolchain on
# install), vips_flatten dies with a clear message rather than
# silently corrupting memory.
sub _vips-flatten-shim(
    VipsImage, CArray[VipsImage], num64, num64, num64 --> int32)
    is native($shim-lib // '')
    is symbol('vips_shim_flatten') { * };
sub vips_flatten(
    VipsImage $in, CArray[VipsImage] $out,
    num64 $r = 255e0, num64 $g = 255e0, num64 $b = 255e0 --> int32
) is export {
    die "vips_flatten requires the libvips_shim. Reinstall Vips::Native "
        ~ "with a working C toolchain (xcode-select --install on macOS, "
        ~ "apt install build-essential on Debian)."
        unless $USE-SHIM;
    _vips-flatten-shim($in, $out, $r, $g, $b);
}

# --- vips_embed(VipsImage*, VipsImage**, x, y, w, h, ...) ---
# Place input at (x, y) inside a w×h canvas, filling around it with
# either a fixed colour (extend = VIPS_EXTEND_BACKGROUND) or one of
# the other VipsExtend modes. Same shim-only constraint as flatten.
sub _vips-embed-shim(
    VipsImage, CArray[VipsImage],
    int32, int32, int32, int32, int32,
    num64, num64, num64 --> int32)
    is native($shim-lib // '')
    is symbol('vips_shim_embed') { * };
sub vips_embed(
    VipsImage $in, CArray[VipsImage] $out,
    int32 $x, int32 $y, int32 $width, int32 $height,
    int32 $extend = VIPS_EXTEND_BACKGROUND,
    num64 $r = 255e0, num64 $g = 255e0, num64 $b = 255e0 --> int32
) is export {
    die "vips_embed requires the libvips_shim. Reinstall Vips::Native "
        ~ "with a working C toolchain."
        unless $USE-SHIM;
    _vips-embed-shim($in, $out, $x, $y, $width, $height, $extend, $r, $g, $b);
}

# --- vips_image_write_to_memory(VipsImage *, size_t *) → void * ---
# Non-variadic, so we bind it directly without going through the shim.
# Returns a g_malloc'd buffer of width*height*bands bytes (UCHAR
# format) or NULL on error. Pair with vips_shim_free to release.
sub vips_image_write_to_memory(
    VipsImage, CArray[uint64] --> Pointer[uint8])
    is native($vips-lib) is export { * }

# Free a buffer returned by vips_image_write_to_memory. NULL-safe.
sub vips_shim_free(Pointer)
    is native($shim-lib // '')
    is symbol('vips_shim_free') is export { * };

# Image format / band introspection — needed to validate that a
# write_to_memory result has the expected layout.
sub vips_image_get_bands(VipsImage --> int32)
    is native($vips-lib) is export { * }
sub vips_image_get_format(VipsImage --> int32)
    is native($vips-lib) is export { * }

# VipsBandFormat — the elements vips_image_get_format returns
constant VIPS_FORMAT_NOTSET is export = -1;
constant VIPS_FORMAT_UCHAR  is export = 0;
constant VIPS_FORMAT_CHAR   is export = 1;
constant VIPS_FORMAT_USHORT is export = 2;
constant VIPS_FORMAT_SHORT  is export = 3;
constant VIPS_FORMAT_UINT   is export = 4;
constant VIPS_FORMAT_INT    is export = 5;
constant VIPS_FORMAT_FLOAT  is export = 6;
constant VIPS_FORMAT_DOUBLE is export = 9;

# Memory cleanup for images (from GLib/GObject)
sub g_object_unref(VipsImage) is native($gobject-lib) is export { * }

