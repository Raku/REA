[![Actions Status](https://github.com/lizmat/Version-RubyGems/actions/workflows/linux.yml/badge.svg)](https://github.com/lizmat/Version-RubyGems/actions) [![Actions Status](https://github.com/lizmat/Version-RubyGems/actions/workflows/macos.yml/badge.svg)](https://github.com/lizmat/Version-RubyGems/actions) [![Actions Status](https://github.com/lizmat/Version-RubyGems/actions/workflows/windows.yml/badge.svg)](https://github.com/lizmat/Version-RubyGems/actions)

NAME
====

Version::RubyGems - Implement RubyGems Version logic

SYNOPSIS
========

```raku
use Version::RubyGems;

my $left  = Version::RubyGems.new("1.0.0");
my $right = Version::RubyGems.new("1.0.0.a");

# method interface
say $left.cmp($right);  # Less
say $left."<"($right);  # True

# infix interface
say $left cmp $right;  # Less
say $left < $right;    # True
```

DESCRIPTION
===========

The `Version::RubyGems` distribution provides a `Version::RubyGems` class which encapsulates the logic for creating a `Version`-like object with semantics matching the [RubyGems version of Semantic Versioning](https://guides.rubygems.org/patterns/#semantic-versioning).

RubyGems extends the semver specification to any number of digits, and also allows to include lowercase letters in it to indicate pre-releases.

INSTANTIATION
=============

```raku
my $sv = Version::RubyGems.new("1.2.3-pre");
```

The basic instantion of a `Version::RubyGems` object is done with the `new` method, taking the version string as a positional argument.

ACCESSORS
=========

major
-----

```raku
my $sv = Version::RubyGems.new("1.2.3");
say $sv.major;  # 1
```

Returns the major version value.

minor
-----

```raku
my $sv = Version::RubyGems.new("1.2.3");
say $sv.minor;  # 2
```

Returns the minor version value.

patch
-----

```raku
my $sv = Version::RubyGems.new("1.2.3");
say $sv.patch;  # 3
```

Returns the patch value.

version
-------

```raku
my $sv = Version::RubyGems.new("1.2.3.4");
say $sv.version;  # (1 2 3 4)
```

Returns the constituent parts of the version specification.

pre-release
-----------

```raku
my $sv = Version::RubyGems.new("1.2.3-foo.bar");
say $sv.pre-release;  # (foo bar)
```

Returns a `List` with the pre-release tokens.

CLASS METHODS
=============

as-generic-range
----------------

```raku
say Version::RubyGems.as-generic-range('1.2');   # (== 1.2)
say Version::RubyGems.as-generic-range('^1.2');  # (>= 1.2 < 2)
say Version::RubyGems.as-generic-range('~1.2');  # (>= 1.2 < 1.3)
```

Convert an RubyGems version range specification to a generic range specification, consisting of a `Slip` with a string representing a comparator ("==", ">=", "<") and a `Version::RubyGems` object, possibly repeated.

OTHER METHODS
=============

inc
---

```raku
say Version::RubyGems.new("1.0").inc;     # Version::RubyGems.new("1.1")
say Version::RubyGems.new("1.0").inc(0);  # Version::RubyGems.new("2")
```

Returns a newly instantiated `Version::RubyGems` object with the indicated part of the version information incremented, starting with "0" for the major version part, "1" for the minor, etc. Defaults to the highest possible part. Removes any lower version parts, and any pre-release information.

```raku
my $v = Version::RubyGems.new("1.0.2-pre");
say $v.inc(:pre-release($v.pre-release));
# Version::RubyGems.new("1.1-pre");
```

Optionally takes `:pre-release` argument to add.

cmp
---

```raku
my $left  = Version::RubyGems.new("1.0");
my $right = Version::RubyGems.new("1.a");

say $left.cmp($left);   # Same
say $left.cmp($right);  # Less
say $right.cmp($left);  # More
```

The `cmp` method returns the `Order` of a comparison of the invocant and the positional argument, which is either `Less`, `Same`, or `More`. This method is the workhorse for comparisons.

eqv
---

```raku
my $left  = Version::RubyGems.new("1.0.0");
my $right = Version::RubyGems.new("1.0.0");

say $left.eqv($right);  # True
```

The `eqv` method returns whether the internal state of two `Version::RubyGems` objects is identical.

== != < <= > >=
---------------

```raku
my $left  = Version::RubyGems.new("1.2.3");
my $right = Version::RubyGems.new("1.2.4");

say $left."=="($left);  # True
say $left."<"($right);  # True
```

These oddly named methods provide the same functionality as their infix counterparts. Please note that you **must** use the `"xx"()` syntax, because otherwise the Raku compiler will assume you've made a syntax error.

EXPORTED INFIXES
================

The following `infix` candidates handling `Version::RubyGems` are exported:

  * cmp (returns `Order`)

  * eqv == != < <= > >= (returns `Bool`)

AUTHOR
======

Elizabeth Mattijsen <liz@raku.rocks>

Source can be located at: https://github.com/lizmat/Version-RubyGems . Comments and Pull Requests are welcome.

If you like this module, or what I’m doing more generally, committing to a [small sponsorship](https://github.com/sponsors/lizmat/) would mean a great deal to me!

COPYRIGHT AND LICENSE
=====================

Copyright 2025 Elizabeth Mattijsen

This library is free software; you can redistribute it and/or modify it under the Artistic License 2.0.

