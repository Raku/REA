# 0.0.2

* Don't download file if target location exists.
* Introducing headers

