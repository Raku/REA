A package for statitical decision theory (e.g. in games) for building
adaptive systems. Needs Game::Bayes and Game::Stats packages.
