#!/usr/bin/perl

use strict;
print "1..1\n";
print "ok 1\n";

