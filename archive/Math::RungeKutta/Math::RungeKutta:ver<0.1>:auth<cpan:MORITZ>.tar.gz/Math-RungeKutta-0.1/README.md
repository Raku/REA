[![Build Status](https://travis-ci.org/moritz/Math-RungeKutta.svg?branch=master)](https://travis-ci.org/moritz/Math-RungeKutta)

