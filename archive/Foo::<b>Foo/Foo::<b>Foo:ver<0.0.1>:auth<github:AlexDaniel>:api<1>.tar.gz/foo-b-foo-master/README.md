## `Foo::<b>Foo`

A module with `<b>` in its name.
