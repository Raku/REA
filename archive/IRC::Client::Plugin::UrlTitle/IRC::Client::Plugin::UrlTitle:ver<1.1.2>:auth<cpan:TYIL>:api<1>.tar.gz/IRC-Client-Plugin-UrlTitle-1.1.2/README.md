NAME
====

IRC::Client::Plugin::UrlTitle

AUTHOR
======

Patrick Spek <p.spek@tyil.work>

VERSION
=======

1.1.2

Description
===========

Plugin for IRC::Client to report titles of URLs posted in IRC channels.

Installation
============

Install this module through [zef](https://github.com/ugexe/zef):

```sh
zef install IRC::Client::Plugin::UrlTitle
```

Next, you can use it as a plugin in an [`IRC::Client`](https://modules.perl6.org/dist/IRC::Client:github:Zoffix%20Znet) project by adding it in the `:plugins` parameter:

    use Config;
    use IRC::Client;
    use IRC::Client::Plugin::UrlTitle;

    sub MAIN
    {
	    .run with IRC::Client.new(
		    :nick("testbot"),
		    :plugins(
			    IRC::Client::Plugin::UrlTitle.new,
		    )
	    );
    }

License
=======

This module is distributed under the terms of the GPL-3.0.

