$name     =  task_var 'name'
$message  =  task_var 'message'
Write-Host "$name say $message"
