run_task '00'
set_stdout('ruby rocks!')
foo
