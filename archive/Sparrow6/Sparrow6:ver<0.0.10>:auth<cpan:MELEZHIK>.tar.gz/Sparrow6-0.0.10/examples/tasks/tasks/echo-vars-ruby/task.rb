puts "this is ruby tasks called modules/echo-vars-ruby/task.rb"
puts "foo: #{task_var('foo')}"
puts "bar: #{task_var('bar')}"
