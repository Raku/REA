print "Sparrow6\n";

