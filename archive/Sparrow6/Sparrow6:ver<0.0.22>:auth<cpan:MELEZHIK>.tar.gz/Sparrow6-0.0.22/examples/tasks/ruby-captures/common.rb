def foo
  puts "# Ruby. Foo!"
end
