* bash task - add pip modules bin to PATH
