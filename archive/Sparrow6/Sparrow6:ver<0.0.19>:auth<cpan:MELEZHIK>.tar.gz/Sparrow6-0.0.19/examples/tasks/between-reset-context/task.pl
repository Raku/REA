print <<HERE;
    foo
      hello
    bar

    hello
    hello

HERE
