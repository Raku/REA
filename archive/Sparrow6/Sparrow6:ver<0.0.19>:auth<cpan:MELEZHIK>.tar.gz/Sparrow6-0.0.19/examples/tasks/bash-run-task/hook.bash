run_task echo-vars-ruby foo FOO1 bar BAR2
run_task 02 FOO_THING FOO_VALUE
run_task bash name "Bash"

set_stdout good bye!


