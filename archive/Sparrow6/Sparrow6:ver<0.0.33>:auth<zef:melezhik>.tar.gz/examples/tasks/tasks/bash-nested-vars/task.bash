echo "[" foo.bar.baz $(task_var foo.bar.baz) "]"
echo "[" main.foo $(config main.foo) "]"
