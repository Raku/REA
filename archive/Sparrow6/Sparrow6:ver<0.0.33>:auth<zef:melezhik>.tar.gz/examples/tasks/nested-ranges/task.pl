print <<HERE;
    foo1
      foo2
        foo3
          foo4
        bar
      bar
    bar
HERE
