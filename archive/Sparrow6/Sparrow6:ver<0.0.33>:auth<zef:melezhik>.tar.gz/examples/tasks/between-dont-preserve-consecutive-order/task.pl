print <<HERE;
  foo
    1
      a
    2
      b
    3
      c
  bar
HERE
