set -e
set -x

ls -l /root
