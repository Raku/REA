print "
    foo
        Z
        00
        111
        AAA
    bar

    foo
        22
        44
        66
        88
    bar

    foo
        11
        33
        BB
    bar

    foo
        K
        AAA
        111
        333
    bar
"

