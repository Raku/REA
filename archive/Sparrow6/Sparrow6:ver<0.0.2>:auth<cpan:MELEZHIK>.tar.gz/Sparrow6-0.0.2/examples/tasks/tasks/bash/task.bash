bash_generator $name
