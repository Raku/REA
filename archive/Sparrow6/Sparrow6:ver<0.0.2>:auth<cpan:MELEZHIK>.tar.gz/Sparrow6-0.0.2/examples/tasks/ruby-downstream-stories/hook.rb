run_task 'echo-vars-ruby', { 'foo' => 'FOO_value' , 'bar' => 'BAR_value' }
set_stdout "done"
