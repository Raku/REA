print "main.foo = [".(config()->{main}->{foo}), "]\n";

