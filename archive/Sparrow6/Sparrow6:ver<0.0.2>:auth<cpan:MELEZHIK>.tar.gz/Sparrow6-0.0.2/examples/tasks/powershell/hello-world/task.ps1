[Console]::Out.Flush() 

Write-Host "Hello, World!"

