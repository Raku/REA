from sparrow6lib import *
run_task(
  'echo-vars-python', { 
      'foo' : 'python says foo!!!', 
      'bar' : 'python says bar!!!'  
    } 
);
