def ruby_rocks
  'ruby rocks!' 
end
