print "task begins\n";
die "I am gone!";

