print "
Foo

  1
  2
  3

  fooo
  100
  baaar

Bar

fooo

  10
  20
  30

baaar
"

