echo  2019-04-01
echo  Name: Sparrow
echo  App Version Number: 0.0.1

