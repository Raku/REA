#!bash

echo 1 one
echo 2 two
echo 3 three

