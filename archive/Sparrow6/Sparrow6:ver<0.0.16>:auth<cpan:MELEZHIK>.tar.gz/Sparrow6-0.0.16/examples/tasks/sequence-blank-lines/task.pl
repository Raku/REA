print <<HERE;
aaa
bbb

ccc
HERE
