print <<HERE;
    this string followed by
    that string followed by
    another one string
    with that string
    at the very end.
HERE
