def my_generator
  puts 'begin:'
  puts 1
  puts 2
  puts 3
  puts 'end:'
  puts 'assert: 1 I am OK'
end
