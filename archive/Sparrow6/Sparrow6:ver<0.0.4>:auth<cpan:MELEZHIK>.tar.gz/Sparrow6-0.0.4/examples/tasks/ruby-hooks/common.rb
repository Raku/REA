def foo
  puts 'OK!!!' 
end
