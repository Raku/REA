function bash_generator {
  echo hello: $1
}
