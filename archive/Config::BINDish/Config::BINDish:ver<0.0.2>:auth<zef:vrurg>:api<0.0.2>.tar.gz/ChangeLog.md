VERSIONS
========

v0.0.2
------

  * Implemented grammar value type (`value:sym<type>`) specification

  * Replaced dot (`.`) separator with slash (`/`) in macros: `"{block.option}"` is now `"{block/option}"`

  * Implemented parent block reference in macros: `"{../../option}"`

  * Added a new standard value type: file path

  * API version bumped to v0.0.2

