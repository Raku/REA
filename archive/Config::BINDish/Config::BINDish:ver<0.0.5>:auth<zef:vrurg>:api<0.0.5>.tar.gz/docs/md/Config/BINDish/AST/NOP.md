CLASS
=====

`class Config::BINDish::AST::NOP` - No-op node

DESCRIPTION
===========

Is [`Config::BINDish::AST`](../AST.md).

Empty do-nothing node.

SEE ALSO
========

[`Config::BINDish`](../../BINDish.md), [`Config::BINDish::AST`](../AST.md)

AUTHOR
======

Vadim Belman <vrurg@cpan.org>

