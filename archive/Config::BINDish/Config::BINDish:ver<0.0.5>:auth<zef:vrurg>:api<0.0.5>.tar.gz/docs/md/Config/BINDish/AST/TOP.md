CLASS
=====

`class Config::BINDish::AST::TOP` - the root of AST tree

DESCRIPTION
===========

Is [`Config::BINDish::AST::Block`](Block.md).

SEE ALSO
========

[`Config::BINDish`](../../BINDish.md), [`Config::BINDish::AST`](../AST.md)

AUTHOR
======

Vadim Belman <vrurg@cpan.org>

