CLASS
=====

`class Config::BINDish::AST::Value` - a value container

DESCRIPTION
===========

Does [`Config::BINDish::AST::Container`](Container.md).

Is [`Config::BINDish::AST`](../AST.md).

SEE ALSO
========

[`Config::BINDish`](../../BINDish.md)

AUTHOR
======

Vadim Belman <vrurg@cpan.org>

