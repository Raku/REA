## Foo::Dependencies::Self

A module that depends on itself.
