NAME
====

Async::Command

Async::Command::Multi

AUTHOR
======
Mark Devine <mark@markdevine.com>

TITLE
=====
Asynchronous Command(s)

SUBTITLE
========
Wrap external command(s) in promise(s) & capture results.

Documentation
=============
See the doc/ directory.

Citation
========
Crafted by example from Perl 6 Fundamentals, by Moritz Lenz (ISBN
978-1-4842-2899-9).
