
# Stache

Stache is an extensible mustache-style templating engine.

## Basic Use

Raku script:

```text
{{ basic-example }}
```

Output:

```raku
{{ basic-example-output }}
```

