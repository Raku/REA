[![Actions Status](https://github.com/lizmat/Tie-Array/actions/workflows/linux.yml/badge.svg)](https://github.com/lizmat/Tie-Array/actions) [![Actions Status](https://github.com/lizmat/Tie-Array/actions/workflows/macos.yml/badge.svg)](https://github.com/lizmat/Tie-Array/actions) [![Actions Status](https://github.com/lizmat/Tie-Array/actions/workflows/windows.yml/badge.svg)](https://github.com/lizmat/Tie-Array/actions)

NAME
====

Raku port of Perl's Tie::Array module

SYNOPSIS
========

THIS FUNCTIONALITY DEPENDED ON RAKUDO INTERNAL FEATURES THAT WILL NOT BE AVAILABLE IN THE 6.E LANGUAGE VERSION. SO ANY ATTEMPT TO INSTALL THIS DISTRIBUTION WILL FAIL.

If you are running on older pre-6.e Rakudo's, then please install version [`0.0.9`](https://raku.land/zef:lizmat/Tie-Array?v=0.0.9) of this module.

Please note that there are usually better ways attaching special functionality to arrays, hashes and scalars in Raku than using `tie`. Please see the Raku documentation on [Custom Types](https://docs.raku.org/language/subscripts#Custom_types) for more information to handling the needs that Perl's tie fulfills in a more efficient way in Raku.

AUTHOR
======

Elizabeth Mattijsen <liz@raku.rocks>

Source can be located at: https://github.com/lizmat/Tie-Array . Comments and Pull Requests are welcome.

COPYRIGHT AND LICENSE
=====================

Copyright 2018, 2019, 2020, 2021, 2025, 2026 Elizabeth Mattijsen

Originally re-imagined from Perl as part of the CPAN Butterfly Plan.

This library is free software; you can redistribute it and/or modify it under the Artistic License 2.0.

