#!/bin/bash

set -e

tom --run=hello
echo LAST
tom --last
echo LAST
