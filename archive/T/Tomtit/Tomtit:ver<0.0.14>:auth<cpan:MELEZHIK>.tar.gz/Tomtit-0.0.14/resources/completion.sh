#/usr/bin/env bash
_dothis_completions()
{


  if [ "${#COMP_WORDS[@]}" != "2" ]; then
    return
  fi

  if ! test -d .tom; then
    return
  else
    cur_word="${COMP_WORDS[COMP_CWORD]}"
    COMPREPLY=($(compgen -W "$(cd .tom && ls -1 *.pl6 | perl -n -e 'chomp; s{.pl6}{}; print "$_ " ')" -- ${cur_word} ))
  fi


}

complete -F _dothis_completions tom

