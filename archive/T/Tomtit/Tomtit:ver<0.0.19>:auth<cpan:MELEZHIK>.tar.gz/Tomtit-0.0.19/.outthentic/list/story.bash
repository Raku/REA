tom --list
