#!/bash

tom foobar 2>&1

echo
