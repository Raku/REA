unit class Terminal::UI::Pane;
use Terminal::ANSI;
use Log::Async;
use Terminal::UI::Style;
use Terminal::UI::Utils;
use Terminal::ANSI::OO 't';
use Terminal::ANSIParser;
use Unicode::UTF8-Parser;
logger.untapped-ok = True;
method pod { $=pod }

subset UInt of Int where * >= 0;

#| Absolute top of the pane (default: top of the frame + 1)
has UInt $.top;

#| Absolute left edge of the pane (default: left of the frame + 1)
has UInt $.left;

#| Number of rows in the pane
has UInt $.height;

#| Number of columns
has UInt $.width;

#| Is it focusable?
has Bool $.focusable is rw = True;

#| Can lines be selected?
has Bool $.selectable is rw = True;

#| Whether this pane is currently focused
has Bool $.focused;

#| Index into @.lines (negative if we scrolled down): first line in the pane
has Int $.first-visible = 0;

#| Index into @.lines (negative if we scrolled down): currently selected line
has Int $!current-line = 0;   # index into @.lines

#| Optional descriptive name
has $.name is rw = 'unnamed';

#| The frame associated with this pane
has $.frame handles <screen>;

#| Lines of content: exactly what is sent to the screen (including formatting characters)
has @.lines;

#| Lines of raw content: unformatted, contains arrays sent to the put method
has @.raw;

#| Metadata for each line
has @.meta;

#| Style singleton
has $.style handles <colors> = Terminal::UI::Style.singleton;

#| A set of callable actions
has Callable:D %.actions;

#| A set of callable actions which will be called synchronously
has %!sync-actions;

#| Scroll automatically when putting a new line?
has Bool $.auto-scroll is rw = True;

has Lock $!write-lock .= new;

has UInt $!cursor-col = 0;
has Bool $!need-new-line = False;

method set-cursor-col(UInt $col) {
  $!cursor-col = $col;
}

method TWEAK {
  return without $.frame;
  $!height ||= $.frame.height - 2;
  $!top    ||= $.frame.top + 1;
  $!width  ||= $.frame.width - 2;
  $!left   ||= $.frame.left + 1;
}

#| Absolute bottom (top + height)
method bottom { $.top + $.height; }

#| Absolute right column (left + width)
method right { $.left + $.width; }

method reformat {
  for 0..^@!lines {
    self!format-line($_);
  }
}

#| Change the size
method set-size($!width,$!height) { }

method !format-line(Int $i) {
  trace "reformatting line $i";
  with @!raw[$i] {
    my $args = @!raw[$i];
    @!lines[$i] = self!raw2line($args);
  } else {
    error "no raw line $i";
  }
}

#| Change the offset from the top
method set-top($!top) { }

#| Metadata associated with the current line
method current-meta {
  return without $!current-line;
  @.meta[ $!current-line ]
}

#| The index of the current line
method current-line-index {
  $!current-line;
}

#| The raw text of the current line
method current-line {
  return without $!current-line;
  @.raw[ $!current-line ]
}

#| Draw the currently selected line
method draw-selected-line {
  return unless $!selectable;
  return without self.selected-row;
  my Int $l = self.selected-row;
  if $.focused {
    atomically {
      set-bg-color(self.colors<focused><selected><bg>);
      set-fg-color(self.colors<focused><selected><fg>);
      self!draw-row($l, :inner, :!border);
      normal-video;
      self!draw-row($l, :!inner, :border, :hl);
    }
  } else {
    atomically {
      set-bg-color(self.colors<unfocused><selected><bg>);
      set-fg-color(self.colors<unfocused><selected><fg>);
      self!draw-row($l, :inner, :!border);
      normal-video;
    }
  }
}

#| Select a visible row.  (0 is the top row)
method select-visible(Int $r) {
  return unless $.selectable;
  return if @.lines == 0;
  $!first-visible //= @.lines.elems max $!height;
  self.select($!first-visible + $r);
}

#| Select the first row of content
method select-first {
  return unless @!lines;
  self.select(0);
}

#| Select the last row of content
method select-last {
  return unless @!lines;
  self.select(@!lines.elems - 1);
}

#| Select the last visible row.
method select-last-visible {
  self.select-visible(self.height - 1);
}

#| Select the last visible row.
method select-first-visible {
  self.select-visible(0);
}

method validate {
  without $!current-line {
    warning "no current line";
    return;
  }
  my $str = "checking first-visible ($!first-visible) <= current ($!current-line) <= last ({self.last-visible})";
  trace $str;
  abort("failed $str") unless $!first-visible <= $!current-line <= self.last-visible;
}

#| Disable selecting of lines within a pane
method disable-selection {
  $!current-line = Nil;
  $.selectable = False;
}

#| Enable selecting of lines within a pane
method enable-selection {
  $.selectable = True;
}

#| Select an index in the content.
method select($line!) {
  return unless $.selectable;
  trace "selecting line $line";
  unless @!lines {
    info "cannot select line {$line.raku}, no content";
    return;
  }
  unless $!first-visible <= $line <= self.last-visible {
    my $prev-row = $!current-line // 0;
    $!current-line = $line;
    my $lines = $line - $prev-row;
    info "selecting line $line, need to scroll up (or down) by $lines";
    if $lines > 0 {
      self.scroll-up: :$lines;
    } else {
      self.scroll-down: lines => -$lines;
    }
    self.redraw;
    return;
  }
  my $prev-row = self.selected-row;
  $!current-line = $line;
  self.draw-selected-line;
  with $prev-row {
    self!draw-row($prev-row) if $prev-row != self.selected-row;
  }
}

#| Index of the bottom line which is visible (first-visible + height - 1)
method last-visible(Bool :$with-content = False) {
  return $!first-visible + $!height - 1 unless $with-content;
  return min( @!lines.elems - 1, $!first-visible + $!height - 1)
}

#| Select the line $n above the current one, possibly scrolling the screen down
method select-up($n = 1) {
  without $!current-line {
    warning "cannot select up, no current line";
    return;
  }
  my $actual = $n min $!current-line;
  info "select up by $n, current line $!current-line, actual is $actual";
  return unless $actual >= 1;
  # self.scroll-down if $!current-line == $!first-visible;
  self.select($!current-line - $actual);
}

method !trace($msg) {
  trace sprintf(
    "current-line %s, first-visible %s, lines %s, height %s: $msg",
    ($!current-line // 'nil'), ($!first-visible // 'nil'), @!lines.elems, $.height
  );
}

#| Select the line $n lines below the current one, possibly scrolling the screen up
method select-down($n = 1) {
  without $!current-line {
    warning "cannot select down, no current line";
    return;
  }
  my $actual = $n min (@!lines.elems - $!current-line - 1);
  info "select down $n, actual is $actual";
  return unless $actual >= 1;
  self.select($!current-line + $actual);
}

#| Move the selector down 10 rows
method select-down_10 {
  self.select-down(10);
}

#| Move the selector up 10 rows
method select-up_10 {
  self.select-up(10);
}

#| Select down by the number of lines in the pane
method page-down {
  self.select-down($.height);
}

#| Select up by the number of lines in the pane
method page-up {
  self.select-up($.height);
}

method !set-scroll-region {
  set-scroll-region(self.top, self.bottom - 1);
}

method !draw-row($row, Bool :$border = True, Bool :$inner = True, Bool :$maybe = False, Bool :$hl = False) {
  unless (0 ≤ $row ≤ $.height) {
    warning "draw-row -- line out of range; should be 1 ≤ $row ≤ $.height" unless $maybe;
    return;
  }
  return without $!first-visible;
  my $index = $!first-visible + $row - 1;
  my $str = @!lines[$index] // '';
  my Int $h = self.top + $row.trim - 1;
  if $border && $inner && self.frame {
    self.frame.print-line($h,"$str");
  } elsif $border && self.frame {
    self.frame.draw-side($h, :$hl);
  } elsif $inner {
    print-at $h, self.left, " " x self.width;
    print-at $h, self.left, "$str";
  } else {
    error "bad arguments";
  }
}

method !has-vertical-overlap {
  return False without self.frame;
  self.frame.screen.pane-count(min => self.top, max => self.bottom) > 1;
}

#| Same as redraw
method draw {
  self.redraw;
}

#| Refresh the screen
method redraw {
  $!write-lock.lock;
  for 1..$.height {
    if self.selected-row and $_ == self.selected-row {
      self.draw-selected-line;
    } else {
      self!draw-row($_);
    }
  }
  $!write-lock.unlock;
}

#| Scroll the visible contents up.  Optionally limit scrolling based on the contents.
method scroll-up(Bool :$limit = True, Int :$lines = 1) {
  debug "scroll up by $lines";
  my $actual = $lines;
  if $limit && $!first-visible + self.height + $lines > self.lines.elems {
    $actual = - ( $!first-visible + self.height - self.lines.elems );
    warning "cannot scroll up because first visible + height >= elems, will scroll $actual instead";
    return if $actual == 0;
  }
  if ($actual >= self.height or self!has-vertical-overlap) {
    $!first-visible += $actual;
    if $!current-line < self.first-visible {
      $!current-line = self.first-visible;
    }
    self.redraw;
    return;
  }
  atomically {
    self!set-scroll-region;
    scroll-up($actual);
  }
  $!first-visible += $actual;
  if $!current-line < self.first-visible {
    $!current-line = self.first-visible;
  }
  self.draw-selected-line;
  for 0..^($actual) {
    self!draw-row(self.height - $_)
  }
}

#| Scroll the visible contents down.  Optionally limit scrolling based on the contents.
method scroll-down(Int :$lines = 1) {
  debug "scroll down by $lines, first-visible={$!first-visible//0}, lines.elems={@!lines.elems}, current-line={$!current-line//0}";
  my $actual = $lines;
  if $!first-visible < $lines {
    $actual = $!first-visible;
    return if $actual == 0;
  }
  if ( $actual >= self.height or self!has-vertical-overlap) {
    $!first-visible -= $actual;
    if $!current-line > self.last-visible {
      $!current-line = self.last-visible;
    }
    self.redraw;
    return;
  }
  atomically {
    self!set-scroll-region;
    scroll-down($actual);
  }
  $!first-visible -= $actual;
  with $!current-line {
    if $!current-line > self.last-visible {
      $!current-line = self.last-visible;
    }
    abort("scrolling calculation wrong") without self.selected-row;
    self.draw-selected-line;
  }
  self!draw-row($_) for 1..($actual);
}

#| Selected row, in the range 1..$!height
method selected-row {
  return Nil without $!current-line;
  return Nil without $!first-visible;
  return Nil unless $.focusable;
  my $r = $!current-line - $!first-visible + 1;
  unless 1 <= $r <= $.height {
    warning "selected row $r is out of range (height: {$.height})";
    return;
  }
  $r;
}

#| Clear and add content centered vertically and horizontally
multi method splash(@content, :$center = True, :$title, :$top is copy) {
  self.clear;
  self.update(:1line, [ t.bold => $title ], :center) if $title;
  $top //= (self.height div 2) - (@content.elems div 2);
  for @content.kv -> $i, $arg {
    self.update: :line($top + $i), @$arg, :$center;
  }
}

#| Clear and add content centered vertically and horizontally
multi method splash($content, :$center = True, :$title, :$top) {
  self.splash($content.lines, :$title, :$center, :$top)
}

multi method update(Str $content, Int :$line!, Bool :$center, :%meta) {
  self.update([$content], :$line, :$center, :%meta);
}

#| Update a line of content
multi method update($content, Int :$line!, Bool :$center, :%meta) {
  if $line > @!lines.elems - 1 {
    for @!lines.elems .. $line {
      # autovivify
      self.put("",:!scroll-ok);
    }
  }
  @!meta[$line] = %meta with %meta;
  @!lines[$line] = self!raw2line($content // [], :$center);
  @!raw[$line] = $content // [];
  self!draw-row($line + 1 - $!first-visible);
}

sub sanitize(Str(Mu) $s) {
  return "" unless $s && $s.defined;
  $s.trans("\t" => '  ', :g);
}

method !centered($str) {
  my $cnt = sanitize($str).fmt("%{self.width div 2 + $str.chars div 2}s");
  $cnt.fmt("%-{self.width}s");
}

subset WrapModes of Str where * eq any <none word hard>;

#| Print a raw string to the terminal
method print(Str $str) {
  # If string contains \n or \r (and is more than just that char), split and process recursively
  if $str ne "\n" && $str ne "\r" && $str ~~ /\n|\r/ {
    for $str.split(/(\n|\r)/, :v) -> $part {
      self.print(~$part) if $part ne '';
    }
    return;
  }

  # Determine which line to write to
  my $line-index;

  # For actual content (not control characters), check if we need a new line
  if $str ne "\n" && $str ne "\r" && !$str.starts-with("\e") {
    # Need a new line if: empty OR we saw a newline and need a new line
    if !@!lines.elems || $!need-new-line {
      $line-index = @!lines.elems;  # Create new line at end
      @!lines[$line-index] = '';
      @!raw[$line-index] = '';
      $!need-new-line = False;  # Clear the flag
    } else {
      $line-index = @!lines.end;  # Continue on last line
    }
  } else {
    # For control chars, use existing last line if any
    $line-index = @!lines.end max 0;
  }

  # Calculate visible row for this line
  my $visible-row = $line-index - ($!first-visible // 0);

  # If beyond visible area, scroll to show the line at bottom
  if $visible-row >= $.height {
    $!first-visible = $line-index - $.height + 1;
    $visible-row = $.height - 1;
    # Adjust current-line to stay within valid range
    with $!current-line {
      if $!current-line < $!first-visible {
        $!current-line = $!first-visible;
      }
    }
  } elsif $visible-row < 0 {
    $visible-row = 0;
  }

  my $screen-row = self.top + $visible-row;

  # Set scroll region, print, and reset atomically
  atomically {
    self!set-scroll-region;
    print-at $screen-row, self.left + $!cursor-col, $str;
    reset-scroll-region;
  }

  # Update cursor position and line content based on the character
  if $str eq "\n" {
    # Signal we need a new line next time
    $!cursor-col = 0;
    $!need-new-line = True;

    # Update first-visible to follow the cursor at the bottom
    my $new-line-index = @!lines.end;
    if $new-line-index >= $.height {
      $!first-visible = $new-line-index - $.height + 1;
      # Adjust current-line to stay within valid range
      with $!current-line {
        if $!current-line < $!first-visible {
          $!current-line = $!first-visible;
        }
      }
    }

    # Redraw border after newline
    self.frame.draw() with self.frame;
  } elsif $str eq "\r" {
    # Carriage return - reset column position only, don't clear stored content or signal new line
    $!cursor-col = 0;
  } elsif $str.starts-with("\e") {
    # Escape sequences are invisible, don't update column or add to content
  } else {
    # For regular visible chars, write at cursor position using substr
    my $line = @!lines[$line-index];
    # Pad line if cursor is past the end
    if $!cursor-col > $line.chars {
      $line ~= ' ' x ($!cursor-col - $line.chars);
    }
    # Write character(s) at cursor position
    substr-rw($line, $!cursor-col, $str.chars) = $str;
    @!lines[$line-index] = $line;
    @!raw[$line-index] = $line;
    $!cursor-col += $str.chars;
  }
}

#| Stream data from a Supply to the pane, parsing ANSI sequences
method stream(Supply $supply) {
  my $buffer = '';

  my sub flush-buffer {
    if $buffer {
      self.print($buffer);
      $buffer = '';
    }
  }

  my &parse := make-ansi-parser(emit-item => -> $item {
    given $item {
      when Terminal::ANSIParser::CSI {
        flush-buffer();
        self.print($item.Str);
      }
      when Terminal::ANSIParser::OSC
          | Terminal::ANSIParser::PM
          | Terminal::ANSIParser::APC
          | Terminal::ANSIParser::DCS {
        warning "ignoring { .^name } sequence " ~ .raku;
        flush-buffer();
      }
      when Terminal::ANSIParser::Sequence {
        warning "sequence class is { .^name }";
        flush-buffer();
        self.print($item.Str);
      }
      when Int {
        my $char = chr($item);
        if $char eq "\n" || $char eq "\r" {
          flush-buffer();
          self.print($char);
        } else {
          $buffer ~= $char;
        }
      }
      default {
        flush-buffer();
        warning "Unknown ANSI item: " ~ $item.^name ~ " | " ~ $item.raku;
      }
    }
  });

  # Convert buf8 chunks to individual bytes, then decode UTF-8 with proper buffering
  my $byte-supply = supply {
    whenever $supply -> $chunk {
      emit $_ for $chunk.list;
    }
  }
  my $char-supply = parse-utf8-bytes($byte-supply);

  $char-supply.tap: -> $char {
    parse($char.ord) if $char ~~ Str;
    parse($char) if $char ~~ Int;  # Invalid UTF-8 bytes
    flush-buffer();
  }
}

#| Add lines of content, possibly scrolling.
#| Content is added one line at a time -- the content
#| can be any type that has a 'lines' method.
multi method put($content, Bool :$scroll-ok = $.auto-scroll, Bool :$center, :%meta, WrapModes :$wrap = 'none') {
  $!write-lock.lock;
  LEAVE $!write-lock.unlock;
  # self.validate;
  without $content {
    warning "content is undefined";
    return;
  }
  if $content ~~ IO or ( $content.?lines // 0) > 1 {
    for $content.lines -> $l {
      self.put(~$l, :$scroll-ok, :$center, :%meta);
    }
    return;
  }
  my $str := $content.Str;
  if ( $wrap eq 'hard' and $str.chars > $.width ) {
    for $str.comb($.width) -> $l {
      self.put(~$l, :$scroll-ok, :$center, :%meta);
    }
    return;
  }
  if ( $wrap eq 'word' and $str.chars > $.width ) {
    my @words = $str.words;
    my $line = '';
    for @words -> $w {
      if $w.chars > $.width {
        # word is too long, hard wrap it
        for $w.comb($.width) -> $hw {
          self.put($line, :$scroll-ok, :$center, :%meta) if $line.chars > 0;
          $line = '';
          self.put($hw, :$scroll-ok, :$center, :%meta);
        }
        next;
      }
      if $line.chars + 1 + $w.chars > $.width {
        self.put($line, :$scroll-ok, :$center, :%meta);
        $line = $w;
      } else {
        $line ~= " " if $line.chars > 0;
        $line ~= $w;
      }
    }
    self.put($line, :$scroll-ok, :$center, :%meta) if $line.chars > 0;
    return;
  }

  $!first-visible //= 0;
  $!current-line //= 0;
  my $should-scroll = self.last-visible == (@!lines - 1);
  @!meta[ @!lines.elems ] = %meta with %meta;
  with @!raw[ @!lines.elems ] {
    warning "cannot center formatted text" if $center;
    @!lines.push: sanitize($str);
    # raw done, don't calculate
  } else {
    if $center {
      my $cnt = sanitize($str).fmt("%{self.width div 2 + $str.chars div 2}s");
      @!lines.push: $cnt.fmt("%-{self.width}s");
    } else {
      @!lines.push: sanitize($str).substr(0,self.width);
    }
    @!raw.push: $str;
  }
  # Signal that print should start a new line after put
  $!need-new-line = True;
  if $scroll-ok && $should-scroll {
    self.scroll-up; # draws the row at self.height
  } else {
    self!draw-row(@!lines.elems - ($!first-visible // 0), :maybe);
  }
  self;
}

method !raw2line($args, Bool :$center) {
  my $line = '';
  my $left = $.width;
  for $args<> {
    when Str {
     with .substr(0,$left) {
       $line ~= $_;
       $left -= .chars;
       $left -= .uniprops("W").grep(* eq "W").elems;
     }
    }
    when Pair {
      $line ~= .key;
      with (.value // '').substr(0,$left) {
        $line ~= $_;
        $left -= .chars;
        $left -= .uniprops("W").grep(* eq "W").elems;
      }
    }
    default {
      fatal "unknown arg: " ~ .^name ~ ' -- ' ~ (.raku);
    }
    last unless $left > 0;
  }
  if $center {
    $line = (" " x ($left div 2)) ~ $line ~ (" " x ( $left - ($left div 2)));
  } else {
    $line ~= " " x $left;
  }
  $line;
}

method !raw2line-hardwrap(@args, Int :$indent = 0) {
  my @remaining = @args;
  return (Nil,Empty) unless @args > 0;
  my $width = $.width - $indent;
  my $line = '';
  my $left = $width;
  loop {
    last unless @remaining;
    my Pair $this = @remaining[0] ~~ Str ?? ( "" => @remaining.shift) !! @remaining.shift;
    $line ~= $this.key;
    if $this.value.chars > $left {
      $line ~= $this.value.substr(0,$left);
      @remaining.unshift: ( $this.key => $this.value.substr($left) );
      $left = 0;
    } else {
      $line ~= $this.value;
      $left -= $this.value.chars;
    }
    last unless $left > 0;
  }
  $line ~= " " x $left;
  ((" " x $indent) ~ $line, @remaining);
}

method !raw2line-wordwrap(@args, Int :$indent = 0) {
    return (Nil,Empty) unless @args;
    my @remaining = @args;
    my $width = $.width - $indent;
    my $line = '';
    my $left = $width;
    my $has-word = False;

    loop {
        last unless @remaining;
        my $this = @remaining[0] ~~ Str ?? ("" => @remaining.shift) !! @remaining.shift;

        # Add formatting key
        $line ~= $this.key;

        # Process words
        my @words = $this.value.words;
        while @words {
            my $word = @words[0];
            my $space-needed = $word.chars + ($has-word ?? 1 !! 0);

            # Word too long for width
            if $word.chars > $width {
                # Return current line if not empty
                if $has-word {
                    @remaining.unshift: ($this.key => @words.join(" "));
                    return ((" " x $indent) ~ $line ~ (" " x $left), @remaining);
                }
                # Split long word
                @words[0] = $word.substr($width);
                $line = $word.substr(0, $width);
                @remaining.unshift: ($this.key => @words.join(" "));
                return ((" " x $indent) ~ $line, @remaining);
            }

            # Word doesn't fit current line
            if $space-needed > $left {
                @remaining.unshift: ($this.key => @words.join(" "));
                return ((" " x $indent) ~ $line ~ (" " x $left), @remaining);
            }

            # Add word to line
            $line ~= " " if $has-word;
            $line ~= $word;
            $left = $width - $line.chars;
            $has-word = True;
            @words.shift;
        }
    }

    ((" " x $indent) ~ $line ~ (" " x $left), @remaining);
}

#| Put formatted text.  Each element is either a string or a pair.  Strings
#| are printed.  Keys of pairs are printed, and then their values.  Keys are
#| assumed to be formatting, and do not count towards the length of the line.
#| :indent puts left padding on every wrapped line; :hang adds extra padding
#| on continuation lines only (eg. to align wrapped text under the text
#| after a bullet, rather than under the bullet itself).
multi method put(@args, Bool :$scroll-ok = $.auto-scroll, :%meta, WrapModes :$wrap = 'none', Bool :$center, Int :$indent = 0, Int :$hang = 0) {
  die "escape character in args: please use a pair" if @args.grep: { $_ ~~ Str && /\e/ }
  my $i = @!lines.elems;
  if $wrap eq 'hard' {
    my $str;
    my @rem = @args;
    my $first = True;
    loop {
      last unless @rem && @rem.elems > 0;
      my ($next,@left) := self!raw2line-hardwrap(@rem, :indent($indent + ($first ?? 0 !! $hang)));
      $str = $next;
      last without $str;
      @rem = @left;
      @!raw[ $i ] = @rem.clone;
      self.put($str, :$scroll-ok, :%meta);
      $i++;
      $first = False;
    }
  } elsif $wrap eq 'word' {
    my $str;
    my @rem = @args;
    my $first = True;
    loop {
      last unless @rem && @rem.elems > 0;
      my ($next,@left) := self!raw2line-wordwrap(@rem, :indent($indent + ($first ?? 0 !! $hang)));
      $str = $next;
      last without $str;
      @rem = @left;
      @!raw[ $i ] = @rem.clone;
      self.put($str, :$scroll-ok, :%meta);
      $i++;
      $first = False;
    }
  } else {
    @!raw[ $i ] = @args.clone;
    self.put(self!raw2line(@args, :$center), :$scroll-ok, :%meta);
  }
}

#| Focus on this pane
method focus {
  info "focusing";
  $!focused = True;
  if @!lines == 0 {
    self.put: "";
  }
  self.draw-selected-line;
  self;
}

#| Remove focus from this pane
method unfocus {
  info "unfocusing";
  $!focused = False;
  self.draw-selected-line;
  self;
}

#| Clear the content and redraw
method clear {
  @!lines = (" " x $.width) xx $.height;
  $!current-line = 0;
  $!first-visible = 0;
  self.redraw;
  @!lines = ();
  @!meta = ();
  @!raw = ();
  $!current-line = Nil;
  $!first-visible = Nil;
  self.call('after_clear', arg => self, :maybe);
}

#| Associate callbacks with events
multi method on(*%kv) {
   for %kv.pairs {
     self.on(name => .key, action => .value);
   }
}

#| Associate a callback, with the name of an action
multi method on(Str :$name!, Callable :$action!) {
  %!actions{ $name } = $action
}

multi method on-sync(*%kv) {
   for %kv.pairs {
     self.on-sync(name => .key, action => .value);
   }
}

#| Associate a synchronous callback, with the name of an action
multi method on-sync(Str :$name!, Callable :$action!) {
  %!actions{ $name } = $action;
  %!sync-actions{ $name } = True;
}

#| Run the action with the given name
method call($name, :$arg, Bool :$maybe) {
  if $name eq <select-up select-down select-last select-first page-up page-down select-down_10 select-up_10>.any {
    return self."$name"() unless %!actions{ $name };
  }
  unless %!actions{ $name } {
    info "no action for $name in pane {self.name}" unless $maybe;
    return;
  }
  my &code := %!actions{ $name };
  if $arg {
    return code($arg);
  }
  my %sig = &code.signature.params.grep(*.named).map(*.name => 1);
  my %args;
  %args<meta> = self.current-meta if %sig{'$meta'};
  if %sig{'%meta'} {
    my %meta = self.current-meta.Hash;
    %args<meta> = %meta;
  }
  %args<raw> = @!raw[$!current-line] if %sig{'$raw'};
  debug "sending args for $name: " ~ %args.keys.join(',');
  if %!sync-actions{$name} {
    code(|%args);
  } else {
    start code(|%args);
  }
}

#| Run a shell command, and send the lines of the output to this pane, optionally filtering the output
method exec(@cmd, :$filter) {
  trace "running @cmd";
  my $proc = run |@cmd, :out, :err;
  for $proc.out.lines -> $text {
    self.put("$text") if !$filter.defined || ($text ~~ $filter);
  }
  for $proc.err.lines -> $text {
    self.put("error: $text");
  }
  trace "done " ~ $proc.exitcode;
}

=NAME Terminal::UI::Pane -- An area that contains scrollable text

=begin DESCRIPTION

A pane is a text area that can scroll.  It also has as registry of
actions, which may be referenced by name.

=end DESCRIPTION

