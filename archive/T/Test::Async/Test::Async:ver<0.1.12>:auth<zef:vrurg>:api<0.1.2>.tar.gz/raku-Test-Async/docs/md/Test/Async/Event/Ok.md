Class `Event::Ok`
=================

Is [`Event::Test`](Test.md).

Reports test pass.

SEE ALSO
========

[`Test::Async::Event`](../Event.md)

AUTHOR
======

Vadim Belman <vrurg@cpan.org>

