Class `Event::BailOut`
======================

Is [`Event::Report`](Report.md).

Emitted when test suite is about to bail out.

SEE ALSO
========

[`Test::Async::Event`](../Event.md)

AUTHOR
======

Vadim Belman <vrurg@cpan.org>

