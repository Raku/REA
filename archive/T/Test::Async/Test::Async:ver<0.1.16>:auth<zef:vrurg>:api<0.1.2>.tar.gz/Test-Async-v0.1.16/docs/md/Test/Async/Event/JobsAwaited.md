# Class <Event::JobsAwaited>

Is [`Event`](https://raku.land/?q=Event)

Emitted when all pending jobs are completed.

# SEE ALSO

  - [`Test::Async::Event`](../Event.md)

  - [`INDEX`](../../../../../INDEX.md)

# COPYRIGHT

(c) 2020-2023, Vadim Belman <vrurg@cpan.org>

# LICENSE

Artistic License 2.0

See the [*LICENSE*](../../../../../LICENSE) file in this distribution.
