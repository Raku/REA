NAME
====



`Test::Async::Metamodel::BundleHOW` - metaclass backing bundle roles

DESCRIPTION
===========



The only function is to register the bundle role with slang defined in [`Test::Async::Decl`](../Decl.md).

SEE ALSO
========

[`Test::Async::Manual`](../Manual.md), [`Test::Async::Decl`](../Decl.md)

AUTHOR
======

Vadim Belman <vrurg@cpan.org>

