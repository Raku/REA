Class `Event::NotOk`
====================

Is [`Event::Test`](Test.md).

Reports flunked test.

SEE ALSO
========

[`Test::Async::Event`](../Event.md)

AUTHOR
======

Vadim Belman <vrurg@cpan.org>

