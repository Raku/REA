NAME
====



`Test::Async::Metamodel::ReporterHOW` - metaclass backing a reporter bundle

DESCRIPTION
===========



This class inherits from `Test::Async::Metamodel::BundleHOW` and adds implicit application of [`Test::Async::Reporter`](../Reporter.md) role.

SEE ALSO
========

[`Test::Async::Manual`](../Manual.md), [`Test::Async::Decl`](../Decl.md)

AUTHOR
======

Vadim Belman <vrurg@cpan.org>

