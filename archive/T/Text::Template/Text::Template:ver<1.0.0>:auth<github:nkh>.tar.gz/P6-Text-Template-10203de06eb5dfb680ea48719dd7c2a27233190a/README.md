# P6-Text-Template
Render text template with embedded variables and Perl6 code
