perl6 --doc=Markdown ./lib/Text/Center.pm6 > ./README.md
