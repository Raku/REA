# Want to help?

You can really help in any number of ways. One of the things I would
like is to have the module done completely using Perl 6 Grammars,
which are out of my reach right now. 

If it's too much for you
too,
[take a look at the issues](https://github.com/retupmoca/p6-markdown/issues). Some
of them are old... And some of them are more urgent than others, for
instance
the
[one on nested lists](https://github.com/retupmoca/p6-markdown/issues/25). 

New features are also welcome, but first thing first. If you have any
doubt, just raise an issue and I'll get back to you.
