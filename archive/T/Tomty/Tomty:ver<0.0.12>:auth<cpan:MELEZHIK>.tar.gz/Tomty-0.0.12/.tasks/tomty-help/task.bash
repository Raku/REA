tomty --help
