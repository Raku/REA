[![Build Status](https://travis-ci.org/perl6/tap-harness6.svg?branch=master)](https://travis-ci.org/perl6/tap-harness6)



