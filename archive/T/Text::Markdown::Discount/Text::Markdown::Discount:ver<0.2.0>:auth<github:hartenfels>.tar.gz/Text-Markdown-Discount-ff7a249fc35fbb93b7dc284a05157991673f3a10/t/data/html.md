bare link http://doc.perl6.org/

angly link <http://doc.perl6.org/>

[titled link](http://doc.perl6.org/)

<a href="http://doc.perl6.org/">html link</a>
