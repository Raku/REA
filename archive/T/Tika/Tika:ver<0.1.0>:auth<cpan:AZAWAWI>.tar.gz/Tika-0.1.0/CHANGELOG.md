# Changelog for Tika

## 0.1.0 - 2018-11-08
  - :tada: Initial version lands on CPAN.
