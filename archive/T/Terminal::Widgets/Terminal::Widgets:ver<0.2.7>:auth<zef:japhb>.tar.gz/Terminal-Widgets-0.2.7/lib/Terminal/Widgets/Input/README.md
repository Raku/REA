# Input Widgets

This directory contains all widgets primarily intended as inputs, such as
classic form elements and editors.

If the widget provides an interactive view but is _not_ intended primarily for
input/editing, it probably belongs in `Viewer/` or `Viz/` instead.
