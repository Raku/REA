# Internationalization (I18N) Modules

This directory contains modules, classes, and operators that power the I18N
engine, such as string translation and locale sensitivity.
