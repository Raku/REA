# Utility Modules

This directory contains modules that are primarily intended as collections of
utility functions for widgets or other modules.  For example, color space
calculations and data format conversions would belong here.
