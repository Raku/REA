# Progress Widgets

This directory contains widgets that primarily act as progress trackers, plus
the `Terminal::Widgets::Progress::Tracker` role they share.

Examples here would be progress bars, throbbers, job status trackers, etc.
