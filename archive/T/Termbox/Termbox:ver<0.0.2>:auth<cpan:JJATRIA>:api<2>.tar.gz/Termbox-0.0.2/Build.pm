unit class Build;

method build ($cwd) { run './configure', :$cwd }
