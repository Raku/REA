# Rakudist Teddy::Bear

Dummy Raku module to test SparrowCI service.

# Author 

Alexey Melezhik
