Change log for the Test::Deeply::Relaxed Perl 6 module
======================================================

0.1.0
-----

Initial public release.
