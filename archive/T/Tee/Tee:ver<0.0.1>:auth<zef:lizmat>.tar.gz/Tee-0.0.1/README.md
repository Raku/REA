[![Actions Status](https://github.com/lizmat/Tee/actions/workflows/linux.yml/badge.svg)](https://github.com/lizmat/Tee/actions) [![Actions Status](https://github.com/lizmat/Tee/actions/workflows/macos.yml/badge.svg)](https://github.com/lizmat/Tee/actions) [![Actions Status](https://github.com/lizmat/Tee/actions/workflows/windows.yml/badge.svg)](https://github.com/lizmat/Tee/actions)

NAME
====

Tee - Duplicate $*OUT and/or $*ERR output

SYNOPSIS
========

```raku
use Tee;

my $out = "output.stdout".IO.open(:a);
Tee("output.stdout", my $*OUT);
say "foo";   # foo␤ on STDOUT and "output.stdout" file
note "bar";  # bar␤ on STDERR
```

DESCRIPTION
===========

The `Tee` distribution duplicates any output sent to STDOUT and/or STDERR to zero or more files. Files can be specified as either a path (as string or as `IO::Path` object), or as an `IO::Handle` object.

If you're more interested in trapping `STDOUT` and/or `STDERR`, you should have a look at the [`Trap`](https://raku.land/zef:lizmat/Trap) distribution.

INSTANTIATION
=============

The `Tee` class can be called directly with two or three positional arguments. The first positional argument indicates the file(s) which should be written to. If there's only a single file, it can be specified directly. If there are more files, they must be specified as a list.

The second and third argument indicate the source to be used. They **must** be specified as `my $*OUT` (for duping STDOUT) and/or `my $*ERR` (for duping STDERR).

METHODS
=======

method close
------------

```raku
my $tee = Tee($out, my $*OUT);
$tee.close;
```

In some case, it can be necessary to close the files to which output has been duplicated. The `close` method on the `Tee` object will do that for you.

AUTHOR
======

Elizabeth Mattijsen <liz@raku.rocks>

Source can be located at: https://github.com/lizmat/Tee . Comments and Pull Requests are welcome.

If you like this module, or what I’m doing more generally, committing to a [small sponsorship](https://github.com/sponsors/lizmat/) would mean a great deal to me!

COPYRIGHT AND LICENSE
=====================

Copyright 2025 Elizabeth Mattijsen

This library is free software; you can redistribute it and/or modify it under the Artistic License 2.0.

