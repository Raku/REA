NAME
====

Transit::Network - Plan and set up public transportation routes or networks

SYNOPSIS
========

```
use Transit::Network;
```

DESCRIPTION
===========
Transit::Network (and the bundled programs) enables you to plan and set up public transportation
routes or complete networks.

See https://raku-musings.com/transit-network/ for a description of this module.

The module comes with some sample networks. Use the «--help» command line option, or the «help» 
command, to get the location of the zip file.

    $ networkplanner --help

    $ networkplanner
    networkplanner: Enter «exit» to exit
    > help

AUTHOR
======

Arne Sommer <arne.sommer@gmail.com>

COPYRIGHT AND LICENSE
=====================

Copyright 2021-2022 Arne Sommer

This library is free software; you can redistribute it and/or modify it under the Artistic License 2.0.

