# p6-Text-VimColour

Converts scripts into colour syntax HTML using vim.

Idea was shamelessly stolen from the original Perl 5 Text::VimColor

Pull requests welcome.
