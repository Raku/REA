# Trove test harness

## Overview

Yet another test harness written in Raku language and inspired by `bash` driven test suite built into [Pheix](https://gitlab.com/pheix-pool/core-perl6) content management system.

## License information

This is free and opensource software, so you can redistribute it and/or modify it under the terms of the [The Artistic License 2.0](https://opensource.org/licenses/Artistic-2.0).

## Author

Please contact me via [LinkedIn](https://www.linkedin.com/in/knarkhov/) or [Twitter](https://twitter.com/CondemnedCell). Your feedback is welcome at [narkhov.pro](https://narkhov.pro/contact-information.html).
