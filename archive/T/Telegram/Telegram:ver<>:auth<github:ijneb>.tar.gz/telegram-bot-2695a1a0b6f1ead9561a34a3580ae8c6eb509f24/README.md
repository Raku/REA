# Perl6 Telegram Bot Library

This will soon be a reactive Telegram bot library written for Perl6.
