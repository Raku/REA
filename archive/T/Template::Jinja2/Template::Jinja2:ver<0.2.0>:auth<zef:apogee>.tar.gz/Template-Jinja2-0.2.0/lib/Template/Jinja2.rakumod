use Template::Jinja2::Lexer;
use Template::Jinja2::Parser;
use Template::Jinja2::AST;
use Template::Jinja2::Renderer;
use Template::Jinja2::Context;
use Template::Jinja2::Filters;
use Template::Jinja2::Tests;
use Template::Jinja2::Loader;
use Template::Jinja2::Exceptions;

class RenderedTemplate { ... }
class Namespace { ... }

class Template::Jinja2 is export {
	has %.filters;
	has %.tests;
	has $.loader;
	has Bool:D $.autoescape = False;
	has Bool:D $.trim-blocks = False;
	has Bool:D $.lstrip-blocks = False;
	has Str:D $.block-start = '{%';
	has Str:D $.block-end = '%}';
	has Str:D $.variable-start = '{{';
	has Str:D $.variable-end = '}}';
	has Str:D $.comment-start = '{#';
	has Str:D $.comment-end = '#}';
	has Bool:D $.keep-trailing-newline = True;
	has Str $.newline-sequence = "\n";
	has Str $.line-statement-prefix;
	has Str $.line-comment-prefix;
	has %.globals;

	submethod BUILD(
		:%filters, :%tests, :$loader, :$autoescape = False,
		:$trim-blocks = False, :$lstrip-blocks = False,
		:$block-start = '{%', :$block-end = '%}',
		:$variable-start = '{{', :$variable-end = '}}',
		:$comment-start = '{#', :$comment-end = '#}',
		:$keep-trailing-newline = True, :$newline-sequence = "\n",
		:$line-statement-prefix = Str, :$line-comment-prefix = Str,
		:%globals
	) {
		%!filters = builtin-filters();
		%!filters{$_} = %filters{$_} for %filters.keys;
		%!tests = builtin-tests();
		%!tests{$_} = %tests{$_} for %tests.keys;
		$!loader = $loader;
		$!autoescape = $autoescape;
		$!trim-blocks = $trim-blocks;
		$!lstrip-blocks = $lstrip-blocks;
		$!block-start = $block-start;
		$!block-end = $block-end;
		$!variable-start = $variable-start;
		$!variable-end = $variable-end;
		$!comment-start = $comment-start;
		$!comment-end = $comment-end;
		$!keep-trailing-newline = $keep-trailing-newline;
		$!newline-sequence = $newline-sequence;
		$!line-statement-prefix = $line-statement-prefix;
		$!line-comment-prefix = $line-comment-prefix;
		wire-registries(%!filters, %!tests);
		%!globals = self!builtin-globals();
		%!globals{$_} = %globals{$_} for %globals.keys;
	}

	method !builtin-globals(--> Hash) {
		my %g;
		%g<range> = sub (*@args) {
			given @args.elems {
				when 1 { (0 ..^ @args[0]).list }
				when 2 { (@args[0] ..^ @args[1]).list }
				when 3 {
					my @result;
					my $i = @args[0];
					if @args[2] > 0 {
						while $i < @args[1] { @result.push: $i; $i += @args[2] }
					} elsif @args[2] < 0 {
						while $i > @args[1] { @result.push: $i; $i += @args[2] }
					}
					@result.list;
				}
				default { () }
			}
		};
		%g<namespace> = sub (*@args, *%kwargs) {
			my %ns;
			for @args -> $arg {
				if $arg ~~ Associative {
					%ns{$_} = $arg{$_} for $arg.keys;
				}
			}
			%ns{$_} = %kwargs{$_} for %kwargs.keys;
			Namespace.new(data => %ns);
		};
		%g<dict> = sub (*@args, *%kwargs) {
			my %d;
			for @args -> $arg {
				if $arg ~~ Associative {
					%d{$_} = $arg{$_} for $arg.keys;
				}
			}
			%d{$_} = %kwargs{$_} for %kwargs.keys;
			%d;
		};
		%g<cycler> = sub (*@items) {
			my $idx = 0;
			my $len = @items.elems;
			sub () {
				my $val = @items[$idx % $len];
				$idx++;
				$val;
			}
		};
		%g<joiner> = sub ($sep = ', ') {
			my $first = True;
			sub () {
				if $first { $first = False; '' }
				else { $sep }
			}
		};
		#|( Raise a TemplateRuntimeError from inside a template. Used by
		    HuggingFace chat templates (Mistral, Llama-3-Instruct, etc.)
		    to assert structural invariants — typically that messages
		    alternate user/assistant correctly or that a required field
		    is present. The thrown exception is uncaught by the renderer
		    so it propagates to the .render() caller. )
		%g<raise_exception> = sub ($message = 'Template raised an exception') {
			die TemplateRuntimeError.new($message.Str);
		};
		%g;
	}

	method from-string(Str:D $source is copy --> RenderedTemplate) {
		# Pre-process line statements
		if $!line-statement-prefix.defined || $!line-comment-prefix.defined {
			$source = self!preprocess-line-statements($source);
		}
		my $tmpl = parse($source,
			:trim-blocks($!trim-blocks),
			:lstrip-blocks($!lstrip-blocks),
			:block-start($!block-start), :block-end($!block-end),
			:variable-start($!variable-start), :variable-end($!variable-end),
			:comment-start($!comment-start), :comment-end($!comment-end));
		RenderedTemplate.new(:ast($tmpl), :env(self));
	}

	method get-template(Str:D $name --> RenderedTemplate) {
		die TemplateNotFoundError.new("No loader configured") unless $!loader.defined;
		my $source = $!loader.get-source($name);
		self.from-string($source);
	}

	method !preprocess-line-statements(Str:D $source --> Str:D) {
		my @lines = $source.split("\n");
		my @result;
		for @lines -> $line {
			my $processed = $line;
			# Check for line comment prefix first (more specific)
			if $!line-comment-prefix.defined {
				my $stripped = $line.trim-leading;
				if $stripped.starts-with($!line-comment-prefix) {
					@result.push: '';  # Comment lines produce empty output
					next;
				}
			}
			# Check for line statement prefix
			if $!line-statement-prefix.defined {
				my $stripped = $line.trim-leading;
				if $stripped.starts-with($!line-statement-prefix) {
					my $stmt = $stripped.substr($!line-statement-prefix.chars).trim;
					# Remove trailing colon (Python-style)
					$stmt = $stmt.subst(/\:$/, '');
					$processed = "{$!block-start} $stmt {$!block-end}";
				}
			}
			@result.push: $processed;
		}
		@result.join("\n");
	}

	method make-renderer(--> Renderer) {
		my &loader-fn = $!loader.defined
			?? sub ($name) { $!loader.get-source($name) }
			!! sub ($name) { Str };
		Renderer.new(
			filters => %!filters,
			tests => %!tests,
			loader => &loader-fn,
			autoescape => $!autoescape,
		);
	}
}

class Namespace is export {
	has %.data;

	method get(Str:D $key --> Any) { %!data{$key} }
	method set(Str:D $key, $value) { %!data{$key} = $value }
	method FALLBACK(Str:D $name) { %!data{$name} }
}

class RenderedTemplate is export {
	has TemplateNode $.ast is required;
	has Template::Jinja2 $.env is required;

	method render(*%vars --> Str:D) {
		my $ctx = Context.new(vars => %vars, globals => $!env.globals);
		my $renderer = $!env.make-renderer();
		my $result = $renderer.render($!ast, $ctx);
		# Apply newline_sequence normalization
		if $!env.newline-sequence ne "\n" {
			$result = $result.subst("\n", $!env.newline-sequence, :g);
		}
		# Strip trailing newline unless keep_trailing_newline
		if !$!env.keep-trailing-newline && $result.chars > 0 && $result.ends-with("\n") {
			$result = $result.substr(0, *-1);
		}
		$result;
	}
}
