use Template::Jinja2::Context;
use Template::Jinja2::Exceptions;

# Python method semantics for template values.
#
# Jinja2 has no method-call syntax of its own: `foo.bar()` resolves `bar`
# on the underlying Python object and calls it. Real templates lean on
# that constantly — HuggingFace chat templates above all, which reach for
# `content.strip()`, `tool.items()` and `msg.get('content', '')` in the
# same breath as filters. This module is that object layer.
#
# The semantics implemented here are Python's, not those of Raku's
# similarly-named methods. The differences that bite:
#
#   * `'a b'.split()` with no argument splits on runs of whitespace and
#     drops empty fields; with a separator it is a literal split that
#     keeps them ('a,,b'.split(',') is three fields).
#   * `strip('xy')` removes any of the given characters from the ends,
#     it is not a suffix/prefix trim.
#   * `find` returns -1 when the needle is absent, never Nil.
#   * `title` uppercases the first letter after every non-alphabetic
#     character, so "it's" becomes "It'S" — a Python quirk, faithfully
#     reproduced (and shared with the `title` filter).
#   * `replace` replaces every occurrence unless a count is given, and
#     an empty `old` inserts between every character.
#
# Dict methods (`items`, `keys`, `values`) return their entries in
# sorted-key order. Python dicts preserve insertion order, but a Raku
# Hash is unordered, so there is no insertion order left to preserve by
# the time a template sees one; sorting makes the output deterministic
# and matches what `{% for k in d %}` and the `items`/`dictsort` filters
# already do in this engine.
module Template::Jinja2::Methods {

my constant STR-METHODS = <
	endswith find lower lstrip replace rstrip split startswith strip title upper
>;

my constant DICT-METHODS = < get items keys values >;

# === Type naming ===

#|( Python-flavoured type name for a template value. Used in error
    messages so that they read like the AttributeError/TypeError a
    template author already knows from Python. )
sub python-type-name($value --> Str:D) is export {
	return 'NoneType'  if $value ~~ JinjaNone;
	return 'undefined' if $value ~~ Undefined;
	return 'undefined' unless $value.defined;
	return 'str'       if $value ~~ SafeString;
	given $value {
		when Bool        { 'bool' }
		when Int         { 'int' }
		when Numeric     { 'float' }
		when Str         { 'str' }
		when JinjaTuple  { 'tuple' }
		when Positional  { 'list' }
		when Associative { 'dict' }
		when Callable    { 'function' }
		default          { $value.^name }
	}
}

# === Dispatch surface ===

#|( True when $name is a Python method this module implements for the
    given receiver. The renderer asks first so that template-defined
    callables stored in a dict (imported macros, namespace fields) keep
    winning over the builtin methods. )
sub python-method-exists($receiver, Str:D $name --> Bool:D) is export {
	return False unless $receiver.defined;
	return so STR-METHODS.first($name)  if is-string($receiver);
	return so DICT-METHODS.first($name) if $receiver ~~ Associative;
	False;
}

#|( Names implemented for the receiver's type, for error messages. )
sub python-method-names($receiver --> List) is export {
	return STR-METHODS.list  if is-string($receiver);
	return DICT-METHODS.list if $receiver.defined && $receiver ~~ Associative;
	();
}

#|( Call a Python method on a template value.

    Dies with a TemplateRuntimeError naming the method, the receiver
    type and (where relevant) the offending argument. Callers are
    expected to have checked python-method-exists first; calling
    anything else still produces a clean error rather than leaking a
    Raku dispatch failure. )
sub python-method($receiver, Str:D $name, @args --> Any) is export {
	if is-string($receiver) {
		my $result = str-method(string-of($receiver), $name, @args);
		# Markup semantics: str methods on a |safe value stay safe, the
		# way Jinja2's Markup type behaves.
		return $receiver ~~ SafeString ?? remark-safe($result) !! $result;
	}
	if $receiver.defined && $receiver ~~ Associative {
		return dict-method($receiver, $name, @args);
	}
	die python-method-error($receiver, $name);
}

sub python-method-error($receiver, Str:D $name --> TemplateRuntimeError) is export {
	my $type = python-type-name($receiver);
	my @known = python-method-names($receiver);
	my $hint = @known.elems > 0
		?? " (supported: {@known.join(', ')})"
		!! '';
	TemplateRuntimeError.new("'$type' object has no method '$name'$hint");
}

# === String methods ===

sub str-method(Str:D $s, Str:D $name, @args --> Any) {
	given $name {
		when 'strip'  { strip-method($s, $name, @args, :left, :right) }
		when 'lstrip' { strip-method($s, $name, @args, :left) }
		when 'rstrip' { strip-method($s, $name, @args, :right) }
		when 'lower'  { check-arity('str', $name, @args, 0, 0); $s.lc }
		when 'upper'  { check-arity('str', $name, @args, 0, 0); $s.uc }
		when 'title'  { check-arity('str', $name, @args, 0, 0); py-title($s) }
		when 'startswith' { affix-method($s, $name, @args, :prefix) }
		when 'endswith'   { affix-method($s, $name, @args) }
		when 'replace'    { replace-method($s, $name, @args) }
		when 'split'      { split-method($s, $name, @args) }
		when 'find'       { find-method($s, $name, @args) }
		default { die python-method-error($s, $name) }
	}
}

sub strip-method(Str:D $s, Str:D $name, @args, Bool:D :$left = False, Bool:D :$right = False --> Str:D) {
	check-arity('str', $name, @args, 0, 1);
	# strip() / strip(None) strip whitespace; strip(chars) strips any of
	# the characters in chars.
	if @args.elems == 0 || @args[0] ~~ JinjaNone || !@args[0].defined {
		return do if $left && $right { $s.trim }
			elsif $left  { $s.trim-leading }
			else         { $s.trim-trailing };
	}
	strip-chars($s, want-str('str', $name, @args[0], 1), :$left, :$right);
}

sub strip-chars(Str:D $s is copy, Str:D $chars, Bool:D :$left, Bool:D :$right --> Str:D) {
	return $s if $chars eq '';
	my $set = $chars.comb.Set;
	if $left {
		while $s.chars > 0 && $set{$s.substr(0, 1)} { $s = $s.substr(1) }
	}
	if $right {
		while $s.chars > 0 && $set{$s.substr(*-1, 1)} { $s = $s.substr(0, *-1) }
	}
	$s;
}

sub affix-method(Str:D $s, Str:D $name, @args, Bool:D :$prefix = False --> Bool:D) {
	check-arity('str', $name, @args, 1, 1);
	# The argument may be a tuple (or list) of candidates, in which case
	# any match wins — Python allows exactly this and chat templates use
	# it for role/marker sets.
	my @candidates = @args[0] ~~ Positional ?? @args[0].list !! (@args[0],);
	for @candidates -> $candidate {
		my $affix = want-str('str', $name, $candidate, 1);
		return True if $prefix ?? $s.starts-with($affix) !! $s.ends-with($affix);
	}
	False;
}

sub replace-method(Str:D $s, Str:D $name, @args --> Str:D) {
	check-arity('str', $name, @args, 2, 3);
	my $old = want-str('str', $name, @args[0], 1);
	my $new = want-str('str', $name, @args[1], 2);
	my $count = @args.elems >= 3 ?? want-int('str', $name, @args[2], 3) !! -1;
	py-replace($s, $old, $new, $count);
}

sub py-replace(Str:D $s, Str:D $old, Str:D $new, Int:D $count --> Str:D) {
	return $s if $count == 0;
	# Python inserts $new between every character (and at both ends)
	# when $old is empty.
	if $old eq '' {
		my @chars = $s.comb;
		my $limit = $count < 0 ?? @chars.elems + 1 !! min($count, @chars.elems + 1);
		my $out = '';
		my $inserted = 0;
		for 0 .. @chars.elems -> $i {
			if $inserted < $limit { $out ~= $new; $inserted++ }
			$out ~= @chars[$i] if $i < @chars.elems;
		}
		return $out;
	}
	my $out = '';
	my $pos = 0;
	my $done = 0;
	loop {
		last if $count >= 0 && $done >= $count;
		my $idx = $s.index($old, $pos);
		last without $idx;
		$out ~= $s.substr($pos, $idx - $pos) ~ $new;
		$pos = $idx + $old.chars;
		$done++;
	}
	$out ~ $s.substr($pos);
}

sub split-method(Str:D $s, Str:D $name, @args --> List) {
	check-arity('str', $name, @args, 0, 2);
	my $maxsplit = @args.elems >= 2 ?? want-int('str', $name, @args[1], 2) !! -1;
	my $sep = @args.elems >= 1 ?? @args[0] !! Any;
	if !$sep.defined || $sep ~~ JinjaNone {
		return py-split-whitespace($s, $maxsplit);
	}
	my $sep-str = want-str('str', $name, $sep, 1);
	die TemplateRuntimeError.new("str.split() empty separator") if $sep-str eq '';
	($maxsplit < 0 ?? $s.split($sep-str) !! $s.split($sep-str, $maxsplit + 1)).list;
}

sub py-split-whitespace(Str:D $s, Int:D $maxsplit --> List) {
	my @chars = $s.comb;
	my $len = @chars.elems;
	my @out;
	my $i = 0;
	loop {
		$i++ while $i < $len && @chars[$i] ~~ /^\s$/;
		last if $i >= $len;
		if $maxsplit >= 0 && @out.elems == $maxsplit {
			# Python keeps the remainder verbatim, trailing whitespace
			# and all, once maxsplit fields have been taken.
			@out.push: @chars[$i .. $len - 1].join;
			last;
		}
		my $start = $i;
		$i++ while $i < $len && !(@chars[$i] ~~ /^\s$/);
		@out.push: @chars[$start .. $i - 1].join;
	}
	@out.list;
}

sub find-method(Str:D $s, Str:D $name, @args --> Int:D) {
	check-arity('str', $name, @args, 1, 3);
	my $needle = want-str('str', $name, @args[0], 1);
	my $len = $s.chars;
	my $start = @args.elems >= 2 ?? clamp-index(want-int('str', $name, @args[1], 2), $len) !! 0;
	my $end   = @args.elems >= 3 ?? clamp-index(want-int('str', $name, @args[2], 3), $len) !! $len;
	return -1 if $start > $len || $end < $start;
	my $idx = $s.substr($start, $end - $start).index($needle);
	$idx.defined ?? $start + $idx !! -1;
}

sub clamp-index(Int:D $i, Int:D $len --> Int:D) {
	$i < 0 ?? max(0, $len + $i) !! min($i, $len);
}

sub py-title(Str:D $s --> Str:D) {
	# Python's str.title(): the first cased character of each run is
	# uppercased, the rest lowercased. Uncased characters (digits,
	# apostrophes, underscores) end a run, hence "it's" -> "It'S".
	# <:L> rather than <alpha> because <alpha> counts '_' as a letter.
	my $out = '';
	my $prev-alpha = False;
	for $s.comb -> $ch {
		if $ch ~~ /^<:L>$/ {
			$out ~= $prev-alpha ?? $ch.lc !! $ch.uc;
			$prev-alpha = True;
		} else {
			$out ~= $ch;
			$prev-alpha = False;
		}
	}
	$out;
}

# === Dict methods ===

sub dict-method($d, Str:D $name, @args --> Any) {
	given $name {
		when 'items' {
			check-arity('dict', $name, @args, 0, 0);
			$d.keys.sort.map({ JinjaTuple.new(items => [$_, $d{$_}]) }).list;
		}
		when 'keys' {
			check-arity('dict', $name, @args, 0, 0);
			$d.keys.sort.list;
		}
		when 'values' {
			check-arity('dict', $name, @args, 0, 0);
			$d.keys.sort.map({ $d{$_} }).list;
		}
		when 'get' {
			check-arity('dict', $name, @args, 1, 2);
			my $key = dict-key(@args[0]);
			return $d{$key} if $d{$key}:exists;
			# Python's dict.get returns None, not the empty string, when
			# no default is supplied.
			@args.elems >= 2 ?? @args[1] !! JINJA-NONE;
		}
		default { die python-method-error($d, $name) }
	}
}

sub dict-key($key --> Str:D) {
	return $key.value if $key ~~ SafeString;
	return $key       if $key ~~ Str;
	return 'None'     if $key ~~ JinjaNone || !$key.defined;
	~$key;
}

# === Argument helpers ===

sub check-arity(Str:D $type, Str:D $name, @args, Int:D $min, Int:D $max) {
	my $got = @args.elems;
	return if $min <= $got <= $max;
	my $expect = do if $min == $max {
		$min == 0 ?? 'no arguments' !! "exactly $min argument{$min == 1 ?? '' !! 's'}";
	} elsif $min == 0 {
		"at most $max argument{$max == 1 ?? '' !! 's'}";
	} else {
		"from $min to $max arguments";
	};
	die TemplateRuntimeError.new(
		"{$type}.{$name}() takes $expect ($got given)");
}

sub want-str(Str:D $type, Str:D $name, $arg, Int:D $pos --> Str:D) {
	return $arg.value if $arg ~~ SafeString;
	return $arg       if $arg ~~ Str;
	die TemplateRuntimeError.new(
		"{$type}.{$name}() argument $pos must be str, not {python-type-name($arg)}");
}

sub want-int(Str:D $type, Str:D $name, $arg, Int:D $pos --> Int:D) {
	return $arg.Int if $arg ~~ Int && $arg !~~ Bool;
	die TemplateRuntimeError.new(
		"{$type}.{$name}() argument $pos must be int, not {python-type-name($arg)}");
}

# === Receiver helpers ===

sub is-string($value --> Bool:D) {
	return False unless $value.defined;
	$value ~~ Str || $value ~~ SafeString;
}

sub string-of($value --> Str:D) {
	$value ~~ SafeString ?? $value.value !! ~$value;
}

sub remark-safe($result --> Any) {
	return SafeString.new(value => $result) if $result ~~ Str;
	if $result ~~ Positional && $result !~~ JinjaTuple {
		return $result.map({ $_ ~~ Str ?? SafeString.new(value => $_) !! $_ }).list;
	}
	$result;
}

}
