module Template::Jinja2::Filters {

sub resolve-attr($obj, Str:D $attr) {
	# Resolve dotted attributes like 'date.year' or 'value.0'
	my $current = $obj;
	for $attr.split('.') -> $part {
		return Any unless $current.defined;
		if $current ~~ Associative && ($current{$part}:exists) {
			$current = $current{$part};
		} elsif $part ~~ /^\d+$/ && $current ~~ Positional {
			my $idx = $part.Int;
			$current = $idx < $current.elems ?? $current[$idx] !! Any;
		} else {
			return Any;
		}
	}
	$current;
}

sub builtin-filters(--> Hash) is export {
	my %f;

	# --- String filters ---

	%f<upper> = sub ($value, *%_) { (~($value // '')).uc };
	%f<lower> = sub ($value, *%_) { (~($value // '')).lc };
	%f<capitalize> = sub ($value, *%_) {
		my $s = ~($value // '');
		$s ?? $s.substr(0, 1).uc ~ $s.substr(1).lc !! '';
	};
	# Jinja2's title filter, which is deliberately NOT Python's
	# str.title(): a word starts after a run of whitespace or of the
	# opening punctuation Jinja2 splits on, so "it's" titles to "It's"
	# and "1st" to "1st". Python's str.title() would give "It'S" and
	# "1St" — that spelling lives on the .title() method implemented in
	# Template::Jinja2::Methods.
	%f<title> = sub ($value, *%_) {
		my $s = ~($value // '');
		my $result = '';
		my $at-word-start = True;
		for $s.comb -> $ch {
			if $ch ~~ /^<[\- \s \( \{ \[ \<]>$/ {
				$result ~= $ch;
				$at-word-start = True;
			} else {
				$result ~= $at-word-start ?? $ch.uc !! $ch.lc;
				$at-word-start = False;
			}
		}
		$result;
	};
	%f<trim> = sub ($value, $chars = Any, *%_) {
		my $s = ~($value // '');
		if $chars.defined && $chars ne '' {
			# Strip specific characters from both ends
			my @chs = $chars.comb.unique;
			while $s.chars > 0 && $s.substr(0, 1) eq any(@chs) {
				$s = $s.substr(1);
			}
			while $s.chars > 0 && $s.substr(*-1, 1) eq any(@chs) {
				$s = $s.substr(0, *-1);
			}
			$s;
		} else {
			$s.trim;
		}
	};
	%f<lstrip> = sub ($value, *%_) { (~($value // '')).trim-leading };
	%f<rstrip> = sub ($value, *%_) { (~($value // '')).trim-trailing };
	%f<striptags> = sub ($value, *%_) {
		my $s = ~($value // '');
		# Remove HTML comments first, then tags
		$s = $s.subst(/ '<!--' .*? '-->' /, '', :g);
		$s = $s.subst(/ '<' <-[>]>* '>' /, '', :g);
		$s.subst(/\s+/, ' ', :g).trim;
	};
	%f<truncate> = sub ($value, $length = 255, $killwords = False, $end = '...', $leeway = 5, *%kw) {
		my $s = ~($value // '');
		my $do-kill = %kw<killwords> // $killwords;
		my $do-end = %kw<end> // $end;
		my $do-leeway = %kw<leeway> // $leeway;
		return $s if $s.chars <= $length + $do-leeway;
		my $max-chars = $length - $do-end.chars;
		return $do-end if $max-chars < 0;
		if $do-kill {
			return $s.substr(0, $max-chars) ~ $do-end;
		}
		my $truncated = $s.substr(0, $max-chars);
		my $last-space = $truncated.rindex(' ');
		$truncated = $truncated.substr(0, $last-space) if $last-space.defined;
		$truncated ~ $do-end;
	};
	%f<wordwrap> = sub ($value, $width = 79, :$break_long_words = True, :$wrapstring = "\n", *%_) {
		my $s = ~($value // '');
		# Split on existing newlines first, then wrap each paragraph
		my @paragraphs = $s.split("\n");
		my @result;
		for @paragraphs -> $para {
			my @words = $para.split(/\s+/).grep(*.chars > 0);
			if @words.elems == 0 {
				@result.push: '';
				next;
			}
			my @lines;
			my $line = '';
			for @words -> $word {
				if $line.chars + $word.chars + 1 > $width && $line ne '' {
					@lines.push: $line;
					$line = $word;
				} else {
					$line = $line ne '' ?? "$line $word" !! $word;
				}
			}
			@lines.push: $line if $line ne '';
			@result.push: @lines.join($wrapstring);
		}
		@result.join($wrapstring);
	};
	%f<center> = sub ($value, $width = 80, *%_) {
		my $s = ~($value // '');
		my $pad = $width - $s.chars;
		return $s if $pad <= 0;
		my $left = ' ' x ($pad div 2);
		my $right = ' ' x ($pad - $pad div 2);
		$left ~ $s ~ $right;
	};
	%f<replace> = sub ($value, $old, $new, $count?, *%_) {
		my $s = ~($value // '');
		my $old-str = ~$old;
		my $new-str = ~$new;
		if $count.defined {
			my $n = 0;
			$s.subst($old-str, -> { $n++; $n <= $count ?? $new-str !! $old-str }, :g);
		} else {
			$s.subst($old-str, $new-str, :g);
		}
	};
	%f<wordcount> = sub ($value, *%_) { (~($value // '')).split(/\s+/).grep(*.chars > 0).elems };
	%f<indent> = sub ($value, $width = 4, $first = False, $blank = False, *%kw) {
		my $s = ~($value // '');
		my $do-first = %kw<first> // $first;
		my $do-blank = %kw<blank> // $blank;
		my $w = %kw<width> // $width;
		my $pad = $w ~~ Str ?? $w !! ' ' x $w;
		my @lines = $s.split("\n");
		for @lines.kv -> $i, $line {
			if $i == 0 {
				@lines[$i] = $pad ~ $line if $do-first;
				next;
			}
			next if $line eq '' && !$do-blank;
			@lines[$i] = $pad ~ $line;
		}
		@lines.join("\n");
	};
	%f<string> = sub ($value, *%_) { ~($value // '') };

	# --- HTML/URL filters ---

	%f<e> = %f<escape> = sub ($value, *%_) {
		(~($value // '')).trans(['&', '<', '>', '"', "'"] => ['&amp;', '&lt;', '&gt;', '&#34;', '&#39;']);
	};
	%f<forceescape> = %f<escape>;
	%f<urlencode> = sub ($value, *%_) {
		my $s = ~($value // '');
		$s.subst(/<-[a..zA..Z0..9\-_.~]>/, -> $/ { '%' ~ $/.Str.encode('utf-8').list.map(*.fmt('%02X')).join('%') }, :g);
	};
	%f<urlize> = sub ($value, :$trim_url_limit, :$nofollow = False, :$target, :$rel = 'noopener', :$extra_schemes, *%_) {
		my $s = ~($value // '');
		# Build URL pattern
		my $scheme-pat = 'http' ~ 's?' ~ '://';
		$s.subst(/ 'http' 's'? '://' <[\w / \- _ . ~ : ? \# \[ \] @ ! $ & ( ) * + , ; = %]>+ /, -> $/ {
			my $url = $/.Str;
			my $display = $trim_url_limit.defined && $url.chars > $trim_url_limit
				?? $url.substr(0, $trim_url_limit) ~ '...'
				!! $url;
			my $attrs = "href=\"{$url}\"";
			$attrs ~= " rel=\"{$rel}\"" if $rel.defined && $rel ne '';
			$attrs ~= " target=\"{$target}\"" if $target.defined;
			"<a {$attrs}>{$display}</a>";
		}, :g);
	};

	# --- Numeric filters ---

	%f<int> = sub ($value, $default = 0, *%kw) {
		my $def = %kw<default> // $default;
		my $base = %kw<base> // 10;
		if $value.defined {
			try {
				my $v = ~$value;
				if $base != 10 {
					# Strip 0x/0o/0b prefixes
					$v = $v.subst(/^0<[xXoObB]>/, '');
					return $v.parse-base($base).Int;
				}
				return $v.Int;
			}
		}
		$def;
	};
	%f<float> = sub ($value, $default = 0.0, *%kw) {
		my $def = %kw<default> // $default;
		if $value.defined {
			try { return $value.Num }
		}
		$def;
	};
	%f<abs> = sub ($value, *%_) { ($value // 0).abs };
	%f<round> = sub ($value, $precision = 0, $method = 'common', *%_) {
		my $n = ($value // 0).Num;
		my $result;
		given $method {
			when 'ceil'  { $result = ($n * 10 ** $precision).ceiling / 10 ** $precision }
			when 'floor' { $result = ($n * 10 ** $precision).floor / 10 ** $precision }
			default      { $result = ($n * 10 ** $precision).round / 10 ** $precision }
		}
		# Python's round returns float, always format with decimal point
		if $precision <= 0 {
			$result = $result.Num;
			my $s = ~$result;
			$s ~= '.0' unless $s.contains('.');
			return $s;
		}
		$result;
	};
	%f<filesizeformat> = sub ($value, $binary = False, *%_) {
		my $bytes = ($value // 0).Num;
		my @units = $binary
			?? <Bytes KiB MiB GiB TiB PiB>
			!! <Bytes kB MB GB TB PB>;
		my $base = $binary ?? 1024 !! 1000;
		my $unit-idx = 0;
		while $bytes >= $base && $unit-idx < @units.elems - 1 {
			$bytes /= $base;
			$unit-idx++;
		}
		if $unit-idx == 0 {
			"{$bytes.Int} {@units[$unit-idx]}";
		} else {
			my $rounded = $bytes.round(0.1);
			my $s = ~$rounded;
			$s ~= '.0' unless $s.contains('.');
			"$s {@units[$unit-idx]}";
		}
	};

	# --- List/collection filters ---

	%f<length> = %f<count> = sub ($value, *%_) {
		return 0 unless $value.defined;
		$value ~~ Str ?? $value.chars !! $value.elems;
	};
	%f<first> = sub ($value, *%_) { $value.defined && $value.elems > 0 ?? $value[0] !! Any };
	%f<random> = sub ($value, *%_) {
		return Any unless $value.defined;
		my @items = $value ~~ Str ?? $value.comb !! $value.list;
		return Any unless @items.elems > 0;
		@items[(rand * @items.elems).Int];
	};
	%f<last> = sub ($value, *%_) { $value.defined && $value.elems > 0 ?? $value[*-1] !! Any };
	%f<reverse> = sub ($value, *%_) {
		return '' unless $value.defined;
		$value ~~ Str ?? $value.flip !! $value.reverse.list;
	};
	%f<sort> = sub ($value, $reverse = False, :$case_sensitive = False, :$attribute, *%_) {
		return () unless $value.defined;
		my @items = $value.list;
		if $attribute.defined {
			# Support multi-attribute sort: 'value1,value2'
			my @attrs = $attribute.split(',');
			@items = @items.sort(-> $a, $b {
				my $result = 0;
				for @attrs -> $attr {
					my $va = resolve-attr($a, $attr);
					my $vb = resolve-attr($b, $attr);
					$result = ($va // '') cmp ($vb // '');
					last if $result != 0;
				}
				$result;
			});
		} elsif !$case_sensitive {
			@items = @items.sort({ $_ ~~ Str ?? $_.lc !! $_ });
		} else {
			@items = @items.sort;
		}
		@items = @items.reverse if $reverse;
		@items.list;
	};
	%f<unique> = sub ($value, $case_sensitive = False, :$attribute, *%_) {
		return () unless $value.defined;
		my @items = $value.list;
		if $attribute.defined {
			my %seen;
			my @result;
			for @items -> $item {
				my $key = resolve-attr($item, $attribute);
				my $k = $case_sensitive ?? ~($key // '') !! (~($key // '')).lc;
				unless %seen{$k}:exists {
					%seen{$k} = True;
					@result.push: $item;
				}
			}
			return @result.list;
		}
		if !$case_sensitive {
			@items.unique(:with(-> $a, $b { $a ~~ Str && $b ~~ Str ?? $a.lc eq $b.lc !! $a eqv $b })).list;
		} else {
			@items.unique.list;
		}
	};
	%f<min> = sub ($value, :$case_sensitive = False, :$attribute, *%_) {
		return Any unless $value.defined && $value.elems > 0;
		my @items = $value.list;
		if $attribute.defined {
			return @items.min({ resolve-attr($_, $attribute) // '' });
		}
		if !$case_sensitive {
			@items.min({ $_ ~~ Str ?? $_.lc !! $_ });
		} else {
			@items.min;
		}
	};
	%f<max> = sub ($value, :$case_sensitive = False, :$attribute, *%_) {
		return Any unless $value.defined && $value.elems > 0;
		my @items = $value.list;
		if $attribute.defined {
			return @items.max({ resolve-attr($_, $attribute) // '' });
		}
		if !$case_sensitive {
			@items.max({ $_ ~~ Str ?? $_.lc !! $_ });
		} else {
			@items.max;
		}
	};
	%f<sum> = sub ($value, $attribute = Any, :$start = 0, *%_) {
		return $start unless $value.defined;
		my @items = $value.list;
		if $attribute.defined {
			@items = @items.map({ resolve-attr($_, $attribute) // 0 });
		}
		$start + @items.sum;
	};
	%f<join> = sub ($value, $separator = '', $attribute = Any, *%_) {
		return '' unless $value.defined;
		my @items = $value.list;
		if $attribute.defined {
			@items = @items.map({ resolve-attr($_, $attribute) // ~$_ });
		}
		@items.map(-> $v { $v ~~ Bool ?? ($v ?? 'True' !! 'False') !! ~($v // '') }).join(~$separator);
	};
	%f<list> = sub ($value, *%_) {
		return () unless $value.defined;
		$value ~~ Str ?? $value.comb.list !! $value.list;
	};
	%f<map> = sub ($value, *@args, :$attribute, :$default, *%kwargs) {
		return () unless $value.defined;
		if $attribute.defined {
			return $value.list.map({
				if $_ ~~ Associative && ($_{$attribute}:exists) {
					$_{$attribute};
				} elsif $default.defined {
					$default;
				} else {
					Any;
				}
			}).list;
		}
		# map(filter_name) — simplified: we don't have filter access here
		$value.list;
	};
	%f<select> = sub ($value, *@args, *%_) {
		return () unless $value.defined;
		$value.list.grep(-> $v { $v.defined && ($v !~~ Bool || $v) && ($v !~~ Numeric || $v != 0) }).list;
	};
	%f<reject> = sub ($value, *@args, *%_) {
		return () unless $value.defined;
		$value.list.grep(-> $v { !$v.defined || ($v ~~ Bool && !$v) || ($v ~~ Numeric && $v == 0) }).list;
	};
	%f<selectattr> = sub ($value, $attr, *@args, *%_) {
		return () unless $value.defined;
		$value.list.grep({ $_ ~~ Associative && ($_{$attr}:exists) && $_{$attr} }).list;
	};
	%f<rejectattr> = sub ($value, $attr, *@args, *%_) {
		return () unless $value.defined;
		$value.list.grep({ !($_ ~~ Associative && ($_{$attr}:exists) && $_{$attr}) }).list;
	};
	%f<groupby> = sub ($value, $attr, :$default, :$case_sensitive = False, *%_) {
		return () unless $value.defined;
		my %groups;
		my @order;
		for $value.list -> $item {
			my $key = resolve-attr($item, $attr);
			$key = $default // '' unless $key.defined;
			my $group-key = !$case_sensitive && $key ~~ Str ?? $key.lc !! ~$key;
			unless %groups{$group-key}:exists {
				@order.push: $group-key;
				%groups{$group-key} = [];
			}
			%groups{$group-key}.push: $item;
		}
		@order.map({ [$_, %groups{$_}.list] }).list;
	};
	%f<batch> = sub ($value, $n, $fill = Any, *%_) {
		return () unless $value.defined;
		my @items = $value.list;
		my @batches;
		my $i = 0;
		while $i < @items.elems {
			my @batch = @items[$i ..^ min($i + $n, @items.elems)];
			if $fill.defined && @batch.elems < $n {
				@batch.append: ($fill xx ($n - @batch.elems));
			}
			@batches.push: @batch.list;
			$i += $n;
		}
		@batches.list;
	};
	%f<slice> = sub ($value, $slices, $fill = Any, *%_) {
		return () unless $value.defined;
		my @items = $value.list;
		my $n = @items.elems;
		my $base-size = $n div $slices;
		my $extra = $n mod $slices;
		my $max-size = $base-size + ($extra > 0 ?? 1 !! 0);
		my @result;
		my $i = 0;
		for ^$slices -> $s {
			my $chunk-size = $base-size + ($s < $extra ?? 1 !! 0);
			my @chunk = @items[$i ..^ min($i + $chunk-size, $n)];
			if $fill.defined && @chunk.elems < $max-size {
				@chunk.append: ($fill xx ($max-size - @chunk.elems));
			}
			@result.push: @chunk.list;
			$i += $chunk-size;
		}
		@result.list;
	};
	%f<items> = sub ($value, *%_) {
		return () unless $value.defined && $value ~~ Associative;
		$value.pairs.sort(*.key).map({ ($_.key, $_.value) }).list;
	};

	# --- Dict/attr filters ---

	%f<attr> = sub ($value, $name, *%_) {
		return Any unless $value.defined;
		$value ~~ Associative ?? $value{$name} !! Any;
	};
	%f<d> = %f<default> = sub ($value, $default = '', $boolean = False, *%kw) {
		my $bool-flag = %kw<boolean> // $boolean;
		if $bool-flag {
			# With boolean=True, falsy values also get the default
			return (!$value.defined || ($value ~~ Bool && !$value) || ($value ~~ Str && $value eq '') || ($value ~~ Numeric && $value == 0)) ?? $default !! $value;
		}
		$value.defined ?? $value !! $default;
	};

	# --- Format filters ---

	%f<format> = sub ($value, *@args, *%_) {
		my $s = ~($value // '');
		my $i = 0;
		$s.subst(/'%' <[sd]>/, -> $/ { $i < @args.elems ?? ~@args[$i++] !! '' }, :g);
	};
	%f<pprint> = sub ($value, *%_) { $value.raku };

	# --- Serialization ---

	#|( tojson accepts Python's json.dumps separators kwarg — a
	    (item_separator, key_separator) tuple — because chat templates
	    use it to emit compact JSON: `tools | tojson(separators=(',', ':'))`
	    (Kimi K2) tokenises differently from the spaced default, so the
	    whitespace is load-bearing. )
	%f<tojson> = sub ($value, :$indent, :$separators, *%_) {
		my $item-sep = ', ';
		my $key-sep = ': ';
		if $separators.defined && $separators ~~ Positional && $separators.list.elems == 2 {
			$item-sep = ~$separators.list[0];
			$key-sep  = ~$separators.list[1];
		}
		to-json-str($value, indent => $indent, :$item-sep, :$key-sep);
	};
	%f<xmlattr> = sub ($value, :$autospace = True, *%_) {
		return '' unless $value.defined && $value ~~ Associative;
		# Filter out None/undefined values
		my @valid = $value.pairs.grep({ $_.value.defined }).sort(*.key);
		my $attrs = @valid.map(-> $p {
			$p.key ~ '="' ~ (~$p.value).trans(['&', '<', '>', '"'] => ['&amp;', '&lt;', '&gt;', '&#34;']) ~ '"'
		}).join(' ');
		$autospace && $attrs ne '' ?? ' ' ~ $attrs !! $attrs;
	};

	# --- Misc ---

	%f<safe> = sub ($value, *%_) { $value };
	%f<dictsort> = sub ($value, $case_sensitive = False, :$by = 'key', :$reverse = False, *%_) {
		return () unless $value.defined && $value ~~ Associative;
		my @pairs = $value.pairs;
		if $by eq 'value' {
			@pairs = @pairs.sort(*.value);
		} else {
			@pairs = $case_sensitive
				?? @pairs.sort(*.key)
				!! @pairs.sort({ .key ~~ Str ?? .key.lc !! .key });
		}
		@pairs = @pairs.reverse if $reverse;
		@pairs.map({ ($_.key, $_.value) }).list;
	};

	%f;
}

sub wire-registries(%filters, %tests) is export {
	# Replace select/reject/map with versions that can use test/filter names

	%filters<select> = sub ($value, *@args, *%_) {
		return () unless $value.defined;
		if @args.elems > 0 && @args[0] ~~ Str {
			my $test-name = @args[0];
			my @test-args = @args[1..*];
			if %tests{$test-name}:exists {
				return $value.list.grep(-> $v { so %tests{$test-name}($v, |@test-args) }).list;
			}
		}
		# No test name: filter truthy
		$value.list.grep(-> $v { $v.defined && ($v !~~ Bool || $v) && ($v !~~ Numeric || $v != 0) }).list;
	};

	%filters<reject> = sub ($value, *@args, *%_) {
		return () unless $value.defined;
		if @args.elems > 0 && @args[0] ~~ Str {
			my $test-name = @args[0];
			my @test-args = @args[1..*];
			if %tests{$test-name}:exists {
				return $value.list.grep(-> $v { !so %tests{$test-name}($v, |@test-args) }).list;
			}
		}
		$value.list.grep(-> $v { !$v.defined || ($v ~~ Bool && !$v) || ($v ~~ Numeric && $v == 0) }).list;
	};

	%filters<selectattr> = sub ($value, $attr, *@args, *%_) {
		return () unless $value.defined;
		if @args.elems > 0 && @args[0] ~~ Str {
			my $test-name = @args[0];
			my @test-args = @args[1..*];
			if %tests{$test-name}:exists {
				return $value.list.grep({
					$_ ~~ Associative && %tests{$test-name}(($_{$attr} // Any), |@test-args)
				}).list;
			}
		}
		$value.list.grep({ $_ ~~ Associative && ($_{$attr}:exists) && $_{$attr} }).list;
	};

	%filters<rejectattr> = sub ($value, $attr, *@args, *%_) {
		return () unless $value.defined;
		if @args.elems > 0 && @args[0] ~~ Str {
			my $test-name = @args[0];
			my @test-args = @args[1..*];
			if %tests{$test-name}:exists {
				return $value.list.grep({
					!($_ ~~ Associative && %tests{$test-name}(($_{$attr} // Any), |@test-args))
				}).list;
			}
		}
		$value.list.grep({ !($_ ~~ Associative && ($_{$attr}:exists) && $_{$attr}) }).list;
	};

	%filters<map> = sub ($value, *@args, :$attribute, :$default, *%kwargs) {
		return () unless $value.defined;
		if $attribute.defined {
			return $value.list.map({
				if $_ ~~ Associative && ($_{$attribute}:exists) {
					$_{$attribute};
				} elsif $default.defined {
					$default;
				} else {
					Any;
				}
			}).list;
		}
		if @args.elems > 0 && @args[0] ~~ Str {
			my $filter-name = @args[0];
			if %filters{$filter-name}:exists {
				return $value.list.map(-> $v { %filters{$filter-name}($v) }).list;
			}
		}
		$value.list;
	};
}

sub to-json-str($value, :$indent, Str:D :$item-sep = ', ', Str:D :$key-sep = ': ' --> Str:D) {
	return 'null' unless $value.defined;
	given $value {
		when Bool { $value ?? 'true' !! 'false' }
		when Int  { ~$value }
		when Num | Rat { ~$value }
		when Str {
			'"' ~ $value.trans(['"', '\\', "\n", "\r", "\t"]
				=> ['\\"', '\\\\', '\\n', '\\r', '\\t']) ~ '"'
		}
		when Positional {
			'[' ~ $value.map({ to-json-str($_, :$indent, :$item-sep, :$key-sep) }).join($item-sep) ~ ']'
		}
		when Associative {
			'{' ~ $value.sort(*.key).map({
				to-json-str(.key, :$indent, :$item-sep, :$key-sep)
					~ $key-sep
					~ to-json-str(.value, :$indent, :$item-sep, :$key-sep)
			}).join($item-sep) ~ '}'
		}
		default { '"' ~ ~$value ~ '"' }
	}
}

}
