use Template::Jinja2::Exceptions;

module Template::Jinja2::Context {

class Undefined is export {
	method Str(--> Str:D) { '' }
	method gist(--> Str:D) { '' }
	method Bool(--> Bool:D) { False }
	method defined(--> Bool:D) { False }
}

class JinjaNone is export {
	method Str(--> Str:D) { 'None' }
	method gist(--> Str:D) { 'None' }
	method Bool(--> Bool:D) { False }
	method defined(--> Bool:D) { False }
	method Numeric(--> Int:D) { 0 }
}

constant JINJA-NONE is export = JinjaNone.new;

class SafeString is export {
	has Str:D $.value is required;
	method Str(--> Str:D) { $!value }
	method gist(--> Str:D) { $!value }
	method chars(--> Int:D) { $!value.chars }
	method contains($s) { $!value.contains($s) }
}

class JinjaTuple is export does Positional {
	has @.items;
	method elems { @!items.elems }
	method list  { @!items.list }
	method AT-POS($i) { @!items[$i] }
	method Numeric { @!items.elems }
}

constant UNDEFINED is export = Undefined.new;

class Context is export {
	has @.scope-stack;
	has %.globals;

	method new(:%vars, :%globals) {
		my $ctx = self.bless(:%globals);
		$ctx.scope-stack.push: %vars;
		$ctx;
	}

	method resolve(Str:D $name --> Any) {
		# Search scope stack from top to bottom
		for @!scope-stack.reverse -> %scope {
			return %scope{$name} if %scope{$name}:exists;
		}
		# Fall back to globals
		return %!globals{$name} if %!globals{$name}:exists;
		UNDEFINED;
	}

	method is-defined(Str:D $name --> Bool:D) {
		for @!scope-stack.reverse -> %scope {
			return True if %scope{$name}:exists;
		}
		return True if %!globals{$name}:exists;
		False;
	}

	method set(Str:D $name, $value) {
		@!scope-stack[*-1]{$name} = $value;
	}

	method push-scope(%vars = {}) {
		@!scope-stack.push: %vars;
	}

	method pop-scope() {
		@!scope-stack.pop if @!scope-stack.elems > 1;
	}

	method derived(:%vars --> Context) {
		my $new = Context.bless(globals => %!globals);
		for @!scope-stack -> %s {
			$new.scope-stack.push: %s.clone;
		}
		$new.scope-stack.push: %vars;
		$new;
	}
}

}
