module Template::Jinja2::Tests {

sub builtin-tests(--> Hash) is export {
	my %t;

	%t<defined>     = sub ($value, *@_) { $value.defined };
	%t<undefined>   = sub ($value, *@_) { !$value.defined };
	%t<none>        = sub ($value, *@_) { !$value.defined };
	%t<boolean>     = sub ($value, *@_) { $value ~~ Bool };
	%t<integer>     = sub ($value, *@_) { $value ~~ Int };
	%t<float>       = sub ($value, *@_) { $value ~~ Num || $value ~~ Rat };
	%t<number>      = sub ($value, *@_) { $value ~~ Numeric };
	%t<string>      = sub ($value, *@_) { $value ~~ Str };
	%t<sequence>    = sub ($value, *@_) { $value ~~ Positional || $value ~~ Str };
	%t<mapping>     = sub ($value, *@_) { $value ~~ Associative };
	%t<iterable>    = sub ($value, *@_) { $value ~~ Iterable || $value ~~ Str };
	%t<callable>    = sub ($value, *@_) { $value ~~ Callable };
	%t<sameas>      = sub ($value, $other, *@_) { $value === $other };
	%t<eq>          = %t<equalto> = sub ($value, $other, *@_) { $value eqv $other };
	%t<ne>          = sub ($value, $other, *@_) { !($value eqv $other) };
	%t<lt>          = %t<lessthan> = sub ($value, $other, *@_) { $value < $other };
	%t<le>          = sub ($value, $other, *@_) { $value <= $other };
	%t<gt>          = %t<greaterthan> = sub ($value, $other, *@_) { $value > $other };
	%t<ge>          = sub ($value, $other, *@_) { $value >= $other };
	%t<even>        = sub ($value, *@_) { $value ~~ Int && $value % 2 == 0 };
	%t<odd>         = sub ($value, *@_) { $value ~~ Int && $value % 2 != 0 };
	%t<divisibleby> = sub ($value, $num, *@_) { $value ~~ Numeric && $num ~~ Numeric && $value % $num == 0 };
	%t<in>          = sub ($value, $seq, *@_) {
		return False unless $seq.defined;
		if $seq ~~ Str { $seq.contains(~$value) }
		elsif $seq ~~ Positional { $value eq any($seq.list) }
		elsif $seq ~~ Associative { $seq{$value}:exists }
		else { False }
	};
	%t<true>        = sub ($value, *@_) { $value ~~ Bool && $value };
	%t<false>       = sub ($value, *@_) { $value ~~ Bool && !$value };
	%t<lower>       = sub ($value, *@_) { $value ~~ Str && $value eq $value.lc && $value ne $value.uc };
	%t<upper>       = sub ($value, *@_) { $value ~~ Str && $value eq $value.uc && $value ne $value.lc };

	%t;
}

}
