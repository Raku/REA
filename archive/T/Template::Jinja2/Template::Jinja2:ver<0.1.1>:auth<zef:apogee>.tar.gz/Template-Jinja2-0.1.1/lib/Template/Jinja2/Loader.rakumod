use Template::Jinja2::Exceptions;

module Template::Jinja2::Loader {

role Loader is export {
	method get-source(Str:D $name --> Str) { ... }
}

class FileSystemLoader does Loader is export {
	has Str:D $.searchpath is required;

	method get-source(Str:D $name --> Str) {
		my $path = $!searchpath.IO.child($name);
		die TemplateNotFoundError.new("Template '$name' not found") unless $path.e;
		$path.slurp;
	}
}

class DictLoader does Loader is export {
	has %.templates;

	method get-source(Str:D $name --> Str) {
		die TemplateNotFoundError.new("Template '$name' not found")
			unless %!templates{$name}:exists;
		%!templates{$name};
	}
}

}
