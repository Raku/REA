unit module Template::Jinja2::Exceptions;

class TemplateSyntaxError is Exception is export {
	has Str:D $.message is required;
	has Int $.lineno;
	has Str $.source;
	method new(Str:D $message, Int :$lineno, Str :$source) {
		self.bless(:$message, :$lineno, :$source);
	}
	method gist(--> Str:D) {
		$!lineno.defined
			?? "TemplateSyntaxError: $!message (line $!lineno)"
			!! "TemplateSyntaxError: $!message";
	}
}

class TemplateRuntimeError is Exception is export {
	has Str:D $.message is required;
	method new(Str:D $message) { self.bless(:$message) }
	method gist(--> Str:D) { "TemplateRuntimeError: $!message" }
}

class UndefinedError is Exception is export {
	has Str:D $.message is required;
	method new(Str:D $message) { self.bless(:$message) }
	method gist(--> Str:D) { "UndefinedError: $!message" }
}

class TemplateNotFoundError is Exception is export {
	has Str:D $.message is required;
	method new(Str:D $message) { self.bless(:$message) }
	method gist(--> Str:D) { "TemplateNotFoundError: $!message" }
}

# Control flow exceptions (not errors)
class LoopBreak is Exception is export { }
class LoopContinue is Exception is export { }
