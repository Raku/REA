use Template::Jinja2::Lexer;
use Template::Jinja2::AST;
use Template::Jinja2::Exceptions;

module Template::Jinja2::Parser {

class ExprParser { ... }

class Parser is export {
	has Token @.tokens;
	has Int $!pos = 0;

	method parse(@tokens --> TemplateNode) {
		@!tokens = @tokens;
		$!pos = 0;
		my Node @body = self!parse-body();
		TemplateNode.new(:@body);
	}

	# --- Token stream helpers ---

	method !current(--> Token) {
		return Token.new(:type(TOKEN_TEXT), :value('')) if $!pos >= @!tokens.elems;
		@!tokens[$!pos];
	}

	method !peek(--> Token) {
		return Token.new(:type(TOKEN_TEXT), :value('')) if $!pos + 1 >= @!tokens.elems;
		@!tokens[$!pos + 1];
	}

	method !advance(--> Token) {
		my $tok = self!current;
		$!pos++;
		$tok;
	}

	method !eof(--> Bool:D) {
		$!pos >= @!tokens.elems;
	}

	method !expect-block(Str:D $tag --> Token) {
		my $tok = self!current;
		unless $tok.type === TOKEN_BLOCK && $tok.tag-name eq $tag {
			die TemplateSyntaxError.new("Expected '{$tag}' tag, got '{$tok.Str}'");
		}
		self!advance;
	}

	method !at-block(Str:D $tag --> Bool:D) {
		return False if self!eof;
		my $tok = self!current;
		$tok.type === TOKEN_BLOCK && $tok.tag-name eq $tag;
	}

	method !at-any-block(*@tags --> Bool:D) {
		return False if self!eof;
		my $tok = self!current;
		return False unless $tok.type === TOKEN_BLOCK;
		so $tok.tag-name eq any(@tags);
	}

	# --- Top-level body parsing ---

	method !parse-body(*@end-tags --> List) {
		my Node @body;
		while !self!eof {
			last if @end-tags.elems > 0 && self!at-any-block(|@end-tags);
			my $tok = self!current;
			given $tok.type {
				when TOKEN_TEXT {
					@body.push: Text.new(:value($tok.value));
					self!advance;
				}
				when TOKEN_RAW {
					@body.push: Raw.new(:value($tok.value));
					self!advance;
				}
				when TOKEN_VAR {
					@body.push: Output.new(:expr(self!parse-expression-from-parts($tok.value)));
					self!advance;
				}
				when TOKEN_BLOCK {
					@body.push: self!parse-block-tag();
				}
				default {
					self!advance;  # skip unknown
				}
			}
		}
		@body;
	}

	# --- Block tag dispatch ---

	method !parse-block-tag(--> Node) {
		my $tok = self!current;
		my $tag = $tok.tag-name;
		given $tag {
			when 'if'         { self!parse-if }
			when 'for'        { self!parse-for }
			when 'set'        { self!parse-set }
			when 'with'       { self!parse-with }
			when 'block'      { self!parse-block }
			when 'extends'    { self!parse-extends }
			when 'include'    { self!parse-include }
			when 'import'     { self!parse-import }
			when 'from'       { self!parse-from-import }
			when 'macro'      { self!parse-macro }
			when 'call'       { self!parse-call-block }
			when 'filter'     { self!parse-filter-block }
			when 'do'         { self!parse-do }
			when 'break'      { self!advance; Break.new }
			when 'continue'   { self!advance; Continue.new }
			when 'autoescape' { self!parse-autoescape }
			default {
				die TemplateSyntaxError.new("Unknown tag '$tag'");
			}
		}
	}

	# --- Expression parsing from token parts ---

	method !parse-expression-from-parts(@parts --> Node) {
		my $ep = ExprParser.new(:@parts);
		$ep.parse-expression;
	}

	# --- if tag ---

	method !parse-if(--> If) {
		my $tok = self!advance;  # consume {% if ... %}
		my $test = self!parse-expression-from-parts($tok.value);
		my Node @body = self!parse-body('elif', 'else', 'endif');
		my Node @elif;
		while self!at-block('elif') {
			my $elif-tok = self!advance;
			my $elif-test = self!parse-expression-from-parts($elif-tok.value);
			my Node @elif-body = self!parse-body('elif', 'else', 'endif');
			@elif.push: If.new(:test($elif-test), :body(@elif-body));
		}
		my Node @else-body;
		if self!at-block('else') {
			self!advance;
			@else-body = self!parse-body('endif');
		}
		self!expect-block('endif');
		If.new(:$test, :@body, :@elif, :@else-body);
	}

	# --- for tag ---

	method !parse-for(--> For) {
		my $tok = self!advance;  # consume {% for ... %}
		my @parts = $tok.value;

		# Parse: target [, target2] in iterable [if condition] [recursive]
		my @target-names;
		my $i = 0;

		# Collect target names (before 'in')
		while $i < @parts.elems {
			last if @parts[$i].type === TOKEN_NAME && @parts[$i].value eq 'in';
			if @parts[$i].type === TOKEN_NAME {
				@target-names.push: @parts[$i].value;
			}
			$i++;
		}
		$i++;  # skip 'in'

		die TemplateSyntaxError.new("Expected 'in' in for tag") unless @target-names.elems > 0;
		die TemplateSyntaxError.new("Cannot use 'loop' as iteration variable") if 'loop' eq any(@target-names);
		my @reserved = <true false none True False None>;
		for @target-names -> $n {
			die TemplateSyntaxError.new("Cannot assign to constant '$n'") if $n eq any(@reserved);
		}

		# Build target node
		my Node $target;
		if @target-names.elems == 1 {
			$target = Name.new(:name(@target-names[0]));
		} else {
			$target = TupleLiteral.new(:elements(@target-names.map({ Name.new(:name($_)) })));
		}

		# Split remaining parts into: iterable [if condition] [recursive]
		my Bool $recursive = False;
		my @iter-parts;
		my @filter-parts;
		my $in-filter = False;

		# Check for 'recursive' at the end
		my @remaining = @parts[$i ..^ @parts.elems];
		if @remaining.elems > 0 && @remaining[*-1].type === TOKEN_NAME && @remaining[*-1].value eq 'recursive' {
			$recursive = True;
			@remaining = @remaining[0 ..^ @remaining.elems - 1];
		}

		# Split on 'if' keyword
		for @remaining -> $p {
			if !$in-filter && $p.type === TOKEN_NAME && $p.value eq 'if' {
				$in-filter = True;
				next;
			}
			if $in-filter {
				@filter-parts.push: $p;
			} else {
				@iter-parts.push: $p;
			}
		}

		my $iter = self!parse-expression-from-parts(@iter-parts);
		my Node $filter;
		$filter = self!parse-expression-from-parts(@filter-parts) if @filter-parts.elems > 0;

		my Node @body = self!parse-body('else', 'endfor');
		my Node @else-body;
		if self!at-block('else') {
			self!advance;
			@else-body = self!parse-body('endfor');
		}
		self!expect-block('endfor');
		For.new(:$target, :$iter, :$filter, :@body, :@else-body, :$recursive);
	}

	# --- set tag ---

	method !parse-set(--> Node) {
		my $tok = self!advance;  # consume {% set ... %}
		my @parts = $tok.value;

		# Find '=' in parts
		my $eq-idx = @parts.first(*.type === TOKEN_ASSIGN, :k);

		if $eq-idx.defined {
			# Check for dotted assignment: {% set ns.attr = expr %}
			if $eq-idx >= 2 && @parts[1].type === TOKEN_DOT {
				my $obj-name = @parts[0].value;
				my $attr = @parts[2].value;
				my @expr-parts = @parts[$eq-idx + 1 ..^ @parts.elems];
				my $value = self!parse-expression-from-parts(@expr-parts);
				return SetAttr.new(:$obj-name, :$attr, :$value);
			}
			# {% set name = expr %}
			my $name = @parts[0].value;
			my @reserved = <true false none True False None>;
			die TemplateSyntaxError.new("Cannot assign to constant '$name'")
				if $name eq any(@reserved);
			my @expr-parts = @parts[$eq-idx + 1 ..^ @parts.elems];
			my $value = self!parse-expression-from-parts(@expr-parts);
			Set.new(:$name, :$value);
		} else {
			# Check for dotted set block: {% set ns.attr %}...{% endset %}
			if @parts.elems >= 3 && @parts[1].type === TOKEN_DOT {
				my $obj-name = @parts[0].value;
				my $attr = ~@parts[2].value;
				my Node @body = self!parse-body('endset');
				self!expect-block('endset');
				# Reuse SetAttr with a special body wrapper
				my $value-node = SetBlock.new(:name($attr), :@body);
				return SetAttr.new(:$obj-name, :$attr, :value($value-node));
			}
			# {% set name %}...{% endset %} or {% set name | filter %}...{% endset %}
			my $name = @parts[0].value;
			my Node $filter;
			# Check for pipe — filter chain on the set block
			if @parts.elems > 1 && @parts[1].type === TOKEN_PIPE {
				# Build a dummy expression: parse "x | filter1 | filter2" then extract filter chain
				my @filter-parts = @parts[1 ..^ @parts.elems];
				# Create a Name node placeholder, then parse the pipe chain after it
				$filter = self!parse-expression-from-parts((@parts[0], |@filter-parts));
			}
			my Node @body = self!parse-body('endset');
			self!expect-block('endset');
			SetBlock.new(:$name, :@body, :$filter);
		}
	}

	# --- with tag ---

	method !parse-with(--> With) {
		my $tok = self!advance;  # consume {% with ... %}
		my @parts = $tok.value;
		my @assignments;

		# Parse comma-separated assignments: name = expr [, name = expr]
		my $i = 0;
		while $i < @parts.elems {
			my $name = @parts[$i].value;
			$i++;  # skip name
			$i++ if $i < @parts.elems && @parts[$i].type === TOKEN_ASSIGN;  # skip =
			my @expr-parts;
			while $i < @parts.elems && @parts[$i].type !=== TOKEN_COMMA {
				@expr-parts.push: @parts[$i];
				$i++;
			}
			$i++ if $i < @parts.elems && @parts[$i].type === TOKEN_COMMA;
			my $value = self!parse-expression-from-parts(@expr-parts);
			@assignments.push: Pair.new($name, $value);
		}

		my Node @body = self!parse-body('endwith');
		self!expect-block('endwith');
		With.new(:@assignments, :@body);
	}

	# --- block tag ---

	method !parse-block(--> Block) {
		my $tok = self!advance;
		my @parts = $tok.value;
		my $name = @parts[0].value;
		# Check for hyphens in block name
		if @parts.elems > 1 && @parts[1].type === TOKEN_OPERATOR && @parts[1].value eq '-' {
			die TemplateSyntaxError.new("Block names may not contain hyphens, use an underscore instead.");
		}
		my $scoped = @parts.elems > 1 && @parts[1].value eq 'scoped';
		my Node @body = self!parse-body('endblock');
		self!expect-block('endblock');
		Block.new(:$name, :@body, :$scoped);
	}

	# --- extends tag ---

	method !parse-extends(--> Extends) {
		my $tok = self!advance;
		my $template = self!parse-expression-from-parts($tok.value);
		Extends.new(:$template);
	}

	# --- include tag ---

	method !parse-include(--> Include) {
		my $tok = self!advance;
		my @parts = $tok.value;
		my $ignore-missing = False;
		my $with-context = True;

		# Check for 'ignore missing', 'with context', 'without context'
		my @expr-parts;
		my $i = 0;
		while $i < @parts.elems {
			if $i + 1 < @parts.elems
				&& @parts[$i].type === TOKEN_NAME && @parts[$i].value eq 'ignore'
				&& @parts[$i+1].type === TOKEN_NAME && @parts[$i+1].value eq 'missing' {
				$ignore-missing = True;
				$i += 2;
			} elsif $i + 1 < @parts.elems
				&& @parts[$i].type === TOKEN_NAME && @parts[$i].value eq 'with'
				&& @parts[$i+1].type === TOKEN_NAME && @parts[$i+1].value eq 'context' {
				$with-context = True;
				$i += 2;
			} elsif $i + 1 < @parts.elems
				&& @parts[$i].type === TOKEN_NAME && @parts[$i].value eq 'without'
				&& @parts[$i+1].type === TOKEN_NAME && @parts[$i+1].value eq 'context' {
				$with-context = False;
				$i += 2;
			} else {
				@expr-parts.push: @parts[$i];
				$i++;
			}
		}

		my $template = self!parse-expression-from-parts(@expr-parts);
		Include.new(:$template, :$ignore-missing, :$with-context);
	}

	# --- import tag ---

	method !parse-import(--> Import) {
		my $tok = self!advance;
		my @parts = $tok.value;
		# {% import "template" as name [with context] %}
		my $as-idx = @parts.first({ .type === TOKEN_NAME && .value eq 'as' }, :k);
		die TemplateSyntaxError.new("Import requires 'as' clause") unless $as-idx.defined;

		my @template-parts = @parts[0 ..^ $as-idx];
		my $template = self!parse-expression-from-parts(@template-parts);
		my $name = @parts[$as-idx + 1].value;
		my $with-context = @parts.elems > $as-idx + 2
			&& @parts[$as-idx + 2].value eq 'with';
		Import.new(:$template, :$name, :$with-context);
	}

	# --- from...import tag ---

	method !parse-from-import(--> FromImport) {
		my $tok = self!advance;
		my @parts = $tok.value;
		# {% from "template" import name1 [as alias1], name2 [with context] %}
		my $import-idx = @parts.first({ .type === TOKEN_NAME && .value eq 'import' }, :k);
		die TemplateSyntaxError.new("Expected 'import' in from tag") unless $import-idx.defined;

		my @template-parts = @parts[0 ..^ $import-idx];
		my $template = self!parse-expression-from-parts(@template-parts);

		my @names;
		my $with-context = False;
		my $i = $import-idx + 1;
		while $i < @parts.elems {
			if @parts[$i].type === TOKEN_NAME && @parts[$i].value eq 'with'
				&& $i + 1 < @parts.elems && @parts[$i+1].value eq 'context' {
				$with-context = True;
				$i += 2;
			} elsif @parts[$i].type === TOKEN_NAME {
				my $orig = @parts[$i].value;
				$i++;
				if $i < @parts.elems && @parts[$i].type === TOKEN_NAME && @parts[$i].value eq 'as' {
					$i++;
					my $alias = @parts[$i].value;
					$i++;
					@names.push: Pair.new($orig, $alias);
				} else {
					@names.push: $orig;
				}
				$i++ if $i < @parts.elems && @parts[$i].type === TOKEN_COMMA;
			} else {
				$i++;
			}
		}

		FromImport.new(:$template, :@names, :$with-context);
	}

	# --- macro tag ---

	method !parse-macro(--> Macro) {
		my $tok = self!advance;
		my @parts = $tok.value;
		my $name = @parts[0].value;

		# Parse params from ( ... )
		my @params;
		if @parts.elems > 1 && @parts[1].type === TOKEN_LPAREN {
			my $i = 2;
			while $i < @parts.elems && @parts[$i].type !=== TOKEN_RPAREN {
				my $param-name = @parts[$i].value;
				$i++;
				my Node $default;
				if $i < @parts.elems && @parts[$i].type === TOKEN_ASSIGN {
					$i++;
					# Collect tokens for default value until comma or rparen
					my @default-parts;
					my $depth = 0;
					while $i < @parts.elems {
						last if $depth == 0 && (@parts[$i].type === TOKEN_COMMA || @parts[$i].type === TOKEN_RPAREN);
						$depth++ if @parts[$i].type === TOKEN_LPAREN;
						$depth-- if @parts[$i].type === TOKEN_RPAREN;
						@default-parts.push: @parts[$i];
						$i++;
					}
					$default = self!parse-expression-from-parts(@default-parts);
				}
				@params.push: Pair.new($param-name, $default);
				$i++ if $i < @parts.elems && @parts[$i].type === TOKEN_COMMA;
			}
		}

		# Validate: no required param after optional
		my $saw-default = False;
		for @params -> $p {
			if $p.value.defined {
				$saw-default = True;
			} elsif $saw-default {
				die TemplateSyntaxError.new("Non-default parameter '{$p.key}' follows default parameter");
			}
		}

		my Node @body = self!parse-body('endmacro');
		self!expect-block('endmacro');
		Macro.new(:$name, :@params, :@body);
	}

	# --- call block ---

	method !parse-call-block(--> CallBlock) {
		my $tok = self!advance;
		my @parts = $tok.value;
		my @params;

		# Check for {% call(param1, param2) macro_call() %}
		my $i = 0;
		if $i < @parts.elems && @parts[$i].type === TOKEN_LPAREN {
			$i++;  # skip (
			while $i < @parts.elems && @parts[$i].type !=== TOKEN_RPAREN {
				if @parts[$i].type === TOKEN_NAME {
					@params.push: @parts[$i].value;
				}
				$i++;
				$i++ if $i < @parts.elems && @parts[$i].type === TOKEN_COMMA;
			}
			$i++ if $i < @parts.elems;  # skip )
		}

		my @call-parts = @parts[$i ..^ @parts.elems];
		my $call = self!parse-expression-from-parts(@call-parts);
		my Node @body = self!parse-body('endcall');
		self!expect-block('endcall');
		CallBlock.new(:$call, :@params, :@body);
	}

	# --- filter block ---

	method !parse-filter-block(--> FilterBlock) {
		my $tok = self!advance;
		my $filter = self!parse-expression-from-parts($tok.value);
		my Node @body = self!parse-body('endfilter');
		self!expect-block('endfilter');
		FilterBlock.new(:$filter, :@body);
	}

	# --- do tag ---

	method !parse-do(--> Do) {
		my $tok = self!advance;
		my $expr = self!parse-expression-from-parts($tok.value);
		Do.new(:$expr);
	}

	# --- autoescape tag ---

	method !parse-autoescape(--> AutoEscape) {
		my $tok = self!advance;
		my $enabled = self!parse-expression-from-parts($tok.value);
		my Node @body = self!parse-body('endautoescape');
		self!expect-block('endautoescape');
		AutoEscape.new(:$enabled, :@body);
	}

	# --- Helper: single token to node ---

	method !token-to-node(Token $tok --> Node) {
		given $tok.type {
			when TOKEN_STRING  { StringLiteral.new(:value($tok.value)) }
			when TOKEN_INTEGER { IntegerLiteral.new(:value($tok.value)) }
			when TOKEN_FLOAT   { FloatLiteral.new(:value($tok.value)) }
			when TOKEN_NAME {
				given $tok.value {
					when 'true' | 'True'   { BoolLiteral.new(:value(True)) }
					when 'false' | 'False' { BoolLiteral.new(:value(False)) }
					when 'none' | 'None'   { NoneLiteral.new }
					default                { Name.new(:name($tok.value)) }
				}
			}
			default { Name.new(:name(~$tok.value)) }
		}
	}
}

# === Expression parser (Pratt-style from flat token list) ===

class ExprParser is export {
	has @.parts;
	has Int $!pos = 0;

	method !current(--> Token) {
		return Token.new(:type(TOKEN_NAME), :value('')) if $!pos >= @!parts.elems;
		@!parts[$!pos];
	}

	method !advance(--> Token) {
		my $tok = self!current;
		$!pos++;
		$tok;
	}

	method !eof(--> Bool:D) { $!pos >= @!parts.elems }

	method !at-type(TokenType $t --> Bool:D) {
		return False if self!eof;
		self!current.type === $t;
	}

	method !at-name(Str:D $n --> Bool:D) {
		return False if self!eof;
		self!current.type === TOKEN_NAME && self!current.value eq $n;
	}

	# --- Entry point ---

	method parse-expression(--> Node) {
		self!parse-conditional;
	}

	# --- Conditional (ternary): expr if test else expr ---

	method !parse-conditional(--> Node) {
		my $expr = self!parse-or;
		if self!at-name('if') {
			self!advance;  # skip 'if'
			my $test = self!parse-or;
			my Node $false-expr;
			if self!at-name('else') {
				self!advance;
				$false-expr = self!parse-conditional;
			}
			return Conditional.new(:$test, :true-expr($expr), :$false-expr);
		}
		$expr;
	}

	# --- Filter chain (pipe) — between comparison and concat ---

	method !parse-filter-chain(--> Node) {
		my $node = self!parse-addition;
		while self!at-type(TOKEN_PIPE) {
			self!advance;  # skip |
			my $filter-name = self!advance.value;
			my @args;
			my @kwargs;
			if self!at-type(TOKEN_LPAREN) {
				my @result = self!parse-call-args-with-kwargs;
				@args = @result[0].list;
				@kwargs = @result[1].list;
			}
			$node = Filter.new(:$node, :name($filter-name), :@args, :@kwargs);
		}
		$node;
	}

	# --- Logical OR ---

	method !parse-or(--> Node) {
		my $left = self!parse-and;
		while self!at-name('or') {
			self!advance;
			my $right = self!parse-and;
			$left = Or.new(:$left, :$right);
		}
		$left;
	}

	# --- Logical AND ---

	method !parse-and(--> Node) {
		my $left = self!parse-not;
		while self!at-name('and') {
			self!advance;
			my $right = self!parse-not;
			$left = And.new(:$left, :$right);
		}
		$left;
	}

	# --- Logical NOT ---

	method !parse-not(--> Node) {
		if self!at-name('not') {
			self!advance;
			my $operand = self!parse-not;
			return Not.new(:$operand);
		}
		self!parse-comparison;
	}

	# --- Comparison: ==, !=, <, >, <=, >=, in, not in, is, is not ---

	method !parse-comparison(--> Node) {
		my $left = self!parse-concat;

		if !self!eof && self!current.type === TOKEN_OPERATOR
			&& self!current.value eq any('==', '!=', '<', '>', '<=', '>=') {
			my $op = self!advance.value;
			my $right = self!parse-concat;
			my $result = Compare.new(:$left, :$op, :$right);
			# Chained comparisons: a < b < c → (a < b) and (b < c)
			while !self!eof && self!current.type === TOKEN_OPERATOR
				&& self!current.value eq any('==', '!=', '<', '>', '<=', '>=') {
				my $next-op = self!advance.value;
				my $next-right = self!parse-concat;
				$result = And.new(:left($result),
					:right(Compare.new(:left($right), :op($next-op), :right($next-right))));
				$right = $next-right;
			}
			return $result;
		}

		if self!at-name('in') {
			self!advance;
			my $right = self!parse-concat;
			return Compare.new(:$left, :op('in'), :$right);
		}

		if self!at-name('not') && $!pos + 1 < @!parts.elems
			&& @!parts[$!pos + 1].type === TOKEN_NAME && @!parts[$!pos + 1].value eq 'in' {
			self!advance; self!advance;  # skip 'not in'
			my $right = self!parse-concat;
			return Compare.new(:$left, :op('notin'), :$right);
		}

		if self!at-name('is') {
			self!advance;
			my $negated = False;
			if self!at-name('not') {
				self!advance;
				$negated = True;
			}
			my $name = self!advance.value;
			my Node @args;
			if self!at-type(TOKEN_LPAREN) {
				@args = self!parse-call-args;
			}
			return TestExpr.new(:node($left), :$name, :@args, :$negated);
		}

		$left;
	}

	# --- String concatenation (~) ---

	method !parse-concat(--> Node) {
		my $left = self!parse-filter-chain;
		while !self!eof && self!current.type === TOKEN_OPERATOR && self!current.value eq '~' {
			self!advance;
			my $right = self!parse-filter-chain;
			$left = Concat.new(:$left, :$right);
		}
		$left;
	}

	# --- Addition / Subtraction ---

	method !parse-addition(--> Node) {
		my $left = self!parse-multiplication;
		while !self!eof && self!current.type === TOKEN_OPERATOR
			&& self!current.value eq any('+', '-') {
			my $op = self!advance.value;
			my $right = self!parse-multiplication;
			$left = BinOp.new(:$left, :$op, :$right);
		}
		$left;
	}

	# --- Multiplication / Division / Floor Division / Modulo ---

	method !parse-multiplication(--> Node) {
		my $left = self!parse-power;
		while !self!eof && self!current.type === TOKEN_OPERATOR
			&& self!current.value eq any('*', '/', '//', '%') {
			my $op = self!advance.value;
			my $right = self!parse-power;
			$left = BinOp.new(:$left, :$op, :$right);
		}
		$left;
	}

	# --- Power (**) ---

	method !parse-power(--> Node) {
		my $left = self!parse-unary;
		if !self!eof && self!current.type === TOKEN_OPERATOR && self!current.value eq '**' {
			self!advance;
			my $right = self!parse-unary;
			$left = BinOp.new(:$left, :op('**'), :$right);
		}
		$left;
	}

	# --- Unary (-, +) ---

	method !parse-unary(--> Node) {
		if !self!eof && self!current.type === TOKEN_OPERATOR
			&& self!current.value eq any('-', '+') {
			my $op = self!advance.value;
			my $operand = self!parse-unary;
			return UnaryOp.new(:$op, :$operand);
		}
		self!parse-postfix;
	}

	# --- Postfix: filter (|), dot access, subscript, call ---

	method !parse-postfix(--> Node) {
		my $node = self!parse-primary;
		loop {
			if self!at-type(TOKEN_DOT) {
				self!advance;
				my $next = self!advance;
				if $next.type === TOKEN_INTEGER {
					# Numeric dot access: items.0 → GetItem(items, 0)
					$node = GetItem.new(:$node, :index(IntegerLiteral.new(:value($next.value))));
				} else {
					$node = GetAttr.new(:$node, :attr(~$next.value));
				}
			} elsif self!at-type(TOKEN_LBRACKET) {
				self!advance;  # skip [
				# Check for slice syntax: [start:stop:step]
				if self!at-type(TOKEN_COLON) || self!is-slice-ahead() {
					$node = self!parse-slice($node);
				} else {
					my $index = self.parse-expression;
					if self!at-type(TOKEN_COLON) {
						# Expression followed by : — it's a slice with start
						$node = self!parse-slice-from($node, $index);
					} else {
						unless self!at-type(TOKEN_RBRACKET) {
							die TemplateSyntaxError.new("Expected ']'");
						}
						self!advance;
						$node = GetItem.new(:$node, :$index);
					}
				}
			} elsif self!at-type(TOKEN_LPAREN) {
				my @result = self!parse-call-args-with-kwargs;
				my @args = @result[0].list;
				my @kwargs = @result[1].list;
				$node = Call.new(:$node, :@args, :@kwargs);
			} else {
				last;
			}
		}
		$node;
	}

	# --- Slice helpers ---

	method !is-slice-ahead(--> Bool:D) {
		# Look ahead to see if there's a : before the closing ]
		my $saved = $!pos;
		my $depth = 1;
		while $!pos < @!parts.elems {
			if self!current.type === TOKEN_LBRACKET { $depth++ }
			elsif self!current.type === TOKEN_RBRACKET { $depth--; last if $depth == 0 }
			elsif self!current.type === TOKEN_COLON && $depth == 1 { $!pos = $saved; return True }
			$!pos++;
		}
		$!pos = $saved;
		False;
	}

	method !parse-slice(Node $node --> Slice) {
		# At [, cursor is after [, next is : or expression
		# Parse [:stop:step] or [::step] etc.
		my Node $start;
		if !self!at-type(TOKEN_COLON) && !self!at-type(TOKEN_RBRACKET) {
			$start = self.parse-expression;
		}
		return self!parse-slice-from($node, $start);
	}

	method !parse-slice-from(Node $node, Node $start --> Slice) {
		# Cursor should be at first :
		self!advance if self!at-type(TOKEN_COLON);  # skip first :
		my Node $stop;
		if !self!at-type(TOKEN_COLON) && !self!at-type(TOKEN_RBRACKET) {
			$stop = self.parse-expression;
		}
		my Node $step;
		if self!at-type(TOKEN_COLON) {
			self!advance;  # skip second :
			if !self!at-type(TOKEN_RBRACKET) {
				$step = self.parse-expression;
			}
		}
		self!advance if self!at-type(TOKEN_RBRACKET);
		Slice.new(:$node, :$start, :$stop, :$step);
	}

	# --- Primary expressions ---

	method !parse-primary(--> Node) {
		my $tok = self!current;
		given $tok.type {
			when TOKEN_STRING {
				self!advance;
				# String concatenation: "foo" "bar" → "foobar"
				my $val = $tok.value;
				while !self!eof && self!current.type === TOKEN_STRING {
					$val ~= self!advance.value;
				}
				StringLiteral.new(:value($val));
			}
			when TOKEN_INTEGER {
				self!advance;
				IntegerLiteral.new(:value($tok.value));
			}
			when TOKEN_FLOAT {
				self!advance;
				FloatLiteral.new(:value($tok.value));
			}
			when TOKEN_NAME {
				self!advance;
				given $tok.value {
					when 'true' | 'True'   { BoolLiteral.new(:value(True)) }
					when 'false' | 'False' { BoolLiteral.new(:value(False)) }
					when 'none' | 'None'   { NoneLiteral.new }
					default                { Name.new(:name($tok.value)) }
				}
			}
			when TOKEN_LPAREN {
				self!advance;  # skip (
				if self!at-type(TOKEN_RPAREN) {
					self!advance;
					return TupleLiteral.new(:elements([]));
				}
				my $first = self.parse-expression;
				if self!at-type(TOKEN_COMMA) {
					# Tuple
					my @elements = ($first,);
					while self!at-type(TOKEN_COMMA) {
						self!advance;
						last if self!at-type(TOKEN_RPAREN);
						@elements.push: self.parse-expression;
					}
					self!advance if self!at-type(TOKEN_RPAREN);
					return TupleLiteral.new(:@elements);
				}
				self!advance if self!at-type(TOKEN_RPAREN);
				$first;  # just parenthesized expression
			}
			when TOKEN_LBRACKET {
				self!advance;  # skip [
				my Node @elements;
				until self!eof || self!at-type(TOKEN_RBRACKET) {
					@elements.push: self.parse-expression;
					last unless self!at-type(TOKEN_COMMA);
					self!advance;
				}
				self!advance if self!at-type(TOKEN_RBRACKET);
				ListLiteral.new(:@elements);
			}
			when TOKEN_LBRACE {
				self!advance;  # skip {
				my @pairs;
				until self!eof || self!at-type(TOKEN_RBRACE) {
					my $key = self.parse-expression;
					unless self!at-type(TOKEN_COLON) {
						die TemplateSyntaxError.new("Expected ':' in dict literal");
					}
					self!advance;
					my $value = self.parse-expression;
					@pairs.push: Pair.new($key, $value);
					last unless self!at-type(TOKEN_COMMA);
					self!advance;
				}
				self!advance if self!at-type(TOKEN_RBRACE);
				HashLiteral.new(:@pairs);
			}
			default {
				die TemplateSyntaxError.new("Unexpected token: {$tok.Str}");
			}
		}
	}

	# --- Call arguments ---

	method !parse-call-args(--> List) {
		self!advance;  # skip (
		my Node @args;
		until self!eof || self!at-type(TOKEN_RPAREN) {
			@args.push: self.parse-expression;
			last unless self!at-type(TOKEN_COMMA);
			self!advance;
		}
		self!advance if self!at-type(TOKEN_RPAREN);
		@args;
	}

	method !parse-call-args-with-kwargs() {
		self!advance;  # skip (
		my Node @args;
		my @kwargs;
		until self!eof || self!at-type(TOKEN_RPAREN) {
			# Check for kwarg: name=expr
			if self!current.type === TOKEN_NAME
				&& $!pos + 1 < @!parts.elems
				&& @!parts[$!pos + 1].type === TOKEN_ASSIGN {
				my $name = self!advance.value;
				self!advance;  # skip =
				my $value = self.parse-expression;
				@kwargs.push: Pair.new($name, $value);
			} elsif self!current.type === TOKEN_OPERATOR && self!current.value eq '*' {
				# *args — skip for now
				self!advance;
				@args.push: self.parse-expression;
			} elsif self!current.type === TOKEN_OPERATOR && self!current.value eq '**' {
				# **kwargs — skip for now
				self!advance;
				self.parse-expression;
			} else {
				@args.push: self.parse-expression;
			}
			last unless self!at-type(TOKEN_COMMA);
			self!advance;
		}
		self!advance if self!at-type(TOKEN_RPAREN);
		(@args, @kwargs);
	}
}

# === Convenience function ===

sub parse(Str:D $source, Bool:D :$trim-blocks = False, Bool:D :$lstrip-blocks = False,
	Str:D :$block-start = '{%', Str:D :$block-end = '%}',
	Str:D :$variable-start = '{{', Str:D :$variable-end = '}}',
	Str:D :$comment-start = '{#', Str:D :$comment-end = '#}',
	--> TemplateNode) is export {
	my @tokens = tokenize($source, :$trim-blocks, :$lstrip-blocks,
		:$block-start, :$block-end, :$variable-start, :$variable-end,
		:$comment-start, :$comment-end);
	my $parser = Parser.new;
	$parser.parse(@tokens);
}

}
