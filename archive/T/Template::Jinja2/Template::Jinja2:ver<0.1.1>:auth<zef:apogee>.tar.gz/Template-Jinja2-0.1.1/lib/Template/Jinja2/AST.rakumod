module Template::Jinja2::AST {

# === Base node ===

role Node is export { }

# === Output nodes ===

class TemplateNode does Node is export {
	has Node @.body is required;
}

class Output does Node is export {
	has Node $.expr is required;
}

class Text does Node is export {
	has Str:D $.value is required;
}

class Raw does Node is export {
	has Str:D $.value is required;
}

# === Literal nodes ===

class StringLiteral does Node is export {
	has Str:D $.value is required;
}

class IntegerLiteral does Node is export {
	has Int:D $.value is required;
}

class FloatLiteral does Node is export {
	has Num:D $.value is required;
}

class BoolLiteral does Node is export {
	has Bool:D $.value is required;
}

class NoneLiteral does Node is export { }

class ListLiteral does Node is export {
	has Node @.elements;
}

class HashLiteral does Node is export {
	has @.pairs;  # list of Pair(Node, Node)
}

class TupleLiteral does Node is export {
	has Node @.elements;
}

# === Name / access nodes ===

class Name does Node is export {
	has Str:D $.name is required;
}

class GetAttr does Node is export {
	has Node $.node is required;
	has Str:D $.attr is required;
}

class GetItem does Node is export {
	has Node $.node is required;
	has Node $.index is required;
}

class Slice does Node is export {
	has Node $.node is required;
	has Node $.start;
	has Node $.stop;
	has Node $.step;
}

# === Operator nodes ===

class BinOp does Node is export {
	has Node $.left is required;
	has Str:D $.op is required;
	has Node $.right is required;
}

class UnaryOp does Node is export {
	has Str:D $.op is required;
	has Node $.operand is required;
}

class Compare does Node is export {
	has Node $.left is required;
	has Str:D $.op is required;
	has Node $.right is required;
}

class And does Node is export {
	has Node $.left is required;
	has Node $.right is required;
}

class Or does Node is export {
	has Node $.left is required;
	has Node $.right is required;
}

class Not does Node is export {
	has Node $.operand is required;
}

class Concat does Node is export {
	has Node $.left is required;
	has Node $.right is required;
}

class Conditional does Node is export {
	has Node $.test is required;
	has Node $.true-expr is required;
	has Node $.false-expr;
}

# === Filter / test nodes ===

class Filter does Node is export {
	has Node $.node is required;
	has Str:D $.name is required;
	has Node @.args;
	has @.kwargs;  # list of Pair(Str, Node)
}

class TestExpr does Node is export {
	has Node $.node is required;
	has Str:D $.name is required;
	has Node @.args;
	has Bool:D $.negated = False;
}

# === Call node ===

class Call does Node is export {
	has Node $.node is required;
	has Node @.args;
	has @.kwargs;  # list of Pair(Str, Node)
	has Node $.dyn-args;    # *args
	has Node $.dyn-kwargs;  # **kwargs
}

# === Statement nodes ===

class If does Node is export {
	has Node $.test is required;
	has Node @.body;
	has Node @.elif;      # list of If nodes used as elif
	has Node @.else-body;
}

class For does Node is export {
	has Node $.target is required;
	has Node $.iter is required;
	has Node $.filter;    # optional: {% for x in seq if condition %}
	has Node @.body;
	has Node @.else-body;
	has Bool:D $.recursive = False;
}

class Set does Node is export {
	has Str:D $.name is required;
	has Node $.value is required;
}

class SetAttr does Node is export {
	has Str:D $.obj-name is required;
	has Str:D $.attr is required;
	has Node $.value is required;
}

class SetBlock does Node is export {
	has Str:D $.name is required;
	has Node @.body;
	has Node $.filter;
}

class With does Node is export {
	has @.assignments;  # list of Pair(Str, Node)
	has Node @.body;
}

class Block does Node is export {
	has Str:D $.name is required;
	has Node @.body;
	has Bool:D $.scoped = False;
}

class Extends does Node is export {
	has Node $.template is required;
}

class Include does Node is export {
	has Node $.template is required;
	has Bool:D $.ignore-missing = False;
	has Bool:D $.with-context = True;
}

class Import does Node is export {
	has Node $.template is required;
	has Str:D $.name is required;
	has Bool:D $.with-context = False;
}

class FromImport does Node is export {
	has Node $.template is required;
	has @.names;  # list of Str or Pair(Str, Str) for aliases
	has Bool:D $.with-context = False;
}

class Macro does Node is export {
	has Str:D $.name is required;
	has @.params;  # list of Pair(Str, Node?) — name + optional default
	has Node @.body;
}

class CallBlock does Node is export {
	has Node $.call is required;
	has @.params;
	has Node @.body;
}

class FilterBlock does Node is export {
	has Node $.filter is required;
	has Node @.body;
}

class Do does Node is export {
	has Node $.expr is required;
}

class AutoEscape does Node is export {
	has Node $.enabled is required;
	has Node @.body;
}

class Scope does Node is export {
	has Node @.body;
}

class Break does Node is export { }
class Continue does Node is export { }

# === Assignment target ===

class AssignTarget does Node is export {
	has Str @.names;  # single name or tuple unpacking
}

}
