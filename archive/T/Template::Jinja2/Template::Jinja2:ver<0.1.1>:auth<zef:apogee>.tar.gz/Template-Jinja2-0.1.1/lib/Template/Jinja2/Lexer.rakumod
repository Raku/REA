use Template::Jinja2::Exceptions;

module Template::Jinja2::Lexer {

# === Token types ===

enum TokenType is export (
	TOKEN_TEXT		 => 'text',
	TOKEN_RAW		 => 'raw',
	TOKEN_VAR		 => 'variable',
	TOKEN_BLOCK		 => 'block',
	TOKEN_COMMENT	 => 'comment',
	TOKEN_NAME		 => 'name',
	TOKEN_STRING	 => 'string',
	TOKEN_INTEGER	 => 'integer',
	TOKEN_FLOAT		 => 'float',
	TOKEN_OPERATOR	 => 'operator',
	TOKEN_PIPE		 => 'pipe',
	TOKEN_DOT		 => 'dot',
	TOKEN_COMMA		 => 'comma',
	TOKEN_COLON		 => 'colon',
	TOKEN_ASSIGN	 => 'assign',
	TOKEN_LPAREN	 => 'lparen',
	TOKEN_RPAREN	 => 'rparen',
	TOKEN_LBRACKET	 => 'lbracket',
	TOKEN_RBRACKET	 => 'rbracket',
	TOKEN_LBRACE	 => 'lbrace',
	TOKEN_RBRACE	 => 'rbrace',
);

class Token is export {
	has TokenType $.type is required;
	has $.value is required;
	has Str $.tag-name;
	has Bool $.trim-left = False;
	has Bool $.trim-right = False;
	has Bool $.no-lstrip = False;   # {%+ — disable lstrip
	has Bool $.no-trim = False;     # +%} — disable trim_blocks

	method Str(--> Str:D) { "Token({$!type}, {$!value.raku})" }
	method gist(--> Str:D) { self.Str }
}

# === Template grammar ===

grammar TemplateGrammar is export {
	token TOP { <chunk>* }

	proto token chunk { * }
	token chunk:sym<comment>  { \{ "#" $<tl>=[\-|\+]? .*? $<tr>=[\-|\+]? "#" \} }
	regex chunk:sym<rawblock> { \{ \% $<tl>=[\-|\+]? \s* raw \s* $<tr>=[\-|\+]? \% \} $<content>=(.*?) \{ \% $<tl2>=[\-|\+]? \s* endraw \s* $<tr2>=[\-|\+]? \% \} }
	token chunk:sym<variable> { \{ \{ $<tl>=[\-|\+]? \s* <expr-list> \s* $<tr>=[\-|\+]? \} \} }
	token chunk:sym<block>	  { \{ \% $<tl>=[\-|\+]? \s* <!before raw \s* [\-|\+]? \% \}> <tag-name> [\s* <expr-list>]? \s* $<tr>=[\-|\+]? \% \} }
	token chunk:sym<text>	  { <-[{]>+ || \{ <!before [\%|\{|"#"]> }

	token tag-name { <[a..zA..Z_]> <[a..zA..Z0..9_]>* }

	# Expression list: space-separated expression parts
	token expr-list { <expr-part>+ %% \s* }

	proto token expr-part { * }
	token expr-part:sym<string-dq> { \" $<val>=[ [ <-[\"\\]> | \\ . ]* ] \" }
	token expr-part:sym<string-sq> { \' $<val>=[ [ <-[\'\\]> | \\ . ]* ] \' }
	token expr-part:sym<floatdot>   { \d [ \d | _ ]* \. \d [ \d | _ ]* [ <[eE]> <[+\-]>? \d [ \d | _ ]* ]? }
	token expr-part:sym<floatsci>   { \d [ \d | _ ]* <[eE]> <[+\-]>? \d [ \d | _ ]* }
	token expr-part:sym<hexint>    { 0 <[xX]> <[0..9a..fA..F_]>+ }
	token expr-part:sym<octint>    { 0 <[oO]> <[0..7_]>+ }
	token expr-part:sym<binint>    { 0 <[bB]> <[01_]>+ }
	token expr-part:sym<integer>   { \d [ \d | _ ]* }
	token expr-part:sym<name>	   { <[a..zA..Z_]> <[a..zA..Z0..9_]>* }
	token expr-part:sym<==>       { '==' }
	token expr-part:sym<!=>       { '!=' }
	token expr-part:sym«>=»      { '>=' }
	token expr-part:sym«<=»      { '<=' }
	token expr-part:sym<//>      { '//' }
	token expr-part:sym<**>      { '**' }
	token expr-part:sym<~>       { \~ }
	token expr-part:sym<pipe>    { \| }
	token expr-part:sym<dot>     { \. }
	token expr-part:sym<comma>   { \, }
	token expr-part:sym<colon>   { \: }
	token expr-part:sym<lparen>  { \( }
	token expr-part:sym<rparen>  { \) }
	token expr-part:sym<lbracket> { \[ }
	token expr-part:sym<rbracket> { \] }
	token expr-part:sym<lbrace>  { \{ <!before \{> }
	token expr-part:sym<rbrace>  { \} <!before \}> }
	token expr-part:sym<+>       { \+ <!before \s* [\%\}|\}\}]> }
	token expr-part:sym<->       { \- <!before \s* [\%\}|\}\}]> }
	token expr-part:sym<*>       { \* <!before \*> }
	token expr-part:sym</>       { \/ <!before \/> }
	token expr-part:sym<%>       { '%' <!before \}> }
	token expr-part:sym«<»       { '<' <!before \=> }
	token expr-part:sym«>»       { '>' <!before \=> }
	token expr-part:sym<assign>  { \= <!before \=> }
}

# === Actions ===

class TemplateActions is export {
	has Token @.tokens;

	method chunk:sym<text>($/) {
		@!tokens.push: Token.new(:type(TOKEN_TEXT), :value(~$/));
	}

	method chunk:sym<comment>($/) {
		my $tl-str = ~$<tl>;
		my $tr-str = ~$<tr>;
		@!tokens.push: Token.new(:type(TOKEN_COMMENT), :value(''),
			:trim-left($tl-str eq '-'), :trim-right($tr-str eq '-'),
			:no-lstrip($tl-str eq '+'), :no-trim($tr-str eq '+'));
	}

	method chunk:sym<rawblock>($/) {
		my $tl = (~$<tl>) eq '-';
		my $tr = (~$<tr>) eq '-';
		my $tl2 = (~$<tl2>) eq '-';
		my $tr2 = (~$<tr2>) eq '-';
		my $content = ~$<content>;
		$content = $content.subst(/^\s+/, '') if $tr;
		$content = $content.subst(/\s+$/, '') if $tl2;
		@!tokens.push: Token.new(:type(TOKEN_RAW), :value($content),
			:trim-left($tl), :trim-right($tr2),
			:no-lstrip((~$<tl>) eq '+'), :no-trim((~$<tr2>) eq '+'));
	}

	method chunk:sym<variable>($/) {
		my Token @parts = self!collect-expr-parts($<expr-list>);
		my $tl-str = ~$<tl>;
		my $tr-str = ~$<tr>;
		@!tokens.push: Token.new(:type(TOKEN_VAR), :value(@parts),
			:trim-left($tl-str eq '-'), :trim-right($tr-str eq '-'),
			:no-lstrip($tl-str eq '+'), :no-trim($tr-str eq '+'));
	}

	method chunk:sym<block>($/) {
		my Str:D $tag = ~$<tag-name>;
		my Token @parts;
		@parts = self!collect-expr-parts($<expr-list>) if $<expr-list>.defined;
		my $tl-str = ~$<tl>;
		my $tr-str = ~$<tr>;
		@!tokens.push: Token.new(:type(TOKEN_BLOCK), :value(@parts),
			:tag-name($tag), :trim-left($tl-str eq '-'), :trim-right($tr-str eq '-'),
			:no-lstrip($tl-str eq '+'), :no-trim($tr-str eq '+'));
	}

	# --- expr-part action methods (each `make`s a Token) ---

	method expr-part:sym<string-dq>($/) {
		make Token.new(:type(TOKEN_STRING), :value(self!unescape(~$<val>)));
	}
	method expr-part:sym<string-sq>($/) {
		make Token.new(:type(TOKEN_STRING), :value(self!unescape(~$<val>)));
	}
	method expr-part:sym<floatdot>($/) {
		my $s = (~$/).subst('_', '', :g);
		make Token.new(:type(TOKEN_FLOAT), :value($s.Num));
	}
	method expr-part:sym<floatsci>($/) {
		my $s = (~$/).subst('_', '', :g);
		make Token.new(:type(TOKEN_FLOAT), :value($s.Num));
	}
	method expr-part:sym<hexint>($/) {
		my $s = (~$/).substr(2).subst('_', '', :g);
		make Token.new(:type(TOKEN_INTEGER), :value($s.parse-base(16).Int));
	}
	method expr-part:sym<octint>($/) {
		my $s = (~$/).substr(2).subst('_', '', :g);
		make Token.new(:type(TOKEN_INTEGER), :value($s.parse-base(8).Int));
	}
	method expr-part:sym<binint>($/) {
		my $s = (~$/).substr(2).subst('_', '', :g);
		make Token.new(:type(TOKEN_INTEGER), :value($s.parse-base(2).Int));
	}
	method expr-part:sym<integer>($/) {
		my $s = (~$/).subst('_', '', :g);
		make Token.new(:type(TOKEN_INTEGER), :value($s.Int));
	}
	method expr-part:sym<name>($/) {
		make Token.new(:type(TOKEN_NAME), :value(~$/));
	}
	method expr-part:sym<==>($/)  { make Token.new(:type(TOKEN_OPERATOR), :value('==')) }
	method expr-part:sym<!=>($/)  { make Token.new(:type(TOKEN_OPERATOR), :value('!=')) }
	method expr-part:sym«>=»($/)  { make Token.new(:type(TOKEN_OPERATOR), :value('>=')) }
	method expr-part:sym«<=»($/)  { make Token.new(:type(TOKEN_OPERATOR), :value('<=')) }
	method expr-part:sym<//>($/)  { make Token.new(:type(TOKEN_OPERATOR), :value('//')) }
	method expr-part:sym<**>($/)  { make Token.new(:type(TOKEN_OPERATOR), :value('**')) }
	method expr-part:sym<~>($/)   { make Token.new(:type(TOKEN_OPERATOR), :value('~')) }
	method expr-part:sym<+>($/)   { make Token.new(:type(TOKEN_OPERATOR), :value('+')) }
	method expr-part:sym<->($/)   { make Token.new(:type(TOKEN_OPERATOR), :value('-')) }
	method expr-part:sym<*>($/)   { make Token.new(:type(TOKEN_OPERATOR), :value('*')) }
	method expr-part:sym</>($/)   { make Token.new(:type(TOKEN_OPERATOR), :value('/')) }
	method expr-part:sym<%>($/)   { make Token.new(:type(TOKEN_OPERATOR), :value('%')) }
	method expr-part:sym«<»($/)   { make Token.new(:type(TOKEN_OPERATOR), :value('<')) }
	method expr-part:sym«>»($/)   { make Token.new(:type(TOKEN_OPERATOR), :value('>')) }
	method expr-part:sym<pipe>($/)     { make Token.new(:type(TOKEN_PIPE), :value('|')) }
	method expr-part:sym<dot>($/)      { make Token.new(:type(TOKEN_DOT), :value('.')) }
	method expr-part:sym<comma>($/)    { make Token.new(:type(TOKEN_COMMA), :value(',')) }
	method expr-part:sym<colon>($/)    { make Token.new(:type(TOKEN_COLON), :value(':')) }
	method expr-part:sym<lparen>($/)   { make Token.new(:type(TOKEN_LPAREN), :value('(')) }
	method expr-part:sym<rparen>($/)   { make Token.new(:type(TOKEN_RPAREN), :value(')')) }
	method expr-part:sym<lbracket>($/) { make Token.new(:type(TOKEN_LBRACKET), :value('[')) }
	method expr-part:sym<rbracket>($/) { make Token.new(:type(TOKEN_RBRACKET), :value(']')) }
	method expr-part:sym<lbrace>($/)   { make Token.new(:type(TOKEN_LBRACE), :value('{')) }
	method expr-part:sym<rbrace>($/)   { make Token.new(:type(TOKEN_RBRACE), :value('}')) }
	method expr-part:sym<assign>($/)   { make Token.new(:type(TOKEN_ASSIGN), :value('=')) }

	method !collect-expr-parts($expr-list --> List) {
		my Token @parts;
		return @parts unless $expr-list.defined;
		for $expr-list<expr-part>.list -> $part {
			@parts.push: $part.made if $part.made.defined;
		}
		@parts.list;
	}

	method !unescape(Str:D $s --> Str:D) {
		$s.subst('\\n', "\n", :g)
		  .subst('\\t', "\t", :g)
		  .subst('\\r', "\r", :g)
		  .subst("\\'", "'", :g)
		  .subst('\\"', '"', :g)
		  .subst('\\\\', '\\', :g);
	}
}

# === Convenience ===

sub tokenize(Str:D $source, Bool:D :$trim-blocks = False, Bool:D :$lstrip-blocks = False,
	Str:D :$block-start = '{%', Str:D :$block-end = '%}',
	Str:D :$variable-start = '{{', Str:D :$variable-end = '}}',
	Str:D :$comment-start = '{#', Str:D :$comment-end = '#}',
	--> List) is export {

	my $is-default = $block-start eq '{%' && $variable-start eq '{{' && $comment-start eq '{#';

	if $is-default {
		# Fast path: use the compiled grammar for default delimiters
		my TemplateActions $actions .= new;
		my $match = TemplateGrammar.parse($source, :$actions);
		die TemplateSyntaxError.new("Failed to parse template")
			unless $match.defined;
		my @tokens = $actions.tokens;
		return apply-whitespace-trimming(@tokens, :$trim-blocks, :$lstrip-blocks);
	}

	# Custom delimiters: regex-based chunker
	my @tokens = chunker($source, $block-start, $block-end, $variable-start,
		$variable-end, $comment-start, $comment-end);
	apply-whitespace-trimming(@tokens, :$trim-blocks, :$lstrip-blocks);
}

sub parse-expr-parts(Str:D $expr-str --> List) {
	# Parse expression string using the grammar's expr-list rule
	my TemplateActions $actions .= new;
	# Wrap in {{ }} so the grammar can parse it
	my $wrapped = '{{ ' ~ $expr-str ~ ' }}';
	my $match = TemplateGrammar.parse($wrapped, :$actions);
	return () unless $match.defined && $actions.tokens.elems > 0;
	my $tok = $actions.tokens[0];
	$tok.value ~~ Positional ?? $tok.value.list !! ();
}

sub chunker(Str:D $source, Str:D $bs, Str:D $be, Str:D $vs, Str:D $ve,
	Str:D $cs, Str:D $ce --> List) {
	my @tokens;
	my $pos = 0;
	my $len = $source.chars;

	# Precompute lengths
	my $bs-len = $bs.chars;
	my $be-len = $be.chars;
	my $vs-len = $vs.chars;
	my $ve-len = $ve.chars;
	my $cs-len = $cs.chars;
	my $ce-len = $ce.chars;

	while $pos < $len {
		# Find the nearest tag start
		my $comment-pos = $source.index($cs, $pos);
		my $block-pos   = $source.index($bs, $pos);
		my $var-pos     = $source.index($vs, $pos);

		# Find minimum position, preferring longer delimiter at same position
		my @candidates;
		@candidates.push: ('comment',  $comment-pos, $cs-len) if $comment-pos.defined;
		@candidates.push: ('block',    $block-pos,   $bs-len) if $block-pos.defined;
		@candidates.push: ('variable', $var-pos,     $vs-len) if $var-pos.defined;

		# Sort by position, then by delimiter length (longer = more specific wins)
		@candidates = @candidates.sort({ $^a[1] <=> $^b[1] || $^b[2] <=> $^a[2] });

		my $next = $len;
		my $type = '';
		if @candidates.elems > 0 {
			$type = @candidates[0][0];
			$next = @candidates[0][1];
			# If multiple at same position, verify the source actually starts with the delimiter
			if @candidates.elems > 1 && @candidates[1][1] == $next {
				# Prefer longer delimiter
				if @candidates[1][2] > @candidates[0][2]
					&& $source.substr($next, @candidates[1][2]) eq (
						@candidates[1][0] eq 'comment' ?? $cs !!
						@candidates[1][0] eq 'block' ?? $bs !! $vs) {
					$type = @candidates[1][0];
				}
			}
		}

		# Text before the tag (or remaining text if no more tags)
		if $next > $pos {
			@tokens.push: Token.new(:type(TOKEN_TEXT), :value($source.substr($pos, $next - $pos)));
			$pos = $next;
		}

		last if $type eq '';  # no more tags

		given $type {
			when 'comment' {
				my $tag-start = $next;
				my $inner-start = $tag-start + $cs-len;
				my $end-pos = $source.index($ce, $inner-start);
				unless $end-pos.defined {
					die TemplateSyntaxError.new("Unclosed comment tag");
				}
				# Check for trim markers
				my $inner = $source.substr($inner-start, $end-pos - $inner-start);
				my $tl = $inner.chars > 0 && $inner.substr(0, 1) eq any('-', '+') ?? $inner.substr(0, 1) !! '';
				my $tr = $inner.chars > 0 && $inner.substr(*-1, 1) eq any('-', '+') ?? $inner.substr(*-1, 1) !! '';
				@tokens.push: Token.new(:type(TOKEN_COMMENT), :value(''),
					:trim-left($tl eq '-'), :trim-right($tr eq '-'),
					:no-lstrip($tl eq '+'), :no-trim($tr eq '+'));
				$pos = $end-pos + $ce-len;
			}
			when 'block' {
				my $tag-start = $next;
				my $inner-start = $tag-start + $bs-len;
				my $end-pos = $source.index($be, $inner-start);
				unless $end-pos.defined {
					die TemplateSyntaxError.new("Unclosed block tag");
				}
				my $inner = $source.substr($inner-start, $end-pos - $inner-start);

				# Parse trim markers
				my $tl = '';
				my $tr = '';
				if $inner.chars > 0 && $inner.substr(0, 1) eq any('-', '+') {
					$tl = $inner.substr(0, 1);
					$inner = $inner.substr(1);
				}
				if $inner.chars > 0 && $inner.substr(*-1, 1) eq any('-', '+') {
					$tr = $inner.substr(*-1, 1);
					$inner = $inner.substr(0, *-1);
				}
				$inner = $inner.trim;

				# Check for raw block
				if $inner eq 'raw' || $inner ~~ /^ raw \s/ {
					# Find endraw
					my $raw-end-tag = $bs ~ ($tl eq '-' ?? '-' !! '') ~ ' endraw ';
					# Search for endraw with any trim markers
					my $raw-end = $source.index($bs, $end-pos + $be-len);
					my $raw-content-start = $end-pos + $be-len;
					while $raw-end.defined {
						my $re-inner-start = $raw-end + $bs-len;
						my $re-end = $source.index($be, $re-inner-start);
						last unless $re-end.defined;
						my $re-inner = $source.substr($re-inner-start, $re-end - $re-inner-start).trim;
						# Strip trim markers from endraw inner
						$re-inner = $re-inner.subst(/^<[\-+]>/, '').subst(/<[\-+]>$/, '').trim;
						if $re-inner eq 'endraw' {
							my $content = $source.substr($raw-content-start, $raw-end - $raw-content-start);
							# Apply inner trim
							my $endraw-full = $source.substr($re-inner-start, $re-end - $re-inner-start);
							my $tl2 = $endraw-full.chars > 0 && $endraw-full.trim-leading.substr(0,1) eq '-' ?? '-' !! '';
							my $tr2 = $endraw-full.chars > 0 && $endraw-full.trim-trailing.substr(*-1,1) eq any('-', '+') ?? $endraw-full.trim-trailing.substr(*-1,1) !! '';
							$content = $content.subst(/^\s+/, '') if $tr eq '-';
							$content = $content.subst(/\s+$/, '') if $tl2 eq '-';
							@tokens.push: Token.new(:type(TOKEN_RAW), :value($content),
								:trim-left($tl eq '-'), :trim-right($tr2 eq '-'),
								:no-lstrip($tl eq '+'), :no-trim($tr2 eq '+'));
							$pos = $re-end + $be-len;
							last;
						}
						$raw-end = $source.index($bs, $re-end + $be-len);
					}
					next;
				}

				# Parse tag name and expression
				my $tag-name;
				my @parts;
				if $inner ~~ /^ (<[a..zA..Z_]> <[a..zA..Z0..9_]>*) [\s* (.*)]? $/ {
					$tag-name = ~$0;
					my $expr-str = $1.defined ?? (~$1).trim !! '';
					@parts = parse-expr-parts($expr-str) if $expr-str ne '';
				} else {
					die TemplateSyntaxError.new("Invalid block tag: '$inner'");
				}

				@tokens.push: Token.new(:type(TOKEN_BLOCK), :value(@parts),
					:tag-name($tag-name),
					:trim-left($tl eq '-'), :trim-right($tr eq '-'),
					:no-lstrip($tl eq '+'), :no-trim($tr eq '+'));
				$pos = $end-pos + $be-len;
			}
			when 'variable' {
				my $tag-start = $next;
				my $inner-start = $tag-start + $vs-len;
				my $end-pos = $source.index($ve, $inner-start);
				unless $end-pos.defined {
					die TemplateSyntaxError.new("Unclosed variable tag");
				}
				my $inner = $source.substr($inner-start, $end-pos - $inner-start);

				my $tl = '';
				my $tr = '';
				if $inner.chars > 0 && $inner.substr(0, 1) eq any('-', '+') {
					$tl = $inner.substr(0, 1);
					$inner = $inner.substr(1);
				}
				if $inner.chars > 0 && $inner.substr(*-1, 1) eq any('-', '+') {
					$tr = $inner.substr(*-1, 1);
					$inner = $inner.substr(0, *-1);
				}
				$inner = $inner.trim;

				my @parts = parse-expr-parts($inner);
				@tokens.push: Token.new(:type(TOKEN_VAR), :value(@parts),
					:trim-left($tl eq '-'), :trim-right($tr eq '-'),
					:no-lstrip($tl eq '+'), :no-trim($tr eq '+'));
				$pos = $end-pos + $ve-len;
			}
		}
	}

	# Remaining text
	if $pos < $len {
		@tokens.push: Token.new(:type(TOKEN_TEXT), :value($source.substr($pos)));
	}

	@tokens;
}

sub apply-whitespace-trimming(@input-tokens, Bool:D :$trim-blocks, Bool:D :$lstrip-blocks --> List) {
	# Work with a mutable copy
	my @tokens = @input-tokens.Array;

	# First pass: apply right-trims and trim_blocks to the NEXT text token
	for @tokens.kv -> $i, $tok {
		next if $tok.type === TOKEN_TEXT;

		# Right trim: strip leading whitespace from next text token
		if $tok.trim-right && $i + 1 < @tokens.elems && @tokens[$i + 1].type === TOKEN_TEXT {
			my $text = @tokens[$i + 1].value.subst(/^\s+/, '');
			@tokens[$i + 1] = Token.new(:type(TOKEN_TEXT), :value($text),
				:trim-left(@tokens[$i + 1].trim-left),
				:trim-right(@tokens[$i + 1].trim-right));
		}

		# trim_blocks: after block tags, strip the first newline (unless +% disables it)
		if $trim-blocks && ($tok.type === TOKEN_BLOCK || $tok.type === TOKEN_COMMENT)
			&& !$tok.trim-right && !$tok.no-trim
			&& $i + 1 < @tokens.elems && @tokens[$i + 1].type === TOKEN_TEXT {
			my $text = @tokens[$i + 1].value.subst(/^\n/, '');
			@tokens[$i + 1] = Token.new(:type(TOKEN_TEXT), :value($text),
				:trim-left(@tokens[$i + 1].trim-left),
				:trim-right(@tokens[$i + 1].trim-right));
		}
	}

	# Second pass: apply left-trims and lstrip_blocks to the PREVIOUS text token, and filter comments
	my @result;
	my $line-has-output = False;  # track if non-whitespace-text tokens appear on current line
	for @tokens -> $tok {
		# Left trim: strip trailing whitespace from previous text token
		if $tok.trim-left && @result.elems > 0 && @result[*-1].type === TOKEN_TEXT {
			my $text = @result[*-1].value.subst(/\s+$/, '');
			@result[*-1] = Token.new(:type(TOKEN_TEXT), :value($text));
		}

		# lstrip_blocks: strip leading whitespace on the line before block/comment tags
		# Only apply when the block tag is at the start of a line (only whitespace before it)
		if $lstrip-blocks && ($tok.type === TOKEN_BLOCK || $tok.type === TOKEN_COMMENT)
			&& !$tok.no-lstrip && !$line-has-output
			&& @result.elems > 0 && @result[*-1].type === TOKEN_TEXT {
			my $text = @result[*-1].value;
			my $last-nl = $text.rindex("\n");
			my $line = $last-nl.defined ?? $text.substr($last-nl + 1) !! $text;
			if $line ~~ /^ \h* $/ {
				$text = $last-nl.defined ?? $text.substr(0, $last-nl + 1) !! '';
				@result[*-1] = Token.new(:type(TOKEN_TEXT), :value($text));
			}
		}

		# Track if we've seen output-producing tokens on the current line
		if $tok.type === TOKEN_TEXT {
			if $tok.value.contains("\n") {
				$line-has-output = False;  # reset at newline
			}
			# Text with non-whitespace content counts as output
			my $last-nl = $tok.value.rindex("\n");
			my $current-line = $last-nl.defined ?? $tok.value.substr($last-nl + 1) !! $tok.value;
			$line-has-output = True if $current-line ~~ /\S/;
		} elsif $tok.type === TOKEN_VAR || $tok.type === TOKEN_RAW {
			$line-has-output = True;
		}
		# Block/comment tokens don't count as output for lstrip purposes

		# Skip comment tokens
		next if $tok.type === TOKEN_COMMENT;

		@result.push: $tok;
	}

	# Remove empty text tokens
	@result.grep({ $_.type !== TOKEN_TEXT || $_.value ne '' }).list;
}
}
