use Template::Jinja2::AST;
use Template::Jinja2::Context;
use Template::Jinja2::Exceptions;

module Template::Jinja2::Renderer {

my $LOOP-SENTINEL = class LoopSentinel { }.new;

# === Loop context object (defined before Renderer so it can reference it) ===

class LoopContext is export {
	has %.loop;
	has $.last-changed is rw = $LOOP-SENTINEL;
	has &!recurse;

	method set-recurse(&fn) { &!recurse = &fn }

	method get(Str:D $attr --> Any) {
		return sub (*@args) { self!cycle(|@args) } if $attr eq 'cycle';
		return sub (*@args) { self!changed(|@args) } if $attr eq 'changed';
		%!loop{$attr};
	}

	# Make LoopContext callable for recursive loops: loop(items)
	method call(@items --> Str:D) {
		die TemplateRuntimeError.new("loop is not recursive") unless &!recurse.defined;
		&!recurse(@items);
	}

	method !cycle(*@args --> Any) {
		my $idx = %!loop<index0> % @args.elems;
		@args[$idx];
	}

	method !changed(*@args --> Bool:D) {
		my $current = @args.elems == 1 ?? @args[0] !! @args;
		my $result = !self!vals-equal($.last-changed, $current);
		$.last-changed = $current;
		$result;
	}

	method !vals-equal($a, $b --> Bool:D) {
		return True if !$a.defined && !$b.defined;
		return False unless $a.defined && $b.defined;
		if $a ~~ Numeric && $b ~~ Numeric { return $a == $b }
		~$a eq ~$b;
	}
}

class Renderer is export {
	has %.filters;
	has %.tests;
	has &.loader;
	has Bool:D $.autoescape = False;
	has %.block-chains;  # block-name => list of Node[] from child to base

	method render(TemplateNode $tmpl, Context $ctx --> Str:D) {
		# Check for extends
		my $extends-node = $tmpl.body.first(* ~~ Extends);
		if $extends-node.defined {
			return self!render-with-inheritance($tmpl, $extends-node, $ctx);
		}
		self!render-body($tmpl.body, $ctx);
	}

	method !render-with-inheritance(TemplateNode $child, Extends $extends-node, Context $ctx --> Str:D) {
		# Collect block definitions from child template
		my %child-blocks = self!collect-blocks($child.body);

		# Build block chains: child's block prepended to any existing chain
		my %chains = %!block-chains;
		for %child-blocks.kv -> $name, $body {
			if %chains{$name}:exists {
				%chains{$name} = [|%chains{$name}, $body];
			} else {
				%chains{$name} = [$body];
			}
		}

		# Load parent template
		my $parent-name = self!eval($extends-node.template, $ctx);
		my $parent-source = &!loader($parent-name);
		die TemplateNotFoundError.new("Parent template '$parent-name' not found")
			unless $parent-source.defined;

		use Template::Jinja2::Parser;
		my $parent-ast = parse($parent-source);

		# Render parent with block chains
		my $parent-renderer = Renderer.new(
			filters => %!filters,
			tests => %!tests,
			loader => &!loader,
			autoescape => $!autoescape,
			block-chains => %chains,
		);
		$parent-renderer.render($parent-ast, $ctx);
	}

	method !collect-blocks(@body --> Hash) {
		my %blocks;
		for @body -> $node {
			if $node ~~ Block {
				%blocks{$node.name} = $node.body;
			}
			# Also collect from nested structures (if/for/etc.)
			self!collect-blocks-deep($node, %blocks);
		}
		%blocks;
	}

	method !collect-blocks-deep(Node $node, %blocks) {
		given $node {
			when If {
				for $node.body -> $n { self!collect-blocks-deep($n, %blocks) }
				for $node.elif -> $n { self!collect-blocks-deep($n, %blocks) }
				for $node.else-body -> $n { self!collect-blocks-deep($n, %blocks) }
			}
			when For {
				for $node.body -> $n { self!collect-blocks-deep($n, %blocks) }
			}
			when Block {
				%blocks{$node.name} = $node.body;
				for $node.body -> $n { self!collect-blocks-deep($n, %blocks) }
			}
			default { }
		}
	}

	method !render-body(@body, Context $ctx --> Str:D) {
		my $buf = '';
		for @body -> $node {
			$buf ~= self!render-node($node, $ctx);
		}
		$buf;
	}

	method !render-node(Node $node, Context $ctx --> Str:D) {
		given $node {
			when Text     { $node.value }
			when Raw      { $node.value }
			when Output   { self!render-output($node, $ctx) }
			when If       { self!render-if($node, $ctx) }
			when For      { self!render-for($node, $ctx) }
			when Set      { self!render-set($node, $ctx); '' }
			when SetAttr  { self!render-set-attr($node, $ctx); '' }
			when SetBlock { self!render-set-block($node, $ctx); '' }
			when With     { self!render-with($node, $ctx) }
			when Block    { self!render-block($node, $ctx) }
			when Macro    { self!register-macro($node, $ctx); '' }
			when CallBlock { self!render-call-block($node, $ctx) }
			when Do       { self!eval($node.expr, $ctx); '' }
			when FilterBlock { self!render-filter-block($node, $ctx) }
			when Include  { self!render-include($node, $ctx) }
			when Break    { die LoopBreak.new }
			when Continue { die LoopContinue.new }
			when Extends  { '' }  # handled at template level
			default       { '' }
		}
	}

	method !render-output(Output $node, Context $ctx --> Str:D) {
		my $value = self!eval($node.expr, $ctx);
		my $str = self!to-str($value);
		# Autoescape: escape unless the value is SafeString or expression ends with |safe/|escape
		if $!autoescape && !($value ~~ SafeString) && !self!has-safe-filter($node.expr) {
			$str = self!html-escape($str);
		}
		$str;
	}

	method !has-safe-filter(Node $node --> Bool:D) {
		given $node {
			when Filter { $node.name eq 'safe' || $node.name eq 'e' || $node.name eq 'escape' }
			default { False }
		}
	}

	method !html-escape(Str:D $s --> Str:D) {
		$s.trans(['&', '<', '>', '"', "'"] => ['&amp;', '&lt;', '&gt;', '&#34;', '&#39;']);
	}

	# --- Block (with inheritance support) ---

	method !render-block(Block $node, Context $ctx --> Str:D) {
		# Block chain: [child_body, mid_body, ...] with base block's body as fallback
		my @chain;
		if (%!block-chains{$node.name}:exists) {
			@chain = %!block-chains{$node.name}.list;
		}

		# The body to render is the first in chain (deepest child), or the block default
		my @body-to-render = @chain.elems > 0 ?? @chain[0].list !! $node.body;

		# Build super chain: each level's super() renders the next level
		# chain[0] = child, chain[1] = mid, ..., base = $node.body
		my @super-chain = @chain.elems > 1 ?? @chain[1..*] !! [];
		my @base-body = $node.body;

		self!render-block-with-super(@body-to-render, @super-chain, @base-body, $ctx);
	}

	method !render-block-with-super(@body, @super-chain, @base-body, Context $ctx --> Str:D) {
		my $renderer = self;
		my @next-body = @super-chain.elems > 0 ?? @super-chain[0].list !! @base-body;
		my @remaining-chain = @super-chain.elems > 1 ?? @super-chain[1..*] !! [];

		$ctx.push-scope({});
		$ctx.set('super', sub () {
			$renderer!Renderer::render-block-with-super(@next-body, @remaining-chain, @base-body, $ctx);
		});
		my $result = self!render-body(@body, $ctx);
		$ctx.pop-scope;
		$result;
	}

	# --- If ---

	method !render-if(If $node, Context $ctx --> Str:D) {
		if self!is-truthy(self!eval($node.test, $ctx)) {
			return self!render-body($node.body, $ctx);
		}
		for $node.elif -> $elif {
			if self!is-truthy(self!eval($elif.test, $ctx)) {
				return self!render-body($elif.body, $ctx);
			}
		}
		if $node.else-body.elems > 0 {
			return self!render-body($node.else-body, $ctx);
		}
		'';
	}

	# --- For ---

	method !render-for(For $node, Context $ctx --> Str:D) {
		my $iterable = self!eval($node.iter, $ctx);
		my @items = self!to-list($iterable);

		# Apply for-loop filter: {% for x in items if condition %}
		if $node.filter.defined {
			@items = @items.grep(-> $item {
				$ctx.push-scope({});
				self!assign-target($node.target, $item, $ctx);
				my $result = self!is-truthy(self!eval($node.filter, $ctx));
				$ctx.pop-scope;
				$result;
			}).list;
		}

		if @items.elems == 0 {
			return self!render-body($node.else-body, $ctx) if $node.else-body.elems > 0;
			return '';
		}

		self!render-for-items($node, @items, $ctx, 0);
	}

	method !render-for-items(For $node, @input-items, Context $ctx, Int:D $depth --> Str:D) {
		# Apply for-loop filter on recursive re-entry
		my @items = @input-items;
		if $node.filter.defined && $depth > 0 {
			@items = @items.grep(-> $item {
				$ctx.push-scope({});
				self!assign-target($node.target, $item, $ctx);
				my $result = self!is-truthy(self!eval($node.filter, $ctx));
				$ctx.pop-scope;
				$result;
			}).list;
		}

		if @items.elems == 0 {
			return self!render-body($node.else-body, $ctx) if $node.else-body.elems > 0;
			return '';
		}

		my $buf = '';
		my $len = @items.elems;
		my $prev-item = Any;
		my $renderer = self;
		my $for-node = $node;
		my $last-changed = $LOOP-SENTINEL;

		for @items.kv -> $idx, $item {
			$ctx.push-scope({});

			# Set loop variable
			my %loop = (
				index    => $idx + 1,
				index0   => $idx,
				revindex => $len - $idx,
				revindex0 => $len - $idx - 1,
				first    => $idx == 0,
				last     => $idx == $len - 1,
				length   => $len,
				previtem => $prev-item,
				nextitem => ($idx + 1 < $len ?? @items[$idx + 1] !! Any),
				depth    => $depth + 1,
				depth0   => $depth,
			);

			# Build a loop object with cycle/changed methods, sharing changed state
			my $loop-obj = LoopContext.new(:%loop, :$last-changed);

			# For recursive loops, make loop() callable
			if $node.recursive {
				$loop-obj.set-recurse(sub (@new-items) {
					$renderer!Renderer::render-for-items($for-node, @new-items, $ctx, $depth + 1);
				});
			}

			$ctx.set('loop', $loop-obj);

			# Set target variable(s)
			self!assign-target($node.target, $item, $ctx);

			my $broke = False;
			try {
				$buf ~= self!render-body($node.body, $ctx);
				CATCH {
					when LoopBreak { $broke = True }
					when LoopContinue { }  # just skip rest of body
				}
			}
			$last-changed = $loop-obj.last-changed;
			$prev-item = $item;
			$ctx.pop-scope;
			last if $broke;
		}
		$buf;
	}

	method !assign-target(Node $target, $value, Context $ctx) {
		given $target {
			when Name {
				$ctx.set($target.name, $value);
			}
			when TupleLiteral {
				my @values = self!to-list($value);
				for $target.elements.kv -> $i, $elem {
					self!assign-target($elem, @values[$i], $ctx);
				}
			}
		}
	}

	# --- Set ---

	method !render-set(Set $node, Context $ctx) {
		my $value = self!eval($node.value, $ctx);
		$ctx.set($node.name, $value);
	}

	method !render-set-attr(SetAttr $node, Context $ctx) {
		my $obj = $ctx.resolve($node.obj-name);
		my $value;
		if $node.value ~~ SetBlock {
			$value = self!render-body($node.value.body, $ctx);
			if $node.value.filter.defined {
				$value = self!apply-set-block-filter($node.value.filter, $value, $ctx);
			}
		} else {
			$value = self!eval($node.value, $ctx);
		}
		if $obj.can('set') {
			$obj.set($node.attr, $value);
		} elsif $obj ~~ Associative {
			$obj{$node.attr} = $value;
		} else {
			die TemplateRuntimeError.new("Cannot set attribute on non-namespace object");
		}
	}

	method !render-set-block(SetBlock $node, Context $ctx) {
		my $value = self!render-body($node.body, $ctx);
		# Apply filter chain if present
		if $node.filter.defined {
			$value = self!apply-set-block-filter($node.filter, $value, $ctx);
		}
		# In autoescape mode, set block content is pre-escaped, mark as safe
		$value = SafeString.new(:$value) if $!autoescape;
		$ctx.set($node.name, $value);
	}

	method !apply-set-block-filter(Node $filter-node, $value, Context $ctx) {
		# For set block filters, the AST is Filter(Filter(...Filter(Name(var), f1), f2)..., fN)
		# The innermost Name is the variable placeholder — we substitute $value for it
		given $filter-node {
			when Filter {
				my $inner-value = self!apply-set-block-filter($filter-node.node, $value, $ctx);
				my @args = $filter-node.args.map({ self!eval($_, $ctx) });
				my %kwargs;
				for $filter-node.kwargs -> $pair {
					%kwargs{$pair.key} = self!eval($pair.value, $ctx);
				}
				self!call-filter($filter-node.name, $inner-value, @args, $ctx, :%kwargs);
			}
			when Name {
				# This is the placeholder — return the block content
				$value;
			}
			default { $value }
		}
	}

	# --- With ---

	method !render-with(With $node, Context $ctx --> Str:D) {
		# Evaluate all values in the OUTER scope first, then push new scope
		my @evaluated;
		for $node.assignments -> $pair {
			@evaluated.push: $pair.key => self!eval($pair.value, $ctx);
		}
		$ctx.push-scope({});
		for @evaluated -> $pair {
			$ctx.set($pair.key, $pair.value);
		}
		my $result = self!render-body($node.body, $ctx);
		$ctx.pop-scope;
		$result;
	}

	# --- Macro ---

	method !register-macro(Macro $node, Context $ctx) {
		my $macro-node = $node;
		my $renderer = self;
		my $closure-ctx = $ctx;
		$ctx.set($node.name, sub (*@args, *%kwargs) {
			my %scope;
			for $macro-node.params.kv -> $i, $param {
				my $name = $param.key;
				if $i < @args.elems {
					%scope{$name} = @args[$i];
				} elsif %kwargs{$name}:exists {
					%scope{$name} = %kwargs{$name};
				} elsif $name eq 'caller' && $closure-ctx.is-defined('caller') {
					# Special: pick up caller from call block context
					%scope{$name} = $closure-ctx.resolve('caller');
				} elsif $param.value.defined {
					%scope{$name} = $renderer!Renderer::eval($param.value, $closure-ctx);
				} else {
					%scope{$name} = Any;
				}
			}
			%scope<varargs> = @args[$macro-node.params.elems ..^ @args.elems].list
				if @args.elems > $macro-node.params.elems;
			%scope<kwargs> = %kwargs;
			$closure-ctx.push-scope(%scope);
			my $result = $renderer!Renderer::render-body($macro-node.body, $closure-ctx);
			$closure-ctx.pop-scope;
			$result;
		});
	}

	# --- Call block ---

	method !render-call-block(CallBlock $node, Context $ctx --> Str:D) {
		my $renderer = self;
		my $call-body = $node.body;
		my @call-params = $node.params;

		# Create the caller() function from the call block's body
		my $caller-fn = sub (*@args, *%kwargs) {
			$ctx.push-scope({});
			# Bind call block params to args
			for @call-params.kv -> $i, $param {
				if $i < @args.elems {
					$ctx.set(~$param, @args[$i]);
				}
			}
			my $result = $renderer!Renderer::render-body($call-body, $ctx);
			$ctx.pop-scope;
			$result;
		};

		# Set caller in context, then evaluate the call expression
		$ctx.push-scope({ caller => $caller-fn });
		my $result = self!to-str(self!eval($node.call, $ctx));
		$ctx.pop-scope;
		$result;
	}

	# --- Filter block ---

	method !render-filter-block(FilterBlock $node, Context $ctx --> Str:D) {
		my $content = self!render-body($node.body, $ctx);
		# The filter node should be a Name or Filter chain
		self!apply-filter-node($node.filter, $content, $ctx);
	}

	method !apply-filter-node(Node $filter-node, $value, Context $ctx --> Str:D) {
		given $filter-node {
			when Name {
				self!to-str(self!call-filter($filter-node.name, $value, [], $ctx));
			}
			when Filter {
				# Recursively apply inner filters first
				my $inner-value = self!apply-filter-node($filter-node.node, $value, $ctx);
				my @args = $filter-node.args.map({ self!eval($_, $ctx) });
				my %kwargs;
				for $filter-node.kwargs -> $pair {
					%kwargs{$pair.key} = self!eval($pair.value, $ctx);
				}
				self!to-str(self!call-filter($filter-node.name, $inner-value, @args, $ctx, :%kwargs));
			}
			default { self!to-str($value) }
		}
	}

	# --- Include ---

	method !render-include(Include $node, Context $ctx --> Str:D) {
		my $template-name = self!eval($node.template, $ctx);
		if &!loader.defined {
			my $source;
			try {
				$source = &!loader($template-name);
				CATCH {
					when TemplateNotFoundError {
						$source = Str;
					}
				}
			}
			if $source.defined {
				use Template::Jinja2::Parser;
				my $tmpl = parse($source);
				return self.render($tmpl, $ctx);
			}
		}
		if $node.ignore-missing {
			return '';
		}
		die TemplateNotFoundError.new("Template '$template-name' not found");
	}

	# === Expression evaluation ===

	method !eval(Node $node, Context $ctx --> Any) {
		given $node {
			when StringLiteral  { $node.value }
			when IntegerLiteral { $node.value }
			when FloatLiteral   { $node.value }
			when BoolLiteral    { $node.value }
			when NoneLiteral    { JINJA-NONE }
			when Name           { $ctx.resolve($node.name) }
			when GetAttr        { self!eval-getattr($node, $ctx) }
			when GetItem        { self!eval-getitem($node, $ctx) }
			when Slice          { self!eval-slice($node, $ctx) }
			when BinOp          { self!eval-binop($node, $ctx) }
			when UnaryOp        { self!eval-unaryop($node, $ctx) }
			when Compare        { self!eval-compare($node, $ctx) }
			when And            { self!is-truthy(self!eval($node.left, $ctx)) ?? self!eval($node.right, $ctx) !! self!eval($node.left, $ctx) }
			when Or             { self!is-truthy(self!eval($node.left, $ctx)) ?? self!eval($node.left, $ctx) !! self!eval($node.right, $ctx) }
			when Not            { !self!is-truthy(self!eval($node.operand, $ctx)) }
			when Concat         { self!to-str(self!eval($node.left, $ctx)) ~ self!to-str(self!eval($node.right, $ctx)) }
			when Conditional    { self!eval-conditional($node, $ctx) }
			when Filter         { self!eval-filter($node, $ctx) }
			when TestExpr       { self!eval-test($node, $ctx) }
			when Call           { self!eval-call($node, $ctx) }
			when ListLiteral    { $node.elements.map({ self!eval($_, $ctx) }).list }
			when TupleLiteral   { JinjaTuple.new(items => $node.elements.map({ self!eval($_, $ctx) }).list) }
			when HashLiteral    { self!eval-hash($node, $ctx) }
			default             { Any }
		}
	}

	method !eval-getattr(GetAttr $node, Context $ctx --> Any) {
		my $obj = self!eval($node.node, $ctx);
		return Any unless $obj.defined;

		# Try hash-like access first
		if $obj ~~ Associative && ($obj{$node.attr}:exists) {
			return $obj{$node.attr};
		}

		# Try LoopContext
		if $obj ~~ LoopContext {
			return $obj.get($node.attr);
		}

		# Try Namespace
		if $obj.can('get') && $obj.^name.contains('Namespace') {
			return $obj.get($node.attr);
		}

		# Try method call
		if $obj.can($node.attr) {
			return $obj."$node.attr"();
		}

		Any;
	}

	method !eval-getitem(GetItem $node, Context $ctx --> Any) {
		my $obj = self!eval($node.node, $ctx);
		my $index = self!eval($node.index, $ctx);
		return Any unless $obj.defined;

		if $obj ~~ Positional && $index ~~ Int {
			my $idx = $index < 0 ?? $obj.elems + $index !! $index;
			return ($idx >= 0 && $idx < $obj.elems) ?? $obj[$idx] !! Any;
		}
		if $obj ~~ Associative {
			return $obj{$index};
		}
		if $obj ~~ Str && $index ~~ Int {
			my $idx = $index < 0 ?? $obj.chars + $index !! $index;
			return ($idx >= 0 && $idx < $obj.chars) ?? $obj.substr($idx, 1) !! Any;
		}
		Any;
	}

	method !eval-slice(Slice $node, Context $ctx --> Any) {
		my $obj = self!eval($node.node, $ctx);
		return Any unless $obj.defined;

		my @items = $obj ~~ Str ?? $obj.comb !! $obj.list;
		my $len = @items.elems;

		my $start = $node.start.defined ?? self!eval($node.start, $ctx) !! Any;
		my $stop  = $node.stop.defined  ?? self!eval($node.stop, $ctx)  !! Any;
		my $step  = $node.step.defined  ?? self!eval($node.step, $ctx)  !! Any;

		# Python slice semantics
		my $s = $step // 1;
		my $a;
		my $b;

		if $s > 0 {
			$a = $start.defined ?? ($start < 0 ?? max(0, $len + $start) !! min($start, $len)) !! 0;
			$b = $stop.defined  ?? ($stop < 0  ?? max(0, $len + $stop)  !! min($stop, $len))  !! $len;
		} else {
			$a = $start.defined ?? ($start < 0 ?? max(-1, $len + $start) !! min($start, $len - 1)) !! $len - 1;
			$b = $stop.defined  ?? ($stop < 0  ?? max(-1, $len + $stop)  !! min($stop, $len - 1))  !! -1;
		}

		my @result;
		if $s > 0 {
			my $i = $a;
			while $i < $b { @result.push: @items[$i]; $i += $s }
		} else {
			my $i = $a;
			while $i > $b { @result.push: @items[$i]; $i += $s }
		}

		$obj ~~ Str ?? @result.join !! @result.list;
	}

	method !eval-binop(BinOp $node, Context $ctx --> Any) {
		my $left = self!eval($node.left, $ctx);
		my $right = self!eval($node.right, $ctx);
		given $node.op {
			when '+' {
				if $left ~~ Str || $right ~~ Str {
					return ($left // 0) + ($right // 0) if $left ~~ Numeric && $right ~~ Numeric;
				}
				($left // 0) + ($right // 0);
			}
			when '-'  { ($left // 0) - ($right // 0) }
			when '*'  {
				if $left ~~ Str && $right ~~ Int { $left x $right }
				elsif $left ~~ Positional && $right ~~ Int { (|$left xx $right).list }
				else { ($left // 0) * ($right // 0) }
			}
			when '/'  { ($left // 0) / ($right // 1) }
			when '//' { (($left // 0) / ($right // 1)).floor }
			when '%'  { ($left // 0) % ($right // 1) }
			when '**' { ($left // 0) ** ($right // 0) }
			default   { Any }
		}
	}

	method !eval-unaryop(UnaryOp $node, Context $ctx --> Any) {
		my $val = self!eval($node.operand, $ctx);
		given $node.op {
			when '-' { -($val // 0) }
			when '+' { +($val // 0) }
			default  { $val }
		}
	}

	method !eval-compare(Compare $node, Context $ctx --> Bool:D) {
		my $left = self!eval($node.left, $ctx);
		my $right = self!eval($node.right, $ctx);
		given $node.op {
			when '==' { self!jinja-eq($left, $right) }
			when '!=' { !self!jinja-eq($left, $right) }
			when '<'  { self!jinja-cmp($left, $right) < 0 }
			when '>'  { self!jinja-cmp($left, $right) > 0 }
			when '<=' { self!jinja-cmp($left, $right) <= 0 }
			when '>=' { self!jinja-cmp($left, $right) >= 0 }
			when 'in' { self!jinja-in($left, $right) }
			when 'notin' { !self!jinja-in($left, $right) }
			default { False }
		}
	}

	method !eval-conditional(Conditional $node, Context $ctx --> Any) {
		if self!is-truthy(self!eval($node.test, $ctx)) {
			self!eval($node.true-expr, $ctx);
		} elsif $node.false-expr.defined {
			self!eval($node.false-expr, $ctx);
		} else {
			Any;
		}
	}

	method !eval-filter(Filter $node, Context $ctx --> Any) {
		my $value = self!eval($node.node, $ctx);
		my @args = $node.args.map({ self!eval($_, $ctx) });
		my %kwargs;
		for $node.kwargs -> $pair {
			%kwargs{$pair.key} = self!eval($pair.value, $ctx);
		}
		self!call-filter($node.name, $value, @args, $ctx, :%kwargs);
	}

	method !eval-test(TestExpr $node, Context $ctx --> Bool:D) {
		# Special handling for defined/undefined — check if name exists in context
		if $node.name eq 'defined' | 'undefined' {
			my $is-def;
			if $node.node ~~ Name {
				$is-def = $ctx.is-defined($node.node.name);
			} elsif $node.node ~~ NoneLiteral || $node.node ~~ StringLiteral
				|| $node.node ~~ IntegerLiteral || $node.node ~~ FloatLiteral
				|| $node.node ~~ BoolLiteral || $node.node ~~ ListLiteral
				|| $node.node ~~ HashLiteral {
				# Literals are always defined
				$is-def = True;
			} else {
				# For attribute access, subscript, etc. — evaluate and check
				my $val = self!eval($node.node, $ctx);
				$is-def = $val.defined;
			}
			my $result = $node.name eq 'defined' ?? $is-def !! !$is-def;
			return $node.negated ?? !$result !! $result;
		}

		my $value = self!eval($node.node, $ctx);
		# Convert UNDEFINED sentinel to Any for test evaluation
		$value = Any if $value ~~ Undefined;
		my @args = $node.args.map({ self!eval($_, $ctx) });
		my $result = self!call-test($node.name, $value, @args);
		$node.negated ?? !$result !! $result;
	}

	method !eval-call(Call $node, Context $ctx --> Any) {
		my $callable = self!eval($node.node, $ctx);
		my @args = $node.args.map({ self!eval($_, $ctx) });
		my %kwargs;
		for $node.kwargs -> $pair {
			%kwargs{$pair.key} = self!eval($pair.value, $ctx);
		}

		if $callable ~~ LoopContext {
			# Recursive loop call: loop(items)
			return $callable.call(@args[0] ~~ Positional ?? @args[0].list !! @args);
		} elsif $callable ~~ Callable {
			if %kwargs.elems > 0 {
				$callable(|@args, |%kwargs);
			} else {
				$callable(|@args);
			}
		} else {
			die TemplateRuntimeError.new("'{$node.node.gist // 'object'}' is not callable");
		}
	}

	method !eval-hash(HashLiteral $node, Context $ctx --> Hash) {
		my %h;
		for $node.pairs -> $pair {
			my $key = self!eval($pair.key, $ctx);
			my $value = self!eval($pair.value, $ctx);
			%h{$key} = $value;
		}
		%h;
	}

	# === Filter dispatch ===

	method !call-filter(Str:D $name, $value, @args, Context $ctx, :%kwargs --> Any) {
		if %!filters{$name}:exists {
			return %!filters{$name}($value, |@args, |%kwargs);
		}
		die TemplateRuntimeError.new("No filter named '$name'");
	}

	# === Test dispatch ===

	method !call-test(Str:D $name, $value, @args --> Bool:D) {
		if %!tests{$name}:exists {
			return so %!tests{$name}($value, |@args);
		}
		die TemplateRuntimeError.new("No test named '$name'");
	}

	# === Truthiness (Python semantics) ===

	method !is-truthy($value --> Bool:D) {
		return False if $value ~~ Undefined;
		return False if $value ~~ JinjaNone;
		return False unless $value.defined;
		given $value {
			when Bool { $value }
			when Numeric { $value != 0 }
			when Str { $value ne '' }
			when Positional { $value.elems > 0 }
			when Associative { $value.elems > 0 }
			default { True }
		}
	}

	# === String conversion (Python str() semantics) ===

	method !to-str($value --> Str:D) {
		return '' if $value ~~ Undefined;
		return 'None' if $value ~~ JinjaNone;
		return $value.value if $value ~~ SafeString;
		return '' unless $value.defined;
		given $value {
			when Bool { $value ?? 'True' !! 'False' }
			when Str { $value }
			when Num {
				my $s = ~$value;
				$s ~= '.0' unless $s.contains('.') || $s.contains('e') || $s.contains('E');
				$s;
			}
			when Numeric { ~$value }
			when JinjaTuple {
				my @items = $value.list;
				if @items.elems == 1 {
					'(' ~ self!to-str-repr(@items[0]) ~ ',)';
				} else {
					'(' ~ @items.map({ self!to-str-repr($_) }).join(', ') ~ ')';
				}
			}
			when Positional { '[' ~ $value.map({ self!to-str-repr($_) }).join(', ') ~ ']' }
			when Associative { '{' ~ $value.sort.map({ self!to-str-repr(.key) ~ ': ' ~ self!to-str-repr(.value) }).join(', ') ~ '}' }
			default { ~$value }
		}
	}

	method !to-str-repr($value --> Str:D) {
		return 'None' if $value ~~ JinjaNone;
		return 'None' unless $value.defined;
		given $value {
			when Bool { $value ?? 'True' !! 'False' }
			when Str { "'" ~ $value ~ "'" }
			when Numeric { ~$value }
			when JinjaTuple {
				my @items = $value.list;
				if @items.elems == 1 {
					'(' ~ self!to-str-repr(@items[0]) ~ ',)';
				} else {
					'(' ~ @items.map({ self!to-str-repr($_) }).join(', ') ~ ')';
				}
			}
			when Positional { '[' ~ $value.map({ self!to-str-repr($_) }).join(', ') ~ ']' }
			when Associative { '{' ~ $value.sort.map({ self!to-str-repr(.key) ~ ': ' ~ self!to-str-repr(.value) }).join(', ') ~ '}' }
			default { ~$value }
		}
	}

	# === Comparison helpers ===

	method !jinja-eq($a, $b --> Bool:D) {
		return True if !$a.defined && !$b.defined;
		return False unless $a.defined && $b.defined;
		if $a ~~ Numeric && $b ~~ Numeric { return $a == $b }
		~$a eq ~$b;
	}

	method !jinja-cmp($a, $b --> Int:D) {
		if $a ~~ Numeric && $b ~~ Numeric { return ($a <=> $b).Int }
		(~$a cmp ~$b).Int;
	}

	method !jinja-in($needle, $haystack --> Bool:D) {
		return False unless $haystack.defined;
		if $haystack ~~ Str { return $haystack.contains(~$needle) }
		if $haystack ~~ Positional {
			for $haystack.list -> $item {
				return True if self!jinja-eq($needle, $item);
			}
			return False;
		}
		if $haystack ~~ Associative {
			return $haystack{$needle}:exists;
		}
		False;
	}

	method !to-list($value --> List) {
		return () unless $value.defined;
		if $value ~~ Positional { return $value.list }
		if $value ~~ Associative { return $value.keys.sort.list }
		if $value ~~ Str { return $value.comb.list }
		($value,);
	}
}

}
