CREATE TABLE reminders (
	id SERIAL NOT NULL,
	subject VARCHAR NOT NULL,
	created_by VARCHAR NOT NULL,
	created_in VARCHAR,
	trigger_at TIMESTAMP NOT NULL,
	created_at TIMESTAMP NOT NULL DEFAULT (NOW() AT TIME ZONE 'utc')
);
