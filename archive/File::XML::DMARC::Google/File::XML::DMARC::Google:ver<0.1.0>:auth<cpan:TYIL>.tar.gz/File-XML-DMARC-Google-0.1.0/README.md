NAME
====

File::XML::DMARC::Google

AUTHOR
======

Patrick Spek <p.spek@tyil.work>

VERSION
=======

0.0.0

Description
===========

Parser for XML-formatted DMARC reports from Google

Installation
============

Install this module through [zef](https://github.com/ugexe/zef):

```sh
zef install File::XML::DMARC::Google
```

License
=======

This module is distributed under the terms of the AGPL-3.0.

