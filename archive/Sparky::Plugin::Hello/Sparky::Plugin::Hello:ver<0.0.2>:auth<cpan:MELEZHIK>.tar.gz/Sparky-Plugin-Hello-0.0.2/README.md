# SYNOPSIS

Sparky Hello Plugin


# INSTALL

    $ zef install Sparky::Plugin::Hello


# USAGE

    $ cat sparky.yaml

    plugins:
     - Sparky::Plugin::Hello:
        parameters:
          name: "Sparrow"

# Author

Alexey Melezhik

    
