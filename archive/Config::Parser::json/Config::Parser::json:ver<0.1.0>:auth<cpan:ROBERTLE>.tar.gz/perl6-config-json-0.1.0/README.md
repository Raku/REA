# Config::Parser::json

A JSON parser for [Config](https://github.com/scriptkitties/p6-Config).

## License

Config::Parser::json is licensed under the [Artistic License 2.0](https://opensource.org/licenses/Artistic-2.0).

## Feedback and Contact

Please let me know what you think: Robert Lemmen <robertle@semistable.com>
