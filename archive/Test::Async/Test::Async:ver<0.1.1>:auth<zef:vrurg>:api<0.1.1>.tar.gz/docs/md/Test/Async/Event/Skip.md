Class `Event::Skip`
===================

Is [`Event::Test`](https://github.com/vrurg/raku-Test-Async/blob/v0.1.1/docs/md/Test/Async/Event/Test.md).

Reports skipped test.

SEE ALSO
========

[`Test::Async::Event`](https://github.com/vrurg/raku-Test-Async/blob/v0.1.1/docs/md/Test/Async/Event.md)

AUTHOR
======

Vadim Belman <vrurg@cpan.org>

