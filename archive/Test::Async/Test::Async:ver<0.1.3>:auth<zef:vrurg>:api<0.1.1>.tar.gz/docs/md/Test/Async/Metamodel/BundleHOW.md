NAME
====



`Test::Async::Metamodel::BundleHOW` - metaclass backing bundle roles

DESCRIPTION
===========



The only function is to register the bundle role with slang defined in [`Test::Async::Decl`](https://github.com/vrurg/raku-Test-Async/blob/v0.1.3/docs/md/Test/Async/Decl.md).

SEE ALSO
========

[`Test::Async::Manual`](https://github.com/vrurg/raku-Test-Async/blob/v0.1.3/docs/md/Test/Async/Manual.md), [`Test::Async::Decl`](https://github.com/vrurg/raku-Test-Async/blob/v0.1.3/docs/md/Test/Async/Decl.md)

AUTHOR
======

Vadim Belman <vrurg@cpan.org>

