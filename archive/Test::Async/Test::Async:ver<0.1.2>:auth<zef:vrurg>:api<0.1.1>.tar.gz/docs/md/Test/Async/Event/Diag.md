Class `Event::Diag`
===================

Is [`Event::Report`](https://github.com/vrurg/raku-Test-Async/blob/v0.1.2/docs/md/Test/Async/Event/Report.md).

Carries a diagnostics message. See `diag` in [`Test::Async::Base`](https://github.com/vrurg/raku-Test-Async/blob/v0.1.2/docs/md/Test/Async/Base.md).

SEE ALSO
========

[`Test::Async::Event`](https://github.com/vrurg/raku-Test-Async/blob/v0.1.2/docs/md/Test/Async/Event.md)

AUTHOR
======

Vadim Belman <vrurg@cpan.org>

