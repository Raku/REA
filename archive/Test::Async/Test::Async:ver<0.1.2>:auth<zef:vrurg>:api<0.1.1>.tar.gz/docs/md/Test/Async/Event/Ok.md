Class `Event::Ok`
=================

Is [`Event::Test`](https://github.com/vrurg/raku-Test-Async/blob/v0.1.2/docs/md/Test/Async/Event/Test.md).

Reports test pass.

SEE ALSO
========

[`Test::Async::Event`](https://github.com/vrurg/raku-Test-Async/blob/v0.1.2/docs/md/Test/Async/Event.md)

AUTHOR
======

Vadim Belman <vrurg@cpan.org>

