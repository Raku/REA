Class `Event::Skip`
===================

Is [`Event::Test`](Test.md).

Reports skipped test.

SEE ALSO
========

[`Test::Async::Event`](../Event.md)

AUTHOR
======

Vadim Belman <vrurg@cpan.org>

