Class <Event::JobsAwaited>
==========================

Is [`Event`](../Event.md)

Emitted when all pending jobs are completed.

SEE ALSO
========

[`Test::Async::Event`](../Event.md)

AUTHOR
======

Vadim Belman <vrurg@cpan.org>

