Class `Event::Diag`
===================

Is [`Event::Report`](Report.md).

Carries a diagnostics message. See `diag` in [`Test::Async::Base`](../Base.md).

SEE ALSO
========

[`Test::Async::Event`](../Event.md)

AUTHOR
======

Vadim Belman <vrurg@cpan.org>

