Class `Event::Telemetry`
========================

Is [`Event`](../Event.md)

Under development yet.

SEE ALSO
========

[`Test::Async::Event`](../Event.md)

AUTHOR
======

Vadim Belman <vrurg@cpan.org>

