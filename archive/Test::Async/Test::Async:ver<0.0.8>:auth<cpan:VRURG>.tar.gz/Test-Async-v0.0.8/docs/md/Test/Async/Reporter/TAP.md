NAME
====



`Test::Async::Reporter::TAP` - TAP reporter bundle

DESCRIPTION
===========



Maps events into TAP output.

The class is implementation detail. In addition to methods required by [`Test::Async::Reporter`](https://github.com/vrurg/raku-Test-Async/blob/v0.0.8/docs/md/Test/Async/Reporter.md), also defines `TAP-str-from-ev`.

