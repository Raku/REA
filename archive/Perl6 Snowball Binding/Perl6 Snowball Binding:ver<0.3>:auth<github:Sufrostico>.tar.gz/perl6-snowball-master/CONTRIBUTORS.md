# Contributors

  - [Altai-man](https://github.com/Altai-man) 
    - https://github.com/Sufrostico/perl6-snowball/pull/1
