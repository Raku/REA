# To-do List and Future Ideas

~~strikethrough text~~ means **done**.

- clean up
- speed up

## HTTP::UserAgent
- ~~HTTP Auth~~
- let user set his own cookie jar
- ~~make getprint() return the code response~~
- ~~security fix - use File::Temp to create temporary cookie jar~~
- use Promises
- ~~make SSL dependency as optional~~

## HTTP::Cookies
- path restriction

## OpenSSL
- ~~fix NativeCall's int bug~~
- make it work on more platforms

## IO::Socket::SSL
- make it work on more platforms
- make SSL support more reliable
- add throwing exception on failing SSL
- more tests

