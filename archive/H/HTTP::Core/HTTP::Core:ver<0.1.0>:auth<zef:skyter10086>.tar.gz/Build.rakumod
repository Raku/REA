use v6.d;

# Build the C kernel that HTTP::Core binds to.
#
#   raku -I. Build.rakumod
#   CC="gcc" raku -I. Build.rakumod
#   CC="clang" raku -I. Build.rakumod
#
# `zef install .` calls Build.build on its own, so the command above is only
# for working in-tree. On Windows no Visual Studio is required: zig cc is a
# single portable toolchain and the .dll it emits loads under NativeCall as-is.
#
# With no CC set, the first of `zig cc`, `cc`, `gcc`, `clang` that actually
# runs wins: zig is a single portable toolchain that behaves identically on
# Windows, macOS and Linux, and the rest are whatever the machine already has,
# so a fresh checkout builds without installing anything new. Set CC to
# override the search.
#
# Nothing here needs a shim: the kernel has a plain C ABI, exports plain
# functions, allocates nothing, and never calls back into Raku.

class Build {
    method build($dir) {
        # zef hands over the distribution path as a Str; MAIN hands over an IO.
        my $root = $dir.IO.absolute;
        my $src  = "$root/src/http_wire.c";
        my $hdr  = "$root/src/http_wire.h";

        die "missing C source: $src"   unless $src.IO.e;
        die "missing C header: $hdr"   unless $hdr.IO.e;

        my $libdir = "$root/resources/libraries";
        $libdir.IO.mkdir unless $libdir.IO.d;

        my $dll = "$libdir/" ~ self!lib-name;
        my @candidates = self!cc-candidates;

        say "HTTP::Core: source   $src";
        say "HTTP::Core: output   $dll";

        # Try the candidates in order until one produces a library. Probing with
        # `--version` is not enough: WSL inherits the Windows PATH, so a
        # `zig.exe` there answers `zig version` happily and then fails to
        # compile an ELF target. The compile itself is the only honest test.
        my $built = False;
        for @candidates -> @cc {
            # -fPIC is harmless on Windows and required on ELF targets, so it is
            # passed unconditionally; -shared yields .dll/.so/.dylib on all three
            # platforms with every compiler we care about.
            my @cmd = |@cc, '-shared', '-O3', '-fPIC',
                      '-o', $dll,
                      '-I', "$root/src",
                      $src;

            say "HTTP::Core: compiling C kernel with [{@cc.join(' ')}]";
            my $proc = try run |@cmd, :out, :err;
            without $proc {
                say "HTTP::Core: {@cc.join(' ')} is not on PATH; trying the next one";
                next;
            }

            my $err = $proc.err.slurp;
            my $out = $proc.out.slurp;

            print $out if $out.trim;
            print $err if $err.trim;

            if $proc.exitcode == 0 && $dll.IO.e {
                $built = True;
                last;
            }

            say "HTTP::Core: {@cc.join(' ')} did not build it "
              ~ "(exit {$proc.exitcode}); trying the next one";
        }

        die 'no compiler could build the kernel; tried: '
          ~ @candidates.map(*.join(' ')).join(', ')
          ~ '. Install one, or set CC (for example CC=gcc).'
            unless $built;

        # zef stages a resource under the key named in META6.json and appends
        # the platform's extension to it, so the distribution declares the one
        # key `libraries/http_wire`. PE already names the file that way; ELF and
        # Mach-O want a `lib` prefix, so leave an unprefixed copy behind as well
        # instead of maintaining three keys that cannot all be present.
        unless $*DISTRO.is-win {
            my $alias = "$libdir/http_wire"
                ~ ($*KERNEL.name eq 'darwin' ?? '.dylib' !! '.so');
            copy $dll, $alias;
        }

        say "HTTP::Core: built {self!lib-name} ({$dll.IO.s // 0} bytes)";
        return True;
    }

    # Ordered by how little the user has to install: `zig cc` is one download
    # with no runtime dependency, `cc` is whatever the platform ships, the rest
    # are common enough to be worth trying before giving up.
    my constant COMPILERS = (('zig', 'cc'), ('cc',), ('gcc',), ('clang',));

    method !cc-candidates(--> List) {
        # An explicit CC is an instruction, not a preference: try only that one
        # and report its errors, rather than quietly building with something else.
        return (%*ENV<CC>.words,) with %*ENV<CC>;
        COMPILERS;
    }

    method !lib-name(--> Str) {
        # Not `given $*DISTRO.is-win { when True {...} default {...} }`: Raku's
        # `when True` matches *any* value, `False` included, so that shape
        # picked the Windows name on ELF and Mach-O too and every Unix build
        # produced an `http_wire.dll` that was really a `.so`.
        return 'http_wire.dll'      if $*DISTRO.is-win;
        return 'libhttp_wire.dylib' if $*KERNEL.name eq 'darwin';
        'libhttp_wire.so';
    }
}

# `raku -I. Build.rakumod` — build against the directory holding this file.
# zef reaches Build.build directly and never executes this mainline.
sub MAIN(Str $dir?) {
    Build.build(($dir // $*CWD).IO);
}
