use v6.d;
use lib 'lib';
use HTTP::Core::Server;

# ---------------------------------------------------------------------------
# Watch the connection registry fill and empty.
#
#   cd raku-HTTP-Core
#   raku -Ilib examples/registry-watch.raku
#   DEBUG=1 raku -Ilib examples/registry-watch.raku      # also print accept/drop lines
#
# Before the fix the counter only ever went up: `!drop` threw on a Str/Int
# mismatch inside the frame callback, and the key was a recyclable socket
# address. Every line below that reads "ok" is now a real deregistration.
#
# What to look at with DEBUG=1: each accept line prints `conn#N`, each drop line
# prints the same `conn#N`. That pairing is the fix. The `id=` field will differ
# between the two lines for the same connection -- it is the socket's address,
# and the VM moves objects -- which is exactly why it could not be the key.
# ---------------------------------------------------------------------------

my Bool $debug = %*ENV<DEBUG>.so;

my $port = free-port();
my $app  = HTTP::Core::Server.new(:$port, :debug($debug));
$app.router.get: '/ping', -> $req, %p { 'pong' };
$app.start;

# `start` only arms the listen tap, so the first connect can still be refused.
sub open(--> IO::Socket::INET) {
    for ^40 {
        my $s = try IO::Socket::INET.new(:host('127.0.0.1'), :port($port));
        return $s if $s.defined;
        sleep 0.05;
    }
    die "server never accepted a connection on port {$port}";
}

# One request on an already-open socket: the whole point of keep-alive.
sub ping(IO::Socket::INET $s --> Bool) {
    $s.write("GET /ping HTTP/1.1\r\nHost: x\r\n\r\n".encode);
    my $seen = $s.recv(4096);
    return ($seen.defined && $seen.elems > 0);
}

sub wait-count(Int $want, Int $ticks = 60 --> Int) {
    for ^$ticks {
        return $app.connections if $app.connections == $want;
        sleep 0.05;
    }
    $app.connections;
}

sub row(Str $what, Int $expect) {
    my $got = wait-count($expect);
    printf "  %-46s expect %-3d got %-3d %s\n",
        $what, $expect, $got, ($got == $expect ?? 'ok' !! 'FAIL');
    $got == $expect or $*ERR.say: "  ^ registry never settled";
}

say "== listening on 127.0.0.1:{$port}";

say "\n[1] one keep-alive connection, five requests";
my $s = open;
say "  connected, registry={wait-count(1)}";
for 1..5 -> $i {
    ping($s) or die "request {$i} got no response";
    say "  request {$i}: registry={$app.connections}";
}
$s.close;
say "  socket closed";
row('after close', 0);

say "\n[2] three rounds of six connections, closed each round";
for 1..3 -> $r {
    my @socks;
    for ^6 {
        my $c = open;
        ping($c) or die "round {$r} got no response";
        @socks.push($c);
    }
    say "  round {$r}: six open, registry={wait-count(6)}";
    .close for @socks;
    row("round {$r} after close", 0);
}

say "\n[3] shutdown";
$app.stop;
printf "  %-46s %s\n", 'running', $app.running;
printf "  %-46s %s\n", 'connections', $app.connections;

say "\n== done; every line above should read ok";
