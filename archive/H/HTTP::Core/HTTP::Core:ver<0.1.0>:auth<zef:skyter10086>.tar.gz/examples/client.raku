use v6.d;

# Talk to any HTTP/1.x server through the library's own client stack:
# its URL parser, its request encoder, its response parser, its connection pool.
#
#   raku -Ilib examples/client.raku --help
#   raku -Ilib examples/client.raku --url=http://127.0.0.1:8080/health --verbose
#   raku -Ilib examples/client.raku --url=http://127.0.0.1:8080/echo \
#        --method=POST --data=ping
#   raku -Ilib examples/client.raku --self-test      # spawn a server, hit it, tear it down
#
# Option values may be written either way: "--timeout 5" and "--timeout=5" both
# work. The numeric options are declared Str and converted by num-option(), since
# MAIN only binds a space-separated value to a Str option.
#
# --self-test needs no network and no other terminal, so it doubles as a smoke
# test for the whole stack (pool -> transport -> codec).

use HTTP::Core;              # free-port / core-version
use HTTP::Core::Client;
use HTTP::Core::Server;      # only for --self-test
use HTTP::Core::Response;

#|= One request, one screen. --self-test proves the stack without a network.
sub MAIN(
    #| Absolute URL to request.
    Str  :$url       = 'http://127.0.0.1:8080/',
    #| Verb to use; the server decides what it accepts.
    Str  :$method    = 'GET',
    #| Request body, sent as text.
    Str  :$data,
    #| Content-Type for --data.
    Str  :$type      = 'text/plain',
    #| Seconds allowed for the whole request, every redirect hop included.
    Str  :$timeout   = '10',
    #| Print every response header.
    Bool :$verbose   = False,
    #| Spawn a server in this process, hit it, stop it. No network needed.
    Bool :$self-test = False,
) {
    if $self-test {
        exit self-test($verbose);
    }

    my $timeout-secs = num-option($timeout, '--timeout');
    my $client = HTTP::Core::Client.new(:timeout($timeout-secs));

    my %opt;
    %opt<body> = $data with $data;
    %opt<headers> = ('Content-Type' => $type) if $data.defined;

    my $res = try await $client.request($method.uc, $url, |%opt);

    unless $res.defined && $res !~~ Exception {
        note "request failed: {$res // 'no response'}";
        return 1;
    }

    show($res, $verbose);
    $client.close;
    return 0;
}

# One response, one screen. `reason` is the standard phrase the server sent.
sub show(HTTP::Core::Response $res, Bool $verbose --> Nil) {
    say "status  {$res.status} {$res.reason}";
    say "framing {$res.framing}  ({$res.body-bytes.elems} body byte(s))";

    if $verbose {
        for $res.header-pairs -> $p {
            say "header  {$p.key}: {$p.value}";
        }
    }

    # Bodies are bytes, not text: decode explicitly, and survive a body that is
    # not valid UTF-8 rather than dying halfway through the demo.
    my $text = try $res.body.decode('utf-8') // '(' ~ $res.body-bytes.elems ~ ' bytes, not UTF-8)';
    my $clip = $text.chars > 400 ?? $text.substr(0, 400) ~ '…' !! $text;
    say "body    $clip";
}

# Starts a server on a free port, issues a GET and a POST, stops it. Everything
# runs in one process, so a failure here is a library failure, not an
# environment one.
sub self-test(Bool $verbose --> Int) {
    my $port = free-port();
    my $app  = HTTP::Core::Server.new(:$port);

    $app.router.get: '/hi', -> $req, %p {
        HTTP::Core::Response.text('hello from the self-test');
    }
    $app.router.post: '/echo', -> $req, %p {
        HTTP::Core::Response.new(
            :body($req.body),
            :headers(%( 'Content-Type' => 'application/octet-stream' )),
        )
    };

    $app.start;
    sleep 0.2;   # the listen tap is armed synchronously; let the loop breathe once

    my $client = HTTP::Core::Client.new(:timeout(5), :connect-timeout(2));
    my $base   = "http://127.0.0.1:$port";
    my @fail;

    my $get = try await $client.get("$base/hi");
    @fail.push('GET /hi')       unless $get.defined && $get.status == 200;
    @fail.push('GET body')      unless $get.defined && (try $get.body.decode('utf-8')) eq 'hello from the self-test';
    show($get, $verbose) if $get.defined;

    my $post = try await $client.post("$base/echo", :body('ping'));
    @fail.push('POST /echo')    unless $post.defined && $post.status == 200;
    @fail.push('POST echo body') unless $post.defined && (try $post.body.decode('utf-8')) eq 'ping';
    show($post, $verbose) if $post.defined;

    $client.close;
    $app.stop;

    if @fail {
        note "SELF-TEST FAILED: {@fail.join(', ')}";
        return 1;
    }

    say "self-test ok: GET /hi and POST /echo round-tripped through {$base}";
    return 0;
}

# "--timeout 5" and "--timeout=5" both bind: the option is Str, converted here.
# A bad value is named here instead of producing a bare usage block.
sub num-option(Str $value, Str $name --> Real) {
    my $v = $value.trim;
    die "{$name}: expected a positive number of seconds, got '{$value}'\n"
        unless $v ~~ /^ \d+ [ '.' \d+ ]? $/ && $v.Real > 0;
    $v.Real;
}
