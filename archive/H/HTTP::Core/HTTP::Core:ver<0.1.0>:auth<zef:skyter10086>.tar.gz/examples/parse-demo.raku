use v6.d;

# Parse a raw HTTP request off any byte stream.
#
# The kernel is a pure function: it never reads a socket, never allocates, and
# never calls back into Raku. Your transport feeds bytes, the parser tells you
# how many it consumed, and you decide what to do next. That is what makes it
# safe on MoarVM, which cannot re-enter Raku from a foreign thread.
#
#   raku -Ilib examples/parse-demo.raku

use HTTP::Core;
use HTTP::Core::X;

my $wire = (
    "GET /search?q=raku&page=2 HTTP/1.1\r\n",
    "Host: example.com\r\n",
    "User-Agent: raku-http-core/demo\r\n",
    "Accept: */*\r\n",
    "\r\n",
).join;

say "kernel   : ", core-version();
say "library  : ", library-path();
say "abi ok   : ", assert-abi();
say "";

my $req = parse-request($wire.encode);

say "method   : ", $req.method;
say "target   : ", $req.target;
say "path     : ", $req.path-only;
say "query    : ", $req.query-string;
say "version  : HTTP/", $req.http-version;
say "keepalive: ", $req.keep-alive ?? 'yes' !! 'no';
say "consumed : ", $req.consumed, " of ", $wire.encode.elems, " bytes";
say "";

say "headers  :";
say "  {.key} => {.value}" for $req.header-pairs;

# A body, if advertised by Content-Length, follows the head verbatim.
say "";
say "body     : ", $req.body.elems == 0 ?? '(none)' !! $req.body.decode;

# Incremental arrival: the same bytes split across two reads.
say "";
say "--- partial feed ---";
my $full  = "POST /echo HTTP/1.1\r\nContent-Length: 5\r\n\r\nhello".encode;
my $first = $full.subbuf(0, 12);

try parse-request($first);
say "first 12 bytes: ", $!.defined && $! ~~ HTTP::Core::X::Incomplete
    ?? 'Incomplete (feed more bytes)'
    !! 'unexpected: ' ~ ($!.defined ?? $!.message !! 'no error');

my $second = parse-request($full);
say "reassembled    : ", $second.method, ' ', $second.path-only,
    ' body=', $second.body.decode;
