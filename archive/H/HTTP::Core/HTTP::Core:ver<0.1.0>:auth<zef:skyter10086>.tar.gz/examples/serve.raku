use v6.d;

# A small server whose mainline parses arguments and can describe itself.
#
#   raku -Ilib examples/serve.raku --help
#   raku -Ilib examples/serve.raku --port=9000 --verbose
#   raku -Ilib examples/serve.raku --port 9000 --verbose   # same thing
#   raku -Ilib examples/serve.raku --demo=3      # bind, answer, exit: a smoke test
#
# Option values may be written either way. Raku's MAIN only binds a
# space-separated value to a Str option, so the numeric options below are declared
# Str and converted by int-option(); that is what makes "--port 9000" bind here
# instead of arriving as a stray positional argument.
#
# Handlers may return an HTTP::Core::Response, a Str (sent as text/plain) or a
# Blob (sent as application/octet-stream). Anything else is stringified. A
# handler that dies becomes a 500 and the connection stays usable.
#
# Try, from another terminal:
#   curl -s http://127.0.0.1:9000/health
#   curl -s http://127.0.0.1:9000/users/42
#   curl -s -X POST --data-binary 'ping' http://127.0.0.1:9000/echo

use JSON::Fast;
use HTTP::Core;
use HTTP::Core::Server;
use HTTP::Core::Response;

#|= Serve a handful of routes with the library's own parser and router.
sub MAIN(
    #| TCP port to bind (--port=8080 and --port 8080 both work).
    Str  :$port    = '8080',
    #| Interface to bind.
    Str  :$host    = '127.0.0.1',
    #| Log every accept and drop (same lines as DEBUG=1).
    Bool :$verbose = False,
    #| Serve for this many seconds, then stop: a self-contained smoke test.
    Str  :$demo    = '0',
) {
    my Int $port-num  = int-option($port, '--port', 1, 65_535);
    my Int $demo-secs = int-option($demo, '--demo', 0, 86_400);

    my $app = HTTP::Core::Server.new(:port($port-num), :$host, debug => $verbose);

    $app.router.get: '/', -> $req, %p {
        HTTP::Core::Response.html: qq:to/HTML/;
        <!doctype html>
        <meta charset="utf-8">
        <title>HTTP::Core example</title>
        <h1>raku-HTTP-Core</h1>
        <p>Kernel <code>{core-version()}</code>, HTTP/{$req.http-version}, path <code>{$req.path-only}</code>.</p>
        <ul>
          <li><a href="/health">/health</a></li>
          <li><a href="/users/42">/users/42</a></li>
        </ul>
        HTML
    }

    # Liveness probes want a tiny body and a cheap handler; both are the point.
    $app.router.get: '/health', -> $req, %p {
        HTTP::Core::Response.json: to-json %(
            ok          => True,
            kernel      => core-version(),
            connections => $app.connections,
        );
    }

    # :name is captured into %p<name>.
    $app.router.get: '/users/:id', -> $req, %p {
        HTTP::Core::Response.json: to-json %( id => %p<id>, name => "user {%p<id>}" );
    }

    # A wildcard captures the rest of the path, slashes included.
    $app.router.get: '/files/*', -> $req, %p {
        "you asked for {%p<*>} on HTTP/{$req.http-version}\n"
    }

    # The body arrives only once Content-Length is satisfied, so this is whole
    # even when TCP split the request across several packets.
    $app.router.post: '/echo', -> $req, %p {
        HTTP::Core::Response.new(
            body    => $req.body,
            headers => %( Content-Type => $req.header('content-type') // 'application/octet-stream' ),
        )
    }

    $app.start;

    note "HTTP::Core listening on http://{$host}:{$port-num}  (kernel {core-version()}, {$app.router.routes} routes)";
    note "try: curl -s http://{$host}:{$port-num}/health";

    if $demo-secs > 0 {
        sleep $demo-secs;
        my $left = $app.drop-connections;
        $app.stop;
        note "served {$demo-secs}s, dropped {$left} connection(s), stopped";
        return;
    }

    note "Ctrl-C to stop";

    react {
        whenever signal(SIGINT) {
            $app.stop;
            note "\nstopped";
            done;
        }
    }
}

# Numeric options arrive as Str so that both "--port 8080" and "--port=8080"
# bind. A bad value is named here instead of producing a bare usage block.
sub int-option(Str $value, Str $name, Int $min, Int $max --> Int) {
    my $v = $value.trim;
    die "{$name}: expected a whole number {$min}..{$max}, got '{$value}'\n"
        unless $v ~~ /^ \d+ $/ && $v.Int ~~ $min .. $max;
    $v.Int;
}
