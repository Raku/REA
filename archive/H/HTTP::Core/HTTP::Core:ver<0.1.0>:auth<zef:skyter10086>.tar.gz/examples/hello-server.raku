use v6.d;

# A complete HTTP server in about forty lines.
#
#   raku -Ilib examples/hello-server.raku
#   PORT=9000 raku -Ilib examples/hello-server.raku
#
# It stops itself after DEMO seconds so it can also be used as a smoke test:
#   DEMO=3 raku -Ilib examples/hello-server.raku
#
# Then, from another terminal:
#   curl http://127.0.0.1:<port>/
#   curl -X POST --data-binary 'ping' http://127.0.0.1:<port>/echo

use HTTP::Core;
use HTTP::Core::Server;
use HTTP::Core::Response;

my $port = (%*ENV<PORT> // free-port()).Int;
my $demo = (%*ENV<DEMO> // 0).Int;

my $app = HTTP::Core::Server.new(:$port);

$app.router.get: '/', -> $req, %p {
    HTTP::Core::Response.html: qq:to/HTML/;
    <!doctype html>
    <meta charset="utf-8">
    <title>HTTP::Core</title>
    <h1>Hello from Raku + a C parser</h1>
    <p>You asked for <code>{$req.path-only}</code> over HTTP/{$req.http-version}.</p>
    <p>User-Agent: <code>{$req.header('user-agent') || '(none)'}</code></p>
    HTML
}

$app.router.get: '/json', -> $req, %p {
    HTTP::Core::Response.json: '{"ok":true,"kernel":"' ~ core-version() ~ '"}'
}

# Echo whatever the client sent, byte for byte.
$app.router.post: '/echo', -> $req, %p {
    HTTP::Core::Response.new(
        body    => $req.body,
        headers => %( Content-Type => $req.header('content-type') || 'application/octet-stream' ),
    )
}

# Path parameters and a wildcard.
$app.router.get: '/greet/:name', -> $req, %p {
    "hello, {%p<name>}\n"
}

$app.router.get: '/files/*', -> $req, %p {
    "you asked for the file {%p<*>}\n"
}

$app.start;

say "HTTP::Core listening on http://127.0.0.1:$port";
say "routes: {$app.router.routes}, kernel: {core-version()}";
say "try:   curl http://127.0.0.1:$port/greet/raku";

if $demo > 0 {
    sleep $demo;
    $app.stop;
    say "stopped after {$demo}s (connections left: {$app.connections})";
}
else {
    # Run until Ctrl-C.
    react {
        whenever signal(SIGINT) {
            $app.stop;
            say "\nstopped";
            done;
        }
    }
}
