use v6.d;
use lib 'temp/ab/lib';
use lib 'lib';

use HTTP::Core::Router::Base;
use HTTP::Core::Router::New;
use HTTP::Core::Response::Base;
use HTTP::Core::Response::New;

# ---------------------------------------------------------------------------
# In-process A/B: baseline and optimised implementations in one VM.
#
# Swapping module files between runs cannot separate a real change from the
# machine drifting 10-40% between processes — a control case (parse, untouched)
# moved by 12% across builds in `04-stack.raku`. Here both implementations are
# loaded under different namespaces and measured alternately in the same
# process, so every A is compared against a B taken microseconds later, on the
# same core, same JIT, same GC state.
#
# The alternation order is A,B,B,A per repeat to cancel any monotonic drift.
#
# Run:  raku -Ilib -Itemp/ab/lib bench/05-ab-inproc.raku [N] [REP]
# ---------------------------------------------------------------------------

my $N   = (@*ARGS[0] // 30_000).Int;
my $REP = (@*ARGS[1] // 15).Int;

sub routes-for($r) {
    $r.get:  '/health',           -> $req, %p { 'alive' };
    $r.get:  '/api/v1/users/:id', -> $req, %p { 'ok' };
    $r.post: '/api/v1/users',     -> $req, %p { 'created' };
    $r;
}

my $rb = routes-for(HTTP::Core::Router::Base.new);
my $rn = routes-for(HTTP::Core::Router::New.new);

# Warm up both (JIT, hash growth) and prove they agree before timing anything.
for ($rb, $rn) -> $r {
    die 'static mismatch'  unless $r.match('GET', '/health').[0]('x', %{}) eq 'alive';
    die 'dynamic mismatch' unless $r.match('GET', '/api/v1/users/42').[0]('x', %{}) eq 'ok';
    die 'unknown route'    unless $r.match('GET', '/nope').defined.not;
}

sub time-it(&body, Int $n --> Num) {
    my $t0 = now;
    body($n);
    (now - $t0).Num * 1e9 / $n;
}

sub bench-route($r, Str $path, Int $n --> Nil) {
    my $hit = $r.match('GET', $path);
    for ^$n { $hit = $r.match('GET', $path) }
    # Keep the last result reachable so nothing can be optimised away.
    die 'router broke during timing' unless $hit.defined;
}

# Serialisation: responses built once, payload on both.
my $payout-b = HTTP::Core::Response::Base.new(:body('ok'));
my $payout-n = HTTP::Core::Response::New.new(:body('ok'));
$payout-b.payload(True);
$payout-n.payload(True);

my %res;

# Warm every (implementation, case) pair before sampling.
#
# Without this the first thing measured in the process pays for JIT/spesh
# specialisation that the second one gets for free — the same router read
# 3.5 us in one script and 1.6 us in another purely because of what ran before
# it. 2,000 iterations per pair is enough to specialise the call sites.
my $WARM = 2_000;
for ($rb, $rn) -> $r {
    for '/health', '/api/v1/users/42' -> $p { bench-route($r, $p, $WARM) }
}
$payout-b.payload(True) for ^$WARM;
$payout-n.payload(True) for ^$WARM;

# Interleaved sampling: each repeat measures all four cases, so slow spells hit
# both builds equally. Minimum across repeats is the least noisy estimator.
for ^$REP {
    for @(
        ('route:static',  { bench-route($rb, '/health',           $_) } , { bench-route($rn, '/health',           $_) } ),
        ('route:dynamic', { bench-route($rb, '/api/v1/users/42',  $_) } , { bench-route($rn, '/api/v1/users/42',  $_) } ),
    ) -> ($label, &a, &b) {
        my $ta = time-it(&a, $N);
        my $tb = time-it(&b, $N);
        %res{$label}<base>.push: $ta;
        %res{$label}<new>.push:  $tb;
    }
}

for ^$REP {
    my $ta = time-it({ $payout-b.payload(True) for ^$_[0] }, $N);
    my $tb = time-it({ $payout-n.payload(True) for ^$_[0] }, $N);
    %res{'payload:no-headers'}<base>.push: $ta;
    %res{'payload:no-headers'}<new>.push:  $tb;
}

for %res.keys.sort -> $k {
    my $b = %res{$k}<base>.min;
    my $n = %res{$k}<new>.min;
    printf "%-20s base=%8.1f  new=%8.1f  delta=%+7.1f ns (%+6.1f%%)\n", $k, $b, $n, $n - $b, ($n - $b) / $b * 100;
}
