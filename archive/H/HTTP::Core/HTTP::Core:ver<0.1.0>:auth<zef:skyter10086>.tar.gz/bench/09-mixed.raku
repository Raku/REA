use v6.d;
use lib 'temp/ab/lib';
use lib 'lib';

use HTTP::Core::Router::Base;
use HTTP::Core::Router::New;

# ---------------------------------------------------------------------------
# Mixed routing workload: the router layer as an app actually exercises it.
#
# Isolated per-case numbers are not trustworthy here. The same new router reads
# 15.5 us for a dynamic route in `05-ab-inproc.raku` and 9.6 us in
# `08-diag.raku` — same code, same path, different preceding workload. MoarVM's
# spesh specialises the call site towards whatever shape it saw first, so
# measuring "static only" before "dynamic only" penalises the dynamic case.
#
# A real server interleaves both. So: one loop, one call site, ~1/3 static and
# ~2/3 dynamic, and report total ns per dispatch. That is the number that
# decides whether the change ships.
#
# Run:  raku -Ilib -Itemp/ab/lib bench/09-mixed.raku [N] [REP]
# ---------------------------------------------------------------------------

my $N   = (@*ARGS[0] // 60_000).Int;
my $REP = (@*ARGS[1] // 15).Int;

sub routes-for($r) {
    $r.get:  '/health',           -> $req, %p { 'alive' };
    $r.get:  '/api/v1/users/:id', -> $req, %p { 'ok' };
    $r.post: '/api/v1/users',     -> $req, %p { 'created' };
    $r.get:  '/files/*',          -> $req, %p { 'file' };
    $r;
}

my $base = routes-for(HTTP::Core::Router::Base.new);
my $new  = routes-for(HTTP::Core::Router::New.new);

# 12 dispatches: 4 static (33%), 8 dynamic (67%).
my @plan =
    '/health', '/api/v1/users/42', '/api/v1/users/7',
    '/files/a/b/c.txt', '/api/v1/users/99', '/health',
    '/api/v1/users/13', '/files/x/y', '/api/v1/users/5',
    '/health', '/api/v1/users/64', '/files/q';

for ($base, $new) -> $r {
    for @plan -> $p {
        die "mismatch on $p" unless $r.match('GET', $p).defined;
    }
}

sub run-mixed($r, Int $n --> Nil) {
    my $hit;
    my $i = 0;
    for ^$n {
        $hit = $r.match('GET', @plan[$i]);
        $i = ($i + 1) % 12;
    }
    die 'router broke' unless $hit.defined;
}

sub time-it(&body, Int $n --> Num) {
    my $t0 = now;
    body($n);
    (now - $t0).Num * 1e9 / $n;
}

# Equal warm-up for both, on the same mixed plan.
run-mixed($base, 3_000);
run-mixed($new,  3_000);

my @b;
my @n;
for ^$REP {
    @b.push: time-it({ run-mixed($base, $_) }, $N);
    @n.push: time-it({ run-mixed($new,  $_) }, $N);
}

my $bm = @b.min;
my $nm = @n.min;
printf "mixed dispatch   base=%8.1f ns  new=%8.1f ns  delta=%+7.1f ns (%+6.1f%%)\n",
    $bm, $nm, $nm - $bm, ($nm - $bm) / $bm * 100;
printf "                 base median=%8.1f  new median=%8.1f\n", @b.sort[*/2], @n.sort[*/2];
