use v6.d;
use lib 'lib';
use HTTP::Core::Response;
use HTTP::Core::Router;

# Noise-resistant microbenchmark: small N, many repeats, report minimum.
# A shared desktop drifts 30-40% between runs, so the minimum across ~20 short
# interleaved runs is the only number worth comparing.
#
# Run:  raku -Ilib bench/03-micro.raku [N] [REP]

my $N   = (@*ARGS[0] // 40_000).Int;
my $REP = (@*ARGS[1] // 20).Int;

sub bench(Str $label, &body --> Nil) {
    my @t;
    for ^$REP {
        my $t0 = now;
        body($N);
        @t.push: (now - $t0).Num * 1e9 / $N;
    }
    printf "%-24s %8.1f ns\n", $label, @t.min;
}

my $plain = HTTP::Core::Response.new(:body('ok'));
my $typed = HTTP::Core::Response.text('ok');
$plain.payload(True); $typed.payload(True);

my $r = HTTP::Core::Router.new;
$r.get:  '/health',           -> $req, %p { 'alive' };
$r.get:  '/api/v1/users/:id', -> $req, %p { 'ok' };
$r.post: '/api/v1/users',     -> $req, %p { 'created' };
$r.match('GET', '/health');

bench 'payload:no-headers',  { $plain.payload(True) for ^$N };
bench 'payload:ctype',       { $typed.payload(True) for ^$N };
bench 'match:static',        { $r.match('GET', '/health')          for ^$N };
bench 'match:dynamic',       { $r.match('GET', '/api/v1/users/42') for ^$N };
