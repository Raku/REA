use v6.d;
use lib 'lib';

use HTTP::Core;
use HTTP::Core::Server;
use HTTP::Core::Request;
use HTTP::Core::Response;

# ---------------------------------------------------------------------------
# Layer C, mixed workload — the replacement for `02-dispatch.raku`.
#
# `02-dispatch.raku` parses one dynamic request over and over. After §9 that is
# exactly the measurement shape we no longer trust: one call site, one request
# shape, so spesh specialises for that shape and the number stops describing a
# real request mix.
#
# Here the same four raw requests are replayed in a fixed 4-cycle (2 static,
# 2 dynamic), through one call site, with equal warm-up per layer. Reported
# numbers are the minimum across repeats.
#
# Layer A (the C kernel) is not measured here — `src/http_wire.c` has not
# changed since §3, where it measured 1.0~1.2 us. Everything below is Raku side.
#
# Run:  raku -Ilib bench/10-stack-mixed.raku [N] [REP]
# ---------------------------------------------------------------------------

my $N   = (@*ARGS[0] // 40_000).Int;
my $REP = (@*ARGS[1] // 6).Int;
my $WARM = 3_000;

my @raws = (
    "GET /health HTTP/1.1\r\nHost: example.com\r\nUser-Agent: bench/0.1\r\nAccept: */*\r\n\r\n".encode,
    "GET /api/v1/users/42?page=2 HTTP/1.1\r\nHost: example.com\r\nUser-Agent: bench/0.1\r\nAccept: */*\r\n\r\n".encode,
    "GET /api/v1/users/7 HTTP/1.1\r\nHost: example.com\r\nUser-Agent: bench/0.1\r\nAccept: */*\r\n\r\n".encode,
    "GET /files/a/b/c.txt HTTP/1.1\r\nHost: example.com\r\nUser-Agent: bench/0.1\r\nAccept: */*\r\n\r\n".encode,
);

my $app = HTTP::Core::Server.new(port => 0);
$app.router.get:  '/health',           -> $req, %p { 'alive' };
$app.router.get:  '/api/v1/users/:id', -> $req, %p { 'ok' };
$app.router.get:  '/files/*',          -> $req, %p { 'file' };

# Sanity: every request in the cycle must resolve, or the layer C numbers would
# silently include 404s.
for @raws -> $r {
    my $resp = $app.handle(HTTP::Core::Request.parse($r));
    die "unexpected status {$resp.status} for {$resp.status}" unless $resp.status == 200;
}

sub bench-parse(Int $n --> Num) {
    my $acc = 0;
    my $i = 0;
    my $t0 = now;
    for ^$n {
        my $req = HTTP::Core::Request.parse(@raws[$i]);
        $acc = $acc + $req.method.chars;
        $i = ($i + 1) % 4;
    }
    (now - $t0).Num * 1e9 / $n;
}

sub bench-handle(Int $n --> Num) {
    my $acc = 0;
    my $i = 0;
    my $t0 = now;
    for ^$n {
        my $req  = HTTP::Core::Request.parse(@raws[$i]);
        my $resp = $app.handle($req);
        $acc = $acc + $resp.status;
        $i = ($i + 1) % 4;
    }
    (now - $t0).Num * 1e9 / $n;
}

sub bench-payload(Int $n --> Num) {
    my $acc = 0;
    my $i = 0;
    my $t0 = now;
    for ^$n {
        my $req  = HTTP::Core::Request.parse(@raws[$i]);
        my $resp = $app.handle($req);
        my $wire = $resp.payload(True);
        $acc = $acc + $wire.elems;
        $i = ($i + 1) % 4;
    }
    (now - $t0).Num * 1e9 / $n;
}

# Equal warm-up per layer, so no layer inherits (or pays for) another's spesh.
bench-parse($WARM); bench-handle($WARM); bench-payload($WARM);

my @b; my @c; my @w;
for ^$REP {
    @b.push: bench-parse($N);
    @c.push: bench-handle($N);
    @w.push: bench-payload($N);
}

my $p = @b.min;
my $h = @c.min;
my $wire = @w.min;

printf "%-26s %10.1f ns/req\n", 'B  parse',                 $p;
printf "%-26s %10.1f ns/req   (+%6.1f routing)\n", 'C  parse+handle',        $h, $h - $p;
printf "%-26s %10.1f ns/req   (+%6.1f serialise)\n", 'C" parse+handle+wire',  $wire, $wire - $h;
say '';
printf "routing share:   %.0f%%\n", ($h - $p) / $wire * 100;
printf "serialise share: %.0f%%\n", ($wire - $h) / $wire * 100;
printf "parse share:     %.0f%%\n", $p / $wire * 100;
printf "single-core ceiling: %.0f req/s\n", 1e9 / $wire;
say "N=$N REP=$REP  mix=2 static / 2 dynamic";
