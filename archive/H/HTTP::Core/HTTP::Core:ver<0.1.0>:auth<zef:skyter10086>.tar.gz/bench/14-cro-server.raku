use v6.d;

use Cro::HTTP::Server;
use Cro::HTTP::Router;

# ---------------------------------------------------------------------------
# Cro counterpart of bench/server-bench.raku.
#
#   PORT=18901 raku bench/14-cro-server.raku
#
# Same route shape, same body ('ok'), same bind address, so the only thing that
# differs when both are measured back-to-back is the framework underneath.
# ---------------------------------------------------------------------------

my $port = (%*ENV<PORT> // 18901).Int;

my $app = route {
    get -> 'bench'  { content 'text/plain', 'ok' }
    post -> 'bench' { content 'text/plain', 'ok' }
    get -> 'health' { content 'text/plain', 'alive' }
}

my $server = Cro::HTTP::Server.new(
    :$port,
    :host('0.0.0.0'),
    :application($app),
);

$server.start;

say "ready port=$port framework=cro";

react {
    whenever signal(SIGINT) { $server.stop; done }
}
