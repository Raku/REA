#!/usr/bin/env python3
"""Framework-neutral HTTP/1.1 keep-alive load client (raw sockets, threads)."""
import socket
import sys
import threading
import time

REQ = b"GET /bench HTTP/1.1\r\nHost: 127.0.0.1\r\nUser-Agent: bench/0.2\r\nAccept: */*\r\nConnection: keep-alive\r\n\r\n"


def one_conn(port, n, out, err):
    lat = []
    try:
        s = socket.create_connection(("127.0.0.1", port), timeout=30)
        s.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        buf = b""
        for _ in range(n):
            t0 = time.perf_counter()
            s.sendall(REQ)
            while True:
                i = buf.find(b"\r\n\r\n")
                if i >= 0:
                    head = buf[:i].decode("iso-8859-1")
                    cl = 0
                    for line in head.split("\r\n")[1:]:
                        if line.lower().startswith("content-length:"):
                            cl = int(line.split(":", 1)[1].strip())
                    need = i + 4 + cl
                    while len(buf) < need:
                        chunk = s.recv(65536)
                        if not chunk:
                            raise RuntimeError("eof before body")
                        buf += chunk
                    buf = buf[need:]
                    break
                chunk = s.recv(65536)
                if not chunk:
                    raise RuntimeError("eof before header")
                buf += chunk
            lat.append(time.perf_counter() - t0)
        s.close()
    except Exception as e:  # noqa: BLE001
        err.append(repr(e))
        return
    out.extend(lat)


def run(port, conn, req_):
    out, err = [], []
    t0 = time.perf_counter()
    threads = [threading.Thread(target=one_conn, args=(port, req_, out, err)) for _ in range(conn)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    wall = time.perf_counter() - t0
    if err:
        print("ERROR", err[:3], file=sys.stderr)
        sys.exit(2)
    out.sort()
    n = len(out)
    q = lambda p: out[min(n - 1, int(n * p))] * 1e6  
    return {
        "wall": wall,
        "n": n,
        "rps": n / wall,
        "mean": sum(out) / n * 1e6,
        "p50": q(0.50),
        "p90": q(0.90),
        "p99": q(0.99),
        "max": out[-1] * 1e6,
    }


if __name__ == "__main__":
    port, conn, req_ = int(sys.argv[1]), int(sys.argv[2]), int(sys.argv[3])
    r = run(port, conn, req_)
    print("%.3f %.0f %.1f %.1f %.1f %.1f %.1f" % (
        r["wall"], r["rps"], r["mean"], r["p50"], r["p90"], r["p99"], r["max"]))
