﻿use v6.d;
use lib 'lib';
use HTTP::Core;
use HTTP::Core::Server;
use HTTP::Core::Response;

# ---------------------------------------------------------------------------
# Layer C: everything the server does for a request except the socket.
#
#   parse   : bytes -> Request
#   handle  : Request -> Response (router + handler + coercion)
#   payload : Response -> bytes (head + body)
#
# Comparing against layer B (parse only) isolates routing and serialisation;
# comparing against layer D (real sockets) isolates libuv and the event loop.
#
# Run:  raku -Ilib bench/02-dispatch.raku
# ---------------------------------------------------------------------------

my $N    = (%*ENV<N> // 100_000).Int;
my $WARM = ($N div 10) max 5_000;

my $raw = "GET /api/v1/users/42?page=2 HTTP/1.1\r\nHost: example.com\r\nUser-Agent: bench/0.1\r\nAccept: */*\r\n\r\n".encode;

my $app = HTTP::Core::Server.new(port => 0);
$app.router.get: '/api/v1/users/:id', -> $req, %p { 'ok' };
$app.router.get: '/health',           -> $req, %p { 'alive' };

sub bench-parse(Int $n --> Num) {
    my $acc = 0;
    my $t0 = now;
    for ^$n {
        my $req = HTTP::Core::Request.parse($raw);
        $acc = $acc + $req.method.chars;
    }
    (now - $t0).Num * 1e9 / $n;
}

sub bench-handle(Int $n --> Num) {
    my $acc = 0;
    my $t0 = now;
    for ^$n {
        my $req  = HTTP::Core::Request.parse($raw);
        my $resp = $app.handle($req);
        $acc = $acc + $resp.status;
    }
    (now - $t0).Num * 1e9 / $n;
}

sub bench-payload(Int $n --> Num) {
    my $acc = 0;
    my $t0 = now;
    for ^$n {
        my $req  = HTTP::Core::Request.parse($raw);
        my $resp = $app.handle($req);
        my $wire = $resp.payload(True);
        $acc = $acc + $wire.elems;
    }
    (now - $t0).Num * 1e9 / $n;
}

# Warm up.
bench-parse($WARM); bench-handle($WARM); bench-payload($WARM);

my $p = bench-parse($N);
my $h = bench-handle($N);
my $w = bench-payload($N);

printf "%-24s %10.1f ns/req\n", 'B  parse',                $p;
printf "%-24s %10.1f ns/req   (+%.1f routing)\n", 'C  parse+handle',       $h, $h - $p;
printf "%-24s %10.1f ns/req   (+%.1f serialise)\n", 'C" parse+handle+wire', $w, $w - $h;
say '';
printf "single-core ceiling: %.0f req/s\n", 1e9 / $w;
say "N=$N  warmup=$WARM  kernel={core-version()}";
