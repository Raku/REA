use v6.d;
use lib 'lib';
use HTTP::Core;
use HTTP::Core::Server;
use HTTP::Core::Response;

# ---------------------------------------------------------------------------
# Stack-level A/B benchmark: B / C / C" on the real request path.
#
# `02-dispatch.raku` reports one long run, which on a shared desktop drifts
# 30-40% between runs — enough to hide or invent a 10% change. This script runs
# the same measurement REP times in a single warm process and reports the
# minimum of each, which is what you compare across builds.
#
# Run:  raku -Ilib bench/04-stack.raku [N] [REP]
# ---------------------------------------------------------------------------

my $N   = (@*ARGS[0] // 12_000).Int;
my $REP = (@*ARGS[1] // 8).Int;

my $raw = "GET /api/v1/users/42?page=2 HTTP/1.1\r\nHost: example.com\r\nUser-Agent: bench/0.1\r\nAccept: */*\r\n\r\n".encode;

my $app = HTTP::Core::Server.new(port => 0);
$app.router.get: '/api/v1/users/:id', -> $req, %p { 'ok' };
$app.router.get: '/health',           -> $req, %p { 'alive' };

sub once(--> List) {
    my $acc = 0;

    my $t0 = now;
    for ^$N {
        my $req = HTTP::Core::Request.parse($raw);
        $acc = $acc + $req.method.chars;
    }
    my $p = (now - $t0).Num * 1e9 / $N;

    $t0 = now;
    for ^$N {
        my $req  = HTTP::Core::Request.parse($raw);
        my $resp = $app.handle($req);
        $acc = $acc + $resp.status;
    }
    my $h = (now - $t0).Num * 1e9 / $N;

    $t0 = now;
    for ^$N {
        my $req  = HTTP::Core::Request.parse($raw);
        my $resp = $app.handle($req);
        my $wire = $resp.payload(True);
        $acc = $acc + $wire.elems;
    }
    my $w = (now - $t0).Num * 1e9 / $N;

    ($p, $h, $w, $acc);
}

# Warm up the JIT and the router before sampling.
once();

my (@p, @h, @w);
for ^$REP {
    my ($pp, $hh, $ww, $acc) = once();
    @p.push: $pp; @h.push: $hh; @w.push: $ww;
    die "accumulator collapsed" unless $acc > 0;
}

printf "%-24s %8.1f ns/req\n", 'B  parse',             @p.min;
printf "%-24s %8.1f ns/req   (+%.1f routing)\n",   'C  parse+handle',  @h.min, @h.min - @p.min;
printf "%-24s %8.1f ns/req   (+%.1f serialise)\n", 'C" parse+wire',    @w.min, @w.min - @h.min;
say '';
printf "single-core ceiling: %.0f req/s\n", 1e9 / @w.min;
say "N=$N  REP=$REP  kernel={core-version()}";
