﻿use v6.d;
use lib 'lib';
use NativeCall;
use HTTP::Core::Native;
use HTTP::Core::Request;

# ---------------------------------------------------------------------------
# Layer A vs Layer B: how much does the Raku-side object cost on top of the C
# parser?
#
#   floor : empty loop, to subtract Raku's own loop overhead
#   A     : NativeCall straight into the kernel, no objects, no strings
#   B     : parse-request -> Request, touching method / path-only / one header
#
# Run:  raku -Ilib bench/01-layers.raku
#       N=500000 raku -Ilib bench/01-layers.raku
# ---------------------------------------------------------------------------

my $N = (%*ENV<N> // 200_000).Int;
my $WARM = ($N div 10) max 5_000;

sub make-small(--> Blob) {
    "GET /api/v1/users?page=2 HTTP/1.1\r\nHost: example.com\r\nUser-Agent: bench/0.1\r\nAccept: */*\r\n\r\n".encode;
}

sub make-wide(--> Blob) {
    my @h = "GET /api/v1/users?page=2 HTTP/1.1\r\nHost: example.com";
    @h.push: "X-Header-{$_}: value-{$_}-padding-padding" for ^28;
    (@h.join("\r\n") ~ "\r\n\r\n").encode;
}

sub make-body(--> Blob) {
    my $body = 'x' x 1024;
    "POST /api/v1/echo HTTP/1.1\r\nHost: example.com\r\nContent-Type: text/plain\r\nContent-Length: 1024\r\n\r\n$body".encode;
}

sub ns-per(Instant $t0, Int $n --> Str) {
    my $ns = (now - $t0).Num * 1e9 / $n;
    sprintf '%8.1f ns/req', $ns;
}

# --- floor: the cost of an empty Raku loop, which every other layer inherits ---

sub bench-floor(Int $n --> Str) {
    my $acc = 0;
    my $t0 = now;
    for ^$n { $acc = $acc + 1 }
    ns-per($t0, $n);
}

# --- layer A: pure C, native arrays reused across iterations -----------------

sub bench-native(Blob $raw, Int $n --> Str) {
    my size_t @m-off;  my size_t @m-len;
    my size_t @p-off;  my size_t @p-len;
    my int32  @minor;  my size_t @flat;
    my size_t @cap;    my int32  @ka;  my int64 @clen;

    # Touch the last slot so the buffers cover the range the kernel writes.
    @m-off[0] = 0; @m-len[0] = 0; @p-off[0] = 0; @p-len[0] = 0;
    @minor[0] = 0; @flat[4 * MAX-HEADERS - 1] = 0;
    @cap[0] = MAX-HEADERS; @ka[0] = 0; @clen[0] = -1;

    my $base = nativecast(Pointer[uint8], $raw);
    my $len  = $raw.elems.UInt;

    # Hoist every nativecast out of the loop. Building a Pointer wrapper per
    # argument per iteration costs more than the parse itself, and the native
    # arrays do not move, so the pointers stay valid.
    my Pointer $p-moff = nativecast(Pointer, @m-off);
    my Pointer $p-mlen = nativecast(Pointer, @m-len);
    my Pointer $p-poff = nativecast(Pointer, @p-off);
    my Pointer $p-plen = nativecast(Pointer, @p-len);
    my Pointer $p-minor = nativecast(Pointer, @minor);
    my Pointer $p-flat = nativecast(Pointer, @flat);
    my Pointer $p-cap  = nativecast(Pointer, @cap);
    my Pointer $p-ka   = nativecast(Pointer, @ka);
    my Pointer $p-clen = nativecast(Pointer, @clen);

    my $acc = 0;
    my $rc  = 0;

    my $t0 = now;
    for ^$n {
        # The kernel writes the header count back into the cap slot, so it has
        # to be reset every iteration or the second call reports garbage.
        @cap[0] = MAX-HEADERS;
        $rc = http_parse_request_flat(
            $base, $len,
            $p-moff, $p-mlen, $p-poff, $p-plen, $p-minor,
            $p-flat, $p-cap, $p-ka, $p-clen,
        );
        $acc = $acc + $rc;
    }
    my $r = ns-per($t0, $n);
    die "layer A failed (rc=$rc, acc=$acc)" if $rc < 0;
    $r;
}

# --- layer B: full Raku object, a few strings materialised -------------------

sub bench-object(Blob $raw, Int $n --> Str) {
    my $acc = 0;
    my $t0 = now;
    for ^$n {
        my $req = HTTP::Core::Request.parse($raw);
        # Reading these is what a router would do: two strings plus one lookup.
        $acc = $acc + $req.method.chars + $req.path-only.chars
                   + $req.header('user-agent').chars;
    }
    my $r = ns-per($t0, $n);
    die "layer B failed (acc=$acc)" if $acc < 0;
    $r;
}

# --- driver ----------------------------------------------------------------

my @cases =
    'small  (4 hdr)'  => make-small(),
    'wide   (30 hdr)' => make-wide(),
    'body   (1 KiB)'  => make-body(),
;

say "HTTP::Core layer benchmark";
say "N={$N}  warmup={$WARM}  kernel={HTTP::Core::Native::core-version()}";
say "raku {$*PERL.version}  moar {$*VM.version}";
say '';

# Warm up every path once so the JIT and the library are hot before timing.
bench-native(make-small(), $WARM);
bench-object(make-small(), $WARM);

my %floor;
%floor{$_} = bench-floor($WARM) for @cases>>.key;

say sprintf '%-16s %14s %14s %14s %10s', 'case', 'A (C only)', 'B (+object)', 'B-A', 'B/A';
say '-' x 74;

for @cases -> $c {
    my $label = $c.key;
    my $raw   = $c.value;

    my $a = bench-native($raw, $N);
    my $b = bench-object($raw, $N);

    my $na = +$a.comb(/[\d.]+/)[0];
    my $nb = +$b.comb(/[\d.]+/)[0];

    printf "%-16s %14s %14s %11.1f ns %8.2fx\n",
        $label, $a, $b, $nb - $na, $nb / $na;
}

say '';
say "floor (empty loop): {%floor.values[0]}";
say "done: {$N * 3} requests timed";
