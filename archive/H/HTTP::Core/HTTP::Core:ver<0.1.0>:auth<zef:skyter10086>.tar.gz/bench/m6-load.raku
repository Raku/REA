use v6.d;
use lib 'lib';
use HTTP::Core::Server;
use HTTP::Core::Client;
use HTTP::Core::Response;
use HTTP::Core::Transport::TCP;

# M6 load harness.
#
# Fires N concurrent GETs at one origin with max-per-host deliberately far below
# N, then reports the four numbers the milestone is judged on: how many requests
# succeeded, how many sockets were actually opened, the reuse rate, and how long
# callers sat in the queue.
#
#   raku -Ilib bench/m6-load.raku               # 64 requests, 4 per host
#   raku -Ilib bench/m6-load.raku --n=256 --max-per-host=4 --rounds=3
#
# A round is a burst of N requests; rounds reuse the same pool on purpose, so
# round 2 onwards shows the steady-state reuse rate rather than the cold start.

my Int $N        = 64;
my Int $max      = 4;
my Int $rounds   = 1;
my Bool $verbose = False;

for @*ARGS {
    given $_ {
        when /^'--n='(.+)/            { $N = $0.Int }
        when /^'--max-per-host='(.+)/ { $max = $0.Int }
        when /^'--rounds='(.+)/       { $rounds = $0.Int }
        when '--verbose'              { $verbose = True }
        default {
            note "unknown argument {$_}";
            exit 1;
        }
    }
}

my Int $port = free-port;
my Str $origin = "http://127.0.0.1:{$port}";

my $served = 0;
my Lock $tally .= new;          # handler runs on several scheduler threads

my $server = HTTP::Core::Server.new(:host('127.0.0.1'), :$port);
$server.router.get: '/hi', -> $req, %p {
    $tally.protect({ $served++ });
    HTTP::Core::Response.text('hi');
};
$server.start;

my Int $connects = 0;

my $client = HTTP::Core::Client.new(
    transport-factory => -> Str $o {
        $tally.protect({ $connects++ });
        HTTP::Core::Transport::TCP.connect('127.0.0.1', $port);
    },
    :timeout(30), :connect-timeout(3), :idle-timeout(30),
    :max-per-host($max),
);

my $failures = 0;

for 1 .. $rounds -> $round {
    my $t0 = now;
    my @ps = (^$N).map: -> $i { $client.request('GET', "{$origin}/hi") };

    my $bad = 0;
    my $i = 0;
    for @ps -> $p {
        my $r = await $p.then(-> $x { $x });
        $i++;
        next if $r.status == Kept;
        $bad++;
        my $c = $r.cause;
        note "round {$round} req#{$i} failed: {$c.^name}: {$c ~~ Exception ?? $c.message !! $c.gist}" if $verbose;
    }
    $failures += $bad;

    my %m = $client.pool.metrics-for($origin);
    my Real $secs = (now - $t0).Num.round(0.001);
    printf "round %d: n=%d ok=%d bad=%d wall=%.3fs connects=%d connected=%d fresh=%d reused=%d reuse-rate=%.4f peak-active=%d peak-queued=%d wait-avg=%.1fms wait-max=%.1fms\n",
        $round, $N, $N - $bad, $bad, $secs, $connects, %m<connected>,
        %m<fresh>, %m<reused>, %m<reuse-rate>, %m<peak-active>, %m<peak-queued>,
        %m<wait-ms-avg>, %m<wait-ms-max>;
}

my %m = $client.pool.metrics-for($origin);
say "--- totals ---";
say "requests   = {$N * $rounds}";
say "failed     = {$failures}";
say "connects   = {$connects} (cap = {$max})";
say "connected  = {%m<connected>}";
say "reuse-rate = {%m<reuse-rate>}";
say "served     = {$served}";
say "bound-ok   = ", ($connects <= $max ?? 'yes' !! 'no');
say "all-ok     = ", ($failures == 0 ?? 'yes' !! 'no');

$client.close;
$server.stop;

exit(($failures == 0 && $connects <= $max) ?? 0 !! 1);
