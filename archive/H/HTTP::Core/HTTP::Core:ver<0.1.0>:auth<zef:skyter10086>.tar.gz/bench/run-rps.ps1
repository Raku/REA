﻿# Layer D: real HTTP over a real socket, driven by oha inside WSL.
#
# WSL2 mirrored networking means the client can reach the Windows listener on
# localhost, so the load generator does not compete with the server for the
# same CPU cores.
#
#   .\bench\run-rps.ps1 -Handler const -Concurrency 1,8,32
#   .\bench\run-rps.ps1 -Handler const -Concurrency 8 -ShortConn
#   .\bench\run-rps.ps1 -Handler echo  -Concurrency 8 -Method POST -BodySize 1024
#
# Emits a markdown table row per scenario, ready to paste into RESULTS.md.

param(
    [int]      $Port        = 18900,
    [string]   $Handler     = 'const',
    # String, not [int[]]: `-File script.ps1 -Concurrency 1,4,8` is bound as the
    # single number 148, PowerShell having eaten the commas, which asks oha for
    # 148 connections. Parse it ourselves.
    [string]   $Concurrency = '1,8,32',
    [int]      $Duration    = 15,
    [switch]   $ShortConn,
    [string]   $Method      = 'GET',
    [int]      $BodySize    = 0
)

$levels = $Concurrency -split '[,\s]+' | Where-Object { $_ } | ForEach-Object { [int]$_ }
if (-not $levels) { throw "no concurrency levels parsed from '$Concurrency'" }

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$exe  = 'C:\rakudo\bin\raku.exe'

function Wait-Healthy([int]$p, [int]$tries = 60) {
    for ($i = 0; $i -lt $tries; $i++) {
        try {
            $r = Invoke-WebRequest "http://127.0.0.1:$p/health" -UseBasicParsing -TimeoutSec 2
            if ($r.StatusCode -eq 200) { return $true }
        } catch { }
        Start-Sleep -Milliseconds 250
    }
    $false
}

function Parse-Oha([string]$out) {
    $rps = 0.0; $p50 = '-'; $p99 = '-'; $avg = '-'
    if ($out -match 'Requests/sec:\s+([\d.]+)') { $rps = [double]$matches[1] }
    if ($out -match 'Average:\s+([\d.]+)\s*(\w+)') {
        $avg = "$($matches[1])$($matches[2])"
    }
    # oha prints "  50.00% in 0.4179 ms" — the percent carries decimals, so the
    # literal has to match that, and (?m) is required for a multi-line block.
    if ($out -match '(?m)^\s*50\.00% in ([\d.]+)\s*(\w+)') {
        $p50 = "$($matches[1])$($matches[2])"
    }
    if ($out -match '(?m)^\s*99\.00% in ([\d.]+)\s*(\w+)') {
        $p99 = "$($matches[1])$($matches[2])"
    }
    [pscustomobject]@{ Rps = $rps; P50 = $p50; P99 = $p99; Avg = $avg }
}

# --- start server ------------------------------------------------------------

$env:PORT    = "$Port"
$env:HANDLER = $Handler
$env:DEMO    = '900'

$srv  = Start-Process -FilePath $exe `
        -ArgumentList '-Ilib', 'bench\server-bench.raku' `
        -PassThru -NoNewWindow `
        -RedirectStandardOutput "$root\temp\rps-srv.out" `
        -RedirectStandardError  "$root\temp\rps-srv.err"

if (-not (Wait-Healthy $Port)) {
    Stop-Process -Id $srv.Id -Force -ErrorAction SilentlyContinue
    throw "server did not become healthy on port $Port"
}

Write-Host "server: handler=$Handler port=$Port pid=$($srv.Id)"

# --- body for POST -----------------------------------------------------------

$bodyArg = ''
if ($BodySize -gt 0) {
    $bodyArg = "-d '$('x' * $BodySize)' -T text/plain"
}

$url     = "http://localhost:$Port/bench"
$kaArg   = if ($ShortConn) { '--disable-keepalive' } else { '' }
$method  = if ($Method -ne 'GET') { "-m $Method" } else { '' }

"| handler | conn | c | RPS | avg | p50 | p99 | cores used |"
"|---|---|---|---|---|---|---|---|" | Write-Host

foreach ($c in $levels) {
    $srv.Refresh()
    $cpu0 = $srv.TotalProcessorTime.TotalSeconds
    $t0   = Get-Date

    $remote = "~/bin/oha -z ${Duration}s -c $c --no-tui $kaArg $method $bodyArg '$url' 2>&1"
    $out    = (& wsl -e sh -lc $remote) -join "`n"

    $elapsed = ((Get-Date) - $t0).TotalSeconds
    $srv.Refresh()
    $cores = ($srv.TotalProcessorTime.TotalSeconds - $cpu0) / [Math]::Max($elapsed, 0.001)

    $m    = Parse-Oha $out
    $ka   = if ($ShortConn) { 'close' } else { 'keep' }
    $h    = if ($BodySize -gt 0) { "$Handler/$BodySize" } else { $Handler }

    # Plain interpolation, not -f: mixing -f with a trailing pipe has silently
    # shifted columns here before.
    $rpsStr   = $m.Rps.ToString('N0')
    $coresStr = $cores.ToString('N2')
    Write-Host "| $h | $ka | $c | $rpsStr | $($m.Avg) | $($m.P50) | $($m.P99) | $coresStr |"

    if ($m.Rps -le 0) {
        Write-Host "--- oha output (first 25 lines) ---"
        ($out -split "`n" | Select-Object -First 25) | Write-Host
    }
}

# --- stop server -------------------------------------------------------------

Stop-Process -Id $srv.Id -Force -ErrorAction SilentlyContinue
Write-Host "server stopped"
