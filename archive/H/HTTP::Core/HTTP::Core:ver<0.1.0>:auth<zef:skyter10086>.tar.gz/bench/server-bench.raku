use v6.d;
use lib 'lib';
use HTTP::Core;
use HTTP::Core::Server;
use HTTP::Core::Response;

# ---------------------------------------------------------------------------
# Layer D: the same server the tests use, tuned for load.
#
#   PORT=18900 HANDLER=const raku -Ilib bench/server-bench.raku
#
# HANDLER:
#   const  -> returns 'ok'                (framing cost only)
#   json   -> returns a small JSON body   (framing + type guessing)
#   echo   -> echoes the request body     (adds subbuf + Content-Length)
#
# Binds 0.0.0.0 so the WSL2 client can reach it over the virtual switch.
# Nothing is printed per request: stdout on Windows is expensive enough to
# contaminate the measurement.
# ---------------------------------------------------------------------------

my $port    = (%*ENV<PORT> // 18900).Int;
my $handler = %*ENV<HANDLER> // 'const';
my $demo    = (%*ENV<DEMO> // 0).Int;

my $app = HTTP::Core::Server.new(
    :$port,
    :host('0.0.0.0'),
    # Generous limits: we want to measure throughput, not rejection paths.
    :max-body(16 * 1024 * 1024),
);

given $handler {
    when 'const' {
        $app.router.get: '/bench', -> $req, %p { 'ok' };
    }
    when 'json' {
        $app.router.get: '/bench', -> $req, %p {
            HTTP::Core::Response.json('{"ok":true,"n":42}')
        };
    }
    when 'echo' {
        $app.router.post: '/bench', -> $req, %p {
            HTTP::Core::Response.new(body => $req.body);
        };
    }
    default {
        die "unknown HANDLER=$handler (const|json|echo)";
    }
}

# A 404 route so a wrong URL is visible instead of silently timing out.
$app.router.get: '/health', -> $req, %p { 'alive' };

$app.start;

# One line only, after the listener is up.
say "ready port=$port handler=$handler kernel={core-version()}";

if $demo > 0 {
    sleep $demo;
    $app.stop;
    say "stopped";
}
else {
    react {
        whenever signal(SIGINT) { $app.stop; done }
    }
}
