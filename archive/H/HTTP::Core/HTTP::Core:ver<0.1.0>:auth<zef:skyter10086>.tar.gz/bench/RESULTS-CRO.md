# HTTP::Core vs Cro::HTTP — end-to-end comparison

Measured 2026-11-04 on WSL2 Ubuntu, Ryzen 7 8840HX (24 threads), Rakudo 2026.09,
MoarVM 2026.09. Cro::HTTP 0.8.13.

## Why this file exists

The in-process benchmarks (`05-ab-inproc.raku`, `11-stack-ab.raku`) compare routing
and serialisation in a single process. They say nothing about what happens once a
request has to cross a real TCP socket, get parsed by a real accept loop, and be
written back through a real kernel send buffer. This benchmark covers that layer.

## Method

* Two server processes, both bound to `0.0.0.0`:
  * `bench/server-bench.raku` (`PORT=18900 HANDLER=const`) — HTTP::Core
  * `bench/14-cro-server.raku` (`PORT=18901`) — Cro::HTTP
* Both answer `GET /bench` with the 2-byte body `ok` and `Content-Length: 2`.
  Response bytes were verified with curl before measuring, so framing is
  comparable (Cro adds a `Date` header, HTTP::Core does not; both are fixed-cost
  per response and part of what is being measured).
* Client: `bench/15-cro-vs-core.py`, a deliberately framework-neutral raw-socket
  HTTP/1.1 keep-alive client (Python threads, one socket per connection,
  `TCP_NODELAY`, no HTTP library on either side).
  It was written after a Raku version of the same client turned out to be
  unreliable around `IO::Socket::INET` binary-vs-text mode: `write()` demands a
  `Blob`, `print()` buffers without flushing, and mismatched combinations hang
  instead of erroring. That client was dropped rather than shipped broken.
* Each measurement: N connections, 200 requests per connection, keep-alive.
* Order bias: the client warms both servers first; the sweep alternates core /
  cro per round, and repeated rounds were taken in both orders.
* Numbers below are request latency measured from `sendall()` return to the last
  byte of the response body, i.e. they include client cost. The client cost is
  identical for both targets and therefore cancels in the ratio.

## Throughput

| conns | HTTP::Core rps | Cro::HTTP rps | ratio |
| ----: | -------------: | ------------: | ----: |
|     8 |           5480 |          2181 | 2.5x  |
|    16 |           4941 |          2413 | 2.0x  |
|    32 |           4614 |          2492 | 1.9x  |
|    64 |         4899 \* |          2516 | 1.9x  |

\* one of the two 64-connection runs against HTTP::Core timed out client-side
(see below); the figure is from the run that completed.

## Latency (microseconds, 16 connections x 200 requests)

| target     | mean  | p50  | p90   | p99   | max    |
| ---------- | ----: | ---: | ----: | ----: | -----: |
| HTTP::Core |  3121 | 2343 |  4331 | 33345 |  39738 |
| Cro::HTTP  |  5600 | 4203 |  5706 | 37866 |  45854 |

At 8 connections HTTP::Core's p50 drops to ~860 µs against Cro's ~2130 µs; the
gap narrows in relative terms as concurrency rises, because both servers become
bound by the same client-side thread cost and by WSL2 networking.

## What the numbers say

1. **Fixed-cost framing wins.** HTTP::Core's advantage (1.9x–2.5x) is larger
   end-to-end than the in-process serialisation gap, which is the expected
   direction: its parse path is a single FFI call into `http_wire` plus a
   `nativecast`, whereas Cro runs a pipeline of Raku-level `Supply` taps and
   middleware objects per request.
2. **Both plateau around 2–5 k rps on one core-pair.** Neither scales linearly
   with connections; the plateau is a client-side and WSL2 artifact as much as a
   server property. Absolute numbers here are not comparable to bare-metal nginx
   figures — only the ratio between the two targets is meaningful.
3. **HTTP::Core timed out on the first byte at high concurrency — root-caused
   and fixed.** In 1 of 2 runs at 64 connections, some client sockets hit the
   30 s timeout before the first byte. Cro::HTTP never did. It was never accept
   starvation; see the next section.

## The first-byte stall: a lost wakeup, not accept starvation

Symptom, at 64 connections × 200 keep-alive requests: one or two client sockets
get no first byte at all and give up after 30 s. The server logs nothing — no
`drop`, no framing error. Every other connection is unaffected.

What ruled out the obvious suspects:

| suspect | measurement | verdict |
| --- | --- | --- |
| listen backlog | `ss -ltn` on the listening socket: `Send-Q=128` | not the 64 the queue would need to overflow at, and the 64th connection was accepted |
| Raku accept loop | 63 of 64 connections served fine; the stalled one *had* been accepted (it is in the connection registry) | not accept |
| kernel receive buffer | `ss` sampled during a stall: `Recv-Q>0` never observed | bytes had already been read into userspace |
| `IO::Socket::Async` tap | `Transport` is a thin wrapper over `IO::Socket::Async.Supply(:bin)`, no filtering | the tap fires and data reaches `!feed` |

What it actually was, caught by dumping every connection's state on a timer:

```
pumping=False starved=True waiters=1 rbuf=64 eof=False
```

`rbuf=64` is a whole `GET` request sitting in the connection's byte buffer, with
a waiter parked behind it, `eof=False`, unchanged across six consecutive dumps
(30 s). The bytes arrived; the wakeup did not.

The ordering behind it — TCP delivered one request as two segments:

1. First segment arrives, `!feed` appends it and calls `!pump`. A waiter is
   parked, so the pump calls the decoder, which answers "need more bytes" —
   recorded as `starved = True` — and the loop breaks.
2. Second segment arrives while that pump is still finishing up. Its own `!pump`
   call is refused by the re-entrancy guard (`pumping` already true), which is
   correct: one pump is already running.
3. The running pump reaches its settle step, sees `starved`, and concludes there
   is nothing to retry. It clears `pumping` and returns. The parked waiter has
   now been written off by a verdict the bytes just delivered had already
   invalidated, and nothing else will ever call `!pump` again.

Two changes fix it, both in `HTTP::Core::Connection`:

* the settle step re-evaluates "may anything still make progress" *inside the
  lock* after clearing `pumping`, instead of trusting the `starved` snapshot it
  read on the way in;
* `!feed` clears `starved` when it appends bytes — fresh data invalidates the
  decoder's "need more" verdict by definition.

Why this survived earlier attempts: instrumenting the path with `note` calls
made it disappear. Writing a line to stderr per event widens the window between
the pump's decode and its settle enough that the second segment always lands
either well before or well after, never in between — eight consecutive rounds at
64 connections ran clean *with* logging on. The bug only shows itself on an
uninstrumented build, which is why a periodic timer snapshot (rather than a
per-event `note`) was the instrument that finally caught it.

Verification after the fix, all at `delay_ms=0` (the setting that triggers it):

| load | rounds | requests | stalled connections |
| --- | ---: | ---: | ---: |
| 64 conns × 200 | 15 | 192,000 | 0 |
| 96 conns × 200 | 5 | 96,000 | 0 |
| 128 conns × 200 | 3 | 76,800 | 0 |

The test suite (`prove6 -Ilib t/`, 16 files, 97 tests) stays green. Before the
fix, the same 64-connection setting stalled 1–2 connections roughly every second
or third round.

### The registry leak, fixed separately from the stall

The registry used to be keyed by `transport.id` -- the socket's memory address --
and `!drop` declared that key as `Str` while `transport.id` is an `Int`. The type
check threw inside the frame callback, the promise chain swallowed the exception,
and nothing ever deregistered: one entry per connection, for the life of the
process. Fixing the type alone was not enough, because the key itself was wrong:
an address is unique only among live sockets, so a recycled one let a teardown
miss its own entry -- and the old code handled a collision by *keeping* the stale
one. The key is now `Connection.serial`, a monotonic per-process counter that is
never reused, and the same serial is printed in both the accept and the drop line
so a pairing can be checked by eye.

Measured over 3 rounds x 64 keep-alive connections x 20 requests (3,840 requests):
192 accepts, 192 drops, 0 unpaired, and the registry reads 0 within 0.3s of each
round's close, 0 at the end. `t/17-registry-release.rakutest` pins the behaviour;
the suite is now 17 files / 101 tests, still green.

## Reproduce

```bash
# servers
PORT=18900 HANDLER=const raku -Ilib bench/server-bench.raku &
PORT=18901 raku bench/14-cro-server.raku &

# one measurement: <port> <conns> <requests-per-conn>
# prints: wall_s rps mean_us p50_us p90_us p99_us max_us
python3 bench/15-cro-vs-core.py 18900 16 200
python3 bench/15-cro-vs-core.py 18901 16 200
```

## Dependencies

Cro::HTTP 0.8.13 installed via `zef install Cro::HTTP --/test`. Note that
`JSON::JWT` (a Cro dependency) does not declare `Digest::HMAC` in its META6, and
`DateTime::Parse` had to be force-installed into the `site` repo before
`Cro::HTTP::Cookie` would compile; see the install transcript in the task log if
this needs to be repeated on a clean machine.
