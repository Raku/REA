use v6.d;
use lib 'lib';
use lib 't/fixtures';
use HTTP::Core::Request;
use HTTP::Core::Response;
use HTTP::Core::Codec;
use HTTP::Core::Codec::Raku;
use CurlCaptures;
use CurlResponses;

# What the M2 client primitives cost, and what the C encoder actually buys.
#
# Three questions, all of them measurement questions:
#
#   1. encode: is the C writer worth its FFI cost at the request sizes a client
#      sends? The Raku reference is the baseline -- it is the same algorithm
#      without the boundary.
#   2. Request.encode: the public path adds method dispatch over Codec plus a
#      header-pairs walk. If it lands far above Codec, the walk is the thing to
#      fix, not the kernel.
#   3. parse: a request image and a real chunked response image. This is the
#      cost a pooled client pays per request, so it is the number that decides
#      whether the pool is worth building.
#
# Noise-resistant: many short interleaved repeats, report the minimum. A shared
# desktop drifts 30-40% between runs; the minimum is the only comparable number.
#
# Run:  raku -Ilib -It/fixtures bench/12-codec.raku [N] [REP]

my $N   = (@*ARGS[0] // 20_000).Int;
my $REP = (@*ARGS[1] // 15).Int;

sub bench(Str $label, &body --> Nil) {
    my @t;
    for ^$REP {
        my $t0 = now;
        body($N);
        @t.push: (now - $t0).Num * 1e9 / $N;
    }
    printf "%-28s %9.1f ns\n", $label, @t.min;
}

# A request with a body and a handful of headers: the shape a client posts.
my %req =
    method  => 'POST',
    target  => '/api/v1/things?page=2',
    headers => (
        'Host'         => 'example.com',
        'Content-Type' => 'application/json',
        'User-Agent'   => 'HTTP-Core/0.3.0',
        'Accept'       => '*/*',
    ),
    body => '{"name":"x","n":42}',
;

my $req-wire = HTTP::Core::Codec::encode-request(|%req);
my $parsed   = HTTP::Core::Request.parse($req-wire);

# A real response off the wire, chunked, from the t/09 fixtures.
my %caps  = responses();
my $rwire = %caps<chunked-200><head> ~ %caps<chunked-200><body>;

# Warm the precompiler and any lazily-bound native symbol before timing.
HTTP::Core::Codec::encode-request(|%req) xx 50;
HTTP::Core::Codec::Raku::encode-request(|%req) xx 50;
HTTP::Core::Request.parse($req-wire) xx 50;
HTTP::Core::Response.parse($rwire) xx 50;
$parsed.encode xx 50;

say "request {$req-wire.elems} B, response {$rwire.elems} B, N=$N reps=$REP";
say '';

bench 'encode:c-request',     { HTTP::Core::Codec::encode-request(|%req)      for ^$N };
bench 'encode:raku-request',  { HTTP::Core::Codec::Raku::encode-request(|%req) for ^$N };
bench 'encode:Request.encode',{ $parsed.encode                                for ^$N };
bench 'parse:request',        { HTTP::Core::Request.parse($req-wire)          for ^$N };
bench 'parse:response-chunked', { HTTP::Core::Response.parse($rwire)          for ^$N };
