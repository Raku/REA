use v6.d;
use lib 'lib';
use lib 't/fixtures';
use HTTP::Core::Request;
use HTTP::Core::Codec;
use CurlCaptures;

# The M2 debt, measured on one page: parse, parse -> encode, kernel write.
#
# The claim under test was that a parse -> encode round trip costs about five
# times what the C writer costs on its own, and that the gap is not the kernel
# but the Raku-side materialisation: Request.parse writes byte offsets into an
# arena, then Request.encode asks for those offsets one header at a time as
# Str pairs, concatenates them into one Str, transcodes that Str back to bytes,
# and finally hands the bytes to C -- which copies them a third time.
#
# That path is still here, as `encode-reference`, because a benchmark that only
# measures the new code cannot show what the old code cost. Rows:
#
#   a) parse-only        Request.parse($wire)                  what a server pays
#   b) parse -> encode   Request.parse($wire).encode           the fast path
#   c) kernel write      Codec::encode-request(|%structured)    the C writer alone
#   d) parse -> encode   Request.parse($wire).encode-reference  the M2 path
#
# (c) is fed an already-structured request, so the difference between (b) and
# (c) is exactly the cost of getting from bytes to structure and back. (d) is
# the number this file was written to watch go down; it stays in the sweep so
# the before/after survives in one runnable command.
#
# Two corpora, because header count is the variable that matters: a 107-byte
# capture with four headers and a 193-byte one with five plus a binary body.
#
# Noise resistance: many short interleaved repeats, report the minimum (and the
# median as a sanity check). A shared desktop drifts 30-40% between runs; the
# minimum is the only comparable number.
#
# Run:  raku -Ilib -It/fixtures bench/13-roundtrip.raku [N] [REP]

my $N   = (@*ARGS[0] // 3_000).Int;
my $REP = (@*ARGS[1] // 11).Int;

sub bench(Str $label, &body --> Nil) {
    my @t;
    for ^$REP {
        my $t0 = now;
        body($N);
        @t.push: (now - $t0).Num * 1e9 / $N;
    }
    my @s = @t.sort;
    printf "%-26s min %8.1f  med %8.1f  ns\n", $label, @s[0], @s[(@s.elems - 1) div 2];
}

my %caps = captures();
my $wire = %caps<get-query>;
my $big  = %caps<post-form>;

# Structured counterparts of the two captures, for the kernel-only path.
my %small-req =
    method  => 'GET',
    target  => '/q?a=1&b=%20x&e=',
    headers => (
        'Host'       => '127.0.0.1:65079',
        'User-Agent' => 'curl/8.21.0',
        'Accept'     => '*/*',
        'X-Test'     => 'yes',
    ),
;

my %big-req =
    method  => 'POST',
    target  => '/form',
    headers => (
        'Host'           => '127.0.0.1:65083',
        'User-Agent'     => 'curl/8.21.0',
        'Accept'         => '*/*',
        'Content-Length' => '7',
        'Content-Type'   => 'application/x-www-form-urlencoded',
    ),
    body => 'a=1&b=2',
;

my $p-small = HTTP::Core::Request.parse($wire);
my $p-big   = HTTP::Core::Request.parse($big);

# Warm the precompiler, the native symbols and the lazy head-text cache.
HTTP::Core::Request.parse($wire) xx 50;
HTTP::Core::Request.parse($big) xx 50;
$p-small.encode xx 50;
$p-big.encode xx 50;
$p-small.encode-reference xx 50;
$p-big.encode-reference xx 50;
HTTP::Core::Codec::encode-request(|%small-req) xx 50;
HTTP::Core::Codec::encode-request(|%big-req) xx 50;

say "corpus small={$wire.elems} B (4 hdr)  big={$big.elems} B (5 hdr + body)  N=$N reps=$REP";
say '';

bench 'small parse-only',      { HTTP::Core::Request.parse($wire) for ^$N };
bench 'small parse->encode',    { HTTP::Core::Request.parse($wire).encode for ^$N };
bench 'small kernel-write',     { HTTP::Core::Codec::encode-request(|%small-req) for ^$N };
bench 'small roundtrip-codec',  { HTTP::Core::Request.parse($wire).encode-reference for ^$N };
say '';
bench 'big parse-only',         { HTTP::Core::Request.parse($big) for ^$N };
bench 'big parse->encode',      { HTTP::Core::Request.parse($big).encode for ^$N };
bench 'big kernel-write',       { HTTP::Core::Codec::encode-request(|%big-req) for ^$N };
bench 'big roundtrip-codec',    { HTTP::Core::Request.parse($big).encode-reference for ^$N };
say '';
bench 'big encode-only',        { $p-big.encode for ^$N };
bench 'big encode-only-codec',  { $p-big.encode-reference for ^$N };
