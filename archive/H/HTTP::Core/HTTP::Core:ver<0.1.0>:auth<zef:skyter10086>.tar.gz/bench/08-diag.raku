use v6.d;
use lib 'temp/ab/lib';
use lib 'lib';

use HTTP::Core::Router::Base;
use HTTP::Core::Router::New;
use HTTP::Core::Router::NoFast;

# ---------------------------------------------------------------------------
# Diagnostic: which half of the change costs 1 us on dynamic routes?
#
#   Base    — linear scan over a list of Hashes (the original)
#   NoFast  — parallel arrays, but the static-table probe disabled
#   New     — parallel arrays + static probe
#
# If NoFast ≈ Base, the probe is the cost. If NoFast is still slower than Base,
# the rewrite of the scan itself is at fault, and the probe is innocent.
#
# Run:  raku -Ilib -Itemp/ab/lib bench/08-diag.raku [N] [REP]
# ---------------------------------------------------------------------------

my $N   = (@*ARGS[0] // 30_000).Int;
my $REP = (@*ARGS[1] // 12).Int;

sub routes-for($r) {
    $r.get:  '/health',           -> $req, %p { 'alive' };
    $r.get:  '/api/v1/users/:id', -> $req, %p { 'ok' };
    $r.post: '/api/v1/users',     -> $req, %p { 'created' };
    $r;
}

my $base = routes-for(HTTP::Core::Router::Base.new);
my $nf   = routes-for(HTTP::Core::Router::NoFast.new);
my $new  = routes-for(HTTP::Core::Router::New.new);

for ($base, $nf, $new) -> $r {
    die 'dynamic mismatch' unless $r.match('GET', '/api/v1/users/42').[0]('x', %{}) eq 'ok';
    die 'static mismatch'  unless $r.match('GET', '/health').[0]('x', %{}) eq 'alive';
}

sub time-it(&body, Int $n --> Num) {
    my $t0 = now;
    body($n);
    (now - $t0).Num * 1e9 / $n;
}

sub bench-route($r, Str $path, Int $n --> Nil) {
    my $hit = $r.match('GET', $path);
    for ^$n { $hit = $r.match('GET', $path) }
    die 'router broke' unless $hit.defined;
}

my %res;
for ^$REP {
    for @(
        ('dynamic', '/api/v1/users/42'),
        ('static',  '/health'),
    ) -> ($label, $path) {
        %res{$label}<base>.push:   time-it({ bench-route($base, $path, $_) }, $N);
        %res{$label}<nofast>.push: time-it({ bench-route($nf,   $path, $_) }, $N);
        %res{$label}<new>.push:    time-it({ bench-route($new,  $path, $_) }, $N);
    }
}

for %res.keys.sort -> $k {
    my $b  = %res{$k}<base>.min;
    my $nf = %res{$k}<nofast>.min;
    my $n  = %res{$k}<new>.min;
    printf "%-9s base=%8.1f  nofast=%8.1f (%+6.1f%%)  new=%8.1f (%+6.1f%%)\n",
        $k, $b, $nf, ($nf - $b) / $b * 100, $n, ($n - $b) / $b * 100;
}
