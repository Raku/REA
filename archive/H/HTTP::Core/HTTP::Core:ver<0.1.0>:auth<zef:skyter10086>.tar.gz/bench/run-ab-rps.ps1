# Layer D A/B: same socket-level scenario, baseline vs optimised, alternating.
#
# Swapping module files means the server process has to be restarted anyway, so
# each measurement is its own process — unavoidable at this layer. Alternating
# A/B/A/B and comparing the best of each is the only defence against the
# machine drifting between runs.
#
#   .\bench\run-ab-rps.ps1 -Rounds 2 -Concurrency "8,64" -Duration 10

param(
    [int]    $Rounds      = 2,
    [string] $Concurrency = '8,64',
    [int]    $Duration    = 10,
    [int]    $Port        = 18900
)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$ws   = Split-Path -Parent (Split-Path -Parent $root)
$bl   = Join-Path $ws 'temp\baseline-opt3'
$nw   = Join-Path $ws 'temp\new-opt3'
$exe  = 'C:\rakudo\bin\raku.exe'
$levels = $Concurrency -split '[,\s]+' | Where-Object { $_ } | ForEach-Object { [int]$_ }

function Swap-In([string]$dir) {
    foreach ($f in @('Response.rakumod', 'Router.rakumod')) {
        Copy-Item (Join-Path $dir $f) (Join-Path $root "lib\HTTP\Core\$f") -Force
    }
}

function Wait-Healthy([int]$p, [int]$tries = 80) {
    for ($i = 0; $i -lt $tries; $i++) {
        try {
            $r = Invoke-WebRequest "http://127.0.0.1:$p/health" -UseBasicParsing -TimeoutSec 2
            if ($r.StatusCode -eq 200) { return $true }
        } catch { }
        Start-Sleep -Milliseconds 250
    }
    $false
}

$rows = @()

for ($r = 1; $r -le $Rounds; $r++) {
    foreach ($v in @(@{ n = 'BASE'; d = $bl }, @{ n = 'NEW'; d = $nw })) {
        Swap-In $v.d

        $env:PORT = "$Port"; $env:HANDLER = 'const'; $env:DEMO = '900'
        $srv = Start-Process -FilePath $exe `
                -ArgumentList '-Ilib', 'bench\server-bench.raku' `
                -WorkingDirectory $root -PassThru -NoNewWindow `
                -RedirectStandardOutput (Join-Path $ws 'temp\ab-srv.out') `
                -RedirectStandardError  (Join-Path $ws 'temp\ab-srv.err')

        if (-not (Wait-Healthy $Port)) {
            Stop-Process -Id $srv.Id -Force -ErrorAction SilentlyContinue
            throw "server ($($v.n)) never became healthy"
        }

        foreach ($c in $levels) {
            $srv.Refresh()
            $cpu0 = $srv.TotalProcessorTime.TotalSeconds
            $t0   = Get-Date
            $out  = (& wsl -e sh -lc "~/bin/oha -z ${Duration}s -c $c --no-tui 'http://localhost:$Port/bench' 2>&1") -join "`n"
            $elapsed = ((Get-Date) - $t0).TotalSeconds
            $srv.Refresh()
            $cores = ($srv.TotalProcessorTime.TotalSeconds - $cpu0) / [Math]::Max($elapsed, 0.001)

            $rps = 0.0; $p99 = '-'
            if ($out -match 'Requests/sec:\s+([\d.]+)') { $rps = [double]$matches[1] }
            if ($out -match '(?m)^\s*99\.00% in ([\d.]+)\s*(\w+)') { $p99 = "$($matches[1])$($matches[2])" }

            Write-Host ("{0,-4} r{1} c={2,-3} rps={3,8:N0}  p99={4,-10} cores={5,5:N2}" -f $v.n, $r, $c, $rps, $p99, $cores)
            $rows += [pscustomobject]@{ round = $r; tag = $v.n; c = $c; rps = $rps; p99 = $p99 }
        }

        Stop-Process -Id $srv.Id -Force -ErrorAction SilentlyContinue
        Start-Sleep -Milliseconds 800
    }
}

# Leave the optimised build in place.
Swap-In $nw

""
"--- best of $Rounds round(s)"
# No `-f` here: "{3:+7:N0}" is not a valid composite format and throws at
# runtime, after the measurements have already been taken.
$rows | Group-Object c | Sort-Object { [int]$_.Name } | ForEach-Object {
    $b = ($_.Group | Where-Object tag -eq 'BASE' | Measure-Object rps -Maximum).Maximum
    $n = ($_.Group | Where-Object tag -eq 'NEW'  | Measure-Object rps -Maximum).Maximum
    $d = $n - $b
    $pc = if ($b -gt 0) { $d / $b * 100 } else { 0 }
    "c={0,-3} base={1,8:N0}  new={2,8:N0}  delta={3,7:N0} ({4:+0.0;-0.0}%)" -f [string]$_.Name, $b, $n, $d, $pc
}
