# A/B micro benchmark driver.
#
# Swaps Response.rakumod / Router.rakumod between the baseline copies and the
# optimised copies, running bench/03-micro.raku after each swap. Alternating
# A/B/A/B instead of all-A-then-all-B keeps machine load drift from being
# attributed to the change.
#
#   powershell -File run-ab.ps1 -Rounds 2

param(
    [int] $Rounds = 2,
    [string] $N   = '40000',
    [string] $Rep = '20'
)

$ErrorActionPreference = 'Stop'
$base = Split-Path -Parent $PSScriptRoot
$root = Join-Path $base 'output\raku-http-core'
$bl   = Join-Path $base 'temp\baseline-opt3'
$nw   = Join-Path $base 'temp\new-opt3'
$raku = (Get-Command raku).Source
$out  = Join-Path $PSScriptRoot 'micro.txt'

$rows = @()

for ($r = 1; $r -le $Rounds; $r++) {
    foreach ($v in @(@{ n = 'BASE'; d = $bl }, @{ n = 'NEW'; d = $nw })) {
        Copy-Item (Join-Path $v.d 'Response.rakumod') (Join-Path $root 'lib\HTTP\Core\Response.rakumod') -Force
        Copy-Item (Join-Path $v.d 'Router.rakumod')   (Join-Path $root 'lib\HTTP\Core\Router.rakumod')   -Force

        Set-Location $root
        $p = Start-Process -FilePath $raku `
                -ArgumentList '-Ilib', 'bench/03-micro.raku', $N, $Rep `
                -WorkingDirectory $root -NoNewWindow -Wait -PassThru `
                -RedirectStandardOutput $out

        foreach ($line in (Get-Content $out -Encoding UTF8)) {
            if ($line -match '^(\S+)\s+([\d.]+) ns') {
                $rows += [pscustomobject]@{ round = $r; tag = $v.n; case = $Matches[1]; ns = [double]$Matches[2] }
            }
        }
    }
}

# Restore the optimised build as the working copy.
Copy-Item (Join-Path $nw 'Response.rakumod') (Join-Path $root 'lib\HTTP\Core\Response.rakumod') -Force
Copy-Item (Join-Path $nw 'Router.rakumod')   (Join-Path $root 'lib\HTTP\Core\Router.rakumod')   -Force

$rows | Group-Object case | ForEach-Object {
    $b = ($_.Group | Where-Object tag -eq 'BASE' | Measure-Object ns -Minimum).Minimum
    $n = ($_.Group | Where-Object tag -eq 'NEW'  | Measure-Object ns -Minimum).Minimum
    $d = $n - $b
    '{0,-20} base={1,8:N1}  new={2,8:N1}  delta={3,7:N1} ns ({4,6:N1}%)' -f `
        $_.Name, $b, $n, $d, ($d / $b * 100)
}
