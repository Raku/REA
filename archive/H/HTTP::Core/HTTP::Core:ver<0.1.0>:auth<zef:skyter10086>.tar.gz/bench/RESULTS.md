---
AIGC:
    Label: "1"
    ContentProducer: 001191440300708461136T1XGW3
    ProduceID: aed9bd2c2f3c6f83a54981e0ddb92ca2_2e9712b3d79811f18947525400de85a5
    ReservedCode1: fSeSm4GcwSfLB+CxuU+8D0ei6NW+FF1A8fN2YYVo2q6DYR7yfFFASeLoAY9Q6/KDRbs3VdFRzuYMilc3ymBWNydVEih5cB7ANg5wYZzs9X/5zAdIfZjTswi5UHmGoyPSI7HlNNUchNA38nGXUReB3Ck7vJMGpuQzc+POQ7MNCLgJJr7zlTz+Fhe0Ct0=
    ContentPropagator: 001191440300708461136T1XGW3
    PropagateID: aed9bd2c2f3c6f83a54981e0ddb92ca2_2e9712b3d79811f18947525400de85a5
    ReservedCode2: fSeSm4GcwSfLB+CxuU+8D0ei6NW+FF1A8fN2YYVo2q6DYR7yfFFASeLoAY9Q6/KDRbs3VdFRzuYMilc3ymBWNydVEih5cB7ANg5wYZzs9X/5zAdIfZjTswi5UHmGoyPSI7HlNNUchNA38nGXUReB3Ck7vJMGpuQzc+POQ7MNCLgJJr7zlTz+Fhe0Ct0=
---

---
AIGC:
    Label: "1"
    ContentProducer: 001191440300708461136T1XGW3
    ProduceID: aed9bd2c2f3c6f83a54981e0ddb92ca2_3bf38bdad68811f1b4e4525400cd780f
    ReservedCode1: w+9QJLZFu5XN/8lAdOaArizuF7O+DE1cJQ+ghdpkYtjG2uSQd6Ma5SiPoJQRST4WZe6HROvmf95ObICLBSosQaw9W0O69OrMFNcanN51bW1LPk3HGBr6C7kMl03MvtS008k9Lbh0QuLLTpYX4PnaOpLfAH2EsyrPYfYoO2DJk9zbrupN5/1knOM/l9Y=
    ContentPropagator: 001191440300708461136T1XGW3
    PropagateID: aed9bd2c2f3c6f83a54981e0ddb92ca2_3bf38bdad68811f1b4e4525400cd780f
    ReservedCode2: w+9QJLZFu5XN/8lAdOaArizuF7O+DE1cJQ+ghdpkYtjG2uSQd6Ma5SiPoJQRST4WZe6HROvmf95ObICLBSosQaw9W0O69OrMFNcanN51bW1LPk3HGBr6C7kMl03MvtS008k9Lbh0QuLLTpYX4PnaOpLfAH2EsyrPYfYoO2DJk9zbrupN5/1knOM/l9Y=
---



# HTTP::Core — 压测结果

目的不是拿一个 RPS 数字，而是回答**「慢在哪一层、还值不值得优化 C」**，
然后按数据动手，再看优化是否真的兑现。

## 环境

| 项 | 值 |
|---|---|
| CPU | AMD Ryzen 7 8840HX，12C/24T，2.9 GHz |
| OS | Windows 11 26300 |
| Raku | Rakudo Star 2026.09（MoarVM 2026.09） |
| 服务端 | Windows 侧 `bench/server-bench.raku`，绑 `0.0.0.0` |
| 压测端 | WSL2 Ubuntu 内 `oha 1.16.0` → `localhost`（mirrored 网络） |
| 内核 | `http-wire/0.1.0`，zig cc 编译 |

压测端与服务端不在同一 CPU 池，避免压测工具和被压对象抢核。代价是 loopback 走
vEthernet，**延迟绝对值偏大，只能横向比较**。

---

## 一、四层归因（进程内，不含 socket）

`bench/01-layers.raku` + `bench/02-dispatch.raku`，request 为 4 header 的 GET。

| 层 | 内容 | 初始 | 两轮优化后 | 变化 |
|---|---|---|---|---|
| floor | 空 Raku 循环 | 59 | ~100 | 噪声 |
| **A** | 直调 `http_parse_request_flat` | **1,003** | **~1,100** | 不变（C 侧没动） |
| **B** | `parse-request` → Request | **20,290** | **10,980** | **−46%** |
| **C** | + 路由 + handler | **45,291** | **31,516** | −30% |
| **C″** | + `payload` 序列化 | **87,715** | **67,836** | −23% |

> 初始 C″ 其实是 589,000 ns（sprintf 时代），见第三节。上表「初始」是修掉
> sprintf 与 slip 之后的基线。

第三轮曾把 parse 的九个 out-buffer 提进 `state` 复用，B 掉到 6~7 µs、C″ 到 57 µs，
单核 17,300 req/s。**该改动在多线程下串数据，已回滚**（详见第八节）。回滚后的实测：

| 层 | 两次独立运行 | 取值 |
|---|---|---|
| **B** | 16,897 / 16,854 ns | **16,854 ns** |
| **C** | 51,988 / 49,577 ns | **49,577 ns** |
| **C″** | 81,858 / 71,962 ns | **71,962 ns** |

单核理论天花板：`1e9 / 71,962 ≈ 13,900 req/s`（实测 13,896）。

### A vs 整体

- C 内核自身（纯 C 解析 2 KB 请求）：**1.0 µs**
- 占 C″ 的 1.6%，占真实请求（D 层饱和时 ~47 µs）约 2%

**优化 C 内核的收益上限约 2%，此路不通。**

### header 数量的放大效应

| 请求 | A | B（初始） | B（优化后） |
|---|---|---|---|
| 4 header | 1,003 ns | 22,767 ns | 21,356 ns |
| 30 header | 2,069 ns | 111,357 ns | **40,253 ns** |
| 1 KiB body | 1,043 ns | 29,150 ns | 22,101 ns |

C 侧 4→30 header 只多 1.1 µs，Raku 侧初始多 87 µs。**每 header 从 ~3.6 µs 降到
~1.4 µs**，靠的是不再切片装箱（见第三节 #5）。

---

## 二、整栈 RPS（D 层，真实 socket）

`bench/run-rps.ps1`，`-z 8~10s`，keep-alive。

| handler | conn | c | RPS（初始） | RPS（优化后） | p50 | p99 |
|---|---|---|---|---|---|---|
| const | keep | 1 | 2,584 | ~2,600 | 0.35 ms | 0.62 ms |
| const | keep | 4 | 7,926 | ~8,000 | 0.44 ms | 0.78 ms |
| const | keep | 8 | 10,480 | **13,034** | 0.52 ms | **1.15 ms** |
| const | keep | 16 | 14,059 | — | 0.97 ms | 9.48 ms |
| const | keep | 32 | 13,739 | **17,928** | 1.53 ms | 14.52 ms |
| const | keep | 64 | 16,485 | **21,093** | 2.34 ms | 19.70 ms |
| const | close | 8 | 3,983 | — | 1.45 ms | 21.90 ms |
| json | keep | 8 | 8,814 | — | 0.76 ms | 8.57 ms |
| echo POST 1 KiB | keep | 8 | 10,506 | — | 0.64 ms | 8.44 ms |
| echo POST 64 KiB | keep | 8 | 1,602 | — | 4.72 ms | 16.09 ms |

读法：

- **c=1 的 ~2,600 RPS 不是服务端极限**，是 0.35 ms 往返延迟限制的（WSL↔Windows 虚拟网络）。
- **c=8 时 p99 从 7.53 ms 降到 1.15 ms**，这是本轮优化最直观的收益：吞吐只 +24%，
  但尾部延迟改善 6.5 倍。
- **c 从 8 往上 RPS 继续涨**，21.1k @ c=64（表格为 state 复用版；回滚后 17.4k，
  p99 25.2 ms）。代价是 p99 显著恶化，队列在变长。真正的硬顶还没撞到。
- **短连接只有 keep-alive 的 38%**（3,983 vs 10,480），accept + 三次握手 + TIME_WAIT 很贵。
- **JSON 比纯文本慢 16%**，多出来的是 `Response.json` 的 headers hash。
- **64 KiB body 掉到 1,602 RPS**：大 body 走 `subbuf` 拷贝 + `Buf.append`，是 O(n) 的真实搬运。

---

## 三、优化记录（两轮，7 个热点）

| # | 问题 | 现象 | 修法 | 效果 |
|---|---|---|---|---|
| 1 | `sprintf` 拼 RFC1123 日期 | **单次 229 µs**，占响应 99% | 手写 `pad2` + 字符串拼接 | 229 µs → 0.5 µs |
| 2 | 每请求 `DateTime.now.utc` | 9.4 µs/次 | `time` 判秒 + `state` 缓存 | 9.4 µs → ~0 |
| 3 | `Buf.new: \|$head, \|$bytes` | slip 逐字节 VM 操作 | 先 encode 再单次 `append` | 序列化 464 → 42 µs |
| 4 | 每次路由都 `split` pattern | 2 条路由 42.6 µs | 注册时预编译段数组 | 42.6 → 25.0 µs |
| 5 | `@flat[^4n]` 整体切片装箱 | 每 header 3.6~5 µs | 闭包捕获 native 数组，按需读 | 30 header 111 → 40 µs |
| 6 | 响应头 `push`+`join`+`encode` | 6.6 µs | 字符串拼接 + 一次 encode | 6.6 → 3.0 µs |
| 7 | `Buf.new` + 两次 append | 4.4 µs | append 到刚 encode 的 head 上 | 4.4 → 1.5 µs |
| 8 | parse 缓冲复用（`state`） | 单核 14.7k → 17.3k req/s | 8 线程并发 47% 请求读到别线程的 header 表 | **已回滚**（见第八节） |

### 关键实现：为什么用闭包而不是数组属性

`Request` 要保留 C 内核写出的 header 偏移。直接切片成 Raku 数组会把每个元素装箱，
30 个 header 就是 120 次装箱；而把 native `size_t` 数组存成属性又会被 Raku 的容器语义
复制成普通 Array（等于又装箱一遍）。

可行解是**把 native 数组捕获进一个闭包**：

```raku
my $reader = -> Int $i { @flat[$i].Int };   # 闭包让 @flat 存活
self.bless(:$raw)!adopt(..., $reader, $n, ...);
```

闭包持有 native 数组的引用，对象活着数组就活着；只有真正被读的那个偏移才装箱。
`header('user-agent')` 只读 4~6 个值，而不是 4n 个。

### 汇总

| 指标 | 初始（sprintf 版） | 第一轮后 | 第二轮后 | 第三轮回滚后 | 净提升 |
|---|---|---|---|---|---|
| C″（parse+route+serialise） | 589,000 ns | 87,715 ns | 67,836 ns | **71,962 ns** | **8.2×** |
| 单核理论天花板 | 1,887 req/s | 11,401 req/s | 14,742 req/s | **13,896 req/s** | **7.4×** |
| D 层 c=8 | 9,420~10,480 | 12,839 | 13,034 | **13,082** | +24% |
| D 层 c=64 | 16,485 | 18,583 | 21,093 | **17,426** | +6% |
| D 层 c=8 p99 | 7.53 ms | 3.70 ms | 1.15 ms | **1.19 ms** | **6.3×** |

> c=8 回滚前后几乎一样（13,034 → 13,082），因为这一档受 WSL↔Windows 的往返延迟和
> 排队限制，不是 CPU。c=64 才把单核成本暴露出来：21,093 → 17,426（−17%），
> 与 parse 每请求多出的 ~10 µs 相称。**这正是「单核天花板 ≠ 整栈 RPS」的又一例证。**

RPS 提升远小于单核理论提升，因为 c≥8 时已经部分被网络和排队限制。**只看 RPS 会
得出「优化没效果」的错误结论**；p99 和单核成本才反映真实改动。

---

## 四、结论

| 假设 | 结果 | 依据 |
|---|---|---|
| H1：C 解析器不是瓶颈 | **成立** | 1.0 µs，占总量 2% |
| H2：瓶颈在 Raku 侧对象与序列化 | **成立** | parse 11 µs + 路由 20 µs + 序列化 36 µs = 68 µs 的 97% |
| H3：单线程事件循环决定上限 | **部分成立** | c=8 后增速放缓，但 c=64 仍能到 21k；p99 恶化 17× |

关于 CPU：高并发时 raku 进程消耗 3.6~4.5 核·秒/秒。单线程事件循环做不到，
这部分是 **MoarVM 的 GC 线程在并行回收**。减少每请求分配仍有实际收益，
且收益先以「p99 下降」的形式出现，与观测一致。

---

## 五、下一步（按 ROI 排序）

| 优先级 | 目标 | 做法 | 预期 |
|---|---|---|---|
| 高 | 序列化 36 µs | 响应头模板化：固定 4 行 + Content-Length 数字，避免每请求 3 次 `//` 与 hash 拷贝 | −10 µs |
| 高 | 路由 20 µs | `coerce` 不建临时 headers Hash；静态路径走 Hash 直查 | −15 µs |
| 中 | 大 body | `subbuf` 换视图/偏移传递，避免 64 KiB 拷贝 | 64 KiB 场景 ×2 |
| 中 | 多核 | 多 reactor + `SO_REUSEPORT` | 线性扩展，但要先修上面两条 |
| 低 | parse 17 µs | 合并 9 个 scratch 数组为 1 块内存 + `Pointer.add` 偏移，**仍每请求新建** | −4 µs（须先过 t/03） |

> 前两条已在第四轮完成，实测数据与复测方法见 §9。

按当前数据，做完前两条可把单核成本压到 ~40 µs，天花板约 25k req/s。

---

## 六、复现

```powershell
# 回归（prove6 自动发现 t/ 下面全部 .rakutest：10 文件 / 66 测试）
prove6 -Ilib t/

# 单文件跑
raku -Ilib t/01-parse.rakutest
raku -Ilib t/02-server.rakutest
raku -Ilib t/03-threads.rakutest   # 8 线程 × 20000 轮，任何跨调用缓冲复用都会在这里炸

# 层 A/B
$env:N=100000; raku -Ilib bench/01-layers.raku

# 层 C
$env:N=60000; raku -Ilib bench/02-dispatch.raku

# 层 D（需 WSL 内 ~/bin/oha）
.\bench\run-rps.ps1 -Handler const -Concurrency "1,4,8,16,32,64" -Duration 10
.\bench\run-rps.ps1 -Handler const -Concurrency "8" -Duration 10 -ShortConn
.\bench\run-rps.ps1 -Handler json  -Concurrency "8" -Duration 10
```

## 七、测量注意事项

1. **短连接别跑大数量**：Windows 动态端口约 16k、TIME_WAIT 120 s，超过后全是 connect 失败，
   RPS 会假跌。`-z` 计时比 `-n` 定量安全。
2. **`-Concurrency 1,4,8` 在 `-File` 模式下会被 PowerShell 吃掉逗号**，变成 `148`，
   于是 oha 开了 148 个连接。脚本已改成字符串再手工 split。
3. **前 2 秒不算数**：JIT 预热。用 `-z` 跑时长而不是固定请求数。
4. **不要在请求路径里 `say`**：Windows 上 stdout 重定向成本高到会污染数据。
5. **客户端要先确认不是瓶颈**：oha 在 WSL、服务在 Windows，两边核不重叠。
6. **floor 是关键校准**：空 Raku 循环在 59~194 ns 之间波动，纯属机器噪声。
   floor 抖动大时，同一次运行内的相对比较才可信，跨运行比较要用多次中位数。
7. **header 长度预筛必须用字节数**：`$name.chars` 对非 ASCII 头是错的
   （`X-名字` 是 6 字符但 10 字节），会把中文头整个筛掉。

## 八、一条教训：47% 错误的「胜利」

第三轮最关键的一次改动，也是唯一被完整推翻的一次。

### 起点：分配比解析还贵

`Request.parse` 每次要建 9 个 native 数组（8 个 scratch + 1 个 header 表），
外加 9 次 `nativecast(Pointer, ...)`。微基准单独测这一段：

| 做法 | 成本 |
|---|---|
| 9 个新数组 + 9 次 nativecast（原设计） | 7.5 ~ 9.2 µs |
| 8 个复用 + 1 个新建（`state`） | 2.4 µs |
| 只有 header 表那 1 个新建 | 2.1 µs |

比 C 内核（1.2 µs）还贵四倍。8 个 scratch 缓冲的**内容在方法返回前就被拷成 Int 属性**，
生命周期完全在调用内，看起来「复用绝对安全」。

于是把它们提进 `state`，连带把 8 个 `Pointer` 也缓存起来。单核天花板 14,742 → 17,300 req/s，
B 层 12.2 → 6.1 µs。数字漂亮。

### 崩在哪

写了 `t/03-threads.rakutest`：8 个线程各跑 20,000 次解析，校验每次读回的 header 名和值。

```
malformed request (rc=-1)
```

先怀疑是缓存 `Pointer` 失效（GC 移动），于是做了三版对照探针：

| 版本 | 做法 | 8 线程 × 64,000 次的错误数 |
|---|---|---|
| v0 | 每次调用新建 9 个数组 | **0 / 64,000　PASS** |
| v1 | `state` 数组，每次重新 `nativecast` | 29,853 / 64,000　FAIL |
| v2 | `state` 数组 + 缓存 `Pointer` | 27,309 / 64,000　FAIL |

**v0 完全正确，v1 与 v2 错误率相近（47% vs 43%）。** 缓存 Pointer 不是主因 ——
共享的数组本身就是问题。

结论：**Rakudo 2026.09 里方法内的 `state` 变量在本场景并不是线程隔离的。**
（`state` 的 thread-local 语义在规范里成立，但实测多线程会互相覆盖。）
一旦复用，两个线程同时写同一个 `@cap[0]`，C 内核读到 `cap=0` 就返回 `-1`；
即使侥幸解析成功，header 表的偏移也已经是别线程的。

### 为什么单线程 benchmark 发现不了

`bench/02-dispatch.raku` 是单线程跑 100,000 次，串行执行，复用缓冲永远 "刚刚好被自己覆盖"。
这不是「压测不够狠」，是**观测维度缺失**：只测了吞吐，没测隔离性。

修法不是调参数，是**放弃共享**。回滚后代码里留了注释，写明这条路试过、为什么不通，
免得后来的人（包括我自己）再走一遍。

### 顺带修掉的探针错误

排查过程中探针本身错了三次，都是同一个教训 —— 猜测 API 语义而不看返回值：

| 错误 | 真相 |
|---|---|
| 以为 header 名在 `@m-off[1..]` | 实际 header 表全在 `@flat`，四元组 `(name-off, name-len, value-off, value-len)`；`@m-off/@p-off` 只存 method 和 path 各 1 项 |
| 以为 `rc==0` 是成功 | 成功时 `rc` 是**消耗的字节数**（48），header 数量写在 `@cap[0]` |
| 用 `@cap[0]` 当 header 数做校验 | 对，但要在 kernel 返回后读，且不能用 `$rc` 代替 |

三次错误都表现成「100% 失败」，看起来像数据竞争，实际是探针 bug。**先怀疑探针，再怀疑并发。**

### 收益结算

| 项 | 状态 |
|---|---|
| 序列化侧（`Response.payload` 字符串拼接 + 单次 append） | 保留，−32%（24.8 → 16.9 µs） |
| parse 侧（`state` 复用） | **回滚**，收益归零 |
| `t/03-threads.rakutest` | 保留，8 线程 × 20,000 轮，0 错 |
| 真实 C″ | 71,962 ns（而非 57,000） |
| 整栈 c=64 | 17,426 req/s（而非 21,093） |
| 整栈 c=8 / p99 | 13,082 req/s / 1.19 ms（与复用版持平） |

最终单核 13,896 req/s，相对最初 1,887 是 7.4×。第三轮本想再拿 17%，最后拿到的是
**一个会静默返回别人数据的 bug 被提前拦住**。


## 九、第四轮：模板化与静态直查

第三轮那张表里排在前面的两条（序列化模板化、路由静态直查），这轮做完了。结论先给：
**两条都保留，但只有一条的收益符合预期，另一条的真实收益被单点微基准夸大了三倍。**

### 序列化：无头响应走固定模板

`Response.payload` 原先无论有没有自定义头，都要走一遍 `%!headers` 的遍历和拼接。
实际服务里绝大多数响应是「状态行 + 3~4 个固定头」，于是加了一个无头分支：
`%!headers.elems == 0` 时直接拼固定模板，不做 hash 查找。顺带 `body-bytes`
返回 `encode` 出来的 Blob 本身，省掉一次 `.Buf` 拷贝；空 body 时用
`$out.append($body) if $body.elems` 跳过慢路径。

同进程 A/B（`bench/05-ab-inproc.raku`，N=30000，REP=12~20，取各轮最小值）：

| 场景 | BASE | NEW | delta |
|---|---|---|---|
| payload:no-headers | 11,394 ns | 9,700 ns | **−14.9%** |
| payload:no-headers（另一次运行） | 9,783 ns | 8,238 ns | **−15.8%** |

比预测的 36 → 26 µs 小得多。原因很简单：**微基准里的响应本来就没几个头**，
模板化省掉的是「4 个头 × 每个一次 hash 读」，本来就只有 1~2 µs。第三轮预测的
「−10 µs」是把「序列化总耗时」当成了「头拼接耗时」。带自定义头的响应只测到 −6.6%。

### 路由：静态路径单次 hash 直查

`Router` 加了 `%!static` 索引。第一版索引是 `%!static{$method}{$path}`，**两个 hash 探测**，
结果动态路由（必然 miss）反而变慢；改成 `{$path}{$method}` 单探，miss 成本减半。
再加 `classify()`：注册时就把每条路由算好 `(static, wild)`、段数存进平行数组，
`match` 的线性扫描里用 `@!r-wild[$i] || @!r-nsegs[$i] == $nx` 提前拒掉段数不符的候选，
省掉的是一次 `match-segs`——而 `match-segs` 每次都要分配一个 params Hash。

单个用例的微基准（`05-ab-inproc.raku`）：

| 场景 | BASE | NEW | delta |
|---|---|---|---|
| route:static | 7,971 ns | 1,939 ns | **−75.7%** |
| route:static（另一次） | 7,716 ns | 1,648 ns | **−78.6%** |
| route:dynamic | 13,868 ns | 15,534 ns | **+12.0%** |

静态 −76% 看着漂亮，动态 +12% 就成了问题。于是做诊断（`bench/08-diag.raku`）：
把新实现复制一份，只把 `my $slot = %!static{$path};` 改成 `my $slot = Nil;`，
单独测「关掉静态探测」的版本。

| 场景 | BASE | NEW（关探测） | NEW（开探测） |
|---|---|---|---|
| route:dynamic（run1） | 13,098 ns | 10,868 ns（−17.0%） | **9,578 ns（−26.9%）** |
| route:dynamic（run2） | 12,960 ns | 11,979 ns（−7.6%） | **10,846 ns（−16.3%）** |
| route:static（run1） | 7,498 ns | 7,748 ns（+3.3%） | 3,562 ns（−52.5%） |

**同一个新版 Router，在 `05` 里测出 +12%，在 `08` 里测出 −27%。** 代码一模一样，
路径一模一样。差别只有一个：`05` 先测静态再测动态，`08` 先测动态再测静态。

### 真正的教训：微基准被调用顺序带偏

不是噪声，是可复现的顺序依赖。MoarVM 的 spesh 会针对调用点上「见过的形态」做特化：
在 `05` 里 `rn.match(...)` 这个调用点先是跑了几十万次静态命中（走快路径），
特化就偏向快路径；接下来同一个调用点跑动态（走慢路径）时，特化失效、重新特化，
这一段开销全被算进了 dynamic 的账上。`08` 里顺序反过来，动态先跑，于是它拿到了全部好处。

两个脚本各自连跑两三次都稳定复现同一方向，说明这不是随机抖动，而是**测量方法本身
在说谎**——单点微基准测的是「在某段特定预热历史之后，这条代码要多久」，不是「这条代码要多久」。

修法不是调参数，是换测量对象：**测混合负载**。

`bench/09-mixed.raku` 里只留一个调用点，一条 12 项的计划表（4 静态 + 8 动态，
约 1/3 : 2/3，接近真实 API 服务的比例），两种实现交替跑，比总 ns/dispatch：

| 运行 | BASE | NEW | delta |
|---|---|---|---|
| run1（min） | 14,958 ns | 12,629 ns | **−15.6%** |
| run2（min） | 16,021 ns | 13,013 ns | **−18.8%** |
| run3（min） | 15,334 ns | 12,487 ns | **−18.6%** |
| 中位数参照 | 18,450~19,256 ns | 14,730~16,295 ns | 同向、幅度更大 |

三次方向一致、幅度集中，这才是可信的数字。真实服务器本来就不会「先全天跑静态、
再全天跑动态」，把两者拆开测出来的两个数字，都没有对应的现实场景。

### 真实 socket 压测

`bench/run-ab-rps.ps1`：两轮 BASE/NEW 交替，每轮重启服务进程（换模块文件必须重启），
oha 在 WSL 打 Windows 侧监听，`-z 10s`，取各档最好成绩。

| conn | BASE | NEW | delta | p99 BASE | p99 NEW |
|---|---|---|---|---|---|
| c=8 | 13,035 / 13,322 | 14,564 / 14,345 | **+9.3%** | 1.18 / 1.10 ms | **1.03 / 1.06 ms** |
| c=64 | 23,186 / 23,521 | 24,190 / 24,481 | **+4.1%** | 16.83 / 16.81 ms | 15.93 / 17.17 ms |

两点必须说明：

1. **本轮的 BASE c=64 是 23,521，上一轮记录的是 17,426。** 同一份「未优化」代码，
   跨批次差 35%。这台机器不是受控实验台：后台进程、Windows 更新、WSL 内存回收都会动。
   所以**绝对 RPS 只能同批次比较**，跨章节的数字不可相减。§3 的汇总表当作历史记录看。
2. c=64 的收益（+4.1%）远小于单核收益（路由 −18%），与第三轮同一个规律：
   这一档已经撞在 WSL↔Windows 往返还和排队上，CPU 省下来的时间不直接变成吞吐。
   但 p99 和 CPU 秒数会动——NEW 的 cores 从 4.69/4.45 降到 4.19/4.36，方向正确。

### 回归

```powershell
raku -Ilib t/01-parse.rakutest    # 10/10 pass
raku -Ilib t/02-server.rakutest   # 13/13 pass
raku -Ilib t/03-threads.rakutest  # 8 线程 × 20,000 轮，mismatches=0，PASS thread isolation
```

本轮两条改动都不跨请求持有状态（`%!static` 是只读索引，注册后不再写；
`payload` 每请求新建字符串），所以 `t/03` 依旧全绿。**这不是巧合，是设计约束**：
§8 那次事故之后，任何要跨调用存活的缓冲，都必须先在 `t/03` 里证明隔离性。

### 复现命令

```powershell
# 同进程 A/B（推荐，进程间漂移可到 12%~35%）
raku -Ilib -Itemp/ab/lib bench/05-ab-inproc.raku 30000 20
raku -Ilib -Itemp/ab/lib bench/08-diag.raku     30000 12
raku -Ilib -Itemp/ab/lib bench/09-mixed.raku    60000 15   # 唯一可信的路由结论

# 真实 socket A/B
.\bench\run-ab-rps.ps1 -Rounds 2 -Concurrency "8,64" -Duration 10
```

`temp/ab/lib/HTTP/Core/{Router,Response}/{Base,New,NoFast}.rakumod` 是命名空间改写过的
对照副本，`lib/` 下始终是当前实现；`temp/new-opt3`、`temp/baseline-opt3` 是给
`run-ab-rps.ps1` 用的整文件快照。

## 十、第五轮：整栈同进程 A/B 基础设施 + parse 内存合并

### 基础设施：先有尺子，再动手

前四轮的「改后」数字都来自另一个进程，而这台机器跨进程漂移实测 12%~35%，
5 µs 的解析收益根本藏不住。这一轮先把尺子造出来：

| 部件 | 作用 |
|---|---|
| `tools/gen-ab-full.py` | 把 `lib/HTTP/Core/*` 整栈 6 个模块复制成 `HTTP::Core::Alt::*`，只改包名，其余字节一致 |
| `bench/11-stack-ab.raku` | 同一 VM 里加载两套整栈，各自的 Router/Server/端口；先跑 equivalence gate（同输入同输出），再交替 A,B,B,A 计时 |
| `tools/ab-full-report.py` | 每层单开进程跑 K 次，取中位数 delta 并打印区间；区间就是这台机器的诚实误差棒 |

首次运行（两边同源）必须报 ~0%，否则是基建偏置，不能用来评估改动。本轮校准后
run-to-run 区间 +64%..+85% 全部同向、无跨零现象。

### parse 内存合并：第一版比不改还慢

目标是把内核写出的 9 个 out-参数从「9 个 native array」合并成「1 块 `size_t` 内存 +
`Pointer.add` 偏移」，每请求仍新建（跨请求复用会触发 §8 的串数据事故）。

第一版按计划落地，`bench/11-stack-ab.raku` 当场否掉：

| 层 | 9 数组（旧） | 1 arena + Pointer.add（第一版） | delta |
|---|---|---|---|
| parse | 10,073 ns | **30,102 ns** | +66.1%（更慢） |

把账拆开看，问题不在方案而在 `Pointer.add` 的单价：

| 操作 | 单价 |
|---|---|
| `Pointer.add`（含 deref） | ~1.1 µs |
| `CArray[size_t]` 下标读 | ~0.35 µs |
| 9 个 native array 分配 | 6.7 µs |
| `size_t @arena` 增长到 264 槽 | 9.2 µs |
| `CArray[size_t]` 分配 264 槽 | **2.5 µs** |

11 次 `Pointer.add` ≈ 12 µs，比它想省下的分配钱（6.7 µs）还贵一倍。Raku 侧指针运算
不是免费的，这条必须写进结论。

### 第二版：让 C 自己算槽地址

内核新增 `http_parse_request_arena(buf, len, arena, arena_slots, max_headers)`：
Raku 只传一个基址，C 侧按固定布局写全部槽位（8 个标量 + 4×64 header 四元组），
所有槽统一写满 8 字节，Raku 用 `CArray[size_t]` 读，不需要任何类型化指针视图。

Raku 侧因此只剩：1 次分配、1 次 nativecast、1 次调用、7 次下标读。

| 层 | 旧（9 数组 + flat 入口） | 新（CArray arena + arena 入口） | delta |
|---|---|---|---|
| parse | 11,835 ns | **6,676 ns** | −43.6%（−5,159 ns） |
| parse+handle | 40,561 ns | 35,138 ns | −14.0% |
| parse+handle+wire | 66,911 ns | 57,739 ns | −13.7% |

（N=3000 REP=12 WARM=8000 RUNS=5，每层单进程；parse 区间 +64.1..+85.6% 全部同向）

### 但是：这套 harness 有约 +10% 的系统偏置

跑完立刻把 Alt 副本重生成成当前代码（两边同源），再测一遍，结果不是 0：

| 层 | 同源 base | 同源 alt | 偏置 |
|---|---|---|---|
| parse | 6,346 ns | 6,781 ns | **+12.3%** |
| parse+handle | 39,986 ns | 43,270 ns | +10.1% |
| parse+handle+wire | 68,052 ns | 69,015 ns | +2.7% |

Alt 副本系统性偏慢，与「`lib/` 的实现先被 `use`、Alt 后加载」的顺序一致（spesh 与
inline 缓存先给先来的那份）。所以上面的表必须扣偏置再读：

| 层 | 实测 delta | 系统偏置 | 净效应 |
|---|---|---|---|
| parse | −43.6% | +12.3% | **−50% 量级，结论成立** |
| parse+handle | −14.0% | +10.1% | 约 −4%，落在噪声里 |
| parse+handle+wire | −13.7% | +2.7% | 约 −11%，方向可信、幅度存疑 |

parse 层收益远超偏置，可以当事实用（绝对 −4.4~−5.2 µs/req，多次同向）；整栈层被
Router/Server 的抖动吃掉，本轮不给强断言。下一轮该改 harness：两套实现的加载顺序
各测一次再平均，而不是只测一种顺序。

另外，旧 9 数组版同一天内测到 10,073 ns（校准轮）和 11,835 ns（对比轮）——本机
跨进程漂移依旧，跨章节数字不可相减。

### 真实 socket（弱证据，仅同批次可比）

单连接 keep-alive 顺序打 20,000 请求，两版交替 4 轮取最好：

| 版本 | µs/req |
|---|---|
| 新 | 211 |
| 旧 | 227 |
| delta | **−6.8%** |

这台机器上每请求 200 µs+ 的 socket/唤醒开销把 5 µs 的差异埋进噪声（同版本跨轮波动
12%），并发 RPS 更是两边一起撞客户端瓶颈。**真实链路的结论以微基准为准**，socket 只
用来确认方向不反。

### 回归

```powershell
raku -Ilib t/01-parse.rakutest    # 10/10
raku -Ilib t/02-server.rakutest   # 13/13
raku -Ilib t/03-threads.rakutest  # 8×20,000，mismatches=0，PASS
```

arena 依然每请求新建。这一点不因为「CArray 分配只要 2.5 µs」而放松：§8 的 47%
来自跨调用复用，`state` 在 Rakudo 里不是线程本地的。

### 复现命令

```powershell
gcc -shared -O3 -fPIC -o resources/libraries/http_wire.dll -I src src/http_wire.c
python tools/gen-ab-full.py          # Alt 副本 = 当前基线
python tools/ab-full-report.py 3000 12 5 --layer parse
python tools/ab-full-report.py 3000 12 5
```


## 十一、第六轮：序列化快路 + 路由内核真正落地

### 1. 序列化：`Str.encode` → `nqp::encode`

`bench-ser/ladder` 把 `payload` 的 4.27 µs 拆开，最大一块是 `body-bytes` 的 2.28 µs，
其中 `Str.encode` 独占约 2.0 µs —— 它走的是一条「建 encoder、验编码名、再编码」的
通用路径。`nqp::encode` 是同一件事的底层入口，没有这些前置。

`lib/HTTP/Core/Bytes.rakumod` 新增：

```raku
sub str-bytes(Str $s --> Buf:D) { nqp::encode($s, 'utf8', buf8.new) }
```

`Response.body-bytes` 与 `payload-raku` 改用它。`probe-nqp-encode.raku` 对 16 类字符串
（ASCII / CJK / emoji / 组合字符 / 代理对边界）逐个比对字节，与 `.encode` 完全一致；
返回类型是 `Buf[uint8]`，与 `.encode` 的 `utf8` 只在容器类上不同，`payload` 下游只读字节。

| 层 | 改前 | 改后 |
|---|---|---|
| l1+body-bytes | — | 450 ns |
| l3+nativecast | — | 1,139 ns |
| l7 payload | 4,270 ns | **2,143 ns（−50%）** |

`t/04` 六项全绿（含并发自洽）。

### 2. 路由：内核从「永远返回 −1」到真正接下全部形状

第四轮做好的 `http_route_match` 一直没在线上跑：`Router` 侧 `$!out` 用
`CArray[size_t].new(4 + 4 * 16)` 创建，而 **Rakudo 2026.09 的 `CArray[T].new(Int)` 把
参数当成「单个初始值」，不是元素个数** —— 实际 `elems == 1`。于是 `out_slots` 传成 1，
C 侧 `if (out_slots < 4) return -1` 直接拒单，每个请求都在付一次 FFI 之后回到纯 Raku 走表，
比不做优化还慢（混合负载 +9.7%）。

同一个坑还有两处：

- `Request.parse` 的 arena 用 `CArray[size_t].new` 再写末槽「触发分配」，在此版本上
  只分配了 1 个槽，越界写 264 槽的长度 —— 能跑，但那是堆上的运气。
- 新增的 scratch 用 `Buf.new(1024)`，同样只得到 1 字节，`*` 捕获永远 `need > cap`。

正确写法是 `CArray[T].allocate($n)` 与 `Buf.new(0 xx $n)`。修完后：

- 内核接下命中 / 405 / miss 三种形状，`*` 捕获改由 C 侧拼进 scratch（`Buf` 视图直接
  `subbuf(...).decode` 读回），不再回退到 Raku 走表；
- `add()` 置 `$!stale`，`match()` 首次调用才 `nativecast` 三个表指针并缓存 —— 省掉每请求
  4 次 `nativecast`。

分场景（同进程交替，`temp/router-cases.raku`，30,000 × 7）：

| case | BASE ns | NEW ns | delta |
|---|---|---|---|
| static `/health` | 1,593 | 1,916 | +20%（纯顺序偏置，见 §八） |
| param `/api/v1/users/42` | 12,638 | 10,415 | **−18%** |
| wild `/files/a/b/c.txt` | 26,325 | 11,843 | **−55%** |
| miss `/nope/x` | 14,496 | 7,819 | **−46%** |
| 405 `POST /health` | 19,885 | 7,523 | **−62%** |

混合负载（`bench/09-mixed.raku`，4 静态 + 8 动态）：

| 运行 | BASE | NEW | delta |
|---|---|---|---|
| 40k × 11 | 11,135 ns | 7,345 ns | **−34.0%** |
| 40k × 11 | 10,879 ns | 7,398 ns | **−32.0%** |
| 60k × 9 | 11,358 ns | 7,251 ns | **−36.2%** |

三次同向、幅度集中。上一轮同一个脚本报出 +9.7%（那时内核还在拒单），这轮才是内核的真实形状：
**收益集中在动态路由**（param −18%、wild −55%、miss −46%、405 −62%），静态快路径与它无关。

整栈（`bench/11-stack-ab.raku 20000 7`，Alt 副本是「序列化与路由都还没做」的基线）：

| 层 | BASE（优化后） | ALT（优化前） | delta |
|---|---|---|---|
| parse | 6,388 ns | 6,950 ns | −8.1% |
| parse+handle | 31,559 ns | 41,950 ns | **−24.8%** |
| parse+handle+wire | 34,991 ns | 65,379 ns | **−46.5%** |

这组数字含序列化收益，不能单独归给路由；且 Alt 是上一轮生成的副本，跨批次只能读方向。

### 3. 回归

```powershell
raku -Ilib t/01-parse.rakutest          # 10/10
raku -Ilib t/02-server.rakutest         # 13/13
raku -Ilib t/03-threads.rakutest        # 8×20,000，mismatches=0，PASS
raku -Ilib t/04-serialization.rakutest  # 6/6（含并发自洽）
raku -Ilib t/05-routing-diff.rakutest   # 3/3（内核与参考实现 2,135 次查表一致）
```

`Router` 现在持有 `Buf $!scratch` 与三个指针缓存，属于跨请求存活状态 —— `t/03` 的
8×20,000 依旧 mismatches=0，因为 scratch 每次命中先被 C 侧写满再读，指针缓存只在
`add()` 之后重建。这两条是选 `$!stale` 而不是 `state` 的原因。

### 4. 复现命令

```powershell
python tools/gen-router-ab.py                                  # Router Base/New 副本
raku -Ilib -Itemp/ab/lib temp/router-cases.raku 30000 7        # 分场景
raku -Ilib -Itemp/ab/lib bench/09-mixed.raku 40000 11          # 混合负载（结论依据）
raku -Ilib -Itemp/ab/lib bench/11-stack-ab.raku 20000 7        # 整栈
```

## 十二、第七轮：把测量偏置本身测出来

上一轮把「静态 +20%」记成了加载顺序偏置，并计划「两套实现各反向跑一轮再平均」。
这一轮真的做了，结论有两处跟计划不一样：顺序项确实能消掉，但那 20% 根本不是顺序。

### 1. 双序工具链

`tools/gen-ba.py` 从 AB 脚本生成镜像副本（`use` 与 `build` 顺序对调，
`bench/11-stack-ba.raku`、`temp/router-cases-ba.raku`），`tools/ab-sym.py` 按
**AB → BA → BA → AB** 的顺序跑四个进程，对每个层/大小格算：

```
r_ab = T_alt / T_base   (base 先加载)
r_ba = T_alt / T_base   (alt  先加载)
r    = sqrt(r_ab * r_ba)          对称后比值
d    = sqrt(r_ab / r_ba) - 1      首加载侧白拿的优势
```

四段交错是为了让「整段会话的机器漂移」也落不到某一侧。`d` 才是顺序偏置，
`r` 里剩下的才是真差异。

### 2. 两个把结果读反的 bug

- `tools/ab-sym.py` 的比值方向写反了（用的是 `T_base / T_alt`），于是 delta
  符号与表头的「negative = alt faster」正好相反。旧的对称数字全部反读，
  已修正。
- 同一脚本解析 router 输出时要求 case 名里含 `/`，改名成 `static 32 paths`
  之后整行被静默丢弃。改为按「两个浮点数 + 带百分号的括号」定位。

另外 `tools/gen-ab-full.py` 漏了 `HTTP::Core::Bytes` 的共享改写。`Response`
现在 `use` 它，副本一编译就报 `Could not find HTTP::Core::Alt::Bytes`，
`bench/11-stack-ab.raku` 直接跑不起来。`Bytes` 与 `Native` 同属基元层，
一并按共享处理。

### 3. 同源校准：先量出地板

两侧源码完全一致时的 delta，就是这个 harness 的噪声底。

`bench/11-stack-ab.raku 6000 5`，cycles=2：

| 层 | 对称 delta | order bias |
|---|---|---|
| parse | +8.6% | +1.4% |
| parse+handle | +4.4% | +1.6% |
| parse+handle+wire | +9.3% | −2.5% |

`temp/router-cases.raku 20000 6`，cycles=2，Base 副本换成与 New 同源：

| case | 对称 delta |
|---|---|
| static 32 paths | −6.3% |
| param | −9.7% |
| wild | −6.8% |
| miss | −6.3% |
| 405 | −2.6% |

两套 harness 都是「第二个命名空间稳定快/慢 6–9%」，且方向在各自 harness 内固定。
这是**双副本结构的结构税**，不是加载顺序，也不是被测代码的问题：
`gen-ab-full` 生成的类多十几个属性（`CArray`、`Buf`、三个 `Pointer`），对象布局不同，
同名方法在更大的类里做属性访问就要多一级。任何小于这个数的差异，在一个进程里都测不出来。

### 4. 顺序项：已经消掉了

真实对比（`Router::Base` 旧实现 vs `Router::New`）的 order bias：+0.5%、+2.1%、
+2.9%、−1.1%、−6.2%。镜像前后单跑能差到 35%，对称化之后都在 3% 以内（405 那格
−6.2% 是它本身 140 µs 抖动大）。**顺序偏置这一项可以认为解决。**

### 5. 那 20% 是什么：单路径测太小了

同一份脚本，只改静态格怎么测：

| 测法 | base | new | delta |
|---|---|---|---|
| 单路径 `/health`，镜像顺序 | 1,925 | 3,123 | **+62%** |
| 单路径 `/health`，未镜像 | 1,537 | — | +20 ~ +35% |
| 32 条路径轮转 | 2,964 | 1,888 | **−36%** |

单路径每次都在同一个哈希桶里打转，一次 probe 只有 1.5–3 µs，JIT 与缓存抖动
就能把这格推到 ±25%。而 `Router::Base` 与 `Router::New` 的 `match` 静态快路径
**逐字节相同**（都是从 `%!static{$path}` 取 `$slot{$wanted}`，再比 `idx`），
它本来就不可能差 20%。

改成 32 条路径轮转后，静态格 −36%，方向和 param(−27%)、wild(−57%)、miss(−61%)、
405(−95%) 一致。**结论：静态格从来没有回归，之前那个 +20% 是单路径采样不足。**

### 6. 现在的口径

- 顺序偏置：已消除，报告里保留 `order bias` 栏做自检，超过 ±5% 就该重跑。
- 副本税：6–9%，因 harness 而异。**小于 10% 的改动在双副本同进程 harness 里没有意义**，
  必须走跨进程（`run-ab-rps.ps1`）或加大样本。
- 单格耗时低于 5 µs 时不要用单一路径/单一请求测，至少轮转 32 条，否则噪声吃掉信号。
- 405 那格现在 140 µs：新增的 32 条静态路由让 `Router::Base` 的线性扫描从 6 条涨到 37 条，
  这一格反映的是真实差距被放大，不能与 §十一 的绝对值直接比。

### 7. 复现

```powershell
python tools/gen-ba.py                                   # 生成镜像脚本
python tools/ab-sym.py --kind router --args "20000 6" --cycles 2
python tools/ab-sym.py --kind stack  --args "6000 5"  --cycles 2
# 同源校准：把 temp/ab/lib/HTTP/Core/Router/Base.rakumod 换成 lib 的 Router 内容
#（类名改成 ::Base），重跑上面第一条；原件在 Base.rakumod.orig
```

`bench/11-stack-ab.raku` 尾部那句「同源就该报 ~0%」是错的，实测地板是 6–9%，
已改。

## 十三、M0 重构：Framing + Connection + Transport（无优化目标）

`Server!pump` 原来是「buffer ~= chunk → parse-request → is-complete → dispatch →
write」一锅端，现在是四段：`Framing`（消息边界，纯函数）→ `Connection`（缓冲 +
停泊的 Promise，事件驱动）→ `Transport::TCP`（IO::Socket::Async 的一层壳）→
`Server`（只管路由、派发、keep-alive 策略）。

M0 的验收标准是**没有变化**：t/01–t/05 全绿，`parse+handle` 变化 < 4%。所以这里要
证明的不是赢了多少，而是**没输**。

### 1. 怎么测「重构前后」而不用两个进程

跨进程漂移 12%~35%（§7.6），拿来做 4% 的门槛等于掷骰子。办法是把**重构前的整栈**
生成成 `HTTP::Core::Alt::*` 副本，让新代码（`base`）和旧代码（`alt`）跑在同一个 VM 里：

1. 重构前先把当时的 `temp/ab-full` 另存为 `temp/ab-prem0`（里面就是旧 `!pump`）。
2. 跑一轮 = 旧 vs 新。
3. 用新代码重新生成 `temp/ab-full`（`python tools/gen-ab-full.py`），再跑一轮 =
   **同源校准**，量出这一对副本自己的地板。
4. M0 效应 = 第一轮 delta − 第二轮 delta。两轮都跑 ab 和 ba 两个顺序。

`bench/11-stack-ab.raku` / `-ba.raku` 的 Alt 路径改成读 `%*ENV<AB_LIB>`，默认仍是
`temp/ab-full/lib`，这样同一个脚本不用改就能指向 `temp/ab-prem0/lib`：

```powershell
$env:AB_LIB='temp/ab-prem0/lib'; raku -Ilib bench/11-stack-ab.raku 12000 5 handle
$env:AB_LIB='temp/ab-full/lib';  raku -Ilib bench/11-stack-ab.raku 12000 5 handle
```

### 2. 结果（N=12000 REP=5，层 = parse+handle，mix 2 静态 / 2 动态）

| 轮次 | 顺序 | 旧代码 delta | 同源 delta |
| --- | --- | --- | --- |
| 1 | ab | +8.9% | +8.0% |
| 1 | ba | +6.5% | +11.8% |
| 1 | 均值 | **+7.7%** | **+9.9%** |
| 2 | ab | +4.7% | +8.7% |
| 2 | ba | +8.1% | +8.5% |
| 2 | 均值 | **+6.4%** | **+8.6%** |

两轮的结论一致：**旧 − 同源 = −2.2pp，两轮一模一样。**

也就是说重构后的 `parse+handle` 落在噪声里、方向略偏快（约 −2%），远在 4% 门槛
之内。方向偏快不奇怪：`Framing::Outcome` 是一个对象换掉了「多次方法调用 + 布尔
判断」，`INCOMPLETE` 还是共享实例；但 2% 小于这套 harness 的地板（6–9% 副本税），
**不当收益记账**，M0 仍是纯重构。

### 3. 顺手修的两件事

- `!pump` 的重入：`Promise.keep` 会把 waiter 的续体就地跑起来，续体又回头要下一条
  消息。`Connection!pump` 用 `$!pumping` 挡住嵌套调用，新 waiter 由外层 `while`
  接着喂——每处理一条流水线请求不再多压一个栈帧（旧 `!pump` 本来就是 `while` 循环，
  这条不能退化成递归）。
- `tools/gen-ab-full.py` 现在把 `Transport` / `Transport::TCP` / `Framing` /
  `Connection` 也列为**共享**（和 `Native`、`Bytes` 一样），并且把签名里
  `HTTP::Core::Alt::Transport` 这类类型约束一并改回非 Alt 名。否则副本要么缺模块，
  要么带着一个不存在的类型名编译失败。

### 4. 回归

```
t/01-parse.rakutest            10 subtests, 37 assertions
t/02-server.rakutest           13 subtests（keep-alive、pipeline、431/413/400 全过）
t/03-threads.rakutest          threads=8 rounds=20000 mismatches=0
t/04-serialization.rakutest    6 subtests
t/05-routing-diff.rakutest     2135 lookups, kernel 与 reference 一致
```

流水线是这次唯一真会变的行为面：旧 `!pump` 一条 `while` 把整包榨干，新路径每轮只要
「下一条消息」，`Promise.keep` 就地跑续体，很容易退化成一条消息一个栈帧。所以单独
在单包内塞 50 / 200 / 2000 条请求（同一次 `write`）：

```
pipelined=50    responses=50    bytes=8350
pipelined=200   responses=200   bytes=33400
pipelined=2000  responses=2000  bytes=334000
```

2000 条同包无栈溢出、无丢响应，`$!pumping` 那道闸 + 外层 `while` 是有效的。

**测量陷阱（新踩的）**：客户端别用阻塞 `IO::Socket::INET.read` 配合同进程的
`IO::Socket::Async` 服务器——第一版压测脚本就是这么写的，跑到 600 秒超时都读不满，
看起来像服务器挂了，其实是测试自己把 reactor 饿死。客户端也走 async + `Promise.in(15)`
兜底，才是能出结论的写法。

### 5. 复现

```powershell
python tools/gen-ab-full.py
$env:AB_LIB='temp/ab-prem0/lib'; raku -Ilib bench/11-stack-ab.raku 12000 5 handle
$env:AB_LIB='temp/ab-prem0/lib'; raku -Ilib bench/11-stack-ba.raku 12000 5 handle
$env:AB_LIB='temp/ab-full/lib';  raku -Ilib bench/11-stack-ab.raku 12000 5 handle
$env:AB_LIB='temp/ab-full/lib';  raku -Ilib bench/11-stack-ba.raku 12000 5 handle
```

---

## 十四、M1：client codec（有正确性目标，无性能目标）

这一轮不追数字，原因说清楚：M1 改的是 `HTTP::Core::Codec`——client 侧的编码/解码，
服务端热路径（`Framing` / `Connection` / `Server` / `Response.payload`）一行未动。
`bench/11-stack-*` 量的是 parse+handle，改动不在它的执行路径上，跑 A/B 只会得到
一份噪声，所以本轮不跑，也不把"没变慢"写成结论。

内核版本串升到 `http-wire/0.3.0`（新增 `http_parse_response_arena` /
`http_framing_kind` / `http_write_request`）。这个串是 ABI 契约的一部分：
`t/01` 断言它，一旦 load path 上是旧的动态库，就在这里炸，而不是在别处产生
难以归因的错位。

### 1. 交付内容

| 方向 | 入口 | 说明 |
|---|---|---|
| 请求 → 字节 | `encode-request` | 有序头对，`body` 或 Str 皆可 |
| 字节 → 请求 | `parse-request` | M0 已有 |
| 响应 → 字节 | `Response.payload` | M0 已有 |
| 字节 → 响应 | `parse-response` / `decode-response` | 带 framing / consumed / is-complete / close |

`HTTP::Core` 现在一次 `use` 就能拿到四个方向（转发到 `HTTP::Core::Codec`，
不做别名——实现留在 Codec，公共面留在 `HTTP::Core`）。

### 2. 两个真问题，都不是"多写点代码"能躲的

**（1）`Str.index` 数的是字素，不是字节。**

`"\r\n"` 在 UAX #29 下是一个字素簇。一条 152 字节的响应线缆，
`$wire.decode('latin-1').index("\r\n\r\n")` 返回 **141**，而真正的 head 边界在
**145**；七个 CRLF，正好少七位。据此切 head 会得到被啃掉尾巴的头块和带 `n\n`
前缀的 body。

第一版 `t/06` 就是这么写的，于是它断言了"实现错了"。**测试先挂，不一定是实现挂。**
任何终止符搜索都必须跑在 `Buf` 上；`t/06` 里留了 `blank-line-at` 做字节级查找。

**（2）`Content-Length` 该不该由 codec 算。**

最后定的口径是：算，因为这是对已交付字节的算术，不是策略——

- 有 body 且无 `Transfer-Encoding`：补 `Content-Length`；
- 调用方给了 `Transfer-Encoding`：让位，不动；
- 调用方给了 `Content-Length` 但与 body 不等：`die`，不把不可解析的请求发上线；
- 无 body：不补（`GET` 加 `Content-Length: 0` 是无意义噪声）。

`Host` / `Date` 仍然归调用方：那两个需要上下文，codec 猜就是撒谎。

### 3. 端到端证据

`t/07-live-client` 不给 socket 手搓字节，全部走 `encode-request` 写、
`parse-response` 读，对本库自己的 server 打三个请求：

```
GET /hi     -> status=200 framing=content-length body='hello'  consumed=165 extent=170 wire=170
POST /echo  -> status=200 framing=content-length body='abcdef' consumed=164 extent=170 wire=170
GET /nope   -> status=404 framing=content-length body='Not Found' consumed=131 extent=140 wire=140
```

`extent == wire` 全部相等，这才是连接复用的前提：读端必须能算出"这一条到此为止"，
而头是服务端自己加的（`Date` / `Server` / `Connection`），不是测试能预知的。

### 4. 全绿

`t/01`–`t/07`，连跑两轮，零失败。`t/07` 用 `free-port` 拿端口，避免和本机
其它进程抢；`Promise.in(5)` 兜底，超时算失败而不是挂死——上一轮已经吃过
"测试把 reactor 饿死、看起来像服务器挂了"的亏。

### 5. 复现

```powershell
raku -Ilib t/06-codec.rakutest        # 11 子测试：四方向 + 四种 framing
raku -Ilib t/07-live-client.rakutest  # 3 子测试：真实 socket 端到端
```

---

## 十五、M2：client codec 的对拍（有正确性目标，性能只做取证）

M2 的验收口径不是"跑通"，是**逐字节对得上**。所以这一轮的主要工作不是写实现，
是造一批外部证据，再让实现去撞它：

- `t/fixtures/CurlCaptures.rakumod`：7 份 `curl --trace-ascii` 抓下来的真实请求；
- `t/fixtures/CurlResponses.rakumod`：6 份真实响应（大小写混排、多 `set-cookie`、
  `302` 空 body、`204`、chunked、CL+JSON）。

这些字节**不是本库生成的**，是 curl 和对端服务器生成的，所以它们能证明的东西
比"自己和自己往返"多一层。

### 1. Raku 参考实现先行，然后 A/B

`HTTP::Core::Codec::Raku` 是同算法的无 FFI 版本，签名与 `Codec` 完全一致，
`use HTTP::Core::Codec::Raku` 就能整体替换。`t/08` 第一个子测试把两者钉在一起：
17 种形态（含 64 KiB body、Latin-1/CJK body、非 ASCII 头值、`Transfer-Encoding`
接管 framing、以及两边都必须拒绝的 `Content-Length` 与 body 不符）**逐字节相等**。

A/B（`bench/12-codec`，171 B 请求，三次取最小）：

| 路径 | ns/请求 | 相对 |
|---|---|---|
| `Codec::encode-request`（C 写器） | 10 069 – 10 709 | 1.0x |
| `Codec::Raku::encode-request`（参考实现） | 17 003 – 18 207 | 1.6 – 1.7x |

**C 版值这个 FFI。** 顺带纠正一条早先写进注释的猜测：原注释说参考实现"慢约 8x"，
实测只有 1.5x——Raku 的字符串拼接并不慢，真正贵的是 Str body 的一次转码。
注释已按实测改掉，留着错的数字比没数字更坏。

### 2. curl 对拍：parse → encode 必须回到原字节

`t/08` 第二个子测试对每份抓包做 `parse` 再 `encode`，断言**等于抓包原文**：

```
get-no-user-agent   58 B    get-plain 84 B    get-query 107 B
get-repeat-cookie  111 B    post-empty 153 B  post-form 159 B
put-binary         193 B
```

7/7 逐字节回原。这条断言比"解析字段对"强得多：它同时约束了字段顺序、
大小写、重复字段的次序、以及 `Content-Length` 派生后落笔的位置。

### 3. 响应侧：头块不是哈希

`t/09` 拿 6 份真实响应回读，162 项断言覆盖状态行、原因短语（原样，不重写）、
head 长度、每个字段的名与值、framing、body 视图。三个子测试专门钉住容易被
"顺手优化掉"的语义：

| 子测试 | 钉住的事实 |
|---|---|
| `set-cookie` 两条都在 | 头块是有序列表，不是 `Hash`；`header()` 取第一个且大小写不敏感 |
| 字段名大小写原样 | `CF-RAY` 不被规范化，值里的引号与 `%` 转义不动 |
| chunked 说自己是 chunked | `framing` 不冒充 `content-length`，末块标记在流里，`is-complete` 不撒谎 |

截断输入一律 `X::Incomplete`，不是"尽力而为的部分对象"——一个半截响应能让
池把脏连接放回去，那比抛异常危险得多。

### 4. 一个测量上的发现：头字段物化才是 encode 的大头

`$parsed.encode`（parse → encode 往返）实测 ~55 µs，是 C 写器本身（10.7 µs）的
5 倍多。拆开看，慢的不是内核：

| 项 | ns |
|---|---|
| 一次 `header-name` 的边际成本 | 1 595 |
| 其中：两次 `CArray[size_t]` 读 | 840（420/次） |
| 10 次切片读取（5 头）合计 | ~14 500 – 15 200 |
| 已缓存 Str 上 `substr` 同样 10 次 | 723 |

arena 解决的是**存储**不装箱，**读取**仍然要装箱：`$!arena[i].Int` 420 ns/次，
两个元素拼一个头字段，光读偏移就 840 ns。切片本身也没白给——`http_copy_at`
每次 `buf8.allocate` 一个新原生缓冲，~1.5 µs/字段。

于是给 `Request` 加了一条惰性 ASCII 头文本缓存：头块是纯 ASCII 时
（`chars == consumed`）一次性解码，之后按字节偏移直接 `substr`；一旦头里出现
多字节序列就退回逐字段字节拷贝，因为那时字节偏移和字符位置不再等价，
用 Str 索引会落在字符中间。非 ASCII 那条路由 `t/01` 的 UTF-8 头用例和 `t/08`
的非 ASCII 头值用例守着，两处都过。

**但这条优化不等于把 encode 救回来了。** 往返仍是 5 倍于内核，因为剩余成本在
Raku 侧的 Str 组装与整块转码里。结论要按路径分开说：

- 真实 client 发请求走 `Codec::encode-request`（用户数据进来，不经 arena），
  **10.7 µs，不受影响**；
- 只有 parse → encode 往返（`t/08` 的对拍路径）付这 45 µs。

把往返也压下去需要换 API 形状（内核边写边取偏移，永不物化 Pair 列表），
那是 M3 以后的事，这一轮只把它记成账。

### 5. 全绿

`t/01`–`t/09` 一轮全跑，零失败。顺带清掉一个历史遗留：`t/` 下躺着一份早期
`08-wire-oracle_20261102_133227_833.rakumod` 草稿（`use lib '.'` 的旧版），
它自己编译不过，任何"跑整个目录"的脚本都会把它算成失败。

### 6. 复现

```powershell
raku -Ilib -It/fixtures t/08-wire-oracle.rakutest   # 4 子测试：C/参考对拍 + 7 份 curl 抓包
raku -Ilib -It/fixtures t/09-responses.rakutest     # 5 子测试：6 份真实响应
raku -Ilib -It/fixtures bench/12-codec.raku        # 编码/解析成本 + C vs 参考 A/B
```

---

## 附录：测试文件改用 .rakutest（2026-11-03）

`.rakumod` 是模块后缀，测试文件用它就得靠人肉枚举才能跑。现在 `t/01`–`t/10`
全部改成 `.rakutest`，交给 harness 自动发现；`t/fixtures/CurlCaptures.rakumod`、
`t/fixtures/CurlResponses.rakumod` 是辅助模块，后缀保持不变。

改后缀顺带暴露了一个真问题：`t/03-threads` 原来只 `say` 一句
`PASS thread isolation`，没有任何 TAP 计划，prove6 报
`Parse errors: No plan found in TAP output` —— 也就是说它以前从来没被任何
harness 真正校验过，只是"人眼看它没崩"。现已改成标准 TAP（`plan 1` +
`is $total-bad, 0, ...`，线程数/轮数走 `diag`），语义不变但失败会真的红。

`prove6 -Ilib t/` 实测输出：

```
t\01-parse.rakutest ........... ok
t\02-server.rakutest .......... ok
t\03-threads.rakutest ......... ok
t\04-serialization.rakutest ... ok
t\05-routing-diff.rakutest .... ok
t\06-codec.rakutest ........... ok
t\07-live-client.rakutest ..... ok
t\08-wire-oracle.rakutest ..... ok
t\09-responses.rakutest ....... ok
t\10-client-m3.rakutest ....... ok
All tests successful.
Files=10, Tests=66,  11 wallclock secs
Result: PASS
```

*（内容由AI生成，仅供参考）*
## 十一、M6：池并发与 stale 重试

`bench/m6-load.raku`：一次性发出 N 个请求（全部发起后才 await），`max-per-host`
刻意远小于 N，读的是 `Pool.metrics-for` 与工厂侧独立计数的建连次数。

| 场景 | 请求 | 失败 | 建连（上限） | fresh / reused | 复用率 | peak-active / peak-queued | wall |
|---|---|---|---|---|---|---|---|
| 64 并发 ×1（连跑 5 次） | 64 | 0 | 4（4） | 4 / 60 | **0.9375** | 4 / 60 | ~0.17 s |
| 64 并发 ×2 轮 | 128 | 0 | 4（4） | 4 / 124 | **0.9688** | 4 / 60 | 0.20 s |
| 256 并发 ×2 轮 | 512 | 0 | 4（4） | 4 / 508 | **0.9922** | 4 / 252 | 0.40 s |
| 512 并发 ×1 | 512 | 0 | 8（8） | 8 / 504 | **0.9844** | 8 / 504 | 0.44 s |

第一轮必然是 `fresh = max-per-host`（冷启动），第二轮起复用率才是稳态值——所以
"复用率 >90%" 的验收读的是**第二轮及以后**，而不是把冷启动也算进去。

### 踩到的真缺陷：`state` 变量的惰性初始化不是原子的

64 并发下每批都有 2 个请求 `reused=False` 却收到 EOF：连接刚建好、没发一个字节就断。
服务端 debug 日志给出的是 `nativecast ... but got a P6opaque (Any)`，随后连接被静默丢弃。

根因在 `Response.payload` 的热路径：`state $scratch = buf8.allocate(1)` 的初始化是
惰性的，多个 server 线程**第一次**同时进入该方法时，会读到尚未赋值的容器（Any），
`nativecast` 在原生调用点抛错，异常逃出 reactor 回调，服务端在未写出任何字节的情况下
drop 连接 —— 客户端看到的就是"刚认领就 EOF"。改成文件作用域 `my $SCRATCH`（模块加载
时分配，早于任何 socket 线程）后，同一压测连跑 5 次 `bad=0`。

顺带修掉的两处"证据造假"：

| 症状 | 真相 |
|---|---|
| `served=62`、`ok=63`，像服务端丢请求 | 普通 `Int` 自增在 accept/handler 的多线程上不是原子的，丢增量；改用 `Lock` 保护 |
| 端口被占时服务端静默不服务，只在 stderr 留一行 `Unhandled exception in code scheduled on thread N` | `listen(...).tap` 的 quit 分支没人接；现在记录到 `bind-error` 并打 debug（`t/16` 固化） |

`t/16` 里特意**没有**用"占住端口"制造 bind 失败：Windows 上 `0.0.0.0:$p` 已被监听时，
再绑 `127.0.0.1:$p` 仍然成功，这个用例在 Windows 上根本不成立。改用 RFC 5737 的
`192.0.2.1`（TEST-NET-1，永不路由），跨平台必失败。

### stale 重试的实测（`t/15`）

用真实 Rogue 监听器：首个请求正常答复，同一连接上的第二个请求直接 close 不响应。

| 方法 | 结果 | 对端观测 |
|---|---|---|
| GET（幂等） | 重放一次即 200，body 完整 | 对端看到 `/two` 两次：一次死于 EOF，恰好一次重放；socket 共 2 个（原 + 重放） |
| POST（非幂等） | 明确抛 `X::Network`：`POST ...: pooled connection closed by peer; POST is not idempotent, refusing to retry` | 对端只看到两次 POST，没有第三次 |


## 十二、M2 性能债清偿：parse → encode 不再物化中间结构（2026-11-03）

上一章末尾记的那笔账在这里还掉：`$parsed.encode` 曾是 C 写器单打独斗的 4.5–5 倍，
原因是**往返要走三遍拷贝**——`header-pairs` 每个字段造一个 Pair，Codec 把它们拼成
一个 Str，Str 再转码回 UTF-8，最后交给 C 复制第三遍。而 parse 的产物本来就是
一份「(offset, length) 表 + 原缓冲区」，写作端要的恰好就是这两样东西。

### 1. 新增的两个内核入口

`src/http_wire.c` 里加了 `http_request_bytes` / `http_request_bytes_size`
（共用静态实现 `hw_request_bytes`，182 行），语义是「把 arena 描述过的这个请求
重新写成字节」：

- 请求行与每个字段名、字段值都从 `src` 按 arena 记录的偏移**直接 `memcpy`**，
  不产生任何 Raku 对象；
- 两条派生规则与 Codec 保持一致：body 非空且无 `Transfer-Encoding` 时补
  `Content-Length`，`:close` 且无 `Connection` 字段时补 `Connection: close`；
- 同样的输入长度校验前置：arena 越界 `-1`、body 不在缓冲区内 `-2`、
  声明的 `Content-Length` 与解析出的 body 长度冲突 `-3`。

`http_request_bytes_size` 是同一个函数在 `dst == NULL` 时的形态，只算长度。
Raku 侧因此是**两趟、一次分配**：先问长度，`buf8.allocate` 到最终大小，
再写一遍，不猜、不扩容。第二趟写入的字节数与第一趟不符时直接 `die`，
不留一个尾部没写满的缓冲。

`Request.encode` 改为走这条路径（69 行改动），原来的 Codec 实现保留为
`encode-reference`——**保留它是刻意的**：一条只测新代码的 bench 说明不了旧代码
贵在哪里，而且它正好充当独立实现的对照。`t/08` 新增一个子测试，对 7 份 curl
抓包逐字节断言 `encode` 与 `encode-reference` 一致（带 `:close` 再断一次，
共 14 项），两者一旦分歧就红。

### 2. 基线（改前，2026-11-02，`bench/13-roundtrip.raku 3000 9`）

| 路径 | small 107 B / 4 头 | big 159 B / 5 头 + body |
|---|---|---|
| parse-only | 4 739 ns | 3 884 ns |
| **parse → encode** | **38 157 ns** | **53 163 ns** |
| kernel-write（Codec，已结构化输入） | 8 529 ns | 16 275 ns |
| encode-only（已 parse，走 Codec） | — | 45 368 ns |

往返/写器 = 4.5×（小）、3.3×（大）。文档里那句「约 5 倍、~55 µs」来自更早的一次
口径，这里以同脚本同时取样的三行做基准。

### 3. 优化后（同一台机，`bench/13-roundtrip.raku 3000 11`）

| 路径 | small 107 B / 4 头 | big 159 B / 5 头 + body |
|---|---|---|
| parse-only | 4 415 ns | 3 540 ns |
| **parse → encode（新快路径）** | **6 351 ns** | **5 594 ns** |
| kernel-write（Codec） | 8 209 ns | 19 727 ns |
| parse → encode（`encode-reference`，旧路径同场复测） | 38 757 ns | 70 897 ns |
| encode-only（新路径） | — | 2 008 ns |
| encode-only（`encode-reference`） | — | 53 803 ns |

前后对比（min 口径，同一脚本同一 N）：

| 指标 | 改前 | 改后 | 倍数 |
|---|---|---|---|
| 小请求 parse → encode | 38 157 ns | 6 351 ns | **6.0× 快** |
| 大请求 parse → encode | 53 163 ns | 5 594 ns | **9.5× 快** |
| 大请求 encode-only | 45 368 ns | 2 008 ns | **22.6× 快** |
| 往返 / 写器（小） | 4.5× | **0.77×** | 从「慢 3.5 倍」到「比它还快」 |
| 往返 / 写器（大） | 3.3× | **0.28×** | 同上 |

三条读数一起看才说明问题：

- **往返 ≈ parse + encode-only**（4 415 + 2 008 ≈ 6 423，实测 6 351），也就是
  「parse 完再写出去」现在是两趟纯计算，中间没有任何一层结构。这就是零中间对象
  的定义，不是「优化了一点」。
- 往返比 kernel-write **更快**不是悖论：那一行喂的是已结构化的 `%req`，Codec 仍要
  把哈希里的字段拼成 Str 再转码；快路径不拼。所以「比写器快」恰恰是它绕过了
  Codec 的证据，而不是测量错误。
- 同一轮里旧路径（`encode-reference`）读数 38.8 / 70.9 µs，与改前基线 38.2 / 53.2 µs
  同量级（大请求那次偏高，共享桌面 30–40% 漂移的常态），说明倍数不是换机器换来的。
- kernel-write 大请求从 16.3 µs 涨到 19.7 µs（+21%），是同一份 Codec 代码在两次
  不同时段的噪声，与本次改动无关——本次没碰 Codec 一行。

### 4. 改动面

| 文件 | 行数 | 内容 |
|---|---|---|
| `src/http_wire.c` | +182 | `hw_field_is` / `hw_declared_length` / `hw_request_bytes` 及两个导出入口 |
| `src/http_wire.h` | +49 | 两个函数原型与契约注释 |
| `lib/HTTP/Core/Native.rakumod` | +26 | 两个 NativeCall 绑定 |
| `lib/HTTP/Core/Request.rakumod` | +69 / −6 | `encode` 走快路径、`encode-reference` 保留旧路、错误码翻译 |
| `t/08-wire-oracle.rakutest` | +23 / −1 | 快路径与 Codec 逐字节对拍子测试 |
| `t/01-parse.rakutest` | ±1 | 内核版本串 `http-wire/0.3.0` → `0.4.0` |
| `resources/libraries/http_wire.lib` | 二进制 | zig cc 重编产物 |

内核版本升到 `0.4.0`，因为新增了导出符号——旧 dll 配新 `Native.rakumod` 会在
符号解析处炸，版本串让这种错配在 `t/01` 就显形，而不是等到第一次编码。
`.dll` 不进版本库（`.gitignore` 已挡），`http_wire.lib` 是导入库、按既有约定提交。

### 5. 全绿

`prove6 -Ilib t/`（16 文件 97 测试，含两个 2 万轮的多线程用例）：

```
t\01-parse.rakutest ................. ok
t\02-server.rakutest ................ ok
t\03-threads.rakutest ............... ok
t\04-serialization.rakutest ......... ok
t\05-routing-diff.rakutest .......... ok
t\06-codec.rakutest ................. ok
t\07-live-client.rakutest ........... ok
t\08-wire-oracle.rakutest ........... ok
t\09-responses.rakutest ............. ok
t\10-client-m3.rakutest ............. ok
t\11-m5-tls-chunked-gzip.rakutest ... ok
t\12-pool-queue.rakutest ............ ok
t\13-pool-concurrency.rakutest ...... ok
t\14-serialise-threads.rakutest ..... ok
t\15-stale-retry.rakutest ........... ok
t\16-listen-failure.rakutest ........ ok
All tests successful.
Files=16, Tests=97,  20 wallclock secs
Result: PASS
```

### 6. 复现

```powershell
raku -Ilib -It/fixtures bench/13-roundtrip.raku 3000 11   # 新路径 + 旧路径同场对比
raku -Ilib -It/fixtures t/08-wire-oracle.rakutest         # 5 子测试：C 对拍 + 快路径 vs Codec
prove6 -Ilib t/
```

### 7. 还剩什么

`Request.encode` 的两趟调用之间做了一次 `nativecast` 与 `CArray` 索引，单次 ~0.3 µs，
已经在 parse 本身的量级之下；想再往下压只剩「复用输出缓冲」这一条，但那要求调用方
接受可变缓冲，收益不到 1 µs，不值得换 API 复杂度。这条债到此为止。

*（内容由AI生成，仅供参考）*
