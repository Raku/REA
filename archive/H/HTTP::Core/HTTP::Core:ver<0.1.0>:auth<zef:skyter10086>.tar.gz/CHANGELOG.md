# Changelog

All notable changes to this project. Format follows
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/); this module aims for
[Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## Unreleased

Documentation and help, the metadata drift that made them inaccurate, and the
two defects that stopped a Windows build from being usable.

### Added

- `README.md` `### Windows`: the PowerShell recipe (`$env:CC` instead of
  `CC=…`), which compilers work and what they link against, the `.dll` naming
  convention, and what a successful install prints.
- `Build.rakumod` `MAIN`, so `raku -I. Build.rakumod` — the command the README
  documents — actually runs. Previously only `zef install .` reached
  `Build.build`.

- `docs/API.md` — every public method with arguments and defaults, one table
  per module, plus the exception hierarchy and the environment variables.
- `examples/serve.raku` — the full server with a real mainline:
  `--port`, `--host`, `--verbose`, `--demo`, and a generated `--help`.
  Routes cover path parameters (`/users/:id`), a wildcard (`/files/*`), JSON
  (`/health`) and a body echo (`POST /echo`).
- `examples/client.raku` — the pooled client as a script:
  `--url`, `--method`, `--data`, `--type`, `--timeout`, `--verbose`, and
  `--self-test`, which starts a server in the same process, issues a `GET` and a
  `POST`, and exits non-zero on failure. No network required.
- `examples/registry-watch.raku` — the connection-registry leak as an executable
  check: four points, expected versus observed counts, `ok` / `FAIL` per line.
- `CHANGELOG.md`.

### Changed

- `Build` no longer hard-codes `zig cc` as the default compiler. It tries
  `zig cc`, `cc`, `gcc`, `clang` in that order and keeps the first candidate
  that actually produces the library, because a bare `zef install .` on a
  machine without zig died in `Building` while an installed gcc sat there unused
  — and because probing with `--version` is not enough: WSL inherits the Windows
  `PATH`, so a `zig.exe` sitting there answers happily and then fails to build
  an ELF target. `CC` still overrides the search, and an unusable `CC` now fails
  immediately with the command it ran.
- `README.md` restructured: table of contents, an install section that names the
  library search order, a quick start, an examples table, a troubleshooting
  section built from failures that actually occurred, and pointers into the
  benchmark post-mortems.
- The test command is now `prove -e 'raku -Ilib' t/*.rakutest`, which needs no
  extra distribution; `prove6` is mentioned as an alternative for those who have
  it installed.

### Fixed

- `examples/serve.raku` and `examples/client.raku` only accepted `--option=value`
  for the numeric options. `MAIN` binds a space-separated value only to a `Str`
  option, so `--port 8080`, `--demo 3` and `--timeout 5` arrived as stray
  positional arguments and the scripts printed their usage block instead of
  running. The numeric options are now declared `Str` and validated by
  `int-option` / `num-option`: both spellings work, and a value that is not a
  number is reported by option name instead of falling through to the usage
  block. `README.md` and both script headers describe the two forms.
- `README.md` carried the AIGC content label twice; one copy is kept at the top.
- `META6.json` listed 18 of the 22 provided modules. `HTTP::Core::Bytes`,
  `HTTP::Core::Codec::Content`, `HTTP::Core::Codec::Raku` and
  `HTTP::Core::Transport::TLS` were missing.
- `META6.json` resources named `libraries/http_wire.so`, which is the Windows
  stem on a Unix platform; the build actually emits `libhttp_wire.so` and
  `libhttp_wire.dylib`. Both are now declared with their real names — and, as
  it turned out, naming files at all was the mistake; see the resource-key fix
  below.
- `META6.json` `support.source` pointed at `raku-http-core`, the repository is
  `raku-HTTP-Core`.
- `META6.json` did not declare `Compress::Zlib`, which
  `HTTP::Core::Codec::Content` loads at the top of the file. Machines that
  happened to have it installed (`zef install .` on this one) hid the omission;
  on a clean one `zef` staged the distribution and every `use HTTP::Core`
  afterwards died on the missing module.
- `Build` named every Unix kernel `http_wire.dll`. The platform test was
  written as `given $*DISTRO.is-win { when True { … } default { … } }`, and
  `when True` in Raku matches *any* value, `False` included, so the Windows
  branch won on every platform: an ELF or Mach-O image came out with a `.dll`
  name, and the binding went looking for a file whose name contradicted its
  contents. It is an `if` now.
- `HTTP::Core::Native` resolved its library path in a `constant` at compile
  time. `zef install .` compiles inside a staging repository and deletes it
  afterwards, so `Testing` passed and the very next `use HTTP::Core` died with
  `Cannot locate native library 'http_wire'` (error 0x7e) pointing at a
  directory that no longer existed. Resolution is now deferred to the first
  call (`is native(&_find-lib)`), which is also what makes `library-path()`
  honest after installation.
- `HTTP::Core::Native._find-lib` searched the resource table before the working
  tree, and matched resource keys by prefix — so `libraries/http_wire` resolved
  to the `http_wire.pdb` that `zig cc` drops beside the DLL, and the binding
  tried to dlopen a debug database. The order is now
  `%*ENV<HTTP_CORE_LIB>` → working tree → resource table → loader, and every
  candidate is checked against the platform library suffixes.
- `META6.json` `resources` listed the three build outputs by full name, which
  cannot describe a distribution built on a fourth platform and did not match
  what zef stages (`resources/<hash>.dll`). It now declares the
  platform-independent key `libraries/http_wire`; zef appends the extension.
- `t/14-serialise-threads.rakutest` compared the C fast path against the Raku
  builder byte for byte, `Date` header included, so a clock tick between the two
  payloads failed the test roughly once in a hundred runs. `Date` is normalised
  on both sides before the comparison.
- The `Distribution::Resource` deprecation notice is now explained rather than
  left hanging. Every path accessor on a resource object (`.absolute`, `.Str`,
  `.IO`, `.resolve`) is deprecated in Rakudo 2026.09 in favour of "using
  `%?RESOURCES<key>` directly", which cannot work: the value is a resource
  object and `NativeCall` needs a string. Both would-be replacements were tried
  and rejected — `$?DISTRIBUTION.content('resources/libraries/…')` returns
  `Any` for an installed distribution, and `.open` merely reaches the same
  deprecated `Str` from inside. The one call stays, `README.md` `Troubleshooting`
  gained the reasoning plus how to mute the notice deliberately
  (`RAKUDO_NO_DEPRECATIONS=1`, verified on 2026.09) instead of editing code that
  works.

## 0.1.0

### Added

- C kernel (`src/http_wire.c`) exported through nine functions and bound with
  NativeCall, no shim: request head parsing, flat arena out-parameters, request
  and response writing.
- `HTTP::Core` facade: `parse-request`, `encode-request`, `parse-response`,
  `decode-response`, `response-extent`, `core-version`, `library-path`,
  `assert-abi`.
- Codec for all four directions and all four body framings (`no-body`,
  `content-length`, `chunked`, `until-close`), with a string-building oracle
  (`Codec::Raku`) the C path is tested against byte for byte.
- Router with `:params` and `*` wildcards, 405 with an `Allow` header.
- `HTTP::Core::Server`: keep-alive, pipelining, partial-body dispatch,
  `max-head` / `max-body` limits, connection accounting.
- `HTTP::Core::Client` with redirects, per-request deadlines and a connection
  pool (`HTTP::Core::Pool`) that reports reuse metrics.
- Transports: TCP, TLS, and an in-memory transport for tests.
- Test suite: 17 files, 101 tests.

### Fixed

- Connection registry leak: `!drop` used a `Str` key against an `Int` transport
  id, threw inside the frame callback, and so never deregistered; the key was
  also a recyclable socket address. The registry is now keyed on a monotonic
  `Connection.serial` (`55c8bae`, `cc2c5e2`, `c8d9af9`), with
  `t/17-registry-release.rakutest` as the regression test and
  `bench/RESULTS-CRO.md` as the write-up.
- Lost wakeup in the connection pool (`5998387`).
