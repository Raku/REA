#!/usr/bin/env python3
"""Aggregate several runs of bench/11-stack-ab.raku into one report.

A single run of the in-process A/B is not a measurement on this box: the same
source code measured against itself swings between 0% and 8% from run to run
(Windows scheduler + background load). Reporting one run's delta would let a
noise spike pass as an optimisation.

So: run the harness K times, each run an independent process (the A/B inside a
run is still same-process, which is the part that matters), then take the
median delta per layer and also print the spread. The spread is the honest
error bar for whatever change is being evaluated.

Usage:
    python tools/ab-full-report.py [N] [REP] [RUNS]
    python tools/ab-full-report.py 3000 12 5
"""
import re
import statistics
import subprocess
import sys
import time

ROOT = None
import os
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

LINE = re.compile(
    r"^(?P<layer>\S+)\s+base=\s*(?P<base>[\d.]+)\s+alt=\s*(?P<alt>[\d.]+)\s+"
    r"delta=\s*(?P<delta>[+\-][\d.]+).*?\(\s*(?P<pct>[+\-][\d.]+)%\)"
)
CEIL = re.compile(r"ceiling:\s*([\d.]+)\s*req/s")


def run_once(n: str, rep: str, layer: str, warm: str) -> dict:
    proc = subprocess.run(
        ["raku", "-Ilib", "bench/11-stack-ab.raku", n, rep, layer, warm],
        cwd=ROOT,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    if proc.returncode != 0:
        sys.exit(f"harness failed (rc={proc.returncode}):\n{proc.stderr[-2000:]}")

    out = {"layers": {}, "ceiling": None, "gate": "PASS" if "equivalence gate: PASS" in proc.stdout else "FAIL"}
    for line in proc.stdout.splitlines():
        m = LINE.match(line.strip())
        if m:
            out["layers"][m["layer"]] = {
                "base": float(m["base"]),
                "alt": float(m["alt"]),
                "delta": float(m["delta"]),
                "pct": float(m["pct"]),
            }
        c = CEIL.search(line)
        if c:
            out["ceiling"] = float(c.group(1))
    return out


def main() -> None:
    n = sys.argv[1] if len(sys.argv) > 1 else "3000"
    rep = sys.argv[2] if len(sys.argv) > 2 else "12"
    runs = int(sys.argv[3]) if len(sys.argv) > 3 else 5
    warm = sys.argv[4] if len(sys.argv) > 4 else "8000"

    # One layer per process: see the comment in bench/11-stack-ab.raku. Running
    # all three layers back to back makes the later ones inherit heap/GC state
    # nobody chose, which showed up as a spurious +-7% on same-source code.
    layers = ["parse", "handle", "wire"]
    data = {layer: [] for layer in layers}

    t0 = time.time()
    for layer in layers:
        for i in range(runs):
            r = run_once(n, rep, layer, warm)
            if r["gate"] != "PASS":
                sys.exit("equivalence gate FAILED - stacks are not equivalent")
            key = next(iter(r["layers"]))
            data[layer].append(r["layers"][key])
            print(f"  {layer:<6} run {i + 1}/{runs} done ({time.time() - t0:.0f}s)", flush=True)

    print()
    print(f"in-process whole-stack A/B   N={n} REP={rep} WARM={warm} RUNS={runs} (one layer per process)")
    print(f"{'layer':<20}{'base ns':>10}{'alt ns':>10}{'delta ns':>11}{'delta %':>9}{'pct range':>17}")
    print("-" * 79)
    spreads = []
    for layer in layers:
        bases = [d["base"] for d in data[layer]]
        alts = [d["alt"] for d in data[layer]]
        pcts = [d["pct"] for d in data[layer]]
        deltas = [d["delta"] for d in data[layer]]
        spreads.append(max(pcts) - min(pcts))
        label = {"parse": "parse", "handle": "parse+handle", "wire": "parse+handle+wire"}[layer]
        print(
            f"{label:<20}{statistics.median(bases):>10.1f}{statistics.median(alts):>10.1f}"
            f"{statistics.median(deltas):>+11.1f}{statistics.median(pcts):>+9.1f}"
            f"{min(pcts):>+8.1f}..{max(pcts):+.1f}"
        )
    print("-" * 79)
    print(f"run-to-run spread: up to {max(spreads):.1f} pct-points "
          f"-> treat |delta| below that as noise")
    print(f"total wall time: {time.time() - t0:.0f}s")


if __name__ == "__main__":
    main()
