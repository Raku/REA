# Capture real curl request bytes, one file per case.
#
# Why PowerShell and not Raku: a Raku test that spawns curl *and* listens on a
# socket in the same process deadlocks in this environment (the lone blocking
# socket read and the child-process wait starve each other), and the test suite
# should not depend on the network anyway. So the capture happens once, here,
# and t/08 replays the bytes.
#
# Output: temp/curl-captures.json  ->  { label: hexstring }
#
# Re-run when curl is upgraded:  pwsh -File tools/capture-curl.ps1

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$outFile = Join-Path $root 'temp\curl-captures.json'

$cases = @(
    @{ label = 'get-plain';        path = '/plain';            args = @() },
    @{ label = 'get-query';        path = '/q?a=1&b=%20x&e=';  args = @('-H', 'X-Test: yes') },
    @{ label = 'get-no-user-agent'; path = '/anon';            args = @('-A', '') },
    @{ label = 'post-form';        path = '/form';             args = @('-d', 'a=1&b=2') },
    @{ label = 'post-empty';       path = '/empty';            args = @('-d', '') },
    @{ label = 'get-repeat-cookie'; path = '/cookie';          args = @('-H', 'Cookie: a=1', '-H', 'Cookie: b=2') },
    @{ label = 'put-binary';       path = '/blob';             args = @('-X', 'PUT', '--data-binary', '@/dev/null-replaced') }
)

function Read-Request([System.Net.Sockets.TcpClient] $client) {
    $stream = $client.GetStream()
    $ms = New-Object System.IO.MemoryStream
    $buf = New-Object byte[] 8192
    $headEnd = -1
    $need = 0
    while ($true) {
        $n = $stream.Read($buf, 0, $buf.Length)
        if ($n -le 0) { break }
        $ms.Write($buf, 0, $n)
        $data = $ms.ToArray()
        if ($headEnd -lt 0) {
            for ($i = 0; $i -le $data.Length - 4; $i++) {
                if ($data[$i] -eq 13 -and $data[$i + 1] -eq 10 -and
                    $data[$i + 2] -eq 13 -and $data[$i + 3] -eq 10) { $headEnd = $i; break }
            }
            if ($headEnd -ge 0) {
                $head = [Text.Encoding]::ASCII.GetString($data, 0, $headEnd)
                $clen = 0
                foreach ($line in $head -split "`r`n") {
                    if ($line -match '^(?i)content-length:\s*(\d+)') { $clen = [int]$Matches[1] }
                }
                $need = $headEnd + 4 + $clen
            }
        }
        if ($headEnd -ge 0 -and $data.Length -ge $need) { break }
    }
    $bytes = $ms.ToArray()
    $resp = [Text.Encoding]::ASCII.GetBytes("HTTP/1.1 204 No Content`r`nContent-Length: 0`r`nConnection: close`r`n`r`n")
    $stream.Write($resp, 0, $resp.Length)
    $stream.Flush()
    $client.Close()
    return ,$bytes
}

$results = [ordered]@{}
$tmpBody = Join-Path $env:TEMP 'curl-body.bin'
[IO.File]::WriteAllBytes($tmpBody, [byte[]](0..40))

foreach ($case in $cases) {
    $listener = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Loopback, 0)
    $listener.Start()
    $port = $listener.LocalEndpoint.Port
    $accept = $listener.AcceptTcpClientAsync()

    $argv = @('-sS', '--http1.1', '-o', 'NUL', '--max-time', '10') + $case.args
    $argv = $argv | ForEach-Object { $_.Replace('/dev/null-replaced', $tmpBody) }
    $url = "http://127.0.0.1:$port$($case.path)"

    # Start-Process joins an array with single spaces and quotes nothing, so a
    # header value with a space ("X-Test: yes") would arrive as two arguments.
    $quoted = ($argv + $url) | ForEach-Object {
        if ($_ -eq '') { '""' }
        elseif ($_ -match '[\s"]') { '"' + $_.Replace('"', '\"') + '"' }
        else { $_ }
    }
    $proc = Start-Process -FilePath 'curl.exe' -ArgumentList ($quoted -join ' ') -PassThru -NoNewWindow

    if (-not $accept.Wait(10000)) { throw "no connection for $($case.label)" }
    $bytes = Read-Request $accept.Result
    $proc.WaitForExit(10000) | Out-Null
    $listener.Stop()

    $hex = ($bytes | ForEach-Object { $_.ToString('x2') }) -join ''
    $text = [Text.Encoding]::UTF8.GetString($bytes)

    # A capture that isn't a complete request is worse than no capture: it would
    # bake a truncation into a fixture.
    if ($text -notmatch '\r\n\r\n$' -and $text -notmatch 'content-length') {
        throw "capture for $($case.label) looks truncated"
    }

    $results[$case.label] = $hex
    Write-Host ("{0,-20} {1,4} B  {2}" -f $case.label, $bytes.Length,
        ($text -split "`r`n")[0])
}

$json = $results | ConvertTo-Json -Depth 4
[IO.File]::WriteAllText($outFile, $json, (New-Object Text.UTF8Encoding $false))
Write-Host "`nwrote $outFile"
