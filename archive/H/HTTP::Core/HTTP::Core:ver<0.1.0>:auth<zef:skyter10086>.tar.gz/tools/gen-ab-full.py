#!/usr/bin/env python3
"""Generate a renamed namespace copy of the whole HTTP::Core stack.

Output goes to temp/ab-full/lib/HTTP/Core/Alt/... so a single process can
`use HTTP::Core::Server` and `use HTTP::Core::Alt::Server` side by side and
time them against each other with no cross-process drift.

Only the package name changes; every line of implementation stays byte-for-byte
identical, which is what makes the A/B comparison meaningful.

Run:  python tools/gen-ab-full.py
"""
import os
import re
import shutil
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, "lib")
DST = os.path.join(ROOT, "temp", "ab-full", "lib")

# Facade goes to Core/Alt.rakumod (defines HTTP::Core::Alt), the rest under Alt/.
FACADE = "Core.rakumod"
# Native.rakumod is deliberately NOT copied. Duplicating the native bindings
# gives the Alt stack its own `sub ... is native` declarations, i.e. its own
# NativeCall stubs for the same C functions, and that turns out to cost a
# measurable amount: a same-source calibration measured Alt 12% slower on the
# parse layer alone while being level on the full stack - a pure code-gen
# artefact of the second set of stubs. The C kernel and its bindings are shared
# infrastructure, not the thing under test, so both stacks use the original
# HTTP::Core::Native (see rewrite_shared_native below).
MODULES = [
    "Request.rakumod",
    "Response.rakumod",
    "Router.rakumod",
    "X.rakumod",
    "Server.rakumod",
]

# HTTP::Core -> HTTP::Core::Alt, but never double-rewrite an existing ::Alt.
REWRITE = re.compile(r"HTTP::Core(?!::Alt)(?!\w)")
NOTICE = """# ---------------------------------------------------------------------------
# GENERATED FILE - do not edit.
# Namespace copy of {orig} produced by tools/gen-ab-full.py for in-process
# A/B measurement. Only the package name differs from the original.
# ---------------------------------------------------------------------------
"""


SHARED_NATIVE = re.compile(r"use HTTP::Core::Alt::Native;")
SHARED_NOTE = "use HTTP::Core::Native;  # shared bindings, see tools/gen-ab-full.py"

# Bytes.rakumod lives next to Native.rakumod: it is the primitive layer (str-bytes,
# the UTF-8 fast path), not a layer under test, so it is shared the same way.
# Without this the copy fails to compile as soon as Response `use`s it.
SHARED_BYTES = re.compile(r"use HTTP::Core::Alt::Bytes;")
SHARED_BYTES_NOTE = "use HTTP::Core::Bytes;   # shared primitive layer, see tools/gen-ab-full.py"

# The transport/codec plumbing added in M0 is shared for the same reason as
# Native and Bytes: it is infrastructure both stacks stand on, not a layer under
# test, and a second copy of it would only add another object-layout tax to the
# measurement. Order matters -- the longer name first, or the prefix regex eats
# `Transport::TCP` and turns it into a syntax error.
SHARED_PLUMBING = [
    (
        re.compile(r"use HTTP::Core::Alt::Transport::TCP;"),
        "use HTTP::Core::Transport::TCP;  # shared plumbing, see tools/gen-ab-full.py",
    ),
    (
        re.compile(r"use HTTP::Core::Alt::Transport;"),
        "use HTTP::Core::Transport;  # shared plumbing, see tools/gen-ab-full.py",
    ),
    (
        re.compile(r"use HTTP::Core::Alt::Connection;"),
        "use HTTP::Core::Connection;  # shared plumbing, see tools/gen-ab-full.py",
    ),
    (
        re.compile(r"use HTTP::Core::Alt::Framing;"),
        "use HTTP::Core::Framing;  # shared plumbing, see tools/gen-ab-full.py",
    ),
]


def rewrite(text: str) -> str:
    return REWRITE.sub("HTTP::Core::Alt", text)


# Sharing only the `use` line is not enough: the shared classes also appear as
# type constraints in signatures (`!serve(HTTP::Core::Alt::Transport $t)`), and
# a bare `HTTP::Core::Alt::Transport` typename is invalid once the module is not
# in the Alt namespace. So every remaining reference is un-Alt'ed as well.
# No lookahead: the bare `Transport` in a signature and `Transport::TCP` in a
# `use`/constructor both just need the `::Alt` dropped, and a trailing `::TCP`
# is left untouched by the replacement.
SHARED_NAME = re.compile(r"HTTP::Core::Alt::(?:Transport|Framing|Connection)")


def _unalt(m: "re.Match") -> str:
    return m.group(0).replace("::Alt", "")


def rewrite_shared_native(text: str) -> str:
    text = SHARED_NATIVE.sub(SHARED_NOTE, text)
    text = SHARED_BYTES.sub(SHARED_BYTES_NOTE, text)
    for pattern, note in SHARED_PLUMBING:
        text = pattern.sub(note, text)
    return SHARED_NAME.sub(_unalt, text)


def emit(src_path: str, dst_path: str) -> None:
    # utf-8-sig: the originals carry a BOM, which is only legal at offset 0 and
    # becomes a bogus statement once our header comment is prepended.
    with open(src_path, encoding="utf-8-sig") as fh:
        text = fh.read()
    body = rewrite_shared_native(rewrite(text))
    os.makedirs(os.path.dirname(dst_path), exist_ok=True)
    header = NOTICE.format(orig=os.path.relpath(src_path, SRC).replace(os.sep, "::"))
    with open(dst_path, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(header + body)
    # Guard: the copy must actually define the Alt namespace, not the original.
    if "unit module HTTP::Core::Alt" not in body and "unit class HTTP::Core::Alt" not in body:
        sys.exit(f"FAIL {dst_path}: unit declaration not rewritten")


def main() -> None:
    if os.path.isdir(DST):
        shutil.rmtree(DST)

    emit(os.path.join(SRC, "HTTP", FACADE), os.path.join(DST, "HTTP", "Core", "Alt.rakumod"))
    for name in MODULES:
        emit(
            os.path.join(SRC, "HTTP", "Core", name),
            os.path.join(DST, "HTTP", "Core", "Alt", name),
        )

    written = []
    for dirpath, _, files in os.walk(DST):
        for f in sorted(files):
            written.append(os.path.relpath(os.path.join(dirpath, f), ROOT))
    print(f"generated {len(written)} files under temp/ab-full/lib")
    for w in written:
        print("  " + w.replace(os.sep, "/"))


if __name__ == "__main__":
    main()
