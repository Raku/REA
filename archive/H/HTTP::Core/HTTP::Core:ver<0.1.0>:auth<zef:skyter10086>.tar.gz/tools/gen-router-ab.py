#!/usr/bin/env python3
"""Rebuild the A/B pair for the router.

temp/ab/lib/HTTP/Core/Router/Base.rakumod  - frozen baseline (written once)
temp/ab/lib/HTTP/Core/Router/New.rakumod   - regenerated from lib/ on demand

Both are plain namespace-renamed copies of the same source file, so neither
side pays for inheritance: bench/09-mixed.raku compares two independent
classes under identical conditions.
"""
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, "lib", "HTTP", "Core", "Router.rakumod")
AB = os.path.join(ROOT, "temp", "ab", "lib", "HTTP", "Core", "Router")


def rename(text: str, cls: str) -> str:
    text = text.replace("unit class HTTP::Core::Router;",
                        f"unit class HTTP::Core::Router::{cls};")
    # keep any intra-module references consistent
    text = re.sub(r"\bHTTP::Core::Router\b(?!::)", f"HTTP::Core::Router::{cls}", text)
    return text


def main() -> int:
    src = open(SRC, encoding="utf-8").read()
    os.makedirs(AB, exist_ok=True)
    after = os.path.join(AB, "New.rakumod")
    open(after, "w", encoding="utf-8").write(rename(src, "New"))
    print("new <- lib/HTTP/Core/Router.rakumod")
    if not os.path.exists(os.path.join(AB, "Base.rakumod")):
        print("warning: Base.rakumod missing, A/B has no baseline", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
