# Capture real server responses, head and body kept apart.
#
# curl -D writes the head exactly as received (status line included, CRLF
# intact) and --raw keeps the body's transfer framing, so head ~ body is the
# wire image of one response. That is what Response.parse has to eat.
#
# Output: temp/curl-responses.json -> { label: { head: hex, body: hex } }
#
#   pwsh -File tools/capture-responses.ps1

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$tmp  = Join-Path $root 'temp'

# Chosen for the shapes a client actually has to get right, not for content:
#   chunked         the framing that has no length in the head
#   content-length  the framing that does
#   no body         a status that forbids one (204) and one that omits it (304)
#   redirect        a second response class with a body of its own
#   casing          a server that sends lower-case field names
$targets = @(
    @{ label = 'chunked-200';    url = 'https://example.com/' },
    @{ label = 'cl-200-json';    url = 'https://httpbingo.org/json' },
    @{ label = 'redirect-302';   url = 'https://httpbingo.org/redirect/1' },
    @{ label = 'no-content-204'; url = 'https://httpbingo.org/status/204' },
    @{ label = 'multi-cookie';   url = 'https://httpbingo.org/cookies/set?a=1&b=2' },
    @{ label = 'cased-headers';  url = 'https://www.cloudflare.com/cdn-cgi/trace' }
)
$results = [ordered]@{}

foreach ($t in $targets) {
    # Per-label filenames: a shared pair made a failed run look like a
    # successful one, because the previous case's bytes were still on disk.
    $head = Join-Path $tmp ("resp-" + $t.label + "-head.txt")
    $body = Join-Path $tmp ("resp-" + $t.label + "-body.bin")
    foreach ($f in @($head, $body)) { if (Test-Path $f) { [IO.File]::Delete($f) } }

    $argv = @('-sS', '-m', '20', '--raw')
    if ($t.ContainsKey('extra')) { $argv += @('-D', $head, '-o', $body) + $t.extra }
    else { $argv += @('-D', $head, '-o', $body) }

    $quoted = ($argv + $t.url) | ForEach-Object {
        if ($_ -match '[\s"]') { '"' + ($_ -replace '"', '\\"') + '"' } else { $_ }
    }
    $p = Start-Process -FilePath 'curl.exe' -ArgumentList ($quoted -join ' ') -PassThru -Wait -NoNewWindow
    if ($p.ExitCode -ne 0) { Write-Warning "curl failed for $($t.label) (exit $($p.ExitCode))"; continue }
    if (-not (Test-Path $head)) { Write-Warning "no head for $($t.label)"; continue }

    $hb = [IO.File]::ReadAllBytes($head)
    $bb = if (Test-Path $body) { [IO.File]::ReadAllBytes($body) } else { [byte[]]@() }

    if ($hb.Length -lt 12) { Write-Warning "head too short for $($t.label)"; continue }

    $results[$t.label] = [ordered]@{
        head = (($hb | ForEach-Object { $_.ToString('x2') }) -join '')
        body = (($bb | ForEach-Object { $_.ToString('x2') }) -join '')
    }
    Write-Host ("{0,-16} head {1,5} B  body {2,7} B  {3}" -f $t.label, $hb.Length, $bb.Length,
        ([Text.Encoding]::ASCII.GetString($hb) -split "`r`n")[0])
}

$json = $results | ConvertTo-Json -Depth 4
[IO.File]::WriteAllText((Join-Path $tmp 'curl-responses.json'), $json,
    (New-Object Text.UTF8Encoding $false))
Write-Host "`nwrote temp/curl-responses.json"
