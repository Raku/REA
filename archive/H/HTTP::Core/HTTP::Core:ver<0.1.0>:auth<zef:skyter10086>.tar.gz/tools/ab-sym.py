#!/usr/bin/env python3
"""Run an A/B benchmark in both load orders and cancel the ordering bias.

    python tools/ab-sym.py --kind stack --args "12000 5" --cycles 2
    python tools/ab-sym.py --kind router --args "40000 9" --cycles 2

Both directions are timed in one sequence (AB, BA, BA, AB) so drift that runs
across the whole session also cancels instead of landing on one side.

For every layer / case we report:

    r_ab = T_alt / T_base   with base loaded first
    r_ba = T_alt / T_base   with alt  loaded first
    r    = sqrt(r_ab * r_ba)                      <- the honest ratio (alt/base)
    load-order bias  d = sqrt(r_ab / r_ba) - 1     <- how much the first-loaded
                                                     side gains; +0.10 = 10%

Anything the ordering cannot explain is real. Calibrate the floor first by
running the two sides on identical source: whatever delta that shows is the
harness noise, not a result.

`delta` is the symmetric result expressed the same way the raw runs report it:
(alt - base) / base, i.e. negative = alt faster.
"""
import argparse
import json
import math
import os
import re
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

STACK_RE = re.compile(
    r"^(?P<name>\S+(?:\+\S+)*)\s+base=\s*(?P<b>[\d.]+)\s+alt=\s*(?P<a>[\d.]+)\s+delta=")
# Case labels are free-form (they may or may not contain a slash), so anchor on
# the two numbers and the signed delta + percent column instead of the name.
ROUTER_RE = re.compile(
    r"^\s*(?P<name>\S.*?)\s{2,}(?P<b>\d+\.\d+)\s+(?P<a>\d+\.\d+)\s+[+-]?\d+\.\d+\s+\([+-]?\d+%\)")


def run(script, extra, timeout=1800):
    cmd = ["raku", "-Ilib", script] + extra.split()
    print(f"  $ {' '.join(cmd)}", flush=True)
    p = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True,
                       encoding="utf-8", errors="replace", timeout=timeout)
    out = p.stdout or ""
    if p.returncode != 0:
        tail = (p.stderr or "")[-1200:]
        raise SystemExit(f"FAILED {script} (rc={p.returncode})\n{tail}")
    return out


def parse(out, kind):
    rx = STACK_RE if kind == "stack" else ROUTER_RE
    rows = {}
    for line in out.splitlines():
        m = rx.match(line)
        if not m:
            continue
        name = " ".join(m.group("name").split())
        rows[name] = (float(m.group("b")), float(m.group("a")))
    return rows


def sym(ab, ba):
    # Ratios are alt/base throughout: 1.05 means alt takes 5% longer.
    r_ab = ab[1] / ab[0]
    r_ba = ba[1] / ba[0]
    r = math.sqrt(r_ab * r_ba)
    # Base is loaded first in the AB run, so base looks better there (r_ab high)
    # and worse in BA (r_ba low). d is the advantage the first-loaded side gets.
    d = math.sqrt(r_ab / r_ba) - 1.0
    return r, d


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--kind", choices=["stack", "router"], default="stack")
    ap.add_argument("--script", default=None)
    ap.add_argument("--twin", default=None)
    ap.add_argument("--args", default="")
    ap.add_argument("--cycles", type=int, default=2,
                    help="AB/BA pairs; the sequence is AB,BA,BA,AB for 2")
    ap.add_argument("--json", default=None)
    a = ap.parse_args()

    if a.kind == "stack":
        script = a.script or "bench/11-stack-ab.raku"
        twin = a.twin or "bench/11-stack-ba.raku"
    else:
        script = a.script or "temp/router-cases.raku"
        twin = a.twin or "temp/router-cases-ba.raku"

    # Order matters: mirror the pairs around the middle so that a monotonic
    # drift over the session hits both directions equally.
    seq = []
    for c in range(a.cycles):
        seq.append("ab" if c % 2 == 0 else "ba")
        seq.append("ba" if c % 2 == 0 else "ab")

    runs = {"ab": [], "ba": []}
    for tag in seq:
        print(f"[{tag.upper()}] load order: "
              f"{'base first' if tag == 'ab' else 'alt first'}", flush=True)
        out = run(script if tag == "ab" else twin, a.args)
        rows = parse(out, a.kind)
        if not rows:
            raise SystemExit(f"no rows parsed from {tag} run")
        runs[tag].append(rows)

    # Per direction: keep the minimum across repeats, as in the raku harness.
    def best(tag):
        acc = {}
        for rows in runs[tag]:
            for k, v in rows.items():
                if k not in acc or v[0] < acc[k][0]:
                    acc[k] = v
        return acc

    AB, BA = best("ab"), best("ba")
    names = [n for n in AB if n in BA]

    print()
    if a.kind == "stack":
        print(f"{'layer':<20} {'ab:base':>9} {'ab:alt':>9} {'ba:base':>9} {'ba:alt':>9}"
              f" {'sym base':>9} {'sym alt':>9} {'delta':>8} {'order bias':>11}")
    else:
        print(f"{'case':<26} {'ab:base':>9} {'ab:new':>9} {'ba:base':>9} {'ba:new':>9}"
              f" {'sym base':>9} {'sym new':>9} {'delta':>8} {'order bias':>11}")

    summary = {}
    for n in names:
        r, d = sym(AB[n], BA[n])
        # Geomean of the two base times and of the two alt times, so the printed
        # absolute numbers agree with the printed delta.
        b = math.sqrt(AB[n][0] * BA[n][0])
        alt = b * r
        print(f"{n:<26} {AB[n][0]:9.1f} {AB[n][1]:9.1f} {BA[n][0]:9.1f} {BA[n][1]:9.1f}"
              f" {b:9.1f} {alt:9.1f} {(r - 1) * 100:+7.1f}% {d * 100:+10.1f}%")
        summary[n] = {
            "ab": AB[n], "ba": BA[n],
            "sym_base": b, "sym_alt": alt,
            "ratio": r, "delta_pct": (r - 1) * 100,
            "order_bias_pct": d * 100,
        }

    print()
    print("delta = symmetric (alt vs base), negative = alt faster")
    print("order bias = how much a side gains purely by being loaded first")

    if a.json:
        path = os.path.join(ROOT, a.json)
        with open(path, "w", encoding="utf-8") as fh:
            json.dump({"kind": a.kind, "args": a.args, "cycles": a.cycles,
                       "sequence": seq, "layers": summary}, fh, indent=2)
        print(f"json -> {a.json}")


if __name__ == "__main__":
    main()
