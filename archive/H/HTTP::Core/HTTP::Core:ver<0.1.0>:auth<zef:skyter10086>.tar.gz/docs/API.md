# HTTP::Core — API reference

Everything here is verified against the tree at `0.1.x` on Rakudo 2026.09
(MoarVM). Anything not listed is private: methods whose names start with `!` are
implementation detail and may change without notice.

Two conventions run through the whole library:

* **Offsets are bytes.** `.consumed`, `.body-offset`, `.name-len` and friends
  count bytes, never grapheme clusters. Searching a wire image for a terminator
  must be done on a `Buf`, not on a decoded `Str` (see README → *Byte offsets,
  not graphemes*).
* **Headers are ordered pairs.** `header-pairs` returns the wire verbatim, in
  order, duplicates preserved. `header('X')` returns the first value;
  `header-values('X')` returns all of them.

---

## 1. Facade — `use HTTP::Core`

The short surface. Everything here is exported.

| Routine | Returns | Purpose |
| --- | --- | --- |
| `core-version()` | `Str` | Version string reported by the C kernel itself |
| `library-path()` | `Str` | Absolute path of the shared library the binding resolved |
| `assert-abi()` | `Bool` | Compares kernel ABI against this build; dies on mismatch |
| `parse-request(Blob $raw)` | `HTTP::Core::Request` | Parse one request head; throws `X::Incomplete` / `X::ParseError` |
| `encode-request(|args)` | `Buf` | Build a request from `method` / `target` / `headers` / `body` |
| `parse-response(Blob $raw, :$head)` | `HTTP::Core::Response` | Parse a response; `:head` for HEAD replies |
| `decode-response(Blob $raw, :$head)` | `HTTP::Core::Response` | Alias of `parse-response` |
| `response-extent(Response $r)` | `Int` | Bytes this response occupies on the wire, or `-1` if the head does not say |
| `new-client(*%opt)` | `HTTP::Core::Client` | Convenience constructor |

`free-port()` lives in `HTTP::Core::Server` (it binds port 0, reads the assigned
port, closes) and is exported from there.

## 2. `HTTP::Core::Request`

A value object over *your* buffer: no bytes are copied out until you ask for a
string.

| Method | Returns | Notes |
| --- | --- | --- |
| `method` | `Str` | Request method, uppercased by the caller or as sent |
| `target` | `Str` | Request target exactly as sent (`/a?b=1`) |
| `path` | `Str` | Alias of `target` |
| `path-only` | `Str` | Target minus the query string |
| `query-string` | `Str` | Everything after `?`, empty when absent |
| `http-version` | `Str` | `1.0` or `1.1` |
| `header-count` | `Int` | Number of header fields |
| `header-name(Int $i)` / `header-value(Int $i)` | `Str` | Indexed access, wire order |
| `header(Str $name)` | `Str` | First value, case-insensitive name match |
| `header-pairs` | `List` | Ordered `Pair`s, duplicates preserved |
| `consumed` / `body-offset` | `Int` | Head length in bytes; the body starts here |
| `body` | `Buf` | Bytes after the head, as far as the buffer goes |
| `content-length` | `Int` | Parsed `Content-Length`, or a sentinel when absent |
| `keep-alive` | `Bool` | Whether HTTP/1.x allows reuse for this request |
| `is-complete` | `Bool` | Head present *and* full body present |
| `encode(:$close)` | `Buf` | Re-emit the request bytes; `:close` appends `Connection: close` |
| `encode-reference(:$close)` | `Buf` | Slow, obvious reimplementation used as a test oracle |

`encode` does not rebuild the head from strings: the parser left a table of
`(offset, length)` pairs over your buffer and the kernel copies each field out
of it, so a parse → encode round trip is one `memcpy` per field.

## 3. `HTTP::Core::Response`

### Constructing

| Form | Produces |
| --- | --- |
| `Response.new(:$body, :%headers, :$status)` | Anything; `headers` is a hash or pair list |
| `Response.text($s, $status = 200, *%headers)` | `text/plain; charset=utf-8` |
| `Response.html($s, $status = 200, *%headers)` | `text/html; charset=utf-8` |
| `Response.json($s, $status = 200, *%headers)` | `application/json` — pass a string, not a structure |
| `Response.bytes($blob, $type, $status)` | Octet stream |
| `Response.no-content($status = 204)` | Bodyless status |
| `$res.with-body(...)` | Copy of a response with a different body |

### Reading

| Method | Returns | Notes |
| --- | --- | --- |
| `status` | `Int` | Status code |
| `reason` | `Str` | Reason phrase, derived from the code when the peer omitted it |
| `body` | `Blob` | Body bytes, as far as the buffer goes |
| `body-bytes` | `Blob` | Same bytes, framed view |
| `header(Str $name)` | `Str` | First value |
| `header-values(Str $name)` | `List` | Every value, in order |
| `header-pairs` | `List` | Wire order, duplicates preserved |
| `framing` | `Str` | `no-body` \| `content-length` \| `chunked` \| `until-close` |
| `is-complete` | `Bool` | Every body byte present yet? |
| `usable` | `Bool` | Whether the connection may be reused |
| `http-version` | `Str` | `1.0` / `1.1` |

### Serialising

| Method | Notes |
| --- | --- |
| `payload(Bool $keep-alive = True)` | Head + body as bytes, ready for a socket |
| `payload-raku(...)` | The same, built with string operations |
| `Response.parse($raw, :$head)` | Parse a received response |

## 4. `HTTP::Core::Router`

| Method | Notes |
| --- | --- |
| `add($method, $pattern, &handler)` | `$method` is a verb or `*` for any |
| `get` / `post` / `put` / `patch` / `delete` / `any` | Verb shortcuts |
| `match($method, $path)` | Returns the handler and captured params |
| `allowed-methods($path)` | Feeds the `Allow` header on a 405 |
| `routes` | How many routes are registered |
| `patterns` | Pattern list, in registration order |

Patterns: literal segments, `:name` for one segment, `*` for one wildcard
segment, `*` at the end of a pattern to capture the rest of the path
(`/files/*` → `%p<*>`). Handlers are called as `-> $req, %params { … }` and may
return a `Response`, a `Str` or a `Blob`.

## 5. `HTTP::Core::Server`

| Attribute | Default | Meaning |
| --- | --- | --- |
| `host` | `127.0.0.1` | Bind address |
| `port` | `8080` | Bind port; `free-port()` picks an unused one |
| `router` | new `Router` | The route table |
| `max-head` | 64 KiB | Head bigger than this gets `431` |
| `max-body` | 8 MiB | `Content-Length` bigger than this gets `413` |
| `transport` | `Transport::TCP` | Swap in `Transport::InMemory` for tests |
| `debug` | `False` | Log accept/drop pairs |

| Method | Notes |
| --- | --- |
| `start` | Arms the listener and returns immediately |
| `stop` | Stops accepting; open connections are dropped |
| `running` | Accepting right now? |
| `bind-error` | Why the bind failed, when it did |
| `connections` | Live entries in the connection registry |
| `drop-connections` | Force-close everything outstanding, returns the count |
| `handle($req)` | Dispatch one request without a socket (useful in tests) |
| `serve-transport($transport)` | Run the loop over an injected transport |

`free-port()` is exported for scripts and tests.

## 6. `HTTP::Core::Client`

| Attribute | Default | Meaning |
| --- | --- | --- |
| `timeout` | `10` | Whole request, every hop; `<= 0` disables |
| `connect-timeout` | `3` | TCP/TLS connect |
| `idle-timeout` | `15` | Pooled connection lifetime; keep it below the server's keep-alive |
| `follow` | `True` | Follow redirects |
| `insecure` | `False` | Skip certificate verification (TLS transport only) |
| `ca-file` | unset | Extra CA bundle |
| `debug` | `False` | Log transport-level events |

| Method | Returns |
| --- | --- |
| `get` / `head` / `post` / `put` / `patch` / `delete` / `options` | `Promise` of `Response` |
| `request($method, $url, *%opt)` | `Promise` of `Response` |
| `pool` | The `HTTP::Core::Pool` in use |
| `close` | Close every pooled connection |
| `closed` | Whether the pool is closed |

Per-request options for `request`:

| Option | Type | Notes |
| --- | --- | --- |
| `:headers` | hash or pair list | Added to the generated head |
| `:body` | `Blob` or `Str` | `Str` is encoded UTF-8 |
| `:json` | anything JSON::Fast serialises | Sets `Content-Type: application/json` |
| `:timeout` | `Real` | This request only |
| `:max-redirects` | `Int` | This request only |
| `:follow` | `Bool` | This request only |

Failures arrive as a broken `Promise` carrying a `HTTP::Core::X` exception, so
`try await $client.get($url)` and an `X::Base` check is enough to classify them.

## 7. `HTTP::Core::Pool`

| Method | Notes |
| --- | --- |
| `acquire($origin, :$timeout)` | Promise of a `Lease` |
| `release($lease, :$force)` | Return or discard a lease |
| `close` / `closed` | Whole-pool lifecycle |
| `idle-count($origin)` / `active-count($origin)` | Live counters |
| `waiting($origin?)` | Waiters queued for a lease |
| `stats` / `metrics` / `metrics-for($origin)` | Snapshots for logging and benchmarks |
| `reuse-rate` | Fraction of requests that avoided a new connection |

## 8. Framing, Connection, Transport

| Module | Role |
| --- | --- |
| `HTTP::Core::Framing` | Message boundaries: `Buf` in, `Outcome` out, no promises |
| `HTTP::Core::Framing::Response` | The same boundary rules for responses |
| `HTTP::Core::Connection` | One socket: buffer, parked promises, monotonic `serial` |
| `HTTP::Core::Transport` | Role: `incoming` / `write` / `close` / `id` |
| `HTTP::Core::Transport::TCP` | `IO::Socket::Async` implementation |
| `HTTP::Core::Transport::TLS` | The same over `IO::Socket::Async::SSL` |
| `HTTP::Core::Transport::InMemory` | A transport with no socket; server and client in one process |

`Connection.serial` exists because a socket object's address is reusable: the
registry is keyed on a monotonic integer, so a closed connection can never be
confused with a newer one at the same address. `t/17-registry-release.rakutest`
is the regression test.

## 9. Exceptions — `use HTTP::Core::X`

| Class | Raised when |
| --- | --- |
| `X::Base` | Parent of all of them; catch this to log once |
| `X::Incomplete` | Valid so far, feed more bytes |
| `X::ParseError` | Malformed; answer `400` |
| `X::Network` | Connect or socket failure |
| `X::Timeout` | Deadline expired |
| `X::Protocol` | The peer said something HTTP does not allow |
| `X::Truncated` | Body shorter than its framing promised |
| `X::Redirect` | Redirect chain gave up (`:max-redirects`) |
| `X::Closed` | Used a closed pool or connection |
| `X::InvalidUrl` | URL did not parse |

## 10. Environment variables

| Variable | Used by | Effect |
| --- | --- | --- |
| `HTTP_CORE_LIB` | `HTTP::Core::Native` | Absolute path of the shared library to load, bypassing the search |
| `CC` | `Build.rakumod` | Compiler for the kernel: `zig cc`, `gcc`, `clang` |
| `DEBUG` | `examples/registry-watch.raku` | `1` prints accept/drop lines with matching `conn#N` |
| `PORT` / `DEMO` | `examples/hello-server.raku` | Bind port; seconds to serve before exiting |

## 11. Where to look next

| Command | Shows |
| --- | --- |
| `raku -Ilib examples/serve.raku --help` | Argument list for the full server example |
| `raku -Ilib examples/client.raku --help` | Argument list for the client example |
| `raku -Ilib examples/client.raku --self-test` | End-to-end smoke test, no network needed |
| `raku -Ilib examples/registry-watch.raku` | The connection registry filling and emptying |
| `prove -e 'raku -Ilib' t/*.rakutest` | The whole suite |
| `bench/RESULTS.md`, `bench/RESULTS-CRO.md` | Numbers and post-mortems |
