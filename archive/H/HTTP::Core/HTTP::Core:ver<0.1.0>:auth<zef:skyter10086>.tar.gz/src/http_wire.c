﻿/* http_wire.c -- zero-copy HTTP/1.x request parser
 *
 * No allocation, no callbacks, no globals. Safe to call from any thread,
 * including MoarVM-owned threads driven by NativeCall.
 */

#include "http_wire.h"
#include <string.h>
#include <time.h>

#define HTTP_WIRE_VERSION_STRING "http-wire/0.4.0"

/* 4 x 8 bytes on every 64-bit target; guards against silent padding changes. */
_Static_assert(sizeof(phr_header) == sizeof(void *) * 4,
               "phr_header must stay four machine words");

static const char *const HTTP_VERSION_PREFIX = "HTTP/1.";

static int is_sp(char c) { return c == ' ' || c == '\t'; }

static int lower(int c) { return (c >= 'A' && c <= 'Z') ? c + 32 : c; }

static int mem_ieq(const char *a, const char *b, size_t n)
{
    for (size_t i = 0; i < n; i++) {
        if (lower((unsigned char)a[i]) != lower((unsigned char)b[i])) return 0;
    }
    return 1;
}

HTTPWIRE_API int http_parse_request(
    const char  *buf,
    size_t       len,
    const char **method,
    size_t      *method_len,
    const char **path,
    size_t      *path_len,
    int         *minor_version,
    phr_header  *headers,
    size_t      *num_headers,
    size_t       max_headers)
{
    const char *const end = buf + len;
    const char *p = buf;

    if (buf == NULL || method == NULL || path == NULL || minor_version == NULL ||
        headers == NULL || num_headers == NULL) {
        return -1;
    }

    /* ---- request line: METHOD SP request-target SP HTTP-version CRLF ---- */

    const char *method_start = p;
    while (p < end && *p != ' ') {
        unsigned char c = (unsigned char)*p;
        if (c <= 0x20 || c == 0x7f) return -1; /* control bytes are not tokens */
        p++;
    }
    if (p == end) return -2;          /* truncated mid-method */
    if (p == method_start) return -1; /* empty method */

    *method     = method_start;
    *method_len = (size_t)(p - method_start);
    p++; /* SP */

    const char *path_start = p;
    while (p < end && *p != ' ') {
        unsigned char c = (unsigned char)*p;
        if (c < 0x21 || c == 0x7f) return -1; /* no control bytes in target */
        p++;
    }
    if (p == end) return -2;
    if (p == path_start) return -1;

    *path     = path_start;
    *path_len = (size_t)(p - path_start);
    p++; /* SP */

    /* "HTTP/1." + one digit = 8 bytes */
    if ((size_t)(end - p) < 8) return -2;
    if (memcmp(p, HTTP_VERSION_PREFIX, 7) != 0) return -1;
    if (p[7] < '0' || p[7] > '9') return -1;
    *minor_version = p[7] - '0';
    p += 8;

    if ((size_t)(end - p) < 2) return -2;
    if (p[0] != '\r' || p[1] != '\n') return -1;
    p += 2;

    /* ---- header fields until an empty line ---- */

    size_t n = 0;
    for (;;) {
        if (n >= max_headers) return -1;

        if ((size_t)(end - p) < 2) return -2;
        if (p[0] == '\r' && p[1] == '\n') { p += 2; break; } /* end of head */

        const char *name = p;
        while (p < end && *p != ':') {
            unsigned char c = (unsigned char)*p;
            if (c <= 0x20 || c == 0x7f) return -1; /* SP/CTL before ':' */
            p++;
        }
        if (p == end) return -2;
        if (p == name) return -1;
        size_t name_len = (size_t)(p - name);
        p++; /* ':' */

        while (p < end && is_sp(*p)) p++; /* OWS before value */
        if (p == end) return -2;

        const char *value = p;
        while (p < end && *p != '\r') {
            unsigned char c = (unsigned char)*p;
            if (c == '\n') return -1;
            if (c < 0x20 && c != '\t') return -1;
            p++;
        }
        if (p == end) return -2;

        const char *value_end = p;
        while (value_end > value && is_sp(value_end[-1])) value_end--;

        if ((size_t)(end - p) < 2) return -2;
        p++; /* '\r' */
        if (*p != '\n') return -1;
        p++;

        headers[n].name     = name;
        headers[n].name_len = name_len;
        headers[n].value    = value;
        headers[n].value_len = (size_t)(value_end - value);
        n++;
    }

    *num_headers = n;
    return (int)(p - buf);
}

HTTPWIRE_API int http_should_keep_alive(
    int               minor_version,
    const phr_header *headers,
    size_t            num_headers)
{
    int keep = (minor_version >= 1) ? 1 : 0;

    for (size_t i = 0; i < num_headers; i++) {
        if (headers[i].name_len != 10) continue;
        if (!mem_ieq(headers[i].name, "connection", 10)) continue;

        if (headers[i].value_len == 5 &&
            mem_ieq(headers[i].value, "close", 5)) {
            keep = 0;
        } else if (headers[i].value_len == 10 &&
                   mem_ieq(headers[i].value, "keep-alive", 10)) {
            keep = 1;
        }
    }
    return keep;
}

HTTPWIRE_API long long http_content_length(
    const phr_header *headers,
    size_t            num_headers)
{
    for (size_t i = 0; i < num_headers; i++) {
        if (headers[i].name_len != 14) continue;
        if (!mem_ieq(headers[i].name, "content-length", 14)) continue;
        if (headers[i].value_len == 0) return -1;

        long long acc = 0;
        const char *v = headers[i].value;
        size_t vlen = headers[i].value_len;
        for (size_t k = 0; k < vlen; k++) {
            unsigned char c = (unsigned char)v[k];
            if (c < '0' || c > '9') return -1;
            if (acc > (9223372036854775807LL - (c - '0')) / 10) return -1;
            acc = acc * 10 + (c - '0');
        }
        return acc;
    }
    return -1;
}

HTTPWIRE_API void http_copy_bytes(const char *src, size_t len, char *dst)
{
    if (src != NULL && dst != NULL && len > 0) {
        memcpy(dst, src, len);
    }
}

HTTPWIRE_API void http_copy_at(const char *base, size_t offset, size_t len,
                               char *dst)
{
    if (base != NULL && dst != NULL && len > 0) {
        memcpy(dst, base + offset, len);
    }
}

HTTPWIRE_API size_t http_wire_header_size(void)
{
    return sizeof(phr_header);
}

HTTPWIRE_API const char *http_wire_version(void)
{
    return HTTP_WIRE_VERSION_STRING;
}

/* --- response writer ------------------------------------------------------
 *
 * The mirror image of the parser: it never allocates either, it fills a buffer
 * the caller already owns and reports how many bytes it used. Ownership and
 * lifetime stay entirely on the Raku side.
 *
 * Why the head is assembled in C: doing it in Raku measured ~2.6 us per
 * response -- a status-line interpolation, a hash probe for the reason phrase,
 * a time() call for the Date cache, a four-deep Str concatenation and one
 * .encode of the result. None of that is work Raku is good at; all of it is
 * byte shuffling, which C does in tens of nanoseconds.
 *
 * Contract, deliberately two-pass so the caller can allocate exactly once:
 *
 *   dst == NULL or cap == 0   dry run: returns the exact byte count needed and
 *                             writes nothing.
 *   otherwise                 writes head + body and returns the byte count.
 *                             If cap is too small it writes nothing and
 *                             returns -needed, so a mis-sized call can never
 *                             corrupt memory or leave a partial response.
 *
 * Both passes run the same code path (the put_* helpers only count when dst is
 * NULL), so the dry run cannot disagree with the real write.
 *
 * The reason phrase degrades to "Unknown" for codes not in the table, which is
 * legal: RFC 9110 lets a server omit or invent reason phrases, recipients must
 * ignore them.
 */

typedef struct {
    int         code;
    const char *reason;
} http_reason;

/* Kept in lockstep with %REASON in lib/HTTP/Core/Response.rakumod: t/04
 * compares the C path and the Raku path byte for byte. */
static const http_reason HTTP_REASONS[] = {
    { 100, "Continue" },
    { 101, "Switching Protocols" },
    { 200, "OK" },
    { 201, "Created" },
    { 202, "Accepted" },
    { 203, "Non-Authoritative Information" },
    { 204, "No Content" },
    { 205, "Reset Content" },
    { 206, "Partial Content" },
    { 301, "Moved Permanently" },
    { 302, "Found" },
    { 303, "See Other" },
    { 304, "Not Modified" },
    { 307, "Temporary Redirect" },
    { 308, "Permanent Redirect" },
    { 400, "Bad Request" },
    { 401, "Unauthorized" },
    { 402, "Payment Required" },
    { 403, "Forbidden" },
    { 404, "Not Found" },
    { 405, "Method Not Allowed" },
    { 406, "Not Acceptable" },
    { 408, "Request Timeout" },
    { 409, "Conflict" },
    { 410, "Gone" },
    { 411, "Length Required" },
    { 412, "Precondition Failed" },
    { 413, "Payload Too Large" },
    { 414, "URI Too Long" },
    { 415, "Unsupported Media Type" },
    { 416, "Range Not Satisfiable" },
    { 418, "I'm a teapot" },
    { 422, "Unprocessable Content" },
    { 429, "Too Many Requests" },
    { 431, "Request Header Fields Too Large" },
    { 500, "Internal Server Error" },
    { 501, "Not Implemented" },
    { 502, "Bad Gateway" },
    { 503, "Service Unavailable" },
    { 504, "Gateway Timeout" },
    { 505, "HTTP Version Not Supported" },
};

static const char *http_reason_for(int status)
{
    size_t n = sizeof(HTTP_REASONS) / sizeof(HTTP_REASONS[0]);
    for (size_t i = 0; i < n; i++) {
        if (HTTP_REASONS[i].code == status) return HTTP_REASONS[i].reason;
    }
    return "Unknown";
}

/* A cursor that counts, writes, and refuses to run off the end of the buffer.
 * One code path serves both passes: with dst == NULL it is a pure length
 * calculation, so the dry run cannot drift from the real write. */
typedef struct {
    char  *dst;
    size_t cap;
    size_t pos;
    int    overflow;
} http_writer;

static void w_raw(http_writer *w, const char *s, size_t n)
{
    if (n == 0) return;
    if (w->dst != NULL) {
        if (w->pos + n > w->cap) { w->overflow = 1; return; }
        memcpy(w->dst + w->pos, s, n);
    }
    w->pos += n;
}

static void w_cstr(http_writer *w, const char *s)
{
    size_t n = 0;
    while (s[n] != '\0') n++;
    w_raw(w, s, n);
}

/* Unsigned decimal without sprintf: a three-digit status line does not deserve
 * a format parser, and Rakudo's sprintf costs ~230 us a call anyway. */
static void w_uint(http_writer *w, unsigned long long v)
{
    char   tmp[24];
    size_t n = 0;

    if (v == 0) {
        tmp[n++] = '0';
    }
    else {
        char   rev[24];
        size_t r = 0;
        while (v > 0) {
            rev[r++] = (char)('0' + (int)(v % 10));
            v /= 10;
        }
        while (r > 0) tmp[n++] = rev[--r];
    }
    w_raw(w, tmp, n);
}

static long long http_now(void) { return (long long)time(NULL); }

/* "Sun, 01 Nov 2026 03:12:45 GMT" -- RFC 1123, hand-rolled on purpose:
 * strftime would drag in locale state, and gmtime plus a formatter costs more
 * than the whole rest of the head. Day/month/year come from the civil-from-days
 * algorithm (Hinnant), which needs no libc and no timezone database, so the
 * bytes are identical on Windows, Linux and macOS. */
static void http_date_into(char out[30], long long now)
{
    /* Index 0 is Thursday: DOW[days % 7], and day 0 of the Unix epoch was a
     * Thursday. Anchoring the table on the epoch instead of on Sunday means no
     * "+4" fudge, which is exactly the term that is easy to get wrong. */
    static const char *const DOW[7]  = { "Thu", "Fri", "Sat", "Sun", "Mon", "Tue", "Wed" };
    static const char *const MON[12] = { "Jan", "Feb", "Mar", "Apr", "May", "Jun",
                                         "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };

    long long days = now / 86400;
    long long secs = now % 86400;
    if (secs < 0) { secs += 86400; days -= 1; }

    int dow = (int)(days % 7);
    if (dow < 0) dow += 7;

    long long          z   = days + 719468;
    long long          era = (z >= 0 ? z : z - 146096) / 146097;
    unsigned long long doe = (unsigned long long)(z - era * 146097);
    unsigned long long yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365;
    long long          y   = (long long)yoe + era * 400;
    unsigned long long doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
    unsigned long long mp  = (5 * doy + 2) / 153;
    unsigned long long d   = doy - (153 * mp + 2) / 5 + 1;
    unsigned long long m   = (mp < 10) ? mp + 3 : mp - 9;
    if (m <= 2) y += 1;

    size_t p = 0;
    out[p++] = DOW[dow][0]; out[p++] = DOW[dow][1]; out[p++] = DOW[dow][2];
    out[p++] = ','; out[p++] = ' ';
    out[p++] = (char)('0' + (int)(d / 10));
    out[p++] = (char)('0' + (int)(d % 10));
    out[p++] = ' ';
    unsigned long long mi = (m - 1) % 12;
    out[p++] = MON[mi][0]; out[p++] = MON[mi][1]; out[p++] = MON[mi][2];
    out[p++] = ' ';
    unsigned long long yr = (unsigned long long)y;
    for (int k = 3; k >= 0; k--) { out[p + (size_t)k] = (char)('0' + (int)(yr % 10)); yr /= 10; }
    p += 4;
    out[p++] = ' ';
    unsigned long long hh = (unsigned long long)(secs / 3600);
    unsigned long long mm = (unsigned long long)((secs % 3600) / 60);
    unsigned long long ss = (unsigned long long)(secs % 60);
    out[p++] = (char)('0' + (int)(hh / 10)); out[p++] = (char)('0' + (int)(hh % 10));
    out[p++] = ':';
    out[p++] = (char)('0' + (int)(mm / 10)); out[p++] = (char)('0' + (int)(mm % 10));
    out[p++] = ':';
    out[p++] = (char)('0' + (int)(ss / 10)); out[p++] = (char)('0' + (int)(ss % 10));
    out[p++] = ' ';
    out[p++] = 'G'; out[p++] = 'M'; out[p++] = 'T';
    out[p]   = '\0';
}

HTTPWIRE_API long long
http_write_response(char *dst, size_t cap,
                    int status, int keep_alive,
                    const char *content_type, size_t content_type_len,
                    const char *body, size_t body_len)
{
    char      date[30];   /* 29 printable bytes plus the NUL */
    size_t    need;
    http_writer w;
    http_date_into(date, http_now());

    w.dst = dst;
    w.cap = cap;
    w.pos = 0;
    w.overflow = 0;

    w_cstr(&w, "HTTP/1.1 ");
    w_uint(&w, status < 0 ? 0ULL : (unsigned long long)status);
    w_raw(&w, " ", 1);
    w_cstr(&w, http_reason_for(status));
    w_raw(&w, "\r\n", 2);

    w_cstr(&w, "Date: ");
    w_raw(&w, date, 29);
    w_raw(&w, "\r\n", 2);

    w_cstr(&w, "Server: HTTP-Core/0.1.0\r\n");
    w_cstr(&w, "Content-Length: ");
    w_uint(&w, (unsigned long long)body_len);
    w_raw(&w, "\r\n", 2);

    w_cstr(&w, "Connection: ");
    w_cstr(&w, keep_alive ? "keep-alive" : "close");
    w_raw(&w, "\r\n", 2);

    if (content_type != NULL && content_type_len > 0) {
        w_cstr(&w, "Content-Type: ");
        w_raw(&w, content_type, content_type_len);
        w_raw(&w, "\r\n", 2);
    }

    w_raw(&w, "\r\n", 2);

    if (body != NULL && body_len > 0) {
        w_raw(&w, body, body_len);
    }

    need = w.pos;
    if (dst != NULL && (w.overflow || need > cap)) return -(long long)need;
    return (long long)need;
}

/* The client half of the codec. Same two-pass contract as the response writer.
 *
 * The header block arrives pre-formatted because the client already knows what
 * it wants to send and Raku is perfectly good at building a string; what it is
 * not good at is concatenating that string with the body bytes and copying the
 * whole thing into a buffer. So the formatting stays on the Raku side and the
 * byte layout lives here.
 *
 * Contract for `headers`: each line ends in CRLF, and the terminating blank
 * line is NOT included -- this function writes it. Empty block is fine.
 */
HTTPWIRE_API long long
http_write_request(char *dst, size_t cap, int minor_version,
                   const char *method, size_t method_len,
                   const char *target, size_t target_len,
                   const char *headers, size_t headers_len,
                   const char *body, size_t body_len)
{
    http_writer w;
    char        minor;

    if (method == NULL || method_len == 0) return -1;
    if (target == NULL || target_len == 0) return -1;

    if (minor_version < 0) minor_version = 0;
    if (minor_version > 9) minor_version = 9;
    minor = (char)('0' + minor_version);

    w.dst      = dst;
    w.cap      = cap;
    w.pos      = 0;
    w.overflow = 0;

    w_raw(&w, method, method_len);
    w_raw(&w, " ", 1);
    w_raw(&w, target, target_len);
    w_cstr(&w, " HTTP/1.");
    w_raw(&w, &minor, 1);
    w_raw(&w, "\r\n", 2);

    if (headers_len > 0) w_raw(&w, headers, headers_len);
    w_raw(&w, "\r\n", 2);          /* the blank line that ends the head */

    if (body_len > 0) w_raw(&w, body, body_len);

    if (dst != NULL && (w.overflow || w.pos > cap)) return -(long long)w.pos;
    return (long long)w.pos;
}

HTTPWIRE_API long long
http_request_size(int minor_version,
                  const char *method, size_t method_len,
                  const char *target, size_t target_len,
                  const char *headers, size_t headers_len,
                  const char *body, size_t body_len)
{
    return http_write_request(NULL, 0, minor_version,
                              method, method_len, target, target_len,
                              headers, headers_len, body, body_len);
}

/* --- parse -> bytes, with no intermediate Raku object ---------------------
 *
 * The round trip that matters most is parse-then-re-emit: a proxy does it to
 * every request it forwards, and the tests do it to pin the parser and the
 * writer to each other. Doing it the long way -- parser -> Pair list -> Str
 * concatenation -> transcode -> writer -- costs ~38 us for a 107-byte request
 * against 8.5 us for the writer alone, because every header is rebuilt twice
 * (once as a Str field, once as UTF-8 bytes) before the kernel ever sees it.
 *
 * This entry point deletes the middle two steps. The arena the parser already
 * filled *is* the description of the request: offsets into the caller's own
 * buffer, in wire order. So the kernel walks it and copies the bytes straight
 * out, header by header, appending the two fields the codec derives
 * (Content-Length, Connection: close) exactly where Codec::encode-request
 * would have put them.
 *
 * The derived-field rules are copied from Codec::encode-request on purpose,
 * quirks included:
 *
 *   * Content-Length is added only when the body is non-empty and no
 *     Transfer-Encoding field exists -- a chunked request frames itself.
 *   * The length that counts as "declared" is the LAST Content-Length whose
 *     value is all digits; a non-numeric value does not count as declared, so
 *     it is treated as absent rather than as a conflict.
 *   * `Connection: close` is appended only when asked AND the request carries
 *     no Connection field of its own. The peer's field always wins.
 *
 * The body length comes from the arena's content-length slot, which is what
 * Request.body uses. A body that the buffer cannot cover is refused rather
 * than truncated: an encoder that emits half a body produces a request the
 * peer will happily mis-frame.
 *
 * Two passes, like every other writer here (dst == NULL measures). Return
 * values:
 *
 *   >= 0              bytes written (or, in a measuring pass, needed)
 *   -1..-3            errors, cannot collide with -needed: the shortest
 *                     possible request is 18 bytes
 *   -(long long)pos   dst too small; nothing was written
 */
#define HTTPWIRE_ERR_ARGS     (-1)
#define HTTPWIRE_ERR_BODY     (-2)
#define HTTPWIRE_ERR_LENGTH   (-3)

static int hw_field_is(const char *src, size_t off, size_t len,
                       const char *name, size_t name_len)
{
    return len == name_len && mem_ieq(src + off, name, name_len);
}

/* Last Content-Length value that parses as a plain decimal, or -1. */
static long long hw_declared_length(const char *src, const size_t *arena,
                                   size_t num_headers)
{
    long long declared = -1;

    for (size_t i = 0; i < num_headers; i++) {
        const size_t base = 8 + i * 4;
        const size_t nlen = arena[base + 1];
        const size_t voff = arena[base + 2];
        const size_t vlen = arena[base + 3];
        long long    acc  = 0;
        int          ok   = (vlen > 0);

        if (!hw_field_is(src, arena[base + 0], nlen, "content-length", 14))
            continue;

        for (size_t k = 0; ok && k < vlen; k++) {
            const unsigned char c = (unsigned char)src[voff + k];
            if (c < '0' || c > '9') { ok = 0; break; }
            if (acc > (9223372036854775807LL - (c - '0')) / 10) { ok = 0; break; }
            acc = acc * 10 + (c - '0');
        }
        if (ok) declared = acc;
    }
    return declared;
}

static long long hw_request_bytes(char *dst, size_t cap,
                                  const char *src, size_t src_len,
                                  const size_t *arena, size_t arena_slots,
                                  size_t body_off, int close_flag)
{
    http_writer w;
    char        minor;
    size_t      mo, ml, po, pl, nh, i;
    int         has_te = 0, has_conn = 0;
    long long   blen, declared;

    if (src == NULL || arena == NULL || arena_slots < 8)
        return HTTPWIRE_ERR_ARGS;

    mo  = arena[0]; ml = arena[1];
    po  = arena[2]; pl = arena[3];
    nh  = arena[5];

    if (ml == 0 || pl == 0) return HTTPWIRE_ERR_ARGS;
    if (mo + ml > src_len || po + pl > src_len) return HTTPWIRE_ERR_ARGS;
    if (nh > (arena_slots - 8) / 4) return HTTPWIRE_ERR_ARGS;
    if (body_off > src_len) return HTTPWIRE_ERR_ARGS;

    for (i = 0; i < nh; i++) {
        const size_t base = 8 + i * 4;
        const size_t noff = arena[base + 0], nlen = arena[base + 1];
        const size_t voff = arena[base + 2], vlen = arena[base + 3];

        if (noff + nlen > src_len || voff + vlen > src_len)
            return HTTPWIRE_ERR_ARGS;

        if (hw_field_is(src, noff, nlen, "transfer-encoding", 17)) has_te   = 1;
        if (hw_field_is(src, noff, nlen, "connection", 10))        has_conn = 1;
    }

    /* The body the caller can actually hand over: Request.body reads the same
     * slot, and a value the buffer cannot cover is a truncated message. */
    blen = (arena[7] == (size_t)-1) ? 0 : (long long)arena[7];
    if (blen < 0) blen = 0;
    if ((size_t)blen > src_len - body_off) return HTTPWIRE_ERR_BODY;

    declared = hw_declared_length(src, arena, nh);
    if (blen > 0 && !has_te && declared >= 0 && declared != blen)
        return HTTPWIRE_ERR_LENGTH;

    minor = (char)('0' + ((int)arena[4] < 0 ? 0 : ((int)arena[4] > 9 ? 9 : (int)arena[4])));

    w.dst      = dst;
    w.cap      = cap;
    w.pos      = 0;
    w.overflow = 0;

    w_raw(&w, src + mo, ml);
    w_raw(&w, " ", 1);
    w_raw(&w, src + po, pl);
    w_cstr(&w, " HTTP/1.");
    w_raw(&w, &minor, 1);
    w_raw(&w, "\r\n", 2);

    for (i = 0; i < nh; i++) {
        const size_t base = 8 + i * 4;

        w_raw(&w, src + arena[base + 0], arena[base + 1]);
        w_raw(&w, ": ", 2);
        w_raw(&w, src + arena[base + 2], arena[base + 3]);
        w_raw(&w, "\r\n", 2);
    }

    if (blen > 0 && !has_te && declared < 0) {
        w_cstr(&w, "Content-Length: ");
        w_uint(&w, (unsigned long long)blen);
        w_raw(&w, "\r\n", 2);
    }

    if (close_flag && !has_conn) w_cstr(&w, "Connection: close\r\n");

    w_raw(&w, "\r\n", 2);                       /* the blank line */
    if (blen > 0) w_raw(&w, src + body_off, (size_t)blen);

    if (dst != NULL && (w.overflow || w.pos > cap)) return -(long long)w.pos;
    return (long long)w.pos;
}

HTTPWIRE_API long long
http_request_bytes(char *dst, size_t cap,
                   const char *src, size_t src_len,
                   const size_t *arena, size_t arena_slots,
                   size_t body_off, int close_flag)
{
    return hw_request_bytes(dst, cap, src, src_len,
                            arena, arena_slots, body_off, close_flag);
}

HTTPWIRE_API long long
http_request_bytes_size(const char *src, size_t src_len,
                        const size_t *arena, size_t arena_slots,
                        size_t body_off, int close_flag)
{
    return hw_request_bytes(NULL, 0, src, src_len,
                            arena, arena_slots, body_off, close_flag);
}

/* The same layout rules as http_write_request, no destination argument at all.
 * Kept as a separate entry point rather than a thin wrapper so the ABI never
 * asks a caller to smuggle a null dst through NativeCall's marshalling cache. */
HTTPWIRE_API long long
http_response_size(int status, int keep_alive,
                   const char *content_type, size_t content_type_len,
                   const char *body, size_t body_len)
{
    return http_write_response(NULL, 0, status, keep_alive,
                               content_type, content_type_len, body, body_len);
}

HTTPWIRE_API int
http_parse_request_flat(const char *buf, size_t len,
                        size_t *method_off, size_t *method_len,
                        size_t *path_off,   size_t *path_len,
                        int    *minor_version,
                        size_t *flat_out,   size_t *io_header_cap,
                        int    *keep_alive,
                        long long *content_length)
{
    phr_header  headers[64];
    const char *method = NULL, *path = NULL;
    size_t      mlen = 0, plen = 0, num, cap, want;
    int         minor = 0, rc;

    if (buf == NULL) return -1;

    cap  = (io_header_cap != NULL) ? *io_header_cap : 0;
    want = (cap > 0) ? cap : 64;
    if (want > 64) want = 64;
    num  = want;

    rc = http_parse_request(buf, len, &method, &mlen, &path, &plen,
                            &minor, headers, &num, want);
    if (rc < 0) return rc;

    if (method_off)    *method_off = (size_t)(method - buf);
    if (method_len)    *method_len = mlen;
    if (path_off)      *path_off   = (size_t)(path - buf);
    if (path_len)      *path_len   = plen;
    if (minor_version) *minor_version = minor;

    if (flat_out != NULL && cap > 0) {
        size_t n = (num < cap) ? num : cap;
        size_t i;
        for (i = 0; i < n; i++) {
            flat_out[i * 4 + 0] = (size_t)(headers[i].name  - buf);
            flat_out[i * 4 + 1] = headers[i].name_len;
            flat_out[i * 4 + 2] = (size_t)(headers[i].value - buf);
            flat_out[i * 4 + 3] = headers[i].value_len;
        }
    }

    if (io_header_cap) *io_header_cap = num;
    if (keep_alive)    *keep_alive = http_should_keep_alive(minor, headers, num);
    if (content_length) *content_length = http_content_length(headers, num);
    return rc;
}

HTTPWIRE_API int
http_parse_request_arena(const char *buf, size_t len,
                         size_t *arena, size_t arena_slots,
                         size_t max_headers)
{
    phr_header  headers[64];
    const char *method = NULL, *path = NULL;
    size_t      mlen = 0, plen = 0, num, want;
    int         minor = 0, rc;
    long long   clen;
    size_t      i, n;

    if (buf == NULL || arena == NULL) return -1;

    want = max_headers;
    if (want == 0 || want > 64) want = 64;
    if (arena_slots < 8 + 4 * want) return -1;

    num = want;
    rc  = http_parse_request(buf, len, &method, &mlen, &path, &plen,
                             &minor, headers, &num, want);
    if (rc < 0) return rc;
    if (num > want) num = want;

    n      = (num < want) ? num : want;
    clen   = http_content_length(headers, num);

    arena[0] = (size_t)(method - buf);
    arena[1] = mlen;
    arena[2] = (size_t)(path - buf);
    arena[3] = plen;
    arena[4] = (size_t)minor;
    arena[5] = n;
    arena[6] = (size_t)(http_should_keep_alive(minor, headers, num) != 0);
    arena[7] = (size_t)clen;

    for (i = 0; i < n; i++) {
        arena[8 + i * 4 + 0] = (size_t)(headers[i].name  - buf);
        arena[8 + i * 4 + 1] = headers[i].name_len;
        arena[8 + i * 4 + 2] = (size_t)(headers[i].value - buf);
        arena[8 + i * 4 + 3] = headers[i].value_len;
    }
    return rc;
}
/* ------------------------------------------------------------------------- */
/* Response parser                                                           */
/* ------------------------------------------------------------------------- */

/* Header-block reader, shared by the response parser.
 *
 * The request parser keeps its own inlined copy on purpose: its code shape is
 * pinned by the bench A/B numbers and by three test files, so re-verifying it
 * to save fifty lines is a bad trade. New readers start here.
 *
 * Returns >= 0 on success with *pp advanced past the blank line, -1 malformed,
 * -2 incomplete. */
static int hw_parse_headers(const char **pp, const char *end,
                            phr_header *headers, size_t *num_out,
                            size_t max_headers)
{
    const char *p = *pp;
    size_t      n = 0;

    for (;;) {
        if (n >= max_headers) return -1;

        if ((size_t)(end - p) < 2) return -2;
        if (p[0] == '\r' && p[1] == '\n') { p += 2; break; } /* end of head */

        const char *name = p;
        while (p < end && *p != ':') {
            unsigned char c = (unsigned char)*p;
            if (c <= 0x20 || c == 0x7f) return -1; /* SP/CTL before ':' */
            p++;
        }
        if (p == end) return -2;
        if (p == name) return -1;
        size_t name_len = (size_t)(p - name);
        p++; /* ':' */

        while (p < end && is_sp(*p)) p++; /* OWS before value */
        if (p == end) return -2;

        const char *value = p;
        while (p < end && *p != '\r') {
            unsigned char c = (unsigned char)*p;
            if (c == '\n') return -1;
            if (c < 0x20 && c != '\t') return -1;
            p++;
        }
        if (p == end) return -2;

        const char *value_end = p;
        while (value_end > value && is_sp(value_end[-1])) value_end--;

        if ((size_t)(end - p) < 2) return -2;
        p++; /* '\r' */
        if (*p != '\n') return -1;
        p++;

        headers[n].name      = name;
        headers[n].name_len  = name_len;
        headers[n].value     = value;
        headers[n].value_len = (size_t)(value_end - value);
        n++;
    }

    *pp      = p;
    *num_out = n;
    return (int)n;
}

/* "HTTP/1.x SP 3DIGIT [SP reason] CRLF"
 *
 * The reason phrase is optional and is reported as an offset/length pair
 * instead of a NUL-terminated copy: the kernel never allocates, and a caller
 * that does not want the phrase (most do not) never touches those bytes.
 * A missing phrase yields an empty slice, never a NULL. */
HTTPWIRE_API int http_parse_response(
    const char  *buf,
    size_t       len,
    int         *minor_version,
    int         *status,
    const char **reason,
    size_t      *reason_len,
    phr_header  *headers,
    size_t      *num_headers,
    size_t       max_headers)
{
    const char *const end = buf + len;
    const char *p = buf;
    int         rc;

    if (buf == NULL || minor_version == NULL || status == NULL ||
        headers == NULL || num_headers == NULL) {
        return -1;
    }

    /* ---- status line ---- */

    if ((size_t)(end - p) < 8) return -2;
    if (memcmp(p, HTTP_VERSION_PREFIX, 7) != 0) return -1;
    if (p[7] < '0' || p[7] > '9') return -1;
    *minor_version = p[7] - '0';
    p += 8;

    if (p == end) return -2;
    if (*p != ' ') return -1;
    p++;

    if ((size_t)(end - p) < 3) return -2;
    int code = 0;
    for (int i = 0; i < 3; i++) {
        unsigned char c = (unsigned char)p[i];
        if (c < '0' || c > '9') return -1;
        code = code * 10 + (int)(c - '0');
    }
    if (code < 100) return -1; /* three digits, so 0xx can never be a status */
    *status = code;
    p += 3;

    /* " SP reason-phrase" is optional; "CRLF" straight after the code is legal
     * and is what 204/304 responses from minimal servers look like. */
    const char *reason_start = p;
    const char *reason_end   = p;

    if (p < end && *p == ' ') {
        p++;
        reason_start = p;
        while (p < end && *p != '\r') {
            unsigned char c = (unsigned char)*p;
            if (c < 0x20 && c != '\t') return -1;
            p++;
        }
        if (p == end) return -2;
        reason_end = p;
    }

    if ((size_t)(end - p) < 2) return -2;
    if (p[0] != '\r' || p[1] != '\n') return -1;
    p += 2;

    if (reason != NULL)     *reason     = reason_start;
    if (reason_len != NULL) *reason_len = (size_t)(reason_end - reason_start);

    /* ---- header fields ---- */

    rc = hw_parse_headers(&p, end, headers, num_headers, max_headers);
    if (rc < 0) return rc;

    return (int)(p - buf);
}

/* Is the *last* comma-separated token of a header value `token`, ignoring case
 * and surrounding OWS? Transfer-Encoding is the only user: "gzip, chunked" is
 * chunked, "chunked, gzip" is not, and only the final coding decides framing. */
static int hw_last_token_is(const char *v, size_t n,
                            const char *token, size_t tlen)
{
    size_t end   = n;
    size_t start;

    while (end > 0 && is_sp(v[end - 1])) end--;
    start = end;
    while (start > 0 && v[start - 1] != ',') start--;
    while (start < end && is_sp(v[start])) start++;

    if (end - start != tlen) return 0;
    return mem_ieq(v + start, token, tlen);
}

HTTPWIRE_API int http_framing_kind(
    const phr_header *headers,
    size_t            num_headers,
    int               status,
    int               is_head)
{
    int       te_present = 0;
    int       te_chunked = 0;
    long long clen;

    /* Rule 1: shapes that never carry a body, whatever the headers say. */
    if (is_head) return HTTP_FRAMING_NO_BODY;
    if (status > 0 && status < 200)  return HTTP_FRAMING_NO_BODY;
    if (status == 204 || status == 304) return HTTP_FRAMING_NO_BODY;

    /* Rule 2 first, because Transfer-Encoding overrides Content-Length. The
     * last Transfer-Encoding header wins, and within it the last coding. */
    for (size_t i = 0; i < num_headers; i++) {
        if (headers[i].name_len != 17) continue;
        if (!mem_ieq(headers[i].name, "transfer-encoding", 17)) continue;

        te_present = 1;
        te_chunked = hw_last_token_is(headers[i].value, headers[i].value_len,
                                      "chunked", 7);
    }

    if (te_present) {
        return te_chunked ? HTTP_FRAMING_CHUNKED : HTTP_FRAMING_UNTIL_CLOSE;
    }

    clen = http_content_length(headers, num_headers);
    if (clen >= 0) return HTTP_FRAMING_CONTENT_LENGTH;

    /* Rule 4: a request with no framing headers has no body; a response with
     * no framing headers runs to EOF (RFC 9112 §6.3). */
    if (status <= 0) return HTTP_FRAMING_NO_BODY;
    return HTTP_FRAMING_UNTIL_CLOSE;
}

HTTPWIRE_API int http_parse_response_arena(
    const char *buf, size_t len,
    size_t     *arena, size_t arena_slots,
    size_t      max_headers,
    int         is_head)
{
    phr_header  headers[64];
    const char *reason = NULL;
    size_t      rlen = 0, num, want, i, n;
    int         minor = 0, status = 0, rc;

    if (buf == NULL || arena == NULL) return -1;

    want = max_headers;
    if (want == 0 || want > 64) want = 64;
    if (arena_slots < 8 + 4 * want) return -1;

    num = want;
    rc  = http_parse_response(buf, len, &minor, &status, &reason, &rlen,
                              headers, &num, want);
    if (rc < 0) return rc;
    if (num > want) num = want;
    n = num;

    arena[0] = (size_t)status;
    arena[1] = (size_t)minor;
    arena[2] = n;
    arena[3] = (size_t)(http_should_keep_alive(minor, headers, num) != 0);
    {
        long long clen = http_content_length(headers, num);
        arena[4] = (size_t)clen; /* (size_t)-1 stays (size_t)-1 = absent */
    }
    arena[5] = (size_t)http_framing_kind(headers, num, status, is_head);
    arena[6] = (size_t)(reason - buf);
    arena[7] = rlen;

    for (i = 0; i < n; i++) {
        arena[8 + i * 4 + 0] = (size_t)(headers[i].name  - buf);
        arena[8 + i * 4 + 1] = headers[i].name_len;
        arena[8 + i * 4 + 2] = (size_t)(headers[i].value - buf);
        arena[8 + i * 4 + 3] = headers[i].value_len;
    }
    return rc;
}

/* ------------------------------------------------------------------------- */
/* Route matching                                                            */
/* ------------------------------------------------------------------------- */

#define PHR_KIND_LITERAL 0
#define PHR_KIND_PARAM   1
#define PHR_KIND_WILD    2

/* Split a path the way Raku does it: `split("/", :skip-empty)`.
 * Runs of slashes collapse, a leading slash produces no empty first segment,
 * and a trailing slash produces nothing at all. Returns the segment count, or
 * -1 when the path has more segments than the caller sized for. */
static int ph_split_path(const char *path, size_t len,
                         size_t *starts, size_t *lens, int cap)
{
    size_t i = 0;
    int    n = 0;

    while (i < len) {
        while (i < len && path[i] == '/') i++;
        if (i >= len) break;

        const size_t start = i;
        while (i < len && path[i] != '/') i++;

        if (n == cap) return -1;
        starts[n] = start;
        lens[n]   = i - start;
        n++;
    }
    return n;
}

/* Try one pattern against an already-split path.
 * Returns 1 on match, 0 on mismatch, -1 when the out or scratch buffer is too
 * small. out[2] and out[3] are written only on a match. */
static int ph_match_route(const int32_t *seg, int count, int seg_base,
                          const char *blob,
                          const char *path,
                          const size_t *starts, const size_t *lens, int npath,
                          size_t *out, size_t out_slots,
                          char *scratch, size_t scratch_cap)
{
    int nparams = 0;
    int wild    = 0;

    for (int i = 0; i < count; i++) {
        const int32_t kind = seg[i * 3 + 0];
        const int32_t off  = seg[i * 3 + 1];
        const int32_t slen = seg[i * 3 + 2];

        if (kind == PHR_KIND_WILD) {
            size_t need = 0, w = 0;

            /* The capture is the remaining segments joined with "/", which is
             * not contiguous in the original path once empty segments have
             * been dropped, so it has to be rebuilt. */
            for (int j = i; j < npath; j++) need += lens[j] + 1;
            if (need > 0) need--;
            if (need > scratch_cap) return -1;
            for (int j = i; j < npath; j++) {
                if (j > i) scratch[w++] = '/';
                if (lens[j]) {
                    memcpy(scratch + w, path + starts[j], lens[j]);
                    w += lens[j];
                }
            }

            if (nparams >= HTTPWIRE_MAX_PARAMS) return -1;
            if (4 + 4 * (size_t)(nparams + 1) > out_slots) return -1;
            out[4 + 4 * nparams + 0] = (size_t)(seg_base + i);
            out[4 + 4 * nparams + 1] = 0;
            out[4 + 4 * nparams + 2] = w;
            out[4 + 4 * nparams + 3] = 1;
            nparams++;
            wild = 1;
            goto done;  /* "*" ends the pattern, same as the Raku matcher */
        }

        if (i >= npath) return 0;

        if (kind == PHR_KIND_LITERAL) {
            if ((size_t)slen != lens[i]) return 0;
            if (slen && memcmp(blob + off, path + starts[i], (size_t)slen) != 0)
                return 0;
        }
        else {
            if (nparams >= HTTPWIRE_MAX_PARAMS) return -1;
            if (4 + 4 * (size_t)(nparams + 1) > out_slots) return -1;
            out[4 + 4 * nparams + 0] = (size_t)(seg_base + i);
            out[4 + 4 * nparams + 1] = starts[i];
            out[4 + 4 * nparams + 2] = lens[i];
            out[4 + 4 * nparams + 3] = 0;
            nparams++;
        }
    }

    if (npath != count) return 0;

done:
    out[2] = (size_t)nparams;
    out[3] = wild ? 1 : 0;
    return 1;
}

HTTPWIRE_API int http_route_match(
    const int32_t *segs,   size_t n_segs,
    const int32_t *routes, size_t n_routes,
    const char    *blob,
    const char    *path,   size_t path_len,
    int            method_id,
    size_t        *out,    size_t out_slots,
    char          *scratch, size_t scratch_cap)
{
    size_t starts[HTTPWIRE_MAX_SEGS];
    size_t lens[HTTPWIRE_MAX_SEGS];
    int    npath;
    int    seen = 0;

    if (segs == NULL || routes == NULL || blob == NULL || path == NULL ||
        out == NULL || scratch == NULL) return -1;
    if (out_slots < 4) return -1;
    if (n_segs > (size_t)0x7fffffff) return -1;

    npath = ph_split_path(path, path_len, starts, lens, HTTPWIRE_MAX_SEGS);
    if (npath < 0) return -1;

    for (size_t r = 0; r < n_routes; r++) {
        const int32_t first = routes[r * 4 + 0];
        const int32_t count = routes[r * 4 + 1];
        const int32_t mid   = routes[r * 4 + 2];
        const int32_t flags = routes[r * 4 + 3];
        int rc;

        if (first < 0 || count < 0) continue;
        if ((size_t)first + (size_t)count > n_segs) continue;
        if (count > HTTPWIRE_MAX_SEGS) continue;

        /* Segment count rejects everything but a "*" pattern for free, which
         * is what keeps a large table from costing a call per entry. */
        if ((flags & 1) == 0 && count != npath) continue;

        rc = ph_match_route(segs + (size_t)first * 3, (int)count, (int)first, blob,
                            path, starts, lens, npath,
                            out, out_slots, scratch, scratch_cap);
        if (rc < 0) return rc;
        if (rc == 1) {
            if (mid == 0 || mid == method_id) {
                out[0] = 1;
                out[1] = (size_t)r;
                return 1;
            }
            seen = 1;
        }
    }

    out[0] = seen ? 2 : 0;
    out[1] = 0;
    out[2] = 0;
    out[3] = 0;
    return seen ? 2 : 0;
}
