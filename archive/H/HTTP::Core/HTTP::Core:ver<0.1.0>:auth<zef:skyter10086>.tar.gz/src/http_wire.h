/* http_wire.h -- zero-copy HTTP/1.x request parser
 *
 * Design goals (NativeCall-friendly):
 *   - Stateless: every call takes a buffer, returns a consumed-byte count.
 *   - Zero allocation: all out-pointers point INTO the caller's buffer.
 *   - Zero callbacks: no function pointers, no threads, no global state.
 *   - ABI stable: plain C structs of pointer+size pairs, fixed layout.
 *
 * Return codes for http_parse_request():
 *     > 0  number of bytes consumed (a complete request)
 *     -1   parse error
 *     -2   incomplete, feed more bytes and retry
 */

#ifndef HTTP_WIRE_H
#define HTTP_WIRE_H

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#if defined(_WIN32)
#  define HTTPWIRE_API __declspec(dllexport)
#elif defined(__GNUC__) || defined(__clang__)
#  define HTTPWIRE_API __attribute__((visibility("default")))
#else
#  define HTTPWIRE_API
#endif

/* One header pair. Both name and value point into the request buffer. */
typedef struct phr_header {
    const char *name;
    size_t      name_len;
    const char *value;
    size_t      value_len;
} phr_header;

/* Parse a single HTTP/1.x request head (request line + headers).
 *
 *   buf/len        the raw bytes received so far
 *   method/...     out-params, set to point into buf on success
 *   headers        caller-allocated array of max_headers entries
 *   num_headers    out-param, number of entries actually filled
 *
 * On success returns the byte count consumed; the caller should then advance
 * its read cursor by that amount. The body (if any) starts right after.
 */
HTTPWIRE_API int http_parse_request(
    const char  *buf,
    size_t       len,
    const char **method,
    size_t      *method_len,
    const char **path,
    size_t      *path_len,
    int         *minor_version,
    phr_header  *headers,
    size_t      *num_headers,
    size_t       max_headers);

/* 1 = connection may be reused, 0 = close after this response.
 * HTTP/1.1 defaults to keep-alive, HTTP/1.0 defaults to close. */
HTTPWIRE_API int http_should_keep_alive(
    int                minor_version,
    const phr_header  *headers,
    size_t             num_headers);

/* Content-Length as a signed 64-bit value, or -1 when absent/invalid. */
HTTPWIRE_API long long http_content_length(
    const phr_header *headers,
    size_t            num_headers);

/* Copy helper: avoids binding memcpy through the C runtime on Windows. */
HTTPWIRE_API void http_copy_bytes(const char *src, size_t len, char *dst);

/* Same, but addressed by byte offset from the buffer base. Lets the Raku side
 * keep pure integer offsets instead of performing pointer arithmetic. */
HTTPWIRE_API void http_copy_at(const char *base, size_t offset, size_t len,
                               char *dst);

/* Full-buffer parse that reports a flat, offset-based header table.
 *
 * Why this exists: Rakudo's CArray[CStruct] element accessor does not survive
 * boxing, so a CArray<phr_header> cannot be read back reliably from Raku.
 * The header table therefore travels as a flat size_t quadruple array:
 *   flat_out[i*4 + 0] = name  offset from buf
 *   flat_out[i*4 + 1] = name  length
 *   flat_out[i*4 + 2] = value offset from buf
 *   flat_out[i*4 + 3] = value length
 * Offsets (not pointers) keep the caller from ever holding a dangling pointer.
 *
 * io_header_cap  in: capacity in header entries; out: entries actually parsed.
 * flat_out must hold 4 * capacity size_t values.
 * Any out pointer may be NULL to skip that field.
 */
HTTPWIRE_API int http_parse_request_flat(
    const char *buf, size_t len,
    size_t    *method_off, size_t *method_len,
    size_t    *path_off,   size_t *path_len,
    int       *minor_version,
    size_t    *flat_out,   size_t *io_header_cap,
    int       *keep_alive,
    long long *content_length);

/* Arena entry point: the whole out-parameter set in ONE size_t block.
 *
 * Why this exists: http_parse_request_flat needs eleven pointers, and building
 * them on the Raku side costs ~1 us per Pointer.add call (measured), i.e. more
 * than the parse itself. Here the caller passes the arena base once and the
 * kernel computes every slot address itself.
 *
 * Layout (all slots are full 8-byte size_t values, so a Raku CArray[size_t]
 * can read any of them without a typed pointer view):
 *
 *   arena[0]  method offset        arena[4]  minor version
 *   arena[1]  method length        arena[5]  headers parsed
 *   arena[2]  path offset          arena[6]  keep-alive (0/1)
 *   arena[3]  path length          arena[7]  content-length ((size_t)-1 = none)
 *   arena[8 .. 8+4*max_headers-1]  header table, four size_t per header:
 *                                  name off, name len, value off, value len
 *
 * arena_slots must be >= 8 + 4 * max_headers; max_headers is clamped to 64.
 * Returns the same codes as http_parse_request(): >0 consumed, -1 error, -2
 * incomplete. Nothing is written to the arena unless the parse succeeds.
 */
HTTPWIRE_API int http_parse_request_arena(
    const char *buf, size_t len,
    size_t     *arena, size_t arena_slots,
    size_t      max_headers);

/* --- message framing ------------------------------------------------------
 *
 * "How does this message end?" is the one question a client cannot answer from
 * the head alone without reproducing a fair amount of RFC 9112 §6, and getting
 * it wrong is how a connection pool starts handing out desynchronised sockets.
 * So the decision lives next to the parser, where the header table already is.
 *
 * Four answers, no exceptions:
 *
 *   NO_BODY        0  nothing follows the head. Content-Length may still be
 *                     present and meaningful (HEAD, 304) -- do not delete it.
 *   CONTENT_LENGTH 1  exactly N bytes follow.
 *   CHUNKED        2  chunked transfer coding; needs a decoder (not this file).
 *   UNTIL_CLOSE    3  read to EOF. A response-only shape; reuse is impossible.
 *
 * Rules, in the order RFC 9112 applies them:
 *   1. is_head, 1xx, 204, 304   -> no body
 *   2. Transfer-Encoding present -> chunked if its *last* coding is "chunked",
 *                                   otherwise until-close (and it overrides
 *                                   Content-Length, which is why that check
 *                                   comes first)
 *   3. Content-Length            -> that many bytes
 *   4. anything else             -> until-close for a response, no body for a
 *                                   request (a request with no framing headers
 *                                   simply has no body)
 *
 * `status <= 0` means "this is a request": pass 0 and the 1xx/204/304 branches
 * are skipped by construction.
 */
#define HTTP_FRAMING_NO_BODY        0
#define HTTP_FRAMING_CONTENT_LENGTH 1
#define HTTP_FRAMING_CHUNKED        2
#define HTTP_FRAMING_UNTIL_CLOSE    3

HTTPWIRE_API int http_framing_kind(
    const phr_header *headers,
    size_t            num_headers,
    int               status,
    int               is_head);

/* Parse a response head (status line + header block).
 *
 * Same contract as http_parse_request(): > 0 bytes consumed, -1 malformed,
 * -2 incomplete. Accepts a bare "HTTP/1.1 204\r\n" with no reason phrase,
 * which real servers do send and some clients choke on.
 */
HTTPWIRE_API int http_parse_response(
    const char  *buf,
    size_t       len,
    int         *minor_version,
    int         *status,
    const char **reason,
    size_t      *reason_len,
    phr_header  *headers,
    size_t      *num_headers,
    size_t       max_headers);

/* Arena entry point for responses. Layout, mirroring the request arena so one
 * slot reader can serve both:
 *
 *   arena[0]  status code            arena[4]  content-length ((size_t)-1 = none)
 *   arena[1]  minor version          arena[5]  framing kind (see above)
 *   arena[2]  headers parsed         arena[6]  reason offset
 *   arena[3]  keep-alive (0/1)       arena[7]  reason length
 *   arena[8 ..]  header table, four size_t per header (name off/len, value off/len)
 *
 * is_head is the request's method: HEAD forbids a body but keeps the
 * Content-Length header meaningful.
 */
HTTPWIRE_API int http_parse_response_arena(
    const char *buf, size_t len,
    size_t     *arena, size_t arena_slots,
    size_t      max_headers,
    int         is_head);

/* --- request writer -------------------------------------------------------
 *
 * The client half of the codec. Writes "METHOD SP target SP HTTP/1.x CRLF",
 * then the caller's already-formatted header block, then the blank line, then
 * the body. `headers` is raw bytes whose lines each end in CRLF and which must
 * NOT carry the terminating blank line -- the writer emits that. Passing a
 * half-built block is the only way to get a malformed request out of this, so
 * the Raku side owns the formatting and this function owns the byte layout.
 *
 * Two passes like the response writer: NULL dst (or cap 0) reports the exact
 * size, a short buffer returns -needed and writes nothing.
 */
HTTPWIRE_API long long http_write_request(
    char        *dst,
    size_t       cap,
    int          minor_version,
    const char  *method,
    size_t       method_len,
    const char  *target,
    size_t       target_len,
    const char  *headers,
    size_t       headers_len,
    const char  *body,
    size_t       body_len);

HTTPWIRE_API long long http_request_size(
    int          minor_version,
    const char  *method,
    size_t       method_len,
    const char  *target,
    size_t       target_len,
    const char  *headers,
    size_t       headers_len,
    const char  *body,
    size_t       body_len);

/* --- parse -> bytes without materialising the head -------------------------
 *
 * Re-emits a request that http_parse_request_arena() has already described,
 * copying every byte straight from the original buffer. No Pair list, no Str
 * concatenation, no transcode: the arena is (offset, length) pairs into `src`,
 * which is exactly what a writer needs, so the round trip becomes one pass of
 * memcpy instead of rebuild-then-reparse.
 *
 * Inputs:
 *   src/src_len   the buffer the request was parsed from (still alive)
 *   arena         that request's arena, as filled by http_parse_request_arena
 *   arena_slots   its slot count; must cover 8 + 4 * headers
 *   body_off      byte offset where the head ends (the parser's return value)
 *   close_flag    non-zero to append `Connection: close` when the request has
 *                 no Connection field of its own
 *
 * The two fields the codec derives are added with the same rules as
 * http_write_request's Raku caller: Content-Length when the body is non-empty
 * and no Transfer-Encoding field exists, Connection: close on request.
 *
 * Returns:
 *   >= 0   bytes written, or -- when dst is NULL or cap is 0 -- bytes needed
 *   -1     arena or offsets do not describe a request inside src
 *   -2     the declared body is not fully present in src
 *   -3     a declared Content-Length disagrees with the body
 *   -(pos) short buffer; nothing was written
 *
 * Stateless and re-entrant like the rest of the kernel: `src` is read only
 * during the call, and repeated calls with the same arena agree.
 */
HTTPWIRE_API long long http_request_bytes(
    char        *dst,
    size_t       cap,
    const char  *src,
    size_t       src_len,
    const size_t *arena,
    size_t       arena_slots,
    size_t       body_off,
    int          close_flag);

/* The dry run, as its own entry point: same layout rules, no dst at all. */
HTTPWIRE_API long long http_request_bytes_size(
    const char  *src,
    size_t       src_len,
    const size_t *arena,
    size_t       arena_slots,
    size_t       body_off,
    int          close_flag);

/* --- response writer -------------------------------------------------------
 *
 * The parser's mirror image: no allocation, no globals, caller-owned buffer.
 * Writes one complete response -- status line, Date, Server, Content-Length,
 * Connection, an optional Content-Type, the blank line and the body -- and
 * returns the byte count.
 *
 *   dst == NULL or cap == 0   dry run: returns how many bytes are needed and
 *                             writes nothing. Call it once, allocate exactly
 *                             that many bytes, then call it again to fill them.
 *   cap too small             writes nothing, returns -needed.
 *
 * `body` is copied verbatim, so it may point at Raku-owned memory; nothing is
 * retained past the call. Repeated calls are independent, which is what makes
 * this safe under a threaded server.
 */
HTTPWIRE_API long long http_write_response(
    char        *dst,
    size_t       cap,
    int          status,
    int          keep_alive,
    const char  *content_type,
    size_t       content_type_len,
    const char  *body,
    size_t       body_len);

/* The dry run, as its own entry point: identical layout rules, no dst at all.
 *
 * It exists so that the caller never has to pass a null dst just to ask for a
 * size. NativeCall caches how each argument slot is marshalled, and a slot
 * that has been asked to carry a null pointer once will keep handing the C
 * side nulls afterwards -- a body silently disappearing mid-run was the
 * symptom. No nulls in, no nulls out. */
HTTPWIRE_API long long http_response_size(
    int          status,
    int          keep_alive,
    const char  *content_type,
    size_t       content_type_len,
    const char  *body,
    size_t       body_len);

/* --- route matching -------------------------------------------------------
 *
 * The pattern router, moved next to the parser for the same reason the parser
 * lives here: walking a path in Raku costs ~1.9 us just to split it into
 * segments, and a per-candidate match-segs call on top of that. Splitting the
 * path is a byte-level scan, so it belongs in C.
 *
 * Inputs, all caller-owned and never retained:
 *   segs      3 int32 per pattern segment: kind, blob offset, blob length
 *               kind 0 = literal, 1 = :param, 2 = trailing *
 *   routes    4 int32 per route: first segment index, segment count,
 *             method id (0 = any method), flags (bit 0 = pattern contains a
 *             `*`, which makes the segment count useless as an early reject)
 *   blob      concatenated segment texts, UTF-8
 *   path      the request path, UTF-8
 *   method_id caller-assigned id for the request method; -1 for "not one of
 *             the ids the caller knows", which can then only match a route
 *             registered with method id 0
 *
 * Output, in size_t slots (out_slots must be >= 4 + 4 * params):
 *   out[0]  status: 1 = hit, 2 = path matches but method does not
 *   out[1]  route index
 *   out[2]  parameter count
 *   out[3]  1 when a * captured (its value then lives in scratch)
 *   out[4 + 4*i + 0]  segment index (the caller owns the name string)
 *   out[4 + 4*i + 1]  value byte offset (into path, or into scratch)
 *   out[4 + 4*i + 2]  value byte length
 *   out[4 + 4*i + 3]  value source: 0 = path, 1 = scratch
 *
 * Return: 1 hit, 0 no route matched, 2 method mismatch, -1 output or scratch
 * too small, -2 path has more segments than the kernel will handle.
 *
 * A * captures the remaining segments joined with '/', matching Raku's
 * `split('/', :skip-empty)` + `join('/')` exactly -- repeated slashes are
 * collapsed, and the joined text is written to scratch because it is not
 * contiguous in the request path.
 */
#define HTTPWIRE_MAX_SEGS   64
#define HTTPWIRE_MAX_PARAMS 16

HTTPWIRE_API int http_route_match(
    const int32_t *segs,    size_t n_segs,
    const int32_t *routes,  size_t n_routes,
    const char    *blob,
    const char    *path,    size_t path_len,
    int            method_id,
    size_t        *out,     size_t out_slots,
    char          *scratch, size_t scratch_cap);

/* ABI probes, used by the Raku side to fail fast on layout mismatch. */HTTPWIRE_API size_t http_wire_header_size(void);
HTTPWIRE_API const char *http_wire_version(void);

#ifdef __cplusplus
}
#endif

#endif /* HTTP_WIRE_H */
