use v6.d;

# ---------------------------------------------------------------------------
# HTTP::Core — a minimal HTTP/1.x codec backed by a hand-written C kernel,
# bound through NativeCall with no shim layer.
#
# Layering:
#   IO::Socket::Async (or any transport)  ->  bytes
#        |
#   HTTP::Core.parse-request              ->  HTTP::Core::Request  (zero copy)
#        |
#   router / middleware                   ->  your handler
#        |
#   HTTP::Core::Response.payload          ->  bytes
#
# The client direction is the same codec read the other way round:
#   HTTP::Core::Codec.encode-request      ->  bytes
#   HTTP::Core.parse-response             ->  HTTP::Core::Response
#
# The kernel deliberately owns no event loop, no threads and no callbacks:
# MoarVM cannot safely re-enter Raku from a foreign thread, so a pull-based
# design is the only one that does not deadlock or crash.
# ---------------------------------------------------------------------------

use HTTP::Core::Native;
use HTTP::Core::Request;
use HTTP::Core::Response;
use HTTP::Core::Codec;

unit module HTTP::Core;

# Re-export the pieces a caller needs.
our sub core-version(--> Str) is export { HTTP::Core::Native::core-version() }
our sub library-path(--> Str) is export { HTTP::Core::Native::library-path() }

# Self-check: every CStruct field offset the bindings rely on must match the
# C compiler's view of the same header, or the whole ABI silently corrupts.
our sub assert-abi(--> Bool) is export { HTTP::Core::Native::assert-abi() }

# Parse one HTTP/1.x request head out of a flat byte buffer.
#
#   * Succeeds as soon as the head terminator is present; the body, if any,
#     follows immediately at .body-offset and is exposed through .body.
#   * Throws X::Incomplete when the buffer stops inside the head — feed more
#     bytes and call again (the parser is stateless and re-entrant).
#   * Throws X::ParseError on a malformed request line or header block.
#
# Accepts any Blob (including the `utf8` subtype returned by .encode).
our sub parse-request(Blob:D $raw --> HTTP::Core::Request) is export {
    HTTP::Core::Request.parse($raw)
}

# Parse one HTTP/1.x response head out of a flat byte buffer — the client
# direction. Same contract as parse-request: stateless, re-entrant, throws
# X::Incomplete when the head is truncated.
#
# Diverges from the request side in exactly one way: the returned Response also
# carries the connection-level facts a client needs and cannot infer from the
# body — how the body is framed, how many bytes the head consumed, and whether
# enough body bytes are present yet (.is-complete).
our sub parse-response(Blob:D $raw, Bool :$head = False --> HTTP::Core::Response) is export {
    HTTP::Core::Response.parse($raw, :$head)
}

# The write half of the client direction, and the one question a pool asks.
#
# Thin forwards, not aliases: HTTP::Core::Codec is the implementation and this
# namespace is the public surface, so the indirection is worth one frame. These
# live here so a client needs exactly one `use HTTP::Core` to get all four
# directions -- request in, response out, and the two in reverse.
our sub encode-request(|args) is export {
    HTTP::Core::Codec::encode-request(|args)
}

our sub decode-response(Blob:D $raw, Bool :$head = False --> HTTP::Core::Response) is export {
    HTTP::Core::Codec::decode-response($raw, :$head)
}

our sub response-extent(HTTP::Core::Response $r --> Int) is export {
    HTTP::Core::Codec::response-extent($r)
}

# Build a client. The facade's job is "one use gets you both ends":
#
#   my $c = new-client(:timeout(5), :max-per-host(4));   # exported; a module cannot be dotted
#   my $r = await $c.get('http://127.0.0.1:8080/health');
#
# Loaded at runtime on purpose. Framing (M0) uses this module for the parser, so
# a compile-time `use HTTP::Core::Client` here would close the loop
# HTTP::Core -> Client -> Pool -> Connection -> Framing -> HTTP::Core. Keeping the
# server-only half free of any client dependency is also the property that lets a
# server build be shipped without the pool.
our sub new-client(*%opt --> Mu) is export {
    require HTTP::Core::Client;
    ::('HTTP::Core::Client').new(|%opt)
}
