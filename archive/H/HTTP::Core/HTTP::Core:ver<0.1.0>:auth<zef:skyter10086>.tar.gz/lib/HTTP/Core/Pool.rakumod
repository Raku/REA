use v6.d;
use HTTP::Core::Connection;
use HTTP::Core::Framing::Response;
use HTTP::Core::Transport;
use HTTP::Core::Deadline;
use HTTP::Core::X;

# ---------------------------------------------------------------------------
# A per-origin connection pool that is honest about being concurrent.
#
# Three things happen on `acquire`, in this order, and the order *is* the
# policy:
#
#   1. reuse an idle connection -- but only after proving it is still alive
#   2. otherwise open a new one -- if the origin is below `max-per-host`
#   3. otherwise wait in line
#
# Branch 3 is the one M3 could not do. It existed as a queue, but the queue was
# only ever reached by sequential callers, so none of its failure modes were
# exercised: a waiter whose request timed out while queued, a lease handed to a
# caller that had already given up, two threads entering branch 2 at the same
# instant and both seeing "below the cap". This file now closes all three.
#
# Concurrency model. The pool is entered from many threads ($*SCHEDULER's pool,
# transport callbacks, the caller). Rakudo hashes are not thread-safe, so every
# read-modify-write of the bookkeeping happens under one Lock -- and *only* the
# bookkeeping. Anything that can run user code is deliberately outside it:
#
#   * `Promise.keep` / `.break` run continuations inline, and those call back
#     into `release`/`acquire` (a same-thread re-entrant lock would deadlock,
#     and Raku's Lock is not re-entrant);
#   * `transport.close` runs the peer's `done` handler inline, which is the
#     same hazard wearing a different hat;
#   * the transport factory does I/O and can take a connect-timeout to finish.
#
# So the locked region *decides*, and the unlocked tail *acts*. Connections that
# must die are parked in `@!doomed` inside the lock and closed outside it.
#
# Accounting is per origin and deliberately split into "what I asked for" and
# "what it cost":
#
#   granted  leases handed out            == reused + fresh
#   reused   leases that reused a socket  <- the numerator of the reuse rate
#   connected transport factories invoked (a socket that got built)
#   queued   callers that had to wait     (the queue is real, not decorative)
#
# reuse-rate = reused / granted. It is the number M6 is accepted on, so it is
# measured from the same place the lease is granted, never inferred later.
# ---------------------------------------------------------------------------

unit class HTTP::Core::Pool;

# One borrow. `reused` is not decoration: the client's stale-retry rule keys on
# it ("a pooled socket may be replayed once, a brand-new one may not").
class Lease {
    has HTTP::Core::Connection $.conn is required;
    has Str $.origin is required;
    has Bool $.reused = False;
}

# A caller parked in the queue. `since` is what makes queue latency measurable;
# without it "the pool waits" is a claim no test can falsify.
class Waiter {
    has Promise $.promise is required;
    has Instant $.since is required;
}

# Per-origin counters. All `is rw` because Pool mutates them directly while
# holding the lock; they are never exposed as live objects.
class Stat {
    has Int  $.granted        is rw = 0;
    has Int  $.reused         is rw = 0;
    has Int  $.connected      is rw = 0;
    has Int  $.connect-failed is rw = 0;
    has Int  $.queued         is rw = 0;
    has Int  $.queue-timeouts is rw = 0;
    has Int  $.abandoned      is rw = 0;
    has Int  $.retired        is rw = 0;
    has Int  $.destroyed      is rw = 0;
    has Real $.wait-time      is rw = 0;
    has Real $.max-wait       is rw = 0;
    has Int  $.peak-active    is rw = 0;
    has Int  $.peak-queued    is rw = 0;
}

has &.transport-factory is required;

has Int  $.max-per-host  = 8;
has Real $.idle-timeout  = 15;
has Real $.connect-timeout = 3;
has Int  $.max-head      = 64 * 1024;
has Int  $.max-body      = 8 * 1024 * 1024;
has Bool $.debug         = False;

has Lock $!lock .= new;
has %!idle;      # origin => Array of %( :conn, :since )
has %!active;    # origin => Int, leases outstanding + slots reserved
has %!waiters;   # origin => Array of Waiter, oldest first
has %!stat;      # origin => Stat
has @!doomed;    # connections to close, once the lock is released
has Bool $!closed = False;

sub failed(Exception $e --> Promise) {
    my $p = Promise.new;
    $p.break($e);
    $p;
}

# --- public surface -------------------------------------------------------

method acquire(Str $origin, Real :$timeout --> Promise) {
    return failed(HTTP::Core::X::Closed.new(reason => 'the pool is closed'))
        if $!closed;

    my $d;
    $!lock.protect({ $d = self!acquire-locked($origin, $timeout) });
    self!drain-doomed;

    given $d<kind> {
        when 'reuse' {
            return Promise.kept($d<lease>);
        }
        when 'park' {
            # The timer is armed outside the lock: it may fire immediately for a
            # tiny budget, and its body takes the lock itself.
            self!arm-wait-timeout($d<waiter>, $origin, $timeout);
            return $d<waiter>.promise;
        }
        default {
            # A slot is already reserved; !connect either fills it or frees it.
            return self!connect($origin, reused => False);
        }
    }
}

# Give a lease back. `:force` skips the reusability check -- used when the lease
# itself is known bad (the stale-retry path) and re-probing it would be a lie.
#
# Four outcomes, and each one matters:
#   * a live waiter gets the socket directly (no shelve/un-shelve round trip, so
#     a saturated pool never leaves a socket idle "for an instant" while a
#     caller is queued -- that is how starvation starts);
#   * otherwise the socket is shelved;
#   * a socket that is closed / EOF'd / !reusable is destroyed, never shelved;
#   * a free slot wakes the queue by opening a new connection.
method release(Lease $lease, Bool :$force = False --> Nil) {
    my $d;
    $!lock.protect({ $d = self!release-locked($lease, $force) });
    self!drain-doomed;

    if $d<kind> eq 'handoff' {
        my $w = $d<waiter>;
        my $l = $d<lease>;

        # Between deciding and keeping, a queue-timeout armed by another thread
        # may have broken this promise. Keeping a broken promise is a no-op, so
        # the lease would evaporate -- and a leaked slot is indistinguishable
        # from a permanently smaller pool. Re-check, and re-release on a miss.
        if $w.promise.status == Planned {
            $w.promise.keep($l);
        }
        else {
            self.release($l, :force(False));
        }
        return;
    }

    self!pump($d<origin>) if $d<pump>;
    Nil;
}

method close(--> Nil) {
    my @break;

    # No `return` inside the protect block: `Lock.protect` releases the lock
    # when the block returns normally, and a `return` there would jump out of
    # the *method* with the lock still held -- every later caller deadlocks.
    # So the block reports "already closed" as a value instead.
    my Bool $already = $!lock.protect({
        my Bool $skip = $!closed;
        unless $skip {
            $!closed = True;

            for %!idle.keys -> $o {
                my @q := @(%!idle{$o} //= []);
                my $s := self!stat($o);
                while @q.elems {
                    my %e = @q.pop;
                    @!doomed.push(%e<conn>);
                    $s.destroyed += 1;
                }
            }
            %!idle = ();

            for %!waiters.keys -> $o {
                my @q := @(%!waiters{$o} //= []);
                my $s := self!stat($o);
                while @q.elems {
                    my $w = @q.shift;
                    @break.push($w.promise) if $w.promise.status == Planned;
                    $s.abandoned += 1;
                }
            }
            %!waiters = ();
        }
        $skip;
    });

    self!drain-doomed;

    my $err = HTTP::Core::X::Closed.new(reason => 'the pool was closed while waiting');
    for @break -> $p { $p.break($err) }

    Nil;
}

method closed(--> Bool) { $!closed }

method idle-count(Str $origin) {
    $!lock.protect({ @(%!idle{$origin} //= []).elems });
}

method active-count(Str $origin) {
    $!lock.protect({ %!active{$origin} // 0 });
}

method waiting(Str $origin?) {
    $!lock.protect({
        if $origin.defined {
            @(%!waiters{$origin} //= []).elems
        }
        else {
            my Int $n = 0;
            $n += @(%!waiters{$_}).elems for %!waiters.keys;
            $n;
        }
    });
}

# Live gauges, kept for the callers that predate the counters.
method stats(--> Hash) {
    $!lock.protect({
        my %out;
        my @origins = (|%!idle.keys, |%!active.keys, |%!waiters.keys).unique;
        for @origins -> $o {
            my %m = self!snapshot($o);
            %out{$o} = %(
                idle    => %m<idle>,
                active  => %m<active>,
                waiting => %m<waiting>,
                reused  => %m<reused>,
                granted => %m<granted>,
            );
        }
        %out;
    });
}

# The M6 number. `metrics<total>` is what the acceptance test and the benchmark
# read; the per-origin breakdown is what a human reads when the total looks off.
method metrics(--> Hash) {
    $!lock.protect({
        my %origins;
        for %!stat.keys -> $o { %origins{$o} = self!snapshot($o) }
        %( origins => %origins, total => self!total-snapshot() );
    });
}

method metrics-for(Str $origin --> Hash) {
    $!lock.protect({ self!snapshot($origin) });
}

method reuse-rate(--> Real) {
    $!lock.protect({ self!total-snapshot()<reuse-rate> });
}

# --- decision layer (lock held) ------------------------------------------

method !acquire-locked(Str $origin, Real $timeout --> Hash) {
    my $s := self!stat($origin);
    my @idle := @(%!idle{$origin} //= []);
    my $now = now;

    while @idle.elems {
        my %e = @idle.pop;
        my $conn = %e<conn>;

        # A shelved socket can die three ways while nobody is looking: the peer
        # sent FIN (exhausted), a framing error marked it spent (!reusable), or
        # it simply sat there past idle-timeout and may be about to be reaped.
        if $conn.exhausted || $conn.closed || !$conn.reusable {
            $s.retired += 1;
            @!doomed.push($conn);
            next;
        }
        if $!idle-timeout > 0 && $now - %e<since> > $!idle-timeout {
            $s.retired += 1;
            @!doomed.push($conn);
            next;
        }

        %!active{$origin} = (%!active{$origin} // 0) + 1;
        self!bump-active($origin, $s);
        $s.granted += 1;
        $s.reused  += 1;
        return %( kind => 'reuse', lease => Lease.new(:$origin, :conn($conn), reused => True) );
    }

    self!prune-waiters($origin, $s);

    # Fairness: if anyone is already in line, a new caller joins the back of it.
    # Without this check the freshest caller takes the slot the oldest one has
    # been waiting for, and a steady stream of arrivals starves the queue.
    if @(%!waiters{$origin} //= []).elems {
        return %( kind => 'park', waiter => self!park($origin, $s, $timeout) );
    }

    if (%!active{$origin} // 0) >= $!max-per-host {
        return %( kind => 'park', waiter => self!park($origin, $s, $timeout) );
    }

    %!active{$origin} = (%!active{$origin} // 0) + 1;
    self!bump-active($origin, $s);
    %( kind => 'fresh' );
}

method !release-locked(Lease $lease, Bool $force --> Hash) {
    my Str $origin = $lease.origin;
    my $s := self!stat($origin);

    my Int $n = (%!active{$origin} // 1) - 1;
    $n = 0 if $n < 0;
    %!active{$origin} = $n;

    my $conn = $lease.conn;
    my Bool $usable = !$force && !$!closed
                   && !$conn.closed && !$conn.exhausted && $conn.reusable;

    unless $usable {
        $s.destroyed += 1;
        @!doomed.push($conn);
        return %( kind => 'destroyed', origin => $origin, pump => True );
    }

    # Hand the live socket straight to the oldest waiter. Skipping dead waiters
    # here is what keeps them from swallowing leases: a request that timed out
    # in the queue has no consumer for the connection.
    my @q := @(%!waiters{$origin} //= []);
    while @q.elems {
        my $w = @q.shift;
        if $w.promise.status != Planned {
            $s.abandoned += 1;
            next;
        }
        %!active{$origin} = $n + 1;
        $s.granted += 1;
        $s.reused  += 1;
        self!record-wait($s, $w.since);
        self!bump-active($origin, $s);
        return %(
            kind   => 'handoff',
            origin => $origin,
            waiter => $w,
            lease  => Lease.new(:$origin, :conn($conn), reused => True),
            pump   => False,
        );
    }

    @(%!idle{$origin} //= []).push({ :conn($conn), :since(now) });
    %( kind => 'shelved', origin => $origin, pump => False );
}

# Reserve a slot for the oldest live waiter and return it, or Nil when the
# queue is empty / the origin is at its cap. Called with the lock released.
method !next-pumped(Str $origin --> Mu) {
    my @q := @(%!waiters{$origin} //= []);
    my $s := self!stat($origin);
    my Int $active = %!active{$origin} // 0;

    while @q.elems && $active < $!max-per-host {
        my $w = @q.shift;
        if $w.promise.status != Planned {
            $s.abandoned += 1;
            next;
        }
        $active += 1;
        %!active{$origin} = $active;
        self!bump-active($origin, $s);
        self!record-wait($s, $w.since);
        return $w;
    }
    Nil;
}

method !park(Str $origin, Stat $s, Real $timeout --> Waiter) {
    my $w = Waiter.new(
        promise => Promise.new,
        since   => now,
    );
    my @q := @(%!waiters{$origin} //= []);
    @q.push($w);

    $s.queued += 1;
    $s.peak-queued = @q.elems if @q.elems > $s.peak-queued;

    $w;
}

# A queue wait is not free and must not be unbounded: the caller's own deadline
# covers the time spent waiting, not just the time spent reading. When the
# budget runs out the waiter is removed from the queue *and* its promise broken,
# so no lease can ever be handed to it.
method !arm-wait-timeout(Waiter $w, Str $origin, Real $timeout --> Nil) {
    return unless $timeout.defined && $timeout > 0;
    return unless $*SCHEDULER.defined;

    my $s := $!lock.protect({ self!stat($origin) });
    my Promise $p = $w.promise;

    my &fire = {
        if $p.status == Planned {
            $!lock.protect({
                my @q := @(%!waiters{$origin} //= []);
                my @keep;
                my Bool $found = False;
                for @q -> $x {
                    if !$found && $x === $w {
                        $found = True;
                        next;
                    }
                    @keep.push($x);
                }
                %!waiters{$origin} = @keep if $found;
                $s.queue-timeouts += 1 if $found;
            });
            $p.break(HTTP::Core::X::Timeout.new(
                :phase('queue'),
                reason => "waited more than {$timeout}s for a free connection to {$origin}",
            )) if $p.status == Planned;
        }
    };

    my $cued = try $*SCHEDULER.cue(&fire, :at(now + $timeout));
    unless $cued ~~ Failure {
        $p.then({ try $cued.cancel });
    }
    Nil;
}

method !prune-waiters(Str $origin, Stat $s --> Nil) {
    my @q := @(%!waiters{$origin} //= []);
    return unless @q.elems;

    my @live;
    my Int $dead = 0;
    for @q -> $w {
        if $w.promise.status == Planned { @live.push($w) } else { $dead += 1 }
    }
    return unless $dead;
    %!waiters{$origin} = @live;
    $s.abandoned += $dead;
}

# --- connection life cycle (lock released) -------------------------------

method !connect(Str $origin, Bool :$reused --> Promise) {
    $!lock.protect({ self!stat($origin).connected += 1 });
    $!lock.protect({
        note "DBG connect active={%!active{$origin} // 0} idle={@(%!idle{$origin} // []).elems} waiters={@(%!waiters{$origin} // []).elems}" if $!debug;
    });

    my $raw;
    try {
        $raw = &!transport-factory($origin);
        CATCH { default { $raw = failed($_) } }
    }

    # A factory hands back one of two shapes, and both are legitimate: the TCP
    # and TLS connectors answer with a Promise of a transport (they have real
    # I/O to do), while InMemory -- and every test double written before the
    # pool -- just returns the transport. Accepting only the Promise spelling
    # breaks all in-process tests, which is not a trade worth making.
    if $raw.defined && $raw ~~ Promise {
        # already the async shape
    }
    elsif $raw.defined && $raw.can('incoming') {
        # Wrapped the long way round on purpose: `Promise.kept($transport)`
        # reported the *promise* back as its own result under this module's
        # precompilation, so the lease ended up holding a Promise where a
        # transport was expected. Creating the promise and keeping it in two
        # separate steps is unambiguous and costs nothing.
        my $inner = $raw;
        my $wrapped = Promise.new;
        $wrapped.keep($inner);
        $raw = $wrapped;
    }
    else {
        $raw = failed(HTTP::Core::X::Network.new(
            reason => "transport factory for {$origin} returned neither a transport nor a Promise"));
    }

    my $out = Promise.new;
    my $on-raw = -> $r {
        if $r.status != Kept {
            self!connect-failed($origin);
            self!free-slot($origin);
            self!drain-doomed;
            self!pump($origin);
            $out.break($r.cause);
            return;
        }

        # Anything raised in here -- a transport that does not satisfy the role,
        # a pool that cannot arm a deadline -- lands in the promise returned by
        # `then`, which nobody holds. The caller would then wait on `$out`
        # forever with nothing in the log. So the failure is caught and handed
        # to the caller: a bad factory is a network error, not a hang.
        my $built;
        try {
            $built = self!build-lease($origin, $r.result, :$reused);
            CATCH {
                default {
                    self!connect-failed($origin);
                    self!free-slot($origin);
                    self!drain-doomed;
                    self!pump($origin);
                    $out.break(HTTP::Core::X::Network.new(
                        reason => "could not adopt the connection to {$origin}: {$_.message}"));
                    $built = Mu;
                }
            }
        }

        with $built {
            $!lock.protect({ self!stat($origin).granted += 1 });
            $out.keep($built);
        }
    };

    with-deadline($raw, $!connect-timeout, 'connect').then($on-raw);
    $out;
}

# Turn a transport into a lease. Split out of !connect so the caller can guard
# it: everything that can go wrong (role mismatch, framing setup) happens here,
# and the guard turns it into a broken promise instead of a stranded caller.
method !build-lease(Str $origin, $transport, Bool :$reused --> Lease) {
    my $conn = HTTP::Core::Connection.new(
        :$transport,
        decoder  => HTTP::Core::Framing::Response.new(:max-head($!max-head), :max-body($!max-body)),
        :$!max-head,
        :$!max-body,
        :$!debug,
    );
    Lease.new(:$origin, :$conn, :$reused);
}

method !connect-failed(Str $origin --> Nil) {
    $!lock.protect({ self!stat($origin).connect-failed += 1 });
}

method !free-slot(Str $origin --> Nil) {
    $!lock.protect({
        my Int $n = (%!active{$origin} // 1) - 1;
        %!active{$origin} = $n < 0 ?? 0 !! $n;
    });
}

# Wake the queue after a slot freed up. Each iteration reserves a slot under the
# lock (so two threads cannot both see room for one) and connects outside it.
method !pump(Str $origin --> Nil) {
    loop {
        my $w;
        $!lock.protect({ $w = self!next-pumped($origin) });
        last unless $w.defined;

        my Promise $p = $w.promise;
        self!connect($origin, reused => False).then(-> $r {
            if $r.status == Kept {
                $p.keep($r.result);
            }
            else {
                $p.break($r.cause);
            }
        });
    }
    Nil;
}

method !drain-doomed(--> Nil) {
    loop {
        my @batch;
        $!lock.protect({
            @batch = @!doomed;
            @!doomed = [];
        });
        last unless @batch.elems;
        try $_.close for @batch;
    }
    Nil;
}

# --- accounting (lock held) ----------------------------------------------

method !stat(Str $origin --> Stat) {
    (%!stat{$origin} //= Stat.new)
}

method !bump-active(Str $origin, Stat $s --> Nil) {
    my Int $a = %!active{$origin} // 0;
    $s.peak-active = $a if $a > $s.peak-active;
}

method !record-wait(Stat $s, Instant $since --> Nil) {
    my Real $d = (now - $since);
    $d = 0 if $d < 0;
    $s.wait-time += $d;
    $s.max-wait = $d if $d > $s.max-wait;
}

method !snapshot(Str $origin --> Hash) {
    my $s := (%!stat{$origin} // Stat.new);
    my Int $granted = $s.granted;
    my Int $queued  = $s.queued;

    %(
        granted        => $granted,
        reused         => $s.reused,
        fresh          => $granted - $s.reused,
        connected      => $s.connected,
        connect-failed => $s.connect-failed,
        queued         => $queued,
        queue-timeouts => $s.queue-timeouts,
        abandoned      => $s.abandoned,
        retired        => $s.retired,
        destroyed      => $s.destroyed,
        reuse-rate     => $granted > 0 ?? ($s.reused / $granted) !! 0e0,
        wait-ms-avg    => $queued > 0 ?? ($s.wait-time * 1000 / $queued) !! 0e0,
        wait-ms-max    => $s.max-wait * 1000,
        idle           => (%!idle{$origin}:exists ?? @(%!idle{$origin}).elems !! 0),
        active         => %!active{$origin} // 0,
        waiting        => (%!waiters{$origin}:exists ?? @(%!waiters{$origin}).elems !! 0),
        peak-active    => $s.peak-active,
        peak-queued    => $s.peak-queued,
    );
}

method !total-snapshot(--> Hash) {
    my %t = %(
        granted => 0, reused => 0, fresh => 0, connected => 0,
        connect-failed => 0, queued => 0, queue-timeouts => 0,
        abandoned => 0, retired => 0, destroyed => 0,
        idle => 0, active => 0, waiting => 0,
        peak-active => 0, peak-queued => 0,
    );
    my Real $wait = 0e0;
    my Real $max-wait = 0e0;

    for %!stat.keys -> $o {
        my %m = self!snapshot($o);
        for %t.keys -> $k { %t{$k} += %m{$k} }
        $wait += %m<wait-ms-avg> * %m<queued>;
        $max-wait = %m<wait-ms-max> if %m<wait-ms-max> > $max-wait;
        %t<peak-active> = %m<peak-active> if %m<peak-active> > %t<peak-active>;
        %t<peak-queued> = %m<peak-queued> if %m<peak-queued> > %t<peak-queued>;
    }

    %t<reuse-rate>  = %t<granted> > 0 ?? (%t<reused> / %t<granted>) !! 0e0;
    %t<wait-ms-avg> = %t<queued> > 0 ?? ($wait / %t<queued>) !! 0e0;
    %t<wait-ms-max> = $max-wait;
    %t;
}

