use v6.d;
use NativeCall;
use HTTP::Core::Native;
use HTTP::Core::X;
use HTTP::Core::Codec;

unit class HTTP::Core::Request;

# ---------------------------------------------------------------------------
# A parsed HTTP/1.x request head, plus a zero-copy view of the body.
#
# The C kernel fills offsets into the caller's buffer; this class owns the
# buffer and materialises strings lazily. Nothing here frees C memory because
# the kernel never allocates: every byte lives in $.raw.
#
# The kernel writes header offsets into a native `size_t` block, and slicing
# that block into a Raku Array (`@flat[^4n]`) boxes every element — about
# 3.5-5 microseconds per header, which was the single largest cost in parsing.
# The block is held as one arena and read through a Pointer, so a value is boxed
# only when a caller actually reads it.
# ---------------------------------------------------------------------------

has Blob $.raw is required;

has Int   $!consumed       = 0;
has Int   $!minor-version  = 0;
has Int   $!method-off     = 0;
has Int   $!method-len     = 0;
has Int   $!path-off       = 0;
has Int   $!path-len       = 0;
has Int   $!content-length = -1;
has Bool  $!keep-alive     = False;
has Int   $!n-hdr          = 0;

# Lazily decoded head text, plus whether it is pure ASCII.
#
# Slicing a field straight out of the byte buffer costs ~1.5 us per field
# (a native buffer allocation, an FFI copy and a decode), and a request with
# five headers makes ten slices -- 15 us to read the headers of a 171-byte
# request, more than the C encoder that consumes them. Decoding the head once
# and slicing the Str is ~0.07 us per field.
#
# The shortcut is only valid while byte offset == char offset, which is exactly
# the ASCII case; the check is `chars == consumed` on the decoded head. A head
# with any multi-byte sequence falls back to the byte path, because a header
# value may legally carry UTF-8 and indexing a Str by byte offset would then
# land mid-character.
has Str   $!head-text;
has Bool  $!head-ascii = False;

# The out-arena. Every out-parameter of the kernel lives in one `size_t` block
# (a CArray, so allocation is one calloc-ish step instead of a growing native
# array per field):
#
#   0  method-off       4  minor-version
#   1  method-len       5  headers parsed
#   2  path-off         6  keep-alive (0/1)
#   3  path-len         7  content-length ((size_t)-1 = absent)
#   8 .. SLOT-FLAT+255  header table: 4 * MAX-HEADERS size_t quadruples
#
# Two attempts, two measurements, one survivor:
#
#   1. Pointer.add on a Raku-native `size_t @arena` -- correct but slow. Every
#      add() costs ~1.1 us on this Rakudo, eleven of them put parse at 30.1 us
#      against a 9-array baseline of 10.1 us (bench/11-stack-ab.raku, N=3000
#      REP=12 RUNS=5). The arithmetic that was meant to save allocations cost
#      three times what it saved.
#   2. This version: a CArray arena plus a kernel entry point that addresses its
#      own slots. One allocation, one nativecast, one call. Slot reads go through
#      CArray indexing (~0.35 us) instead of Pointer.add+deref (~1.1 us).
#
# Reusing the arena across calls stays forbidden. Hoisting it into `state` cut
# parse to ~2.4 us once, and with eight threads parsing concurrently 47% of the
# calls came back holding another thread's header table (t/03-threads.rakutest).
# Anything that survives a call is a data race once the server runs a second
# reactor, so the arena is per-request by design.
my constant SLOT-M-OFF  = 0;
my constant SLOT-M-LEN  = 1;
my constant SLOT-P-OFF  = 2;
my constant SLOT-P-LEN  = 3;
my constant SLOT-MINOR  = 4;
my constant SLOT-CAP    = 5;
my constant SLOT-KA     = 6;
my constant SLOT-CLEN   = 7;
my constant SLOT-FLAT   = 8;
my constant ARENA-SLOTS = SLOT-FLAT + 4 * MAX-HEADERS;

my constant CLEN-SIGN-BIT = 9223372036854775808;   # 2**63
my constant CLEN-U-ONE    = 18446744073709551615;  # (size_t)-1

has CArray[size_t] $!arena;

method parse(HTTP::Core::Request:U: Blob:D $raw --> HTTP::Core::Request) {
    # An empty buffer crosses the FFI boundary as a NULL pointer, which the
    # kernel reports as a parse error. Semantically it only means "need more".
    die HTTP::Core::X::Incomplete.new(reason => 'empty buffer') if $raw.elems == 0;

    my CArray[size_t] $arena = CArray[size_t].allocate(ARENA-SLOTS);

    my int32 $rc = http_parse_request_arena(
        nativecast(Pointer[uint8], $raw),
        $raw.elems.UInt,
        nativecast(Pointer, $arena),
        ARENA-SLOTS.UInt,
        MAX-HEADERS.UInt,
    );

    die HTTP::Core::X::Incomplete.new(reason => "head truncated (rc=$rc)")
        if $rc == PARSE-INCOMPLETE;
    die HTTP::Core::X::ParseError.new(reason => "malformed request (rc=$rc)")
        if $rc < 0;

    # The arena travels with the object: it is what keeps the header table
    # reachable while offsets are still being read.
    self.bless(:$raw)!adopt($rc.Int, $arena)
}

# Private attributes cannot be assigned through another object's invocant, so
# every field is funnelled through this in-class setter.
method !adopt(Int $consumed, CArray[size_t] $arena) {
    $!consumed      = $consumed;
    $!arena         = $arena;
    $!minor-version = $arena[SLOT-MINOR].Int;
    $!method-off    = $arena[SLOT-M-OFF].Int;
    $!method-len    = $arena[SLOT-M-LEN].Int;
    $!path-off      = $arena[SLOT-P-OFF].Int;
    $!path-len      = $arena[SLOT-P-LEN].Int;
    $!n-hdr         = $arena[SLOT-CAP].Int;
    $!keep-alive    = $arena[SLOT-KA] != 0;

    my Int $cl = $arena[SLOT-CLEN].Int;
    $cl = $cl - CLEN-U-ONE - 1 if $cl >= CLEN-SIGN-BIT;   # two's complement
    $!content-length = $cl;
    self
}

method !quad(Int $i --> Int) { $!arena[SLOT-FLAT + $i].Int }

method !slice-str(Int $off, Int $len --> Str) {
    return '' if $len <= 0;
    return '' if $off < 0 || $off + $len > $!raw.elems;

    # ASCII head: offsets are interchangeable with char positions, so slice the
    # one decoded Str. Decided on first use and cached on the object.
    unless $!head-text.defined {
        $!head-text  = $!raw.subbuf(0, $!consumed).decode('utf-8');
        $!head-ascii = $!head-text.chars == $!consumed;
    }
    return $!head-text.substr($off, $len) if $!head-ascii;

    # Non-ASCII head: byte offsets are the only honest index, so copy the slice
    # out and decode it on its own.
    my $buf = buf8.allocate($len);
    http_copy_at(
        nativecast(Pointer[uint8], $!raw),
        $off.UInt,
        $len.UInt,
        nativecast(Pointer[uint8], $buf),
    );
    $buf.decode('utf-8')
}

# --- request line ---------------------------------------------------------

method method(--> Str)      { self!slice-str($!method-off, $!method-len) }
method target(--> Str)      { self!slice-str($!path-off,   $!path-len)   }
method http-version(--> Str) { '1.' ~ $!minor-version }

# `path` is the raw request target; path-only/query-string split it.
method path(--> Str) { self.target }

method path-only(--> Str) {
    my $t = self.target;
    my $q = $t.index('?');
    $q.defined ?? $t.substr(0, $q) !! $t
}

method query-string(--> Str) {
    my $t = self.target;
    my $q = $t.index('?');
    ($q.defined && $q + 1 < $t.chars) ?? $t.substr($q + 1) !! ''
}

# --- headers --------------------------------------------------------------

method header-count(--> Int) { $!n-hdr }

method header-name(Int $i --> Str) {
    self!slice-str(self!quad($i * 4), self!quad($i * 4 + 1))
}

method header-value(Int $i --> Str) {
    self!slice-str(self!quad($i * 4 + 2), self!quad($i * 4 + 3))
}

# First match wins, case-insensitively, like most servers do before the
# application layer decides to coalesce duplicates.
method header(Str $name --> Str) {
    my $want = $name.lc;
    my $n    = $!n-hdr;

    # Length prefilter, in BYTES not chars: the kernel reports byte lengths, and
    # "X-名字" is 8 chars but 10 bytes. Comparing against .chars silently dropped
    # every non-ASCII header.
    my $want-len = $want.encode('utf-8').elems;

    for ^$n -> $i {
        my $base = $i * 4;
        my $name-len = self!quad($base + 1);
        next unless $name-len == $want-len;

        if self!slice-str(self!quad($base), $name-len).lc eq $want {
            return self!slice-str(self!quad($base + 2), self!quad($base + 3));
        }
    }
    ''
}

method header-pairs(--> List) {
    (^$!n-hdr).map(-> $i { self.header-name($i) => self.header-value($i) }).List
}

# --- body -----------------------------------------------------------------

# Bytes consumed by the request head; the body starts exactly here.
method consumed(--> Int) { $!consumed }

method body-offset(--> Int) { $!consumed }

method body(--> Buf) {
    my $start = $!consumed;
    return Buf.new if $start >= $!raw.elems;

    my $want = $!content-length > 0 ?? $!content-length !! 0;
    my $end  = $start + $want;
    $end = $!raw.elems if $end > $!raw.elems;

    $!raw.subbuf($start, $end - $start).Buf
}

# --- connection -----------------------------------------------------------

method keep-alive(--> Bool)     { $!keep-alive }
method content-length(--> Int)  { $!content-length }

method is-complete(--> Bool) {
    $!content-length <= 0 || $!raw.elems - $!consumed >= $!content-length
}

# --- encode ---------------------------------------------------------------

# Rebuild this request's wire bytes from its parsed fields.
#
# This is not a convenience wrapper. parse and encode are the two halves of one
# promise, and each is weak alone: an encoder can emit bytes no parser accepts,
# a parser can accept bytes no encoder could produce. Round-tripping a captured
# request through both pins them to each other byte for byte -- t/08 feeds it
# real curl traffic rather than strings we wrote ourselves, so the oracle is
# outside this codebase.
#
# Two choices make the round trip exact rather than merely equivalent:
#
#   * Header order and spelling come straight from the parsed field table,
#     verbatim -- the kernel copies each name and value at the offset the
#     parser recorded. Nothing is normalised, sorted or re-cased, so
#     `Cookie: a=1` stays where the peer put it.
#   * `:close` defaults to False. A parsed request already carries whatever
#     Connection field the peer sent, and Codec only appends `Connection: close`
#     when asked AND no Connection field exists -- so False keeps the capture
#     intact instead of editing it.
#
# Content-Length is the one thing that could drift: Codec refuses a declared
# length that disagrees with the body, so a truncated capture would die here
# with a message instead of emitting a request that promises a body it cannot
# deliver.
#
# The bytes do not come from Codec. Going through it meant header-pairs built a
# Pair per field, Codec joined them into one Str, and that Str was transcoded
# back to UTF-8 -- three full copies of a head we already hold as bytes, and the
# reason a 107-byte round trip cost 38 us against the writer's 8.5. The arena
# from the parser is a (offset, length) table over the original buffer, which is
# exactly what a writer wants, so http_request_bytes walks it and copies the
# head straight out. Measured on the 107-byte capture (bench/13-roundtrip):
# 38.2 us -> 6.4 us, and 53.2 us -> 5.6 us on the 159-byte one with a body --
# from 4.5x the standalone write path to 0.8x of it, because that path pays the
# same materialisation this one skips.
#
# `encode-reference` below keeps the Codec route reachable: it is the independent
# implementation the fast path is checked against, and t/08 asserts the two
# agree byte for byte on every capture.
method encode(Bool :$close = False --> Buf) {
    die "HTTP::Core::Request.encode: body is truncated (have "
      ~ "{$!raw.elems - $!consumed} of {$!content-length} bytes); refusing to "
      ~ "emit a request that claims a body it does not carry"
        unless self.is-complete;

    my Pointer[uint8] $src = nativecast(Pointer[uint8], $!raw);
    my Pointer $arena       = nativecast(Pointer, $!arena);

    # Two passes, never a guess: the length is exact, so the Buf is allocated
    # once at its final size and never grown.
    my int64 $need = http_request_bytes_size(
        $src, $!raw.elems.UInt, $arena, ARENA-SLOTS.UInt,
        $!consumed.UInt, $close.Int,
    );
    self!die-on-kernel-error($need);

    my Buf $out = buf8.allocate($need);
    my int64 $wrote = http_request_bytes(
        nativecast(Pointer[uint8], $out), $need.UInt,
        $src, $!raw.elems.UInt, $arena, ARENA-SLOTS.UInt,
        $!consumed.UInt, $close.Int,
    );

    # A short buffer is the only way the second pass can disagree with the
    # first, and it would mean the measuring pass lied. Refuse rather than
    # hand back a buffer with an unwritten tail.
    die "HTTP::Core::Request.encode: kernel wrote $wrote of $need bytes"
        unless $wrote == $need;

    $out;
}

# The negative returns of http_request_bytes, given words. Kept separate so the
# happy path above reads as two calls and a check.
method !die-on-kernel-error(int64 $rc) {
    return if $rc >= 0;

    my Str $why = do given $rc {
        when -1 { 'the arena does not describe this buffer' }
        when -2 { 'the body is not fully present' }
        when -3 { "a declared Content-Length disagrees with the "
                ~ "{$!content-length} byte body the parser recorded" }
        default { 'unknown kernel error' }
    }
    die "HTTP::Core::Request.encode: $why (kernel rc=$rc)";
}

# The same bytes via Codec: header-pairs -> Str -> UTF-8 -> writer. Slower on
# purpose -- it materialises every field as a Raku Str, which is what makes it
# an independent check rather than a second call into the same code path.
method encode-reference(Bool :$close = False --> Buf) {
    die "HTTP::Core::Request.encode-reference: body is truncated"
        unless self.is-complete;

    HTTP::Core::Codec::encode-request(
        method        => self.method,
        target        => self.target,
        headers       => self.header-pairs,
        body          => self.body,
        minor-version => $!minor-version,
        :$close,
    );
}
