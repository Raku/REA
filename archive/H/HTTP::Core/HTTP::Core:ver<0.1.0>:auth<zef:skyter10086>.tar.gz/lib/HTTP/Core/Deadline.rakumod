use v6.d;
use HTTP::Core::X;

# ---------------------------------------------------------------------------
# One deadline per operation, expressed as "the promise, or a timeout".
#
# Why a module for four lines of logic: the alternative is sprinkling
# `Promise.any($p, Promise.in($t))` at every call site, and that spelling is
# subtly wrong. `Promise.any` only breaks when *all* its inputs break, so a
# timer that fires while the real promise is still pending leaves the combined
# promise pending -- the timeout silently does nothing and the caller hangs
# until the TCP stack gives up, which is exactly the behaviour a timeout is
# supposed to replace.
#
# So: race by hand, first writer wins, and the loser is disarmed.
#
#   $p.then(...)            the real outcome, forwarded verbatim
#   timer -> break $out     fires only if the real outcome has not landed
#
# The timer is armed through `$*SCHEDULER.cue(:at)`, not `Promise.in`, for one
# practical reason: a pool opens a fresh 10-second deadline on every request,
# and an uncancellable timer per request keeps the scheduler's thread alive
# after the work is done. `cue` hands back a Cancellation, so a request that
# finishes in 2 ms also cancels its 10 s timer, and the process exits when the
# work is over instead of when the last timer would have expired.
# ---------------------------------------------------------------------------

our sub with-deadline(Promise:D $p, Real $seconds, Str $phase = 'read' --> Promise) is export {
    return $p unless $seconds.defined && $seconds > 0;

    my $out = Promise.new;
    my $timer;

    # Attach the real outcome first. Rakudo runs `then` callbacks in the order
    # they were attached, so when both fire in the same tick the real result
    # wins and the timer's `status == Planned` guard sees it.
    $p.then(-> $r {
        try $timer.cancel if $timer.defined;
        $r.status == Kept
            ?? $out.keep($r.result)
            !! $out.break($r.cause);
    });

    my &fire = {
        $out.break(HTTP::Core::X::Timeout.new(
            :$phase,
            reason => "{$phase} exceeded {$seconds}s",
        )) if $out.status == Planned;
    };

    # `try` returns a Failure, not Nil, and a Failure is *defined* -- so the
    # naive `$timer = try ...` + `without $timer` pair skips the fallback and
    # then throws from `$timer.cancel` inside the `then` above, where nobody
    # can see it: the combined promise never settles and the caller hangs
    # forever. That is the worst possible failure mode for a timeout, so both
    # spellings are guarded here.
    $timer = Nil;
    if $*SCHEDULER.defined {
        my $cued = try $*SCHEDULER.cue(&fire, :at(now + $seconds));
        $timer = $cued unless $cued ~~ Failure;
    }

    # Schedulers that cannot schedule `:at` (or a replaced $*SCHEDULER) still
    # get a working deadline; only the cancellation is lost.
    unless $timer.defined {
        Promise.in($seconds).then(&fire);
    }

    $out;
}
