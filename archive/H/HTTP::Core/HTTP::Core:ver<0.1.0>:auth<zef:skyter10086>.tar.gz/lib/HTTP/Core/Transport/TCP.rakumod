use v6.d;
use HTTP::Core::Transport;
use HTTP::Core::X;

# ---------------------------------------------------------------------------
# TCP over IO::Socket::Async — the transport the server has always used, now
# behind the role instead of inlined in `Server!serve`.
#
# Nothing about the socket changes: same libuv reactor, same `Supply(:bin)`,
# same `write`/`close`. That is the point of a pure refactor — if this wrapper
# did anything clever, the behaviour it is supposed to preserve would move.
#
# Accepts either a listen-accepted connection (from `.listen(...).tap`) or an
# outbound socket (`.connect(...)`), which is what the future client needs.
# ---------------------------------------------------------------------------

unit class HTTP::Core::Transport::TCP does HTTP::Core::Transport;

has $.socket is required;      # IO::Socket::Async

# Cached: `Supply(:bin)` builds a new Supply on every call, and a connection
# must tap exactly one of them.
has Supply $!incoming;
has Bool $!closed = False;

submethod TWEAK(--> Nil) {
    $!incoming = $!socket.Supply(:bin);
}

method incoming(--> Supply) { $!incoming }

# Writing to a closed socket hands back a broken promise from libuv, which the
# caller is not obligated to handle; short-circuit instead so a race during
# shutdown stays quiet.
method write(Blob:D $bytes --> Promise) {
    return Promise.kept if $!closed;
    $!socket.write($bytes);
}

method close(--> Nil) {
    return if $!closed;
    $!closed = True;
    try $!socket.close;
    Nil;
}

method closed(--> Bool) { $!closed }

method id(--> Int) { $!socket.WHERE }

# Outbound: the one thing a client needs that the server never did.
#
# Returns a Promise of a transport, and breaks -- rather than dies -- on failure,
# so that "connection refused" is an ordinary broken promise the pool's
# connect-deadline can race instead of an exception escaping through the reactor
# callback. The cause is wrapped because `IO::Socket::Async` surfaces the raw
# libuv message, which is not something a caller can branch on.
method connect(HTTP::Core::Transport::TCP:U: Str $host, Int $port --> Promise) {
    my $out = Promise.new;

    IO::Socket::Async.connect($host, $port).then(-> $r {
        if $r.status == Kept {
            $out.keep(HTTP::Core::Transport::TCP.new(socket => $r.result));
        }
        else {
            $out.break(HTTP::Core::X::Network.new(
                reason => "cannot connect to {$host}:{$port}: "
                        ~ ($r.cause ~~ Exception ?? $r.cause.message !! $r.cause)));
        }
    });

    $out;
}
