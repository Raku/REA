use v6.d;
use HTTP::Core::Transport;

# ---------------------------------------------------------------------------
# A transport that is two objects and a Supply, no socket, no port, no reactor
# registration of its own.
#
# Why it is not just a test helper: the server and the client can run in the
# same process over it, which removes the OS from every M3 test. A failure then
# means the protocol stack disagreed with itself, never that a port was taken or
# a SYN timed out. It also drops the noise floor of the A/B benchmarks from
# "cross-process + real socket" to "same process, zero network".
#
# Semantics that must match TCP, because Connection is written against TCP and
# must not be able to tell the difference:
#
#   * write  -> arrives as one Buf on the peer's Supply (a TCP segment)
#   * close  -> the peer sees `done`, i.e. FIN
#   * a write to a closed peer is silently dropped, like a write after RST
#
# What it deliberately does NOT model: partial reads, MTU splitting, latency,
# out-of-order, and TLS. Those are the OS's job; testing them here would just
# re-test the OS.
# ---------------------------------------------------------------------------

unit class HTTP::Core::Transport::InMemory does HTTP::Core::Transport;

has Int $.id;
has Supplier $!inbox .= new;
has Bool $!closed = False;
has $!peer;

# Server-side bookkeeping keys connections by `.id`; sockets give a pointer
# identity for free, these objects need a counter.
my Int $NEXT = 0;

submethod TWEAK(--> Nil) {
    $NEXT = $NEXT + 1;
    $!id = $NEXT;
}

# Two ends, each the other's peer. Returned as a List so callers can write
# `my ($server-side, $client-side) = ...pair;` without index games.
method pair(--> List) {
    my $a = self.new;
    my $b = self.new;
    $a!link($b);
    $b!link($a);
    ($a, $b).List;
}

method !link($other --> Nil) {
    $!peer = $other;
    Nil;
}

method !sink(--> Supplier) { $!inbox }

method incoming(--> Supply) { $!inbox.Supply }

method write(Blob:D $bytes --> Promise) {
    return Promise.kept if $!closed;

    my $peer = $!peer;
    if $peer.defined && !$peer.closed {
        # `emit` on an already-done supplier throws; a write racing with a
        # shutdown must not turn into an exception in the caller's continuation.
        try $peer!sink.emit($bytes.Buf);
    }
    Promise.kept;
}

method close(--> Nil) {
    return if $!closed;
    $!closed = True;

    my $peer = $!peer;
    try $peer!sink.done if $peer.defined && !$peer.closed;
    try $!inbox.done;

    Nil;
}

method closed(--> Bool) { $!closed }
