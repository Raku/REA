use v6.d;
use HTTP::Core::Transport;
use HTTP::Core::X;

# ---------------------------------------------------------------------------
# TLS over IO::Socket::Async::SSL — the same three-verb transport as TCP, with
# a handshake in front of it.
#
# The whole reason this is a separate class instead of a flag on TCP is the
# handshake's failure modes. A TLS connect can fail because the host refused,
# because the certificate did not verify, or because the peer does not speak
# TLS at all; all three surface as different exception texts from OpenSSL, and
# all three must reach the caller as one branchable X::Network rather than
# escaping through the reactor callback.
#
# SNI is not an option here, it is the default: `IO::Socket::Async::SSL.connect`
# takes the host and uses it both for the SNI extension (SSL_CTRL_SET_TLSEXT_HOSTNAME)
# and for the post-handshake hostname check against the certificate. Passing an
# IP literal would therefore both skip SNI and fail verification against any
# real certificate — which is the correct behaviour, not a limitation to paper
# over with `:insecure`.
#
# Port 443 is the default because the only thing that creates this transport is
# an `https://` URL whose port was omitted. Making the caller repeat 443 would
# just be a place for the two to disagree.
# ---------------------------------------------------------------------------

unit class HTTP::Core::Transport::TLS does HTTP::Core::Transport;

my constant DEFAULT-PORT = 443;

has $.socket is required;      # IO::Socket::Async::SSL

has Supply $!incoming;
has Bool $!closed = False;

submethod TWEAK(--> Nil) {
    $!incoming = $!socket.Supply(:bin);
}

method incoming(--> Supply) { $!incoming }

method write(Blob:D $bytes --> Promise) {
    return Promise.kept if $!closed;
    $!socket.write($bytes);
}

method close(--> Nil) {
    return if $!closed;
    $!closed = True;
    try $!socket.close;
    Nil;
}

method closed(--> Bool) { $!closed }

method id(--> Int) { $!socket.WHERE }

# --- trust store ----------------------------------------------------------
#
# OpenSSL's `SSL_CTX_set_default_verify_paths` finds nothing on a stock Windows
# Rakudo install: there is no `/etc/ssl/certs`, and the module ships no bundle.
# The result is every https request failing with "unable to get local issuer
# certificate" while curl on the same box works fine. Resolving a bundle here
# is not a convenience — without it the https path is simply dead on Windows.
#
# Order matters, and the environment variable wins because that is the one knob
# a user can turn without editing code.

my constant CA-CANDIDATES =
    # Windows: Strawberry Perl and Git for Windows both ship a Mozilla bundle.
    'C:\Strawberry\perl\vendor\lib\Mozilla\CA\cacert.pem',
    'C:\Strawberry\c\ssl\cacert.pem',
    'C:\Program Files\Git\mingw64\ssl\certs\ca-bundle.crt',
    'C:\Program Files\Git\usr\ssl\certs\ca-bundle.crt',
    # Linux / BSD.
    '/etc/ssl/certs/ca-certificates.crt',
    '/etc/pki/tls/certs/ca-bundle.crt',
    '/etc/ssl/cert.pem',
    # macOS (Homebrew).
    '/opt/homebrew/etc/openssl@3/cert.pem',
    '/usr/local/etc/openssl@3/cert.pem';

sub resolve-ca-file(--> Str) {
    state Str $cached;

    return $cached if $cached.defined;

    for %*ENV<SSL_CERT_FILE CURL_CA_BUNDLE SSL_CERT_DIR> -> $env {
        next unless $env.defined && $env.chars;
        return $cached = $env if $env.IO.e;
    }

    for CA-CANDIDATES -> $path {
        return $cached = $path if $path.IO.e;
    }

    # Nothing found: return an empty Str so `connect` omits the argument and
    # OpenSSL's own defaults get one last chance. The error message on failure
    # then tells the user which variable to set.
    $cached = '';
}

# A verification failure is the one TLS error a user can actually fix, and the
# OpenSSL text ("unable to get local issuer certificate") does not say how.
sub verification-hint(--> Str) {
    my Str $ca = resolve-ca-file();
    return '' if $ca.chars;
    ' (no CA bundle found: set SSL_CERT_FILE to a PEM bundle, or pass :ca-file to the client)';
}

# --- connect --------------------------------------------------------------

# Returns a Promise of a transport; breaks — never dies — on failure, for the
# same reason TCP does: the pool's connect-deadline races this promise, and an
# exception escaping into the reactor would bypass that race entirely.
method connect(
    HTTP::Core::Transport::TLS:U:
    Str $host,
    Int $port = DEFAULT-PORT,
    Str :$ca-file,
    Bool :$insecure = False,
    --> Promise
) {
    my $out = Promise.new;

    my %opt;
    if $insecure {
        # Skipping the CA bundle is not the same as skipping verification: the
        # module only stops checking the chain when told so explicitly. Before
        # this line `:insecure` silently had no effect, and every self-signed
        # certificate still failed with "self signed certificate".
        %opt<insecure> = True;
    }
    else {
        my Str $ca = $ca-file.defined && $ca-file.chars ?? $ca-file !! resolve-ca-file();
        %opt<ca-file> = $ca if $ca.chars;
    }

    # `require` rather than `use`: an http-only program must not pay for loading
    # OpenSSL bindings, and an in-memory test must not need them installed.
    my $ssl;
    my $load-err;
    {
        require IO::Socket::Async::SSL;
        $ssl = ::('IO::Socket::Async::SSL');
        CATCH { default { $load-err = $_ } }
    }
    with $load-err {
        $out.break(HTTP::Core::X::Network.new(
            reason => "cannot load IO::Socket::Async::SSL for {$host}:{$port}: {$load-err.message}",
        ));
        return $out;
    }

    my $pending;
    my $sync-err;
    {
        # `$host` doubles as the SNI name and as the name the certificate is
        # checked against; there is deliberately no way to split them.
        $pending = $ssl.connect($host, $port, |%opt);
        CATCH { default { $sync-err = $_ } }
    }
    with $sync-err {
        $out.break(HTTP::Core::X::Network.new(
            reason => "TLS handshake with {$host}:{$port} failed: {$sync-err.message}",
        ));
        return $out;
    }

    $pending.then(-> $r {
        if $r.status == Kept {
            $out.keep(HTTP::Core::Transport::TLS.new(socket => $r.result));
        }
        else {
            my $cause = $r.cause;
            my Str $why = $cause ~~ Exception ?? $cause.message !! $cause.gist;
            my Str $hint = $why ~~ /:i verify|certificate|issuer/ ?? verification-hint() !! '';
            $out.break(HTTP::Core::X::Network.new(
                reason => "cannot connect to {$host}:{$port} over TLS: {$why}{$hint}",
            ));
        }
    });

    $out;
}
