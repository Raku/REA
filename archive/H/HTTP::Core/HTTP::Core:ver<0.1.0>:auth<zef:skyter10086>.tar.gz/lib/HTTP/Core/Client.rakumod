﻿use v6.d;
use JSON::Fast;
use HTTP::Core::Client::URL;
use HTTP::Core::Pool;
use HTTP::Core::Codec;
use HTTP::Core::Codec::Content;
use HTTP::Core::Response;
use HTTP::Core::Deadline;
use HTTP::Core::X;

# ---------------------------------------------------------------------------
# The client: URL in, Response out.
#
# Everything below is a thin policy layer over machinery that already exists.
# The pool owns sockets, Connection owns the byte stream, Framing::Response owns
# message boundaries, Codec owns serialisation. What is left here is exactly the
# part that is *policy* and therefore differs between clients:
#
#   * which headers to derive (Host, User-Agent, Accept-Encoding)
#   * how long a request may take, and what a timeout is called
#   * whether to follow a redirect, how the method changes, how many hops
#   * when a stale pooled connection may be retried (idempotent methods only)
#   * which exception class a failure becomes
#
# Three deliberate omissions, all of them M5+:
#
#   * TLS. `https://` now goes through Transport::TLS (SNI, port 443, verified
#     certificates). Loaded at runtime so an http-only program never opens a
#     socket to OpenSSL.
#   * gzip. `Accept-Encoding` is derived from what Codec::Content can actually
#     undo, and every response with a Content-Encoding is decoded before it
#     reaches the caller. If zlib is unavailable the header falls back to
#     `identity` -- advertising a coding we cannot decode is worse than not
#     compressing at all.
#   * `Expect: 100-continue`. The framer *skips* interim 1xx responses, which is
#     required; sending the header is not.
# ---------------------------------------------------------------------------

unit class HTTP::Core::Client;

has Str  $.user-agent      = 'HTTP-Core/0.1.0';
has Real $.timeout         = 10;      # whole request, every hop; <=0 disables
has Real $.connect-timeout = 3;
has Real $.idle-timeout    = 15;      # must stay below the server's keep-alive
has Int  $.max-per-host    = 8;
has Int  $.max-redirects   = 5;
has Bool $.follow          = True;
has Int  $.max-head        = 64 * 1024;
has Int  $.max-body        = 8 * 1024 * 1024;
has Bool $.debug           = False;

# TLS knobs. `$!ca-file` defaults to auto-discovery (see Transport::TLS): on a
# stock Windows Rakudo there is no default trust store, so "just use the system
# one" is not an option that exists.
has Str  $.ca-file;
has Bool $.insecure = False;

has HTTP::Core::Pool $!pool;

# Methods a retry cannot break, per RFC 9110 §9.2.2. POST and PATCH are absent
# on purpose: retailing a POST that may already have reached the handler is a
# duplicate order, not a retry.
my constant %IDEMPOTENT = GET => 1, HEAD => 1, OPTIONS => 1, TRACE => 1,
                          PUT => 1, DELETE => 1;

submethod TWEAK(:&transport-factory?, :$transport? --> Nil) {
    my &factory;

    if &transport-factory {
        &factory = &transport-factory;
    }
    elsif $transport.defined {
        # One fixed transport, no real pooling: what an in-process test pair
        # gives you. Every request borrows the same physical connection.
        #
        # Single-use on purpose. A second `connect` on the same transport would
        # mean two Connections tapping one byte Supply -- both would see the
        # same bytes and both would mis-frame. Failing loudly (and keeping
        # max-per-host at 1, so requests queue instead of racing) is the only
        # honest behaviour; a real pool needs a real factory.
        my $fixed = $transport;
        my Bool $taken = False;

        &factory = -> Str $origin {
            if $taken {
                return failed(HTTP::Core::X::Network.new(
                    reason => "the single transport given to Client.new is already in use; "
                            ~ "pass :transport-factory to get a real pool"));
            }
            $taken = True;
            Promise.kept($fixed);
        };

        $!max-per-host = 1;
    }
    else {
        # The default factory is a closure, not a bare `&connect-origin` sub,
        # because the TLS knobs are per-client state: two clients in one process
        # (one pinning a CA bundle, one not) must not share a global.
        my Str  $ca   = $!ca-file;
        my Bool $ins  = $!insecure;
        &factory = -> Str $origin { connect-origin($origin, $ca, $ins) };
    }

    $!pool = HTTP::Core::Pool.new(
        transport-factory => &factory,
        :$!max-per-host,
        :$!idle-timeout,
        :$!connect-timeout,
        :$!max-head,
        :$!max-body,
        :$!debug,
    );
}

# --- public surface -------------------------------------------------------

method get(Str $url, *%opt --> Promise)     { self.request('GET',     $url, |%opt) }
method head(Str $url, *%opt --> Promise)    { self.request('HEAD',    $url, |%opt) }
method post(Str $url, *%opt --> Promise)    { self.request('POST',    $url, |%opt) }
method put(Str $url, *%opt --> Promise)     { self.request('PUT',     $url, |%opt) }
method patch(Str $url, *%opt --> Promise)   { self.request('PATCH',   $url, |%opt) }
method delete(Str $url, *%opt --> Promise)  { self.request('DELETE',  $url, |%opt) }
method options(Str $url, *%opt --> Promise) { self.request('OPTIONS', $url, |%opt) }

# The general entry point. Named arguments:
#
#   :%headers        extra request headers; multi-value by passing a list
#   :$body           Blob or Str
#   :$json           anything JSON::Fast can serialise; sets Content-Type
#   :$timeout        seconds for this request (whole redirect hop incl. connect)
#   :$max-redirects  hops allowed for this request
#   :$follow         per-request override of the client default
method request(Str $method, Str $url, *%opt --> Promise) {
    # Run the hop chain on the scheduler, always.
    #
    # `!send`/`!attempt` register `then` callbacks. A pooled connection hands
    # back an *already kept* promise, so those callbacks run on whichever thread
    # called `request` -- and if that thread has not awaited anything yet there
    # is no $*SCHEDULER in scope, which silently turns `with-deadline`'s timer
    # and every `start` inside the continuation into no-ops. The request then
    # hangs forever with no timeout. Starting here makes the first request and
    # the tenth request behave identically.
    Promise.start({ await self!request-impl($method, $url, |%opt) });
}

method !request-impl(
    Str $method,
    Str $url,
    :%headers = {},
    :$body,
    :$json,
    Real :$timeout,
    Int  :$max-redirects,
    Bool :$follow,
    --> Promise
) {
    my $u = try HTTP::Core::Client::URL.parse($url);
    unless $u.defined {
        return failed($! ~~ Exception ?? $! !! HTTP::Core::X::InvalidUrl.new(reason => $url));
    }

    my Blob $payload;
    my %h = %headers;

    if $json.defined {
        $payload = to-json($json).encode('utf-8');
        %h<Content-Type> //= 'application/json';
    }
    elsif $body.defined {
        $payload = $body ~~ Blob ?? $body !! $body.Str.encode('utf-8');
    }

    my Real $budget = ($timeout // $!timeout);
    my Instant $deadline = $budget > 0 ?? now + $budget !! Instant;

    self!send(
        $u,
        $method.uc,
        %h,
        $payload,
        $deadline,
        ($max-redirects // $!max-redirects),
        ($follow // $!follow),
    );
}

method pool(--> HTTP::Core::Pool) { $!pool }

method close(--> Nil) { $!pool.close; Nil }

method closed(--> Bool) { $!pool.closed }

# --- one hop --------------------------------------------------------------

# Every callback below is a named sub, not a pointy block with `return`.
#
# A `.then` callback runs after the method that registered it has already
# returned, so a bare `return` inside it has no routine frame to land in and
# Rakudo dies with "Attempt to return outside of any Routine". Inside a sub the
# `return` is local to the sub, which is exactly what the early-exit style below
# means. The alternative -- nesting if/else four deep -- buries the four
# branches that matter here: redirect, stale, framing error, success.

method !send(HTTP::Core::Client::URL $u, Str $m, %h, $payload, Instant $deadline, Int $left, Bool $follow --> Promise) {
    my $out = Promise.new;

    my $on-attempt = sub ($r) {
        unless $r.status == Kept {
            $out.break($r.cause);
            return;
        }

        my $res = $r.result;
        my Int $status = $res.status;
        my Str $loc = $res.header('location') // '';

        # 301/302/303/307/308 with a Location. Anything else -- including a
        # 3xx we do not know how to reinterpret (300, 305, 306) -- is returned
        # to the caller as-is: guessing is how a client corrupts a POST.
        my Bool $is-redirect = $status == 301 || $status == 302 || $status == 303
                            || $status == 307 || $status == 308;

        unless $follow && $is-redirect && $loc.chars {
            $out.keep($res);
            return;
        }

        if $left <= 0 {
            $out.break(HTTP::Core::X::Redirect.new(
                reason => "{$m} {$u}: exceeded {$!max-redirects} redirects "
                        ~ "(last Location: {$loc})",
            ));
            return;
        }

        my $next = try HTTP::Core::Client::URL.parse($loc, $u);
        unless $next.defined {
            $out.break(HTTP::Core::X::InvalidUrl.new(
                reason => "cannot resolve redirect Location '{$loc}' from '{$u}'",
            ));
            return;
        }

        # Method rewriting, per RFC 9110 §15.4:
        #
        #   303                  always GET, body dropped
        #   301/302 + POST       GET, body dropped (universal browser behaviour;
        #                        a real /login -> /home flow depends on it)
        #   301/302 + others     method preserved (RFC 9110 says only POST may be
        #                        rewritten, and being conservative here is what
        #                        keeps a PUT idempotent)
        #   307/308              method *and* body preserved, by definition
        my Str $next-m    = $m;
        my     $next-body = $payload;
        my Bool $drop     = False;

        given $status {
            when 303 { $next-m = 'GET'; $drop = True }
            when 301 | 302 { if $m eq 'POST' { $next-m = 'GET'; $drop = True } }
        }

        my %next-h = %h;
        if $drop {
            $next-body = Nil;
            %next-h<Content-Type>:delete;
        }

        note "HTTP::Core::Client: {$status} -> {$next-m} {$next}" if $!debug;

        self!send($next, $next-m, %next-h, $next-body, $deadline, $left - 1, $follow)
            .then(-> $r2 {
                $r2.status == Kept ?? $out.keep($r2.result) !! $out.break($r2.cause)
            });
    };

    self!attempt($u, $m, self!head-lines($u, %h, $payload), $payload, $deadline)
        .then($on-attempt);

    $out;
}

# --- one attempt (one connection, one response) ---------------------------

method !attempt(
    HTTP::Core::Client::URL $u,
    Str $m,
    List $hdrs,
    $payload,
    Instant $deadline,
    Bool :$retry = True,
    --> Promise
) {
    my Real $budget = $deadline.defined ?? $deadline - now !! 0;

    if $deadline.defined && $budget <= 0 {
        return failed(HTTP::Core::X::Timeout.new(
            :phase(lc $m), reason => "{$m} {$u}: no time left before the deadline",
        ));
    }

    my $out = Promise.new;

    # Assigned in `$on-acquire`, read in `$on-read`. Declared at method scope so
    # the second closure can see the same container the first one filled, and
    # declared *before* `$on-acquire` because lexical lookup is positional.
    my $lease;
    my $conn;
    my $on-read;

    my $on-acquire = sub ($ar) {
        unless $ar.status == Kept {
            $out.break(wrap($ar.cause, "{$m} {$u}"));
            return;
        }

        $lease = $ar.result;
        $conn  = $lease.conn;

        # Per-request decoder state: one pooled socket can serve a HEAD and then
        # a GET, and the two have different body rules.
        $conn.decoder.head = ($m eq 'HEAD');

        my Blob $bytes;
        my $enc-err;
        {
            $bytes = encode-request(
                :method($m),
                :target($u.target),
                :headers($hdrs),
                :body($payload),
            );
            CATCH { default { $enc-err = $_ } }
        }
        with $enc-err {
            $!pool.release($lease, :force);
            $out.break(HTTP::Core::X::Protocol.new(
                reason => "{$m} {$u}: cannot encode request: {$enc-err.message}",
            ));
            return;
        }

        # Ask for the response *before* writing: if the socket is already dead
        # the waiter fails on the next event-loop tick, with nothing in flight.
        my $read = $conn.next-message;

        # The write's promise is deliberately not awaited. A socket that the peer
        # has closed accepts the bytes locally and reports the failure as EOF on
        # the read side; waiting on the write would just add a second way to
        # observe the same death, and some transports never call back at all.
        $conn.write($bytes);

        with-deadline($read, $budget, lc $m).then($on-read);
    };

    $on-read = sub ($rr) {
        unless $rr.status == Kept {
            my $cause = $rr.cause;
            note "DBG on-read reused={$lease.reused} text=[{cause-text($cause)}] class={$cause.^name}" if $!debug;
            $!pool.release($lease, :force);

            # The one shape worth retrying: a *reused* connection that is
            # already closed, observed as EOF before any response byte arrived.
            #
            # Two gates, both required. `reused` keeps a genuinely dead fresh
            # connection from spinning (it is a real network error); the
            # idempotent set keeps a POST from being sent twice, because a peer
            # that acted on the first copy would now act again. The retry is
            # recursive with `retry => False`, so it can happen at most once.
            if $lease.reused && cause-text($cause) eq 'connection closed' {
                if $retry && %IDEMPOTENT{$m} {
                    note "HTTP::Core::Client: stale connection, retrying {$m} {$u}" if $!debug;
                    self!attempt($u, $m, $hdrs, $payload, $deadline, retry => False)
                        .then(-> $r2 {
                            $r2.status == Kept
                                ?? $out.keep($r2.result)
                                !! $out.break($r2.cause)
                        });
                    return;
                }
                $out.break(HTTP::Core::X::Network.new(
                    reason => "{$m} {$u}: pooled connection closed by peer; "
                            ~ "{$m} is not idempotent, refusing to retry",
                ));
                return;
            }

            $out.break(wrap($cause, "{$m} {$u}"));
            return;
        }

        my $frame = $rr.result;

        if $frame.failed {
            $!pool.release($lease, :force);
            $out.break(self!framing-error($frame.error, "{$m} {$u}"));
            return;
        }

        my $res = $frame.response;

        # `usable` is the peer's opinion ("Connection: close") plus the
        # framing's (until-close means the message ended because the socket
        # did). Either one is enough to keep it out of the pool.
        $!pool.release($lease, :force(!$res.usable));

        # Decode before the caller sees it -- and after the lease has been
        # released, deliberately: the body is fully read at this point, so the
        # connection is aligned whether or not the bytes turn out to be valid
        # gzip, and a corrupt body must not cost the pool a healthy socket.
        my $decoded;
        my $dec-err;
        {
            $decoded = self!decoded($res);
            CATCH { default { $dec-err = $_ } }
        }
        with $dec-err {
            $out.break($dec-err ~~ HTTP::Core::X::Base
                ?? $dec-err
                !! HTTP::Core::X::Protocol.new(
                       reason => "{$m} {$u}: content decoding failed: {$dec-err.message}"));
            return;
        }

        $out.keep($decoded);
    };

    $!pool.acquire($u.origin).then($on-acquire);

    $out;
}

# --- header derivation ----------------------------------------------------

my constant %MANAGED = content-length => 1, transfer-encoding => 1,
                       connection => 1;

method !head-lines(HTTP::Core::Client::URL $u, %given, $payload --> List) {
    my @h;
    my %seen;

    my sub add(Str $k, Str $v) {
        return if %seen{$k.lc};
        %seen{$k.lc} = True;
        @h.push($k => $v);
    }

    my %have = %given.keys.map(*.lc).Set;

    add('Host', $u.host-header) unless %have<host>;
    add('User-Agent', $!user-agent) unless %have<user-agent>;
    add('Accept', '*/*') unless %have<accept>;

    # The one header whose value is derived from a capability, not a preference:
    # what we advertise is exactly what !decoded can undo. The two live in the
    # same class for that reason -- there is no branch where we advertise a
    # coding we cannot decode, so a server that sends one gets a loud
    # X::Protocol instead of the caller receiving 400 bytes of DEFLATE labelled
    # text/html.
    unless %have<accept-encoding> {
        add('Accept-Encoding', accept-encoding-value());
    }

    for %given.keys.sort -> $k {
        my Str $lc = $k.lc;
        next if %MANAGED{$lc};

        # A redirect that dropped the body must not carry its Content-Type:
        # "GET with Content-Type: application/json" makes some frameworks try to
        # parse an empty body and answer 400.
        next if $lc eq 'content-type' && !$payload.defined;

        my $v = %given{$k};
        next unless $v.defined;

        add($k, $v ~~ Positional ?? $v.map(*.Str).join(', ') !! $v.Str);
    }

    @h.List;
}

# --- failure mapping ------------------------------------------------------

# One place that turns a caught thing into an exception class the caller can
# `CATCH` on structurally, instead of matching on message text.
#
#   X::Timeout    -- a deadline expired (phase name says connect or the method)
#   X::Network    -- the connection could not be made or went away mid-request
#   X::Truncated  -- the peer closed in the middle of a message
#   X::Protocol   -- the peer said something that is not HTTP we understand
#   X::Redirect   -- too many hops
#   X::InvalidUrl -- the URL or a Location could not be parsed
# A broken promise as a value. `Promise.new.break($e)` reads nicely but does not
# reliably return the promise, and a helper is cheaper than remembering that.
sub failed(Exception $e --> Promise) {
    my $p = Promise.new;
    $p.break($e);
    $p;
}

# `Promise.break('text')` does not leave a Str in `.cause` -- Rakudo wraps it in
# an X::AdHoc, so a plain `$cause ~~ Str` test is always False and every
# string-keyed decision silently falls through to the generic branch. The
# stale-lease rule is exactly such a decision ("did the peer close?"), and
# getting it wrong turns a retryable dead socket into a hard X::Network. Flatten
# all three shapes a transport might use (Str, X::AdHoc, Exception) once, here.
sub cause-text($cause --> Str) {
    return $cause if $cause ~~ Str;
    return $cause.payload
        if $cause ~~ X::AdHoc && $cause.payload ~~ Str;
    return $cause.message if $cause ~~ Exception;
    return $cause.gist if $cause.defined;
    '';
}

sub wrap($cause, Str $context --> Exception) {
    return $cause if $cause ~~ HTTP::Core::X::Base;

    given $cause {
        when Exception {
            HTTP::Core::X::Network.new(reason => "{$context}: {$cause.message}")
        }
        when Str {
            HTTP::Core::X::Network.new(reason => "{$context}: {$cause}")
        }
        default {
            HTTP::Core::X::Network.new(reason => "{$context}: {$cause.gist}")
        }
    }
}

# Framing errors arrive as short strings because Framing is a value-returning
# module with no exception control flow. They are mapped to classes here, at the
# one layer that knows it is talking to an application.
method !framing-error(Str $why, Str $context --> Exception) {
    given $why {
        when 'truncated' {
            HTTP::Core::X::Truncated.new(
                reason => "{$context}: peer closed mid-message")
        }
        when 'head-too-large' {
            HTTP::Core::X::Protocol.new(
                reason => "{$context}: response head exceeds {$!max-head} bytes")
        }
        when 'body-too-large' {
            HTTP::Core::X::Protocol.new(
                reason => "{$context}: response body exceeds the cap")
        }
        when 'bad-response' {
            HTTP::Core::X::Protocol.new(
                reason => "{$context}: malformed response head")
        }
        default {
            HTTP::Core::X::Protocol.new(
                reason => "{$context}: response framing failed ({$why})")
        }
    }
}

# Default transport: TCP for http, IO::Socket::Async::SSL for https.
#
# The scheme decides the transport, and nothing else does -- no "port 443 means
# TLS" guessing, because a plain-http server on 443 and a TLS server on 8080 are
# both perfectly real and guessing between them produces a handshake failure
# nobody can read.
sub connect-origin(Str $origin, Str $ca-file, Bool $insecure --> Promise) {
    my $u = try HTTP::Core::Client::URL.parse($origin);

    unless $u.defined {
        return failed(HTTP::Core::X::InvalidUrl.new(
            reason => "cannot parse origin '{$origin}'"));
    }

    # Loaded at runtime, and looked up by name, for two reasons that both bit:
    # a compile-time `use` would drag IO::Socket::Async (and OpenSSL) into every
    # in-memory test, and a bare `HTTP::Core::Transport::TCP.connect(...)` is
    # resolved against the *role* `HTTP::Core::Transport`, which has no `TCP` in
    # it -- it fails as "Could not find symbol '&TCP'". A test that always
    # injects a transport-factory never sees either problem, which is exactly
    # why the default path needs its own case in t/10.
    if $u.secure {
        require HTTP::Core::Transport::TLS;
        return ::('HTTP::Core::Transport::TLS').connect(
            $u.host, $u.port, :$ca-file, :$insecure);
    }

    require HTTP::Core::Transport::TCP;
    ::('HTTP::Core::Transport::TCP').connect($u.host, $u.port);
}

# --- content decoding -----------------------------------------------------

# Codec::Content is `use`d at the top of this file, so `accept-encoding-value`
# and `decode-body` below are lexical sub calls, not runtime module lookups.
#
# A runtime `require` was tried first and cannot work from here: once
# HTTP::Core::Client is precompiled, `require "HTTP::Core::Codec::Content"`
# returns a bare stub -- the name resolves, `^can('decode-body')` is empty, and
# any call dies with "Too many positionals passed". (Reproduced in an isolated
# probe: the same require succeeds from a plain script and fails from a script
# that has merely loaded this precompiled unit.) The price is that gzip support
# needs Compress::Zlib at load time, which ships with Rakudo Star.

# Undo Content-Encoding. Called after the framing has consumed the whole body,
# so a decode failure must not poison the connection: the bytes are gone from the
# socket either way and the next message is still aligned.
method !decoded(HTTP::Core::Response $res --> HTTP::Core::Response) {
    # A response with no body (204, 304, or the answer to HEAD) may still carry
    # a `Content-Encoding` that describes a body that was never sent -- real
    # servers do exactly that for HEAD, and example.com is one of them. Inflating
    # zero bytes then fails on the gzip trailer, so the honest reading of "no
    # body" wins over the header: nothing to decode, leave the message alone and
    # keep its Content-Length visible to the caller.
    return $res if $res.framing eq 'no-body';

    my Str $enc = $res.header('content-encoding') // '';
    return $res unless $enc.chars;

    # `identity` is the only coding that is always safe to leave alone.
    my @codings = $enc.split(',').map(*.trim.lc).grep(*.chars).grep(* ne 'identity');
    return $res unless @codings.elems;

    my $body = $res.body-bytes;
    my Blob $plain = decode-body($body, $enc, $!max-body);

    note "HTTP::Core::Client: decoded {$body.elems} -> {$plain.elems} bytes ({$enc})"
        if $!debug;

    $res.with-body($plain);
}
