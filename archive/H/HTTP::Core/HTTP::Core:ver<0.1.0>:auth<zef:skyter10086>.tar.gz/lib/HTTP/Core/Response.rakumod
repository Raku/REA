﻿use v6.d;
use NativeCall;          # size_t / int32 / int64 / Pointer / nativecast
use HTTP::Core::Native;
use HTTP::Core::Bytes;   # str-bytes: the fast UTF-8 encoder
use HTTP::Core::X;       # X::Incomplete / X::ParseError, same as Request

# ---------------------------------------------------------------------------
# A response value object plus its wire serialisation.
#
# Kept deliberately dumb: no chunking, no compression, no header negotiation.
# The server decides Connection: and Content-Length: from the request, so a
# handler can stay ignorant of transport details.
#
# One class, two roles:
#
#   handler-built   status + headers + body, serialised by .payload
#   parsed          .parse(Blob) fills the same fields from the wire, plus the
#                   connection-level facts a client cannot infer from the body
#                   (framing kind, bytes consumed, raw head)
#
# Sharing the class is on purpose: a client re-serialises what it received
# (redirects, retries, proxy-style echo) often enough that a second message type
# would just mean two ways to say the same thing.
# ---------------------------------------------------------------------------

unit class HTTP::Core::Response;

has Int  $.status  = 200;
has      %.headers;
has      $.body;
has Bool $.close   = False;

# --- parsed-side state -----------------------------------------------------
#
# These only carry meaning on a response produced by .parse. A handler-built
# response leaves them at their defaults, and the defaults are chosen so that
# reading them anyway gives a sane answer rather than a Nil.
has Int  $.minor-version  = 1;
has      @.header-list;          # ordered Name => value, duplicates kept
has Str  $.reason-text;          # as received; may differ from %REASON
has Int  $.content-length = -1;  # -1 = header absent
has Int  $.consumed       = 0;   # bytes of head eaten by the parser
has Int  $.framing-kind   = 0;   # FRAMING-* from HTTP::Core::Native
has Blob $.raw;                  # the buffer the head was parsed from

# Reason phrases, kept in lockstep with HTTP_REASONS in src/http_wire.c: the C
# writer and the Raku fallback must produce identical bytes, and t/04 checks
# exactly that. Unknown codes degrade to 'Unknown' on both sides.
my %REASON =
    100 => 'Continue',
    101 => 'Switching Protocols',
    200 => 'OK',
    201 => 'Created',
    202 => 'Accepted',
    203 => 'Non-Authoritative Information',
    204 => 'No Content',
    205 => 'Reset Content',
    206 => 'Partial Content',
    301 => 'Moved Permanently',
    302 => 'Found',
    303 => 'See Other',
    304 => 'Not Modified',
    307 => 'Temporary Redirect',
    308 => 'Permanent Redirect',
    400 => 'Bad Request',
    401 => 'Unauthorized',
    402 => 'Payment Required',
    403 => 'Forbidden',
    404 => 'Not Found',
    405 => 'Method Not Allowed',
    406 => 'Not Acceptable',
    408 => 'Request Timeout',
    409 => 'Conflict',
    410 => 'Gone',
    411 => 'Length Required',
    412 => 'Precondition Failed',
    413 => 'Payload Too Large',
    414 => 'URI Too Long',
    415 => 'Unsupported Media Type',
    416 => 'Range Not Satisfiable',
    418 => "I'm a teapot",
    422 => 'Unprocessable Content',
    429 => 'Too Many Requests',
    431 => 'Request Header Fields Too Large',
    500 => 'Internal Server Error',
    501 => 'Not Implemented',
    502 => 'Bad Gateway',
    503 => 'Service Unavailable',
    504 => 'Gateway Timeout',
    505 => 'HTTP Version Not Supported',
;

# A parsed response carries the peer's own words; a handler-built one is
# described by the table, which is also what the C writer emits.
method reason(--> Str) {
    return $!reason-text if $!reason-text.defined;
    %REASON{$!status} // 'Unknown'
}

# Body as raw bytes, whatever the caller handed us.
#
# Returns Blob, not Buf-to-Blob: `Buf.append` accepts any Blob, so the only
# cast that used to happen here bought a full extra copy and nothing else.
method body-bytes(--> Blob) {
    return buf8.new unless $!body.defined;

    # Smartmatch, not `given/when`: the dispatch form costs ~2 us per call on
    # Rakudo 2026.09 (measured), while a plain `~~` is a single type check.
    # Str is first because that is what handlers return nine times out of ten.
    return str-bytes($!body) if $!body ~~ Str;
    return $!body            if $!body ~~ Blob;
    str-bytes($!body.Str)
}

# A copy of this response carrying a different body, with the headers that
# describe the old body removed.
#
# This is what a Content-Encoding decoder needs. After inflating 3 KB of gzip
# into 40 KB of JSON, three things are no longer true of the message: the body
# is not `Content-Encoding: gzip`, its length is not the original
# `Content-Length`, and any strong `ETag` computed over the encoded bytes no
# longer matches what the caller can read. Leaving the first two in place is the
# classic client bug -- the next hop in a proxy chain double-decodes, and a
# caller that trusts Content-Length reads past the end.
#
# `Transfer-Encoding` goes with them, for the same reason one level down: once
# the chunk framing has been walked off the wire, the body in hand is plain
# bytes. A response that still advertises `chunked` while carrying a de-chunked
# body is worse than a stale label -- anything that re-serialises it (a retry, a
# proxy echo, a log replay) will chunk-encode an already-decoded payload and the
# peer will read the first `{"` as a hex chunk size.
#
# `clone`, not a constructor round-trip: the parsed-side state (raw head bytes,
# framing kind, consumed) must survive verbatim, and re-listing 12 attributes is
# a bug waiting for the thirteenth.
method with-body(
    Blob $bytes,
    Bool :$drop-encoding = True,
    Bool :$drop-transfer = False,
    --> HTTP::Core::Response
) {
    return self.clone(:body($bytes)) unless $drop-encoding || $drop-transfer;

    my @hl;
    my %h;
    for @!header-list -> $p {
        my Str $lc = $p.key.lc;
        next if $drop-encoding && ($lc eq 'content-encoding' || $lc eq 'content-length');
        next if $drop-transfer && $lc eq 'transfer-encoding';
        @hl.push($p);
        %h{$p.key} = $p.value;
    }

    self.clone(
        :body($bytes),
        :header-list(@hl),
        :headers(%h),
        :content-length($drop-encoding ?? -1 !! $!content-length),
    );
}

# RFC 1123 date, the only format HTTP/1.1 recipients are required to accept.
sub rfc1123(DateTime $dt --> Str) {
    my @dow = <Sun Mon Tue Wed Thu Fri Sat>;
    my @mon = <Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec>;

    # Built by concatenation, not sprintf: on Rakudo 2026.09 a single sprintf
    # call costs ~230 microseconds, which would dominate the whole response
    # path.
    #
    # Every field is coerced with .Int: DateTime accessors such as .day can come
    # back as Num, which would leak "43.5" into the wire format.
    @dow[$dt.day-of-week.Int % 7] ~ ', ' ~ pad2($dt.day) ~ ' '
        ~ @mon[$dt.month.Int - 1] ~ ' ' ~ $dt.year.Int ~ ' '
        ~ pad2($dt.hour) ~ ':' ~ pad2($dt.minute) ~ ':' ~ pad2($dt.second)
        ~ ' GMT';
}

sub pad2($n --> Str) {
    my $i = $n.Int;
    $i < 10 ?? '0' ~ $i !! ~$i;
}

# The Date header only changes once per second, and reading the clock costs
# ~9 microseconds, so recompute at most once per second.
#
# Module-level state, not `state` inside the sub. A `state` variable is
# initialised lazily on first call, and that initialisation is not atomic: two
# server threads racing into the sub on their first response can both observe
# the container before the assignment lands and read an uninitialised value.
# For these two it would silently emit `Date: ` with no timestamp; for the
# scratch buffer below it is fatal (see the comment there). Holding the cache
# in a file-scope variable initialises it once, in the main thread, when the
# module is loaded -- before any socket thread exists.
my Str $DATE-CACHE = '';
my Int $DATE-STAMP = 0;

sub date-header(--> Str) {
    my $now = time;
    if $now != $DATE-STAMP {
        $DATE-STAMP = $now;
        $DATE-CACHE = rfc1123(DateTime.now.utc);
    }
    $DATE-CACHE;
}

# The complete `Date: ...\r\n` line, cached per second. The value is already
# cached above, but wrapping it in a field name still costs two string
# allocations per response.
my Str $DATE-LINE-CACHE = '';
my Int $DATE-LINE-STAMP = 0;

sub date-line(--> Str) {
    my $now = time;
    if $now != $DATE-LINE-STAMP {
        $DATE-LINE-STAMP = $now;
        $DATE-LINE-CACHE = 'Date: ' ~ rfc1123(DateTime.now.utc) ~ "\r\n";
    }
    $DATE-LINE-CACHE;
}

# Serialise the whole response, head plus body, into one Buf.
#
# $keep-alive comes from the request: the caller does not get to decide, since
# only the request knows whether the client asked for close and whether the
# parser consumed a complete body.
#
# Shape matters more than it looks. Measured on Rakudo 2026.09, per response:
#
#   push into an array + join + encode    ~6.6 us
#   string concatenation + one encode     ~3.0 us
#   Buf.new + two appends                 ~4.4 us
#   appended to the freshly encoded head  ~1.5 us
#
# So the head is built by concatenation and encoded once, and the body is
# appended to that same buffer instead of being copied into a fresh one.
my %SERVER-CONTROLLED = 'Date' => 1, 'Server' => 1,
                        'Content-Length' => 1, 'Connection' => 1;

# The Content-Type values that get the C fast path, encoded once at compile
# time. Encoding a 31-byte Str costs ~1.5 us per response, a hash probe ~0.3 us,
# so the table is what makes passing the type through as bytes affordable.
#
# A constant, never written after BEGIN: the server runs several threads and
# Rakudo hashes are not safe to mutate concurrently. Any other Content-Type
# value simply takes the Raku path.
my constant %CT-BYTES is export(:ct) = %(
    'text/plain; charset=utf-8'       => 'text/plain; charset=utf-8'.encode('utf-8'),
    'text/html; charset=utf-8'        => 'text/html; charset=utf-8'.encode('utf-8'),
    'application/json; charset=utf-8' => 'application/json; charset=utf-8'.encode('utf-8'),
    'application/octet-stream'        => 'application/octet-stream'.encode('utf-8'),
);

# Stand-in pointer for "this argument is absent". Allocated once at module load
# so the marshal cache described in `payload` only ever sees a real buffer, and
# so no per-call allocation happens on the fast path.
my $SCRATCH = buf8.allocate(1);

# Serialise the whole response, head plus body, into one Buf.
#
# $keep-alive comes from the request: the caller does not get to decide, since
# only the request knows whether the client asked for close and whether the
# parser consumed a complete body.
#
# Two paths, byte-identical by construction (t/04 diffs them across a matrix of
# shapes):
#
#   fast  the C writer fills an exactly sized buffer. It handles the shapes the
#         server actually produces -- no headers at all, or exactly one
#         Content-Type it has pre-encoded. One dry-run call reports the exact
#         size, one call fills it, so there is no over-allocation, no subbuf,
#         and no Raku-side string building.
#   slow  the string builder below, for handler-set headers: Date/Server/
#         Connection overrides, several extra headers, an unusual Content-Type.
#
# The fast path is a shape test, not a heuristic: if it cannot prove the
# response has one of those two shapes it hands over to the slow path, and a
# write that disagrees with its own dry run also falls back.
method payload(Bool $keep-alive = True --> Buf) {
    my $body = self.body-bytes;

    # Bind, do not copy: `my %h = %!headers` clones the hash on every response.
    my %h := %!headers;
    my $n := %h.elems;

    my $ct-bytes;
    if $n == 0 {
        # Dominant case: the handler set no headers at all.
    }
    elsif $n == 1 {
        # Next most common: a convenience constructor set Content-Type.
        my $ct := %h<Content-Type>;
        return self.payload-raku($keep-alive) unless $ct ~~ Str;
        $ct-bytes = %CT-BYTES{$ct};
        return self.payload-raku($keep-alive) without $ct-bytes;
    }
    else {
        return self.payload-raku($keep-alive);
    }

    my int32  $ka   = ($keep-alive && !$!close) ?? 1 !! 0;
    my size_t $blen = $body.elems;

    # Always a real pointer, never the Pointer type object.
    #
    # Passing the type object as "this argument is absent" is legal and reads
    # well, but it corrupts the call site: the first argument list to reach the
    # native sub makes NativeCall cache how each slot is marshalled, and once a
    # slot has been seen holding the type object, later calls hand the C side a
    # NULL even when the argument is a perfectly good pointer. It shows up as a
    # body that vanishes from one response to the next, with Content-Length
    # still advertising the bytes. A one-byte scratch buffer casts to a valid
    # pointer and the length argument already says "absent", so the marshal
    # cache only ever sees pointers.
    #
    # File-scope, not `state`. `state` initialisation is lazy and not atomic,
    # so under the M6 concurrency test the very first responses -- several
    # threads entering this method at once -- could see the container before
    # `buf8.allocate(1)` had landed, i.e. an Any. `nativecast` then dies with
    # "expected return type with CPointer ... but got a P6opaque (Any)", the
    # exception escapes the native-call site, the server drops the connection
    # without writing anything, and the client sees a bare EOF on a connection
    # it believes it just leased. Two of those per 64-way burst. Allocating at
    # module load ($SCRATCH, above) removes the race: the buffer exists before
    # any thread runs, and the fast path still allocates nothing per response.
    my $body-ptr = nativecast(Pointer[uint8], $SCRATCH);
    $body-ptr = nativecast(Pointer[uint8], $body) if $blen > 0;

    my $ct-ptr   = nativecast(Pointer[uint8], $SCRATCH);
    my size_t $ctlen = 0;
    if $ct-bytes.defined {
        $ct-ptr = nativecast(Pointer[uint8], $ct-bytes);
        $ctlen  = $ct-bytes.elems;
    }

    my int64 $need = http_response_size($!status, $ka,
                                        $ct-ptr, $ctlen, $body-ptr, $blen);
    # A non-positive dry run means the kernel refused the argument set.
    return self.payload-raku($keep-alive) unless $need > 0;

    my $out = buf8.allocate($need);
    my int64 $wrote = http_write_response(nativecast(Pointer[uint8], $out),
                                          $need, $!status, $ka,
                                          $ct-ptr, $ctlen, $body-ptr, $blen);
    # A short write means the two passes disagreed; never ship half a response.
    return self.payload-raku($keep-alive) unless $wrote == $need;
    $out
}

# The reference implementation: pure Raku, no kernel, and the path every shape
# the C writer cannot prove takes. Kept public because the A/B bench and t/04
# both need to call it directly.
#
# Shape matters more than it looks. Measured on Rakudo 2026.09, per response:
#
#   push into an array + join + encode    ~6.6 us
#   string concatenation + one encode     ~3.0 us
#   Buf.new + two appends                 ~4.4 us
#   appended to the freshly encoded head  ~1.5 us
#
# So the head is built by concatenation and encoded once, and the body is
# appended to that same buffer instead of being copied into a fresh one.
method payload-raku(Bool $keep-alive = True --> Buf) {
    my $body   = self.body-bytes;
    my $status = $!status;
    my $reason = %REASON{$status} // 'Unknown';
    my $conn   = ($keep-alive && !$!close) ?? 'keep-alive' !! 'close';

    my %h := %!headers;
    my $head;

    # Set below when the handler asked for chunked. A handler may frame its own
    # body by setting `Transfer-Encoding: chunked`; RFC 9112 搂6.3 then makes
    # Content-Length forbidden, and emitting both is exactly the contradiction
    # the client-side framer rejects. The body is encoded here rather than by the
    # caller so the two sides of a test round-trip through independent code.
    my Bool $chunked = False;

    if %h.elems == 0 {
        # Dominant case: the handler set no headers at all. Every
        # `%h<Name>` miss costs ~0.35 us, so the four server-controlled fields
        # are emitted from a fixed template with no hash lookups whatsoever.
        $head = "HTTP/1.1 {$status} {$reason}\r\n" ~ date-line()
              ~ "Server: HTTP-Core/0.1.0\r\nContent-Length: {$body.elems}\r\n"
              ~ "Connection: {$conn}\r\n\r\n";
    }
    else {
        my $server = %h<Server>         // 'HTTP-Core/0.1.0';
        my $len    = %h<Content-Length> // $body.elems;
        my $c      = %h<Connection>     // $conn;
        my $date-v = %h<Date>;

        my $te = %h<Transfer-Encoding>;
        $chunked = $te.defined && $te.Str.lc.index('chunked').defined;

        # Server-controlled fields are emitted only if the handler did not set
        # them, so a handler can still override Date or Server deliberately.
        $head = "HTTP/1.1 {$status} {$reason}\r\n"
              ~ ($date-v.defined ?? "Date: {$date-v}\r\n" !! date-line())
              ~ "Server: {$server}\r\n"
              ~ ($chunked ?? '' !! "Content-Length: {$len}\r\n")
              ~ "Connection: {$c}\r\n";

        # `for %h.kv` costs ~2.3 us even when the hash holds one entry, so the
        # common case 鈥?a handler that set nothing but Content-Type 鈥?skips it.
        my $n = %h.elems;
        if $n == 1 {
            my $ct = %h<Content-Type>;
            if $ct.defined {
                $head ~= "Content-Type: {$ct}\r\n";
            }
            else {
                for %h.kv -> $k, $v {
                    next unless $v.defined;
                    next if %SERVER-CONTROLLED{$k};
                    $head ~= "{$k}: {$v}\r\n";
                }
            }
        }
        elsif $n > 1 {
            for %h.kv -> $k, $v {
                next unless $v.defined;
                next if %SERVER-CONTROLLED{$k};
                $head ~= "{$k}: {$v}\r\n";
            }
        }
        $head ~= "\r\n";
    }

    # Head encoded once, body appended to that same buffer. `Buf.new` plus two
    # appends measured faster than `encode(...).Buf` plus one append, because
    # the latter materialises a throwaway Buf for the head first.
    # `buf8.new`, not `Buf.new`: Buf is the parametric role, so `Buf.new`
    # lands in `Buf` while `buf8.allocate` lands in `Buf[uint8]`. Same bytes,
    # different nominal type -- enough for `eqv` to call two identical wire
    # images different, which is precisely what t/04 compares. Both builders
    # now hand back Buf[uint8].
    my $out = buf8.new;
    $out.append(str-bytes($head));
    if $chunked {
        $out.append(chunk-encode($body));
    }
    # Guarded: appending an empty Blob takes the slow slurpy path in Rakudo
    # 2026.09 and cost ~1 us on every 204/304 response.
    elsif $body.elems {
        $out.append($body);
    }
    $out
}

# One chunk for the whole body plus the terminating chunk. Splitting is a
# streaming decision and this stack buffers whole responses anyway, so one chunk
# is the honest encoding of "here is all of it".
sub chunk-encode(Blob $b --> Buf) {
    my $out = buf8.new;
    if $b.elems {
        $out.append(str-bytes($b.elems.fmt('%x') ~ "\r\n"));
        $out.append($b);
        $out.append(str-bytes("\r\n"));
    }
    $out.append(str-bytes("0\r\n\r\n"));
    $out
}

# Slurpy-merge cost control: `%( Content-Type => $t, |%headers )` pays for a
# merge even when the caller passed nothing, and that showed up as ~2.4 us on
# every Response.text call. Build the one-entry hash directly in that case.
sub with-type(Str $type, %extra --> Hash) {
    return %('Content-Type' => $type) unless %extra.elems;

    my %h = 'Content-Type' => $type;
    %h{$_} = %extra{$_} for %extra.keys;
    %h;
}

# Convenience constructors, so handlers can be one-liners.
#
# `text` is also the body *reader* on a parsed response. Both directions in one
# name on purpose: a client that writes `$r.text` and a handler that writes
# `Response.text('ok')` are saying the same thing about the same field, and two
# names would make callers guess which one they hold.
multi method text(Str $text, Int $status = 200, *%headers --> HTTP::Core::Response) {
    self.new(:$status, :body($text), :headers(with-type('text/plain; charset=utf-8', %headers)))
}

# Decoded body. UTF-8, because the alternative -- guessing a charset from
# Content-Type -- belongs to a caller that cares, and `body-bytes` is right there
# for it. Empty body yields '', never a Nil that would explode on .chars.
multi method text(--> Str) {
    my Blob $b = self.body-bytes;
    return '' unless $b.elems;
    $b.decode('utf-8');
}

method html(Str $html, Int $status = 200, *%headers --> HTTP::Core::Response) {
    self.new(:$status, :body($html), :headers(with-type('text/html; charset=utf-8', %headers)))
}

method json(Str $json, Int $status = 200, *%headers --> HTTP::Core::Response) {
    self.new(:$status, :body($json), :headers(with-type('application/json; charset=utf-8', %headers)))
}

method bytes(Blob $data, Str $type = 'application/octet-stream', Int $status = 200 --> HTTP::Core::Response) {
    self.new(:$status, :body($data), :headers(%( Content-Type => $type )))
}

# Empty body, no Content-Length guessing games.
method no-content(Int $status = 204 --> HTTP::Core::Response) {
    self.new(:$status, :body(Buf.new))
}

# ---------------------------------------------------------------------------
# Parsing (the client direction)
# ---------------------------------------------------------------------------
#
# The mirror image of Request.parse, and the same bargain: one FFI call reads
# the status line and the whole header block, writes offsets into a per-call
# arena, and Raku slices only the fields it actually asks for. No allocation in
# C, no data structure built in Raku until someone touches it.
#
# The arena layout is documented in HTTP::Core::Native. Slots 0-7 are:

my constant RESP-STATUS  = 0;
my constant RESP-MINOR   = 1;
my constant RESP-N-HDR   = 2;
my constant RESP-KA      = 3;
my constant RESP-CLEN    = 4;
my constant RESP-FRAMING = 5;
my constant RESP-R-OFF   = 6;
my constant RESP-R-LEN   = 7;
my constant RESP-FLAT    = 8;

my constant RESP-SLOTS = RESP-FLAT + 4 * MAX-HEADERS;

# C's (size_t)-1 and the signed view of it. Same trick as in Request: the
# kernel reports "header absent" as all-ones, and a size_t that comes back
# through NativeCall as a negative Int is that pattern, not a small number.
my constant CLEN-SIGN-BIT = 9223372036854775808;
my constant CLEN-U-ONE    = 18446744073709551615;

sub slice-str(Blob $raw, Int $off, Int $len --> Str) {
    return '' if $len <= 0;
    return '' if $off < 0 || $off + $len > $raw.elems;
    $raw.subbuf($off, $len).decode('utf-8');
}

# Body selection per RFC 9112 搂6.3. What comes back depends on the framing:
#
#   no-body          empty, always -- even if bytes follow (a 204 can be
#                    followed immediately by the next response on a kept-alive
#                    connection, and stealing those bytes would desynchronise it)
#   content-length   exactly N bytes, or whatever is in hand so far; .is-complete
#                    tells the caller which
#   chunked          the raw tail, undecoded. Decoding is M5: it needs a
#                    resumable state machine, not a slice.
#   until-close      the raw tail; the body ends when the socket does
sub pick-body(Blob $raw, Int $consumed, Int $clen, Int $framing --> Blob) {
    my $avail = $raw.elems - $consumed;
    return buf8.new if $avail <= 0;

    given $framing {
        when FRAMING-NO-BODY { return buf8.new }
        when FRAMING-CONTENT-LENGTH {
            my $take = $clen < $avail ?? $clen !! $avail;
            return buf8.new if $take <= 0;
            return $raw.subbuf($consumed, $take);
        }
        default { }
    }
    $raw.subbuf($consumed);
}

# Parse a response from bytes. Partial input is an X::Incomplete (not an error):
# callers append bytes to the buffer and call again, which is exactly what the
# connection layer will do in M2.
#
# :$head says the response is owed to a HEAD request: no body regardless of the
# Content-Length header, which stays readable for the caller that wants it.
method parse(HTTP::Core::Response:U: Blob:D $raw, Bool :$head = False --> HTTP::Core::Response) {
    die HTTP::Core::X::Incomplete.new(reason => 'empty buffer') if $raw.elems == 0;

    my CArray[size_t] $arena = CArray[size_t].allocate(RESP-SLOTS);

    my int32 $rc = http_parse_response_arena(
        nativecast(Pointer[uint8], $raw),
        $raw.elems.UInt,
        nativecast(Pointer, $arena),
        RESP-SLOTS.UInt,
        MAX-HEADERS.UInt,
        ($head ?? 1 !! 0),
    );

    die HTTP::Core::X::Incomplete.new(reason => "response head truncated (rc=$rc)")
        if $rc == PARSE-INCOMPLETE;
    die HTTP::Core::X::ParseError.new(reason => "malformed response (rc=$rc)")
        if $rc < 0;

    my Int $consumed = $rc.Int;
    my Int $status   = $arena[RESP-STATUS].Int;
    my Int $minor    = $arena[RESP-MINOR].Int;
    my Int $n        = $arena[RESP-N-HDR].Int;
    my Int $framing  = $arena[RESP-FRAMING].Int;

    my Int $clen = $arena[RESP-CLEN].Int;
    $clen = $clen - CLEN-U-ONE - 1 if $clen >= CLEN-SIGN-BIT;

    my @hl;
    if $n > 0 {
        @hl = (^$n).map: -> $i {
            my $b = RESP-FLAT + $i * 4;
            slice-str($raw, $arena[$b].Int,     $arena[$b + 1].Int) =>
            slice-str($raw, $arena[$b + 2].Int, $arena[$b + 3].Int)
        };
    }

    my Str $reason = slice-str($raw, $arena[RESP-R-OFF].Int, $arena[RESP-R-LEN].Int);

    # The hash is built for callers that want lookup; the list is built for
    # callers that need order and duplicates (Set-Cookie). Both point at the
    # same strings, so the only cost is the hash insert.
    my %h;
    for @hl -> $p { %h{$p.key} = $p.value }

    self.new(
        :$status,
        :body(pick-body($raw, $consumed, $clen, $framing)),
        :headers(%h),
        :header-list(@hl),
        :reason-text($reason),
        :content-length($clen),
        :consumed($consumed),
        :framing-kind($framing),
        :minor-version($minor),
        :close($arena[RESP-KA] == 0),
        :raw($raw),
    );
}

# --- parsed-side accessors -------------------------------------------------

# All header fields in wire order, duplicates preserved.
method header-pairs(--> List) {
    return @!header-list.List if @!header-list.elems;
    %!headers.pairs.List
}

# Every value for a name, in order. This is the one that matters for Set-Cookie:
# `header('set-cookie')` throws away all but the first, which silently breaks
# cookie handling in a way that only shows up in production.
method header-values(Str $name --> List) {
    my $want = $name.lc;

    if @!header-list.elems {
        my @v;
        for @!header-list -> $p {
            @v.push($p.value) if $p.key.lc eq $want;
        }
        return @v.List;
    }

    my @v;
    for %!headers.kv -> $k, $v {
        @v.push($v) if $k.lc eq $want && $v.defined;
    }
    @v.List
}

method header(Str $name --> Str) {
    my @v = self.header-values($name);
    @v.elems ?? @v[0] !! '';
}

method framing(--> Str) { framing-name($!framing-kind) }

# May the connection that delivered this response be used again?
#
# Two independent vetoes, and both are needed: `Connection: close` is the peer
# saying so, and until-close framing means the message itself only ended because
# the connection did. A pool that checks only the first leaks connections that
# are already half-dead; one that checks only the second reuses a socket the
# peer is about to drop.
method usable(--> Bool) {
    return False if $!close;
    $!framing-kind != FRAMING-UNTIL-CLOSE
}

method http-version(--> Str) { '1.' ~ $!minor-version }

# Is the message complete? Only Content-Length can be answered from the head and
# the bytes in hand. Chunked and until-close are the connection's problem: the
# former needs the M5 decoder, the latter needs EOF.
method is-complete(--> Bool) {
    return True unless $!framing-kind == FRAMING-CONTENT-LENGTH;
    return True if $!content-length <= 0;

    my $avail = $!raw.defined ?? $!raw.elems - $!consumed !! 0;
    $avail >= $!content-length
}
