﻿use NativeCall;

# ---------------------------------------------------------------------------
# Low-level binding to the http_wire C kernel.
#
# Design constraints that shaped this file:
#   * No callbacks: MoarVM cannot safely re-enter Raku from a foreign thread,
#     so the kernel is a pure function over a caller-owned buffer.
#   * No global state: every call is re-entrant.
#   * No pointer arithmetic on the Raku side: the kernel reports byte offsets
#     and copies bytes on request, so Raku only ever deals with integers.
# ---------------------------------------------------------------------------

unit module HTTP::Core::Native;

constant MAX-HEADERS       is export = 64;
constant PARSE-ERROR       is export = -1;
constant PARSE-INCOMPLETE  is export = -2;

# Mirror of the C `phr_header`. Kept for ABI documentation and for the
# nativesizeof() layout check; data never travels through this struct because
# Rakudo cannot reliably read back a CArray of CStruct elements.
class phr-header is repr('CStruct') is export {
    has Pointer[uint8] $.name;
    has size_t         $.name-len;
    has Pointer[uint8] $.value;
    has size_t         $.value-len;
}

sub _find-lib(--> Str) {
    with %*ENV<HTTP_CORE_LIB> {
        return $_ if .so;
    }

    # 1. Working tree, i.e. `raku -Ilib ...` and `zef install .`. zef runs the
    #    test phase against the real source tree, so this hits there too.
    #    lib/HTTP/Core/Native.rakumod -> up 4 = repo root
    my $root = $?FILE.IO.absolute.IO.parent(4);

    # Two things have to line up or the binding silently loads the wrong
    # file: the stem carries a `lib` prefix on ELF/Mach-O but not on PE, and
    # the extension order must match the platform. Getting either wrong lets
    # a stray Windows .dll shadow a freshly built .so, and NativeCall then
    # dies with 'invalid ELF header' from deep inside a precomp.
    my @stems = $*DISTRO.is-win
        ?? ('http_wire',)
        !! ('libhttp_wire', 'http_wire');

    my @ext = $*DISTRO.is-win
        ?? ('.dll', '.so', '.dylib')
        !! ($*KERNEL.name eq 'darwin'
                ?? ('.dylib', '.so', '.dll')
                !! ('.so', '.dylib', '.dll'));

    for @stems -> $stem {
        for @ext -> $ext {
            my $candidate = $root.add("resources/libraries/$stem$ext");
            return $candidate.absolute if $candidate.e;
        }
    }

    # 2. Installed distribution. Once precompiled, $?FILE points into the
    #    precomp store, so step 1 is useless and the resource table is the
    #    only honest anchor for the file zef copied into the site repository.
    #    Keys must stay extension-less (zef appends the platform suffix when
    #    it stages them) and the suffix check afterwards is essential: the
    #    lookup is prefix based, so 'libraries/http_wire' also resolves to the
    #    .pdb / .lib that zig cc drops next to the DLL.
    my @res-keys = $*DISTRO.is-win
        ?? ('libraries/http_wire',)
        !! ('libraries/libhttp_wire', 'libraries/http_wire');

    for @res-keys -> $key {
        my $path;
        # Rakudo 2026.09 deprecates every path accessor a Distribution::Resource
        # has (.absolute, .Str, .IO, .resolve) and ships no replacement that
        # hands a path back; Distribution.content() does not resolve installed
        # resource files either, so .absolute stays the only working route.
        # The one-line notice it prints is silenced with RAKUDO_NO_DEPRECATIONS=1
        # (see README, 'Known notices').
        try { $path = %?RESOURCES{$key}.absolute }
        next unless $path.defined && $path.IO.f;
        next unless $path.IO.extension.lc ~~ any('dll', 'so', 'dylib', '');
        return $path;
    }

    # 3. Fall back to a system-wide install; NativeCall resolves the extension.
    return 'http_wire';
}

# Resolve at first call rather than at compile time: zef install builds this
# unit inside a staging repository whose absolute paths are wiped afterwards,
# so a BEGIN-time constant would freeze a path that no longer exists.

sub http_parse_request(
    Pointer[uint8] $buf,
    size_t         $len,
    Pointer        $method-out,
    CArray[size_t] $method-len,
    Pointer        $path-out,
    CArray[size_t] $path-len,
    CArray[int32]  $minor-version,
    CArray[phr-header] $headers,
    CArray[size_t] $num-headers,
    size_t         $max-headers,
) returns int32 is native(&_find-lib) is symbol('http_parse_request') is export {*}

# The workhorse binding: one call fills the whole request view, with the
# header table delivered as flat (offset, length) quadruples.
# All out-params are taken as raw Pointers rather than CArray: NativeCall
# refuses to hand a native `size_t @array` to a CArray parameter, while a bare
# Pointer accepts nativecast(Pointer, @native-array) without copying.
sub http_parse_request_flat(
    Pointer[uint8] $buf,
    size_t         $len,
    Pointer        $method-off,
    Pointer        $method-len,
    Pointer        $path-off,
    Pointer        $path-len,
    Pointer        $minor-version,
    Pointer        $flat-out,
    Pointer        $io-header-cap,
    Pointer        $keep-alive,
    Pointer        $content-length,
) returns int32 is native(&_find-lib) is symbol('http_parse_request_flat') is export {*}

# Whole out-parameter set in one `size_t` block: the caller supplies the arena
# base and the kernel does all slot addressing. This exists because building
# eleven pointers on the Raku side with Pointer.add costs ~1 us per call, which
# is more than the parse itself.
sub http_parse_request_arena(
    Pointer[uint8] $buf,
    size_t         $len,
    Pointer        $arena,
    size_t         $arena-slots,
    size_t         $max-headers,
) returns int32 is native(&_find-lib) is symbol('http_parse_request_arena') is export {*}

# The response writer: the parser's mirror. Called twice per response -- once
# with a null dst to learn the exact byte count, once to fill an exactly sized
# buffer. Returns the byte count, or -needed if the buffer was short, so the
# Raku side never has to guess how big a head is.
sub http_write_response(
    Pointer[uint8] $dst,
    size_t         $cap,
    int32          $status,
    int32          $keep-alive,
    Pointer[uint8] $content-type,
    size_t         $content-type-len,
    Pointer[uint8] $body,
    size_t         $body-len,
) returns int64 is native(&_find-lib) is symbol('http_write_response') is export {*}

# The dry run as its own entry point. Same layout rules as the writer, no
# destination argument, so the caller has no reason to pass a null pointer into
# a NativeCall slot -- see the note in Response.payload for what that costs.
sub http_response_size(
    int32          $status,
    int32          $keep-alive,
    Pointer[uint8] $content-type,
    size_t         $content-type-len,
    Pointer[uint8] $body,
    size_t         $body-len,
) returns int64 is native(&_find-lib) is symbol('http_response_size') is export {*}

# Body framing, mirroring the HTTP_FRAMING_* macros in src/http_wire.h. The
# kernel owns the decision (it is RFC 9112 §6, and getting it wrong desynchro-
# nises a pooled connection); these constants only name its answer.
constant FRAMING-NO-BODY        is export = 0;
constant FRAMING-CONTENT-LENGTH is export = 1;
constant FRAMING-CHUNKED        is export = 2;
constant FRAMING-UNTIL-CLOSE    is export = 3;

our sub framing-name(Int $kind --> Str) is export {
    given $kind {
        when FRAMING-NO-BODY        { 'no-body'        }
        when FRAMING-CONTENT-LENGTH { 'content-length' }
        when FRAMING-CHUNKED        { 'chunked'        }
        when FRAMING-UNTIL-CLOSE    { 'until-close'    }
        default                     { 'unknown'        }
    }
}

# The response side of the arena parser. Same slot layout as the request arena
# for slots 0-7, plus the framing kind and the reason-phrase slice:
#
#   0 status        4 content-length ((size_t)-1 = absent)
#   1 minor version 5 framing kind
#   2 headers       6 reason offset
#   3 keep-alive    7 reason length
#
# `is-head` is the request method: HEAD forbids a body but leaves the
# Content-Length header meaningful.
sub http_parse_response_arena(
    Pointer[uint8] $buf,
    size_t         $len,
    Pointer        $arena,
    size_t         $arena-slots,
    size_t         $max-headers,
    int32          $is-head,
) returns int32 is native(&_find-lib) is symbol('http_parse_response_arena') is export {*}

# Exposed for completeness and for the C-side tests. The Raku path never calls
# it: the arena parser already wrote the answer into slot 5, which saves a
# second pass over the header table.
sub http_framing_kind(
    Pointer $headers, size_t $num-headers, int32 $status, int32 $is-head,
) returns int32 is native(&_find-lib) is symbol('http_framing_kind') is export {*}

# The client half: request line + pre-formatted header block + the blank line
# that ends the head, then the body. Two passes, exactly like the response
# writer.
sub http_write_request(
    Pointer[uint8] $dst,
    size_t         $cap,
    int32          $minor-version,
    Pointer[uint8] $method,
    size_t         $method-len,
    Pointer[uint8] $target,
    size_t         $target-len,
    Pointer[uint8] $headers,
    size_t         $headers-len,
    Pointer[uint8] $body,
    size_t         $body-len,
) returns int64 is native(&_find-lib) is symbol('http_write_request') is export {*}

sub http_request_size(
    int32          $minor-version,
    Pointer[uint8] $method,
    size_t         $method-len,
    Pointer[uint8] $target,
    size_t         $target-len,
    Pointer[uint8] $headers,
    size_t         $headers-len,
    Pointer[uint8] $body,
    size_t         $body-len,
) returns int64 is native(&_find-lib) is symbol('http_request_size') is export {*}

# Parse -> bytes, skipping the Pair list. The arena the parser filled is already
# a (offset, length) table over the caller's own buffer, so the kernel can copy
# the head out field by field without Raku ever building a Str for it.
#
# Returns bytes written, or bytes needed when dst is NULL/cap is 0; -1..-3 are
# errors (arena inconsistent, body truncated, Content-Length conflict).
sub http_request_bytes(
    Pointer[uint8] $dst,
    size_t         $cap,
    Pointer[uint8] $src,
    size_t         $src-len,
    Pointer        $arena,
    size_t         $arena-slots,
    size_t         $body-off,
    int32          $close-flag,
) returns int64 is native(&_find-lib) is symbol('http_request_bytes') is export {*}

sub http_request_bytes_size(
    Pointer[uint8] $src,
    size_t         $src-len,
    Pointer        $arena,
    size_t         $arena-slots,
    size_t         $body-off,
    int32          $close-flag,
) returns int64 is native(&_find-lib) is symbol('http_request_bytes_size') is export {*}

sub http_should_keep_alive(int32 $minor, CArray[phr-header] $headers, size_t $n)
    returns int32 is native(&_find-lib) is symbol('http_should_keep_alive') is export {*}

sub http_content_length(CArray[phr-header] $headers, size_t $n)
    returns int64 is native(&_find-lib) is symbol('http_content_length') is export {*}

sub http_copy_at(Pointer[uint8] $base, size_t $offset, size_t $len, Pointer[uint8] $dst)
    is native(&_find-lib) is symbol('http_copy_at') is export {*}

# The router's byte-level matcher. Same contract as everything else here: the
# caller owns every buffer, nothing is allocated, nothing is retained.
#
# Why the router is bound to C at all: `split('/', :skip-empty)` alone costs
# ~1.9 us before a single segment is compared, and match-segs adds a Hash
# allocation per candidate route. Walking the path is a byte scan, so it lives
# next to the parser.
#
# out is a size_t block laid out as documented in http_wire.h: status, route
# index, param count, wildcard flag, then a (segment index, value offset, value
# length, value source) quadruple per capture. The segment index is what keeps
# capture names allocation-free: the caller already holds them.
#
# scratch may be given a capacity of 0; a `*` capture then fails with -1 and
# the caller falls back to the pure-Raku matcher.
sub http_route_match(
    Pointer[int32] $segs,    size_t $n-segs,
    Pointer[int32] $routes,  size_t $n-routes,
    Pointer[uint8] $blob,
    Pointer[uint8] $path,    size_t $path-len,
    int32          $method-id,
    Pointer        $out,     size_t $out-slots,
    Pointer[uint8] $scratch, size_t $scratch-cap,
) returns int32 is native(&_find-lib) is symbol('http_route_match') is export {*}

sub http_wire_header_size() returns size_t is native(&_find-lib) is symbol('http_wire_header_size') is export {*}
sub http_wire_version() returns Str is native(&_find-lib) is symbol('http_wire_version') is export {*}

our sub core-version(--> Str) is export { http_wire_version() }
our sub library-path(--> Str) is export { _find-lib() }

# Fails fast when the C struct layout and the Raku CStruct drift apart, which
# would otherwise show up as silent garbage in header name/value pairs.
our sub assert-abi(--> Bool) is export {
    http_wire_header_size() == nativesizeof(phr-header)
}
