use v6.d;
use HTTP::Core::Framing;      # Outcome: the contract Connection relies on
use HTTP::Core::Response;     # .parse, the response value object
use HTTP::Core::X;
use HTTP::Core::Native;       # FRAMING-* constants

# ---------------------------------------------------------------------------
# The response half of message framing.
#
# Framing (request side) answers "how many bytes are one whole request?" by
# trusting `Request.is-complete`. A client cannot do that: it has to cope with
# four body shapes chosen by the peer, plus interim 1xx responses that are not
# messages at all, plus chunked bodies whose length is only knowable by walking
# the chunks. That is what this class adds, and it is the piece whose absence
# makes a pooled connection desynchronise one response later.
#
# Same contract as the request framer, one extra input: `$eof`. The server never
# needs it (a half-received request is simply dropped); a client does, because
# `until-close` bodies end at EOF and because EOF in the middle of a head or of
# a Content-Length body is the difference between "wait" and "truncated".
#
# `:head` is per-request state, not per-connection: a pooled connection can
# serve a HEAD and then a GET, and the header rules differ.
# ---------------------------------------------------------------------------

unit class HTTP::Core::Framing::Response;

has Int  $.max-head = 64 * 1024;
has Int  $.max-body = 8 * 1024 * 1024;

# True when the request that owns the next response used HEAD: no body
# regardless of Content-Length, which stays readable by the caller.
has Bool $.head is rw = False;

my constant INCOMPLETE = HTTP::Core::Framing::Outcome.new(consumed => 0);

# Three states in one value, because "incomplete" and "malformed" and "done"
# must not be conflated by a Nil check: an empty chunk body is a legal message
# and would read as false in boolean context.
class Chunked {
    has Bool $.complete = False;
    has Bool $.failed   = False;
    has Int  $.extent   = 0;      # bytes eaten from the start of the message
    has      $.body;
    has Str  $.error;
}

sub crlf-at(Buf $b, Int $from, Int $to --> Int) {
    my Int $i    = $from;
    my Int $last = $to - 1;
    while $i < $last {
        return $i if $b[$i] == 13 && $b[$i + 1] == 10;
        $i = $i + 1;
    }
    -1;
}

# chunk-size [ ";" chunk-ext ] CRLF chunk-data CRLF ... 0 [ trail ] CRLF CRLF
#
# Returns the end offset of the whole body, not the decoded length: the caller
# needs the former to move the read cursor, and the latter is just `body.elems`.
sub parse-hex(Str $s --> Int) {
    my Str $t = $s.trim;
    return Int unless $t.chars && $t ~~ /^ <[ 0..9 a..f A..F ]>+ $/;
    $t.parse-base(16);
}

sub dechunk(Buf $buf, Int $start, Int $end, Int $max-body --> Chunked) {
    my Buf $body = buf8.new;
    my Int $p    = $start;

    loop {
        my Int $e = crlf-at($buf, $p, $end);
        return Chunked.new unless $e >= 0;          # size line not in yet

        my Str $line = $buf.subbuf($p, $e - $p).decode('latin-1');
        # Chunk extensions are legal and meaningless to us.
        my $semi = $line.index(';');
        $line = $line.substr(0, $semi) with $semi;

        my Int $size = parse-hex($line);
        return Chunked.new(:failed, error => 'bad-chunk') unless $size.defined;
        return Chunked.new(:failed, error => 'body-too-large')
            if $max-body > 0 && $body.elems + $size > $max-body;

        $p = $e + 2;

        if $size == 0 {
            # Trailer section, then a blank line. Trailers are discarded: they
            # are a hop-by-hop detail and nothing above us consumes them yet,
            # but they must be *walked* or the next response starts misaligned.
            loop {
                my Int $t = crlf-at($buf, $p, $end);
                return Chunked.new unless $t >= 0;
                last if $t == $p;
                $p = $t + 2;
            }
            return Chunked.new(:complete, extent => $p + 2, :body($body));
        }

        # Data + its trailing CRLF must both be in hand before we commit: a
        # partially copied chunk would be double-counted on the next call.
        return Chunked.new if $p + $size + 2 > $end;

        return Chunked.new(:failed, error => 'bad-chunk')
            unless $buf[$p + $size] == 13 && $buf[$p + $size + 1] == 10;

        $body.append($buf.subbuf($p, $size));
        $p = $p + $size + 2;
    }
}

method decode(Buf:D $buf, Bool :$eof = False --> HTTP::Core::Framing::Outcome) {
    my Int $n = $buf.elems;
    return INCOMPLETE if $n == 0;

    my Int $offset = 0;

    loop {
        return INCOMPLETE if $offset >= $n;

        # A 1xx that we skip leaves later responses behind it, so the next head
        # starts at $offset rather than at 0.
        my Buf $rest = $offset == 0 ?? $buf !! $buf.subbuf($offset);

        my $res;
        my $err;
        {
            $res = HTTP::Core::Response.parse($rest, :head($!head));
            CATCH { default { $err = $_ } }
        }

        unless $res.defined {
            given $err {
                when HTTP::Core::X::Incomplete {
                    return error('truncated') if $eof;
                    return error('head-too-large') if $rest.elems > $!max-head;
                    return INCOMPLETE;
                }
                when HTTP::Core::X::ParseError {
                    return error('bad-response');
                }
                default {
                    return error('internal');
                }
            }
        }

        my Int $status = $res.status;

        # 100-continue and friends: the body belongs to the *final* response, so
        # discard the interim one and keep reading. 101 is a real answer (the
        # stream becomes something else), but this stack has no upgrade path, so
        # it is returned like any other status rather than silently swallowed.
        if $status >= 100 && $status < 200 && $status != 101 {
            $offset += $res.consumed;
            next;
        }

        my Int $head-end = $offset + $res.consumed;
        my Int $avail    = $n - $head-end;

        given $res.framing-kind {
            when FRAMING-NO-BODY {
                # 204 / 304 / HEAD. Any trailing bytes belong to the *next*
                # response; taking them would be the classic off-by-one that
                # makes every second request fail.
                return HTTP::Core::Framing::Outcome.new(
                    response => $res,
                    consumed => $head-end,
                );
            }

            when FRAMING-CONTENT-LENGTH {
                my Int $clen = $res.content-length;
                $clen = 0 if $clen < 0;
                return error('body-too-large') if $!max-body > 0 && $clen > $!max-body;

                if $avail < $clen {
                    return error('truncated') if $eof;
                    return INCOMPLETE;
                }

                # .parse already sliced exactly $clen bytes for this framing.
                return HTTP::Core::Framing::Outcome.new(
                    response => $res,
                    consumed => $head-end + $clen,
                );
            }

            when FRAMING-CHUNKED {
                my $cr = dechunk($buf, $head-end, $n, $!max-body);
                return error($cr.error) if $cr.failed;
                unless $cr.complete {
                    return error('truncated') if $eof;
                    return INCOMPLETE;
                }

                # The decoded body is a different (shorter) slice and the extent
                # is the encoded one; keep both, or the next response on this
                # connection starts at the wrong byte.
                #
                # `Transfer-Encoding` is dropped because it no longer describes
                # the body; `Content-Encoding` is *kept*, because a body can be
                # both chunked and gzipped and the gzip layer still has work to
                # do. Dropping it here would hand the caller compressed bytes
                # labelled as identity.
                my $whole = $res.with-body($cr.body, :drop-encoding(False), :drop-transfer(True));
                return HTTP::Core::Framing::Outcome.new(
                    response => $whole,
                    consumed => $cr.extent,
                );
            }

            default {
                # until-close: HTTP/1.0 without Content-Length. The message ends
                # when the connection does, which is exactly why such a
                # connection can never go back into the pool.
                return INCOMPLETE unless $eof;

                my $body  = $avail > 0 ?? $buf.subbuf($head-end).Buf !! buf8.new;
                my $whole = $res.clone(:body($body), :close(True));
                return HTTP::Core::Framing::Outcome.new(
                    response => $whole,
                    consumed => $n,
                );
            }
        }
    }
}

# Errors always claim the whole buffer: Connection protects itself against a
# zero-consumed failure, but an explicit extent is clearer than relying on it.
sub error(Str $why, Int $n? --> HTTP::Core::Framing::Outcome) {
    HTTP::Core::Framing::Outcome.new(consumed => ($n // 0), error => $why);
}
