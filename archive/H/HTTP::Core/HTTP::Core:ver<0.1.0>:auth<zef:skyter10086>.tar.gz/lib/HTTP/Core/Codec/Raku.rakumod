use v6.d;

# ---------------------------------------------------------------------------
# The request encoder written the obvious way: string building, `.encode`, no
# FFI, no nqp ops, no scratch buffers. Same result as HTTP::Core::Codec.
#
# Why keep two implementations of the same twelve lines:
#
#   * It is the oracle for the C path. `http_write_request` takes eleven FFI
#     arguments, four of them (ptr,len) pairs; a marshalling mistake there
#     produces bytes that are wrong by a few characters and perfectly valid
#     HTTP -- the kind of bug that passes a round-trip through our own parser
#     and then fails against a real peer. t/08 compares the two on a corpus of
#     shapes and fails on any difference.
#   * It is what a future port or a debug build falls back to. `use
#     HTTP::Core::Codec::Raku` is enough; nothing else has to change, because
#     the signature is the same one Codec exports.
#
# It is slower -- 1.5x on the 171-byte request in bench/12-codec, not the 8x an
# earlier guess assumed (Raku's own concatenation is good; what costs is the
# transcode of a Str body) -- and deliberately not used by the server or the
# client. Reference implementations pay for themselves in being boring.
# ---------------------------------------------------------------------------

unit module HTTP::Core::Codec::Raku;

# Fold $body into bytes: Blob passes through, Str (or anything stringifiable)
# is transcoded, undef is no body at all. Same rule as Codec.
sub body-bytes($body --> Buf) {
    return buf8.new unless $body.defined;
    return $body.Buf if $body ~~ Blob;
    $body.Str.encode('utf-8').Buf;
}

our sub encode-request(
    Str  :$method!,
    Str  :$target!,
    :@headers,
    :$body,
    Int  :$minor-version = 1,
    Bool :$close = False,
    --> Buf
) is export {
    my Buf $payload = body-bytes($body);

    my Str $block          = '';
    my Bool $has-connection = False;
    my Bool $has-te         = False;
    my Int  $declared       = -1;

    for @headers -> $pair {
        my $value = $pair.value;
        next unless $value.defined;

        my Str $lc = $pair.key.lc;
        $has-connection = True if $lc eq 'connection';
        $has-te         = True if $lc eq 'transfer-encoding';
        $declared       = $value.Int if $lc eq 'content-length' && $value.Str ~~ /^\d+$/;

        $block ~= $pair.key ~ ': ' ~ $value ~ "\r\n";
    }

    my Int $blen = $payload.elems;
    if $blen > 0 && !$has-te {
        if $declared < 0 {
            $block ~= "Content-Length: {$blen}\r\n";
        }
        elsif $declared != $blen {
            die "HTTP::Core::Codec::Raku: Content-Length {$declared} "
              ~ "disagrees with a {$blen}-byte body";
        }
    }

    $block ~= "Connection: close\r\n" if $close && !$has-connection;

    my Str $head = "{$method} {$target} HTTP/1.{$minor-version}\r\n" ~ $block ~ "\r\n";

    my Buf $out = $head.encode('utf-8').Buf;
    $out.append($payload) if $blen;
    $out;
}
