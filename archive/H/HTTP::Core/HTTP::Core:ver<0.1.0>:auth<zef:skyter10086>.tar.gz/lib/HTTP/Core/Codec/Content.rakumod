﻿use v6.d;
use HTTP::Core::X;

# `use`, not a runtime `require`: after `require`, the package name resolves to
# a bare stub package (`::('Compress::Zlib::Stream')` prints the right name but
# `.defined` is False and instantiation dies), because the class only becomes a
# real type object when the module is compiled into this unit. The cost is that
# *this file* depends on zlib -- which is fine, since the client loads this file
# only when it intends to advertise gzip, and degrades to identity if the load
# fails.
use Compress::Zlib;

# ---------------------------------------------------------------------------
# Content-Encoding, client side: of the codings we can name, only two are
# codings we can actually undo.
#
# The rule this class exists to enforce is one line long: never advertise a
# coding you cannot decode. Sending `Accept-Encoding: gzip` and handing the
# application 349 bytes of DEFLATE is not a degraded experience, it is silent
# data corruption that looks like a server bug. So the advertisement and the
# decoder live in the same file, and the client asks this file what to send.
#
# Scope: response bodies only. Requests keep `identity`, because compressing a
# request body gains nothing at the sizes this client sends and would add a
# Content-Length recomputation for every caller.
#
# Two real-world wrinkles, both handled below:
#
#   * `deflate` in the wild means either a zlib-wrapped stream (RFC 9110 says
#     this) or a raw DEFLATE stream (what several old servers actually send).
#     Trying zlib first and raw second costs one exception on the broken case
#     and nothing on the correct one.
#   * A gzip member can legitimately be followed by another member. Decoding
#     only the first and ignoring bytes-left would truncate the body, so the
#     leftovers are fed to a fresh stream.
#
# A module with exported subs, not a class with class methods. The class form
# existed only so the client could `require` this file at runtime and call a
# method on the returned type object -- but a runtime `require` of this file
# returns a bare stub once the requiring unit is itself precompiled (name
# resolves, `^can` is empty, every call dies on arity). So the client does a
# compile-time `use` and binds these subs lexically, which cannot go stale.
# ---------------------------------------------------------------------------

unit module HTTP::Core::Codec::Content;

# Codings we can undo. `identity` is implicit and never listed.
sub supported-codings(--> List) is export { ('gzip', 'deflate').List }

# What to put in Accept-Encoding: only the intersection of "useful" and
# "decodable". `br` is absent on purpose -- Rakudo has no brotli decoder, and a
# header that invites brotli breaks every modern CDN response.
sub accept-encoding-value(--> Str) is export { 'gzip, deflate' }

# Split a Content-Encoding / Accept-Encoding field into lowercase tokens.
#
# Content-Encoding is a list applied left to right, so `gzip, br` means "brotli
# over gzip" and must be undone right to left. Order is preserved here for that
# reason; sorting or set-ifying would lose the only information that matters.
sub codings(Str $field --> List) is export {
    return ().List unless $field.defined && $field.chars;

    my @out;
    for $field.split(',') -> $raw {
        my Str $token = $raw.trim.lc;
        # Parameters (`gzip;q=0.5`) are legal on Accept-Encoding, not on
        # Content-Encoding, and meaningless to a decoder either way.
        my $semi = $token.index(';');
        $token = $token.substr(0, $semi).trim with $semi;
        @out.push($token) if $token.chars;
    }
    @out.List;
}

# Decode `$body` according to the Content-Encoding field `$encoding`.
#
# `$max-body` caps the *decoded* size (0 = no cap). It is enforced while
# inflating rather than afterwards, because a 1 KB gzip bomb expands to
# gigabytes and the whole point of a cap is to not allocate them.
#
# Dies with X::Protocol on anything undecodable; returns the input untouched
# when there is nothing to do.
sub decode-body(Blob $body, Str $encoding, Int $max-body = 0 --> Blob) is export {
    my @codings = codings($encoding);
    return $body unless @codings.elems;

    my Blob $data = $body;

    # Undo in reverse: the last coding applied is the first one removed.
    for @codings.reverse -> Str $coding {
        given $coding {
            when 'identity' { }
            when 'gzip'     { $data = inflate-or-die($data, 'gzip', $max-body) }
            when 'deflate'  { $data = inflate-or-die($data, 'zlib', $max-body, :fallback-raw) }
            default {
                die HTTP::Core::X::Protocol.new(
                    reason => "unsupported Content-Encoding '{$coding}'"
                           ~ " (this client decodes: {supported-codings.join(', ')})",
                );
            }
        }
    }
    $data;
}

# One coding, applied to one blob, with failure text the caller can act on.
sub inflate-or-die(Blob $in, Str $mode, Int $max-body, Bool :$fallback-raw = False --> Blob) {
    my $out;
    my $err;
    {
        $out = inflate($in, $mode, $max-body);
        CATCH { default { $err = $_ } }
    }
    return $out if $out.defined;

    # A cap breach and a corrupt stream are both failures but not the same
    # failure: the first must not be retried as raw deflate, and must not be
    # reported as corruption, or the user debugs the peer instead of the limit.
    rethrow-if-cap($err);

    if $fallback-raw {
        my $raw;
        my $err2;
        {
            $raw = inflate($in, 'raw', $max-body);
            CATCH { default { $err2 = $_ } }
        }
        return $raw if $raw.defined;
        rethrow-if-cap($err2);
    }

    die HTTP::Core::X::Protocol.new(
        reason => "cannot decode '{$mode}' body: not a valid {$mode} stream"
               ~ " ({$err.message})",
    );
}

sub rethrow-if-cap($err --> Nil) {
    $err.rethrow if $err ~~ HTTP::Core::X::Protocol && $err.message ~~ /exceeds/;
    Nil;
}

# The inflate loop itself, fed in 32 KiB slices. Two reasons, neither about
# speed:
#   * the cap is checked between slices, so a bomb is stopped after at most one
#     slice of overshoot instead of after the whole expansion;
#   * `bytes-left` is only meaningful at a member boundary, which is how a
#     multi-member gzip body is detected without parsing gzip headers by hand.
my constant SLICE = 32 * 1024;

# Guards against a body made of a million 20-byte members: legal gzip, and a
# decoder that loops without a bound is a denial of service against itself.
my constant MAX-MEMBERS = 64;

sub inflate(Blob $in, Str $mode, Int $max-body --> Blob) {
    my $stream = new-stream($mode);
    my Buf $out = buf8.new;

    my Int $n       = $in.elems;
    my Int $i       = 0;
    my Int $members = 0;

    while $i < $n {
        my Int $take   = min(SLICE, $n - $i);
        my Blob $slice = $in.subbuf($i, $take);

        # zlib reports corruption as a Failure, and a Failure that is merely
        # assigned then abandoned comes back at GC time as "unhandled Failure
        # detected in DESTROY" -- which reads like a bug in the caller. Throw it
        # here, where the message still names the stream, and let
        # inflate-or-die turn it into X::Protocol.
        my $chunk = $stream.inflate($slice);
        $chunk.throw if $chunk ~~ Failure;
        $out ~= $chunk;
        $i += $take;

        if $max-body > 0 && $out.elems > $max-body {
            die HTTP::Core::X::Protocol.new(
                reason => "decoded body exceeds the {$max-body}-byte cap",
            );
        }

        next unless $stream.finished;

        # Finished, but bytes remain: either another member (legal) or garbage.
        my Int $left = $stream.bytes-left;
        my Int $next = $i - $left;

        if $next >= $n {
            $i = $n;
            last;
        }

        unless $mode eq 'gzip' {
            die HTTP::Core::X::Protocol.new(
                reason => "trailing {$left} bytes after a finished {$mode} stream",
            );
        }

        $members++;
        if $members > MAX-MEMBERS {
            die HTTP::Core::X::Protocol.new(
                reason => "gzip body has more than {MAX-MEMBERS} members",
            );
        }

        $stream = new-stream('gzip');
        $i = $next;
    }

    unless $stream.finished {
        die HTTP::Core::X::Protocol.new(
            reason => "{$mode} stream ended before its final block (truncated body)",
        );
    }

    $out;
}

sub new-stream(Str $mode) {
    given $mode {
        when 'gzip' { Compress::Zlib::Stream.new(:gzip) }
        when 'zlib' { Compress::Zlib::Stream.new(:zlib) }
        default     { Compress::Zlib::Stream.new(:deflate) }   # raw DEFLATE, no wrapper
    }
}


