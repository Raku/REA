use v6.d;
use NativeCall;
use HTTP::Core::Native;
use HTTP::Core::Bytes;
use HTTP::Core::Response;

# ---------------------------------------------------------------------------
# The wire codec, both directions, as one entry point each.
#
#   encode-request   structured request      -> bytes   (client sends)
#   decode-response  bytes                   -> Response (client receives)
#
# The other two directions already have homes: Request.parse and
# Response.payload, which is what the server uses. This module exists so a
# client does not have to reach for them by name, and so the asymmetries are
# written down in one place.
#
# Why encode splits the work the way it does: the request line is five pieces of
# known layout, so C writes it; the header block is a list of name/value strings
# whose formatting is trivial, so Raku builds it; and the body is opaque bytes
# that must not be copied twice, so C appends it. Encoding the header block in
# Raku also keeps the FFI signature small -- eleven scalars is already at the
# point where every extra argument costs a marshalling slot per call.
# ---------------------------------------------------------------------------

unit module HTTP::Core::Codec;

# Never pass a null pointer into a NativeCall slot. The marshaller caches the
# pointer type per slot on first call, and a slot that once saw the type object
# keeps a null in its cache -- the parameter type changes from Pointer[uint8] to
# Mu and every later call gets a garbage pointer. An empty Blob therefore still
# gets a real, one-byte buffer to point at.
my $SCRATCH = buf8.allocate(1);

sub data-ptr(Blob $b --> Pointer[uint8]) {
    return nativecast(Pointer[uint8], $SCRATCH) if $b.elems == 0;
    nativecast(Pointer[uint8], $b)
}

# Serialise a request head plus body.
#
#   :@headers   List of Pair, in order; duplicate names are kept (RFC 9110 lets
#               a sender repeat any field as long as the list semantics survive,
#               and some servers require a repeated Cookie)
#   :$body      Blob, or Str, or anything with .Str; undef means no body
#   :$close     when True, appends `Connection: close` unless the caller already
#               supplied a Connection field -- the caller wins, because a client
#               that says `Connection: keep-alive` on a 1.0 request means it
#
# Content-Length is the one header this codec derives, because it is not policy,
# it is arithmetic on bytes the caller just handed over. Omit it on a request
# with a body and the peer cannot tell where the body ends: it either hangs
# waiting or reads the body as the next request. So:
#
#   body, no framing header        the length is added
#   Transfer-Encoding present      hands off -- the caller is framing itself
#   Content-Length also given      it must match the body, or this dies
#
# Host and Date stay the caller's business: those are genuinely about the
# connection and the clock, not about the bytes in hand.
our sub encode-request(
    Str  :$method!,
    Str  :$target!,
    :@headers,
    :$body,
    Int  :$minor-version = 1,
    Bool :$close = False,
    --> Buf
) is export {
    my Blob $body-bytes = body-as-bytes($body);

    my Str $block = '';
    my Bool $has-connection = False;
    my Bool $has-te         = False;
    my Int  $declared-len   = -1;

    for @headers -> $pair {
        my $name  = $pair.key;
        my $value = $pair.value;
        next unless $value.defined;

        my Str $lc = $name.lc;
        $has-connection = True if $lc eq 'connection';
        $has-te         = True if $lc eq 'transfer-encoding';
        $declared-len   = $value.Int if $lc eq 'content-length' && $value.Str ~~ /^\d+$/;

        $block ~= $name ~ ': ' ~ $value ~ "\r\n";
    }

    my Int $blen = $body-bytes.elems;
    if $blen > 0 && !$has-te {
        if $declared-len < 0 {
            $block ~= "Content-Length: {$blen}\r\n";
        }
        elsif $declared-len != $blen {
            die "HTTP::Core::Codec: Content-Length {$declared-len} "
              ~ "disagrees with a {$blen}-byte body";
        }
    }

    $block ~= "Connection: close\r\n" if $close && !$has-connection;

    my Buf $mb = str-bytes($method);
    my Buf $tb = str-bytes($target);
    my Buf $hb = str-bytes($block);

    my $mp = data-ptr($mb);
    my $tp = data-ptr($tb);
    my $hp = data-ptr($hb);
    my $bp = data-ptr($body-bytes);

    my Int $ml = $mb.elems;
    my Int $tl = $tb.elems;
    my Int $hl = $hb.elems;
    my Int $bl = $body-bytes.elems;

    my int64 $need = http_request_size(
        $minor-version, $mp, $ml, $tp, $tl, $hp, $hl, $bp, $bl);

    # Two passes, like every other writer here: measure, then fill. The measure
    # pass cannot legitimately return 0 -- a request line is always non-empty --
    # so anything <= 0 is the kernel rejecting an argument.
    die "HTTP::Core::Codec: cannot size request (rc=$need)"
        if $need <= 0;

    my Buf $out = buf8.allocate($need);

    my int64 $wrote = http_write_request(
        nativecast(Pointer[uint8], $out), $need, $minor-version,
        $mp, $ml, $tp, $tl, $hp, $hl, $bp, $bl);

    die "HTTP::Core::Codec: short write ($wrote of $need)"
        unless $wrote == $need;

    $out
}

# Str -> bytes, or pass a Blob straight through. Kept local because the only
# caller is encode-request and the Str/Blob decision should not leak.
sub body-as-bytes($body --> Blob) {
    return buf8.new unless $body.defined;
    return $body         if $body ~~ Blob;
    str-bytes($body.Str)
}

# Decode a response. Thin, and on purpose: Response.parse is where the work is,
# the same way Request.parse backs the server's request path. This exists so the
# client has one name to call and so a future connection layer can swap in a
# buffered variant without changing call sites.
our sub decode-response(Blob:D $raw, Bool :$head = False --> HTTP::Core::Response) is export {
    HTTP::Core::Response.parse($raw, :$head)
}

# How many bytes does this response occupy on the wire, given the bytes in hand?
#
#   no-body          the head alone
#   content-length   head + N, whatever N is
#   chunked          unknown until decoded (M5)
#   until-close      unknown until EOF
#
# Returns -1 for "cannot be known from the head", which is not an error: for a
# keep-alive pool it is the answer that means "this connection cannot be reused".
our sub response-extent(HTTP::Core::Response $r --> Int) is export {
    given $r.framing-kind {
        when FRAMING-NO-BODY        { $r.consumed }
        when FRAMING-CONTENT-LENGTH {
            $r.content-length < 0 ?? $r.consumed !! $r.consumed + $r.content-length
        }
        default { -1 }
    }
}
