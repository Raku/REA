﻿use v6.d;
use HTTP::Core;
use HTTP::Core::Connection;
use HTTP::Core::Framing;
use HTTP::Core::Response;
use HTTP::Core::Router;
use HTTP::Core::Transport;
use HTTP::Core::Transport::TCP;
use HTTP::Core::X;

# ---------------------------------------------------------------------------
# A pull-model HTTP/1.1 server.
#
#   Reactor    : IO::Socket::Async (libuv, already inside MoarVM)
#   Transport  : HTTP::Core::Transport::TCP (one Buf Supply, one write)
#   Framing    : HTTP::Core::Framing (head in, whole message out)
#   Connection : HTTP::Core::Connection (buffer + parked promises)
#   Parser     : HTTP::Core (C kernel, pure function)
#   Router     : HTTP::Core::Router (patterns)
#   Handler    : your code, returns a Response
#
# The loop is still bytes arrive -> frame -> dispatch -> write -> repeat, but
# the bytes/buffer/framing half now lives in Connection and Framing, shared with
# the client that is coming next. This class keeps only what is server-specific:
# routing, dispatch, policy for rejection status codes, keep-alive decisions.
#
# No callbacks cross the FFI boundary, no second event loop is started, and no
# thread is spawned by the C side. That is the only shape safe on MoarVM today.
# ---------------------------------------------------------------------------

unit class HTTP::Core::Server;

has Str $.host = '127.0.0.1';
has Int $.port = 8080;

has HTTP::Core::Router $.router .= new;

# Guards against memory abuse from a client that never sends CRLFCRLF or that
# announces a body it will never finish.
has Int $.max-head = 64 * 1024;
has Int $.max-body = 8 * 1024 * 1024;

# Serve an already-connected transport instead of listening on a socket.
#
# This is what makes the in-process client test possible: the same HTTP stack
# then runs on both ends with no port, no socket, and no kernel in between, so a
# failing test is a protocol bug rather than an environment one. It is also the
# only way to drive the server from `Transport::InMemory`.
has HTTP::Core::Transport $.transport;

has $!tap;
has %!conns;
has Bool $!running = False;
has Bool $.debug = False;

# The connection registry is written from every accept callback and every
# connection teardown, i.e. from several schedulers at once, and Rakudo hashes
# are not thread-safe. Without this lock two simultaneous accepts can corrupt
# the hash (or lose an entry), and a corrupted registry is indistinguishable
# from a leaked connection: `stop` closes what it can see. Same rule as Pool:
# the lock guards bookkeeping only, `close` always runs outside it.
has Lock $!conns-lock .= new;

# Why the last `start` failed to bind, '' when it did. A bind failure travels
# out of the listen Supply as a *quit*, not as a value, so without capturing it
# here the only trace is an "Unhandled exception in code scheduled on thread N"
# on stderr and a server that looks running but accepts nothing.
has Str $!bind-error = '';

method running(--> Bool) { $!running }
method bind-error(--> Str) { $!bind-error }
method connections(--> Int) { $!conns-lock.protect({ %!conns.elems }) }

# Flatten the three shapes a failed promise can carry, mirroring Client's
# `cause-text`: `Promise.break('text')` wraps a Str in X::AdHoc, so a bare
# `~~ Str` test silently misses every string cause.
sub cause-text($cause --> Str) {
    return 'connection closed' unless $cause.defined;
    return $cause if $cause ~~ Str;
    return $cause.payload
        if $cause ~~ X::AdHoc && $cause.payload ~~ Str;
    return $cause.message if $cause ~~ Exception;
    return $cause.gist;
}

method !dbg(Str $msg --> Nil) {
    note "HTTP::Core::Server: {$msg}" if $!debug;
    Nil;
}

# Status the peer deserves for each framing failure. `internal` is absent on
# purpose: an exception out of the codec is our bug, not theirs, and answering
# it would just put words into a stream we are about to drop.
my constant %REJECT =
    'bad-request'    => (400, 'Bad Request'),
    'head-too-large' => (431, 'Request Header Fields Too Large'),
    'body-too-large' => (413, 'Payload Too Large');

# A port the OS just handed out and we immediately released. Slightly racy by
# nature, but good enough to let tests and demos avoid hard-coded conflicts.
#
# `.port` on a listening IO::Socket::INET is an unset attribute (it yields the
# Int type object); the bound port lives in `.localport`.
our sub free-port(--> Int) is export {
    my $probe = IO::Socket::INET.new(:listen, :localport(0));
    my $port  = $probe.localport.Int;
    $probe.close;
    $port;
}

# Attach one already-connected transport. `start` handles exactly one
# (`new(:$transport)`); a pool with max-per-host > 1 needs a second, third and
# so on, and an in-process transport factory hands them over one at a time.
# The server's per-connection plumbing is identical either way, so this is a
# thin public door onto !serve rather than a second code path.
method serve-transport(HTTP::Core::Transport $transport --> Nil) {
    self!serve($transport);
}

method start(--> HTTP::Core::Server) {
    return self if $!running;

    if $!transport.defined {
        # Pre-connected: no listener, no accept loop. `stop` still closes it.
        self!serve($!transport);
        $!running = True;
        return self;
    }

    $!tap = IO::Socket::Async.listen($!host, $!port).tap(-> $socket {
        self!serve(HTTP::Core::Transport::TCP.new(:$socket));
    }, quit => -> $cause {
        # Bind failed (port taken, address not ours, fd exhausted...). Keep the
        # reason instead of letting it die on a scheduler thread.
        $!bind-error = cause-text($cause);
        self!dbg("listen on {$!host}:{$!port} failed: {$!bind-error}");
    });
    $!running = True;
    self;
}

method stop(--> Nil) {
    $!tap.close if $!tap.defined;
    $!tap = Nil;

    # Take the conns out under the lock, close them outside it: `close` runs the
    # peer's `done` handler inline, which re-enters the registry.
    my @live = $!conns-lock.protect({
        my @c = %!conns.values;
        %!conns = ();
        @c;
    });

    self!dbg("stop: closing {+@live} connection(s)");
    for @live -> $conn {
        try $conn.close;
    }

    try $!transport.close if $!transport.defined;

    $!running = False;
    Nil;
}

# Close every live connection but keep listening. Returns how many were closed.
#
# This is the server half of the keep-alive race that the client pool has to
# survive: a server reaps an idle connection, the FIN crosses the wire, and for
# a window the client still believes the socket is good. Without a way to fire
# that event on demand, that window can only be tested by luck. It is also what
# a real keep-alive timer would call, which is why it lives here rather than in
# a test helper.
method drop-connections(--> Int) {
    my @conns = $!conns-lock.protect({
        my @c = %!conns.values;
        %!conns = ();
        @c;
    });

    self!dbg("drop-connections: closing {+@conns} connection(s)");
    for @conns -> $conn {
        try $conn.close;
    }

    @conns.elems;
}

# --- per-connection plumbing ----------------------------------------------

# A transport in, a connection out. Nothing here is HTTP-aware: the connection
# owns the buffer and parks promises; the transport owns the socket.
method !serve(HTTP::Core::Transport $transport --> Nil) {
    self!dbg("accept id={$transport.id} from {$transport.^name}");

    my $conn;
    my $err;
    {
        $conn = HTTP::Core::Connection.new(
            :$transport,
            :max-head($!max-head),
            :max-body($!max-body),
            :debug($!debug),
        );
        CATCH { default { $err = $_ } }
    }

    with $err {
        # A connection that could not even be built must not silently vanish:
        # the peer is left writing into a socket nobody reads, and the only
        # visible symptom is an EOF on the far end.
        self!dbg("accept id={$transport.id}: cannot build connection: {$err.message}");
        try $transport.close;
        return;
    }

    # Registered under the connection's own serial, never under `transport.id`.
    # The id is a socket address: two connections can share one, and a teardown
    # can hand the same address to a socket that is already gone. Keying on it
    # meant a drop could miss its own entry and leave it in the registry for the
    # life of the process -- a counter that only ever grows, with nothing to see.
    #
    # `id=` in the lines below is therefore decoration, not identity: MoarVM moves
    # objects, so the same connection can print one address when it is accepted
    # and a different one when it is dropped. `conn#N` is what pairs the two.
    my Int $serial = $conn.serial;

    $!conns-lock.protect({
        %!conns{$serial} = $conn;
    });

    self!dbg("accept id={$transport.id} as conn#{$serial}, registry={self.connections}");

    self!listen($conn);
}

# One turn of the read loop: ask for the next framed message, act on it, ask
# again. The ask is a Promise, not a blocking receive, so an idle keep-alive
# connection costs a buffer instead of a thread.
method !listen(HTTP::Core::Connection $conn --> Nil) {
    my $on-frame = sub ($p) {
        # Nothing may escape here. This continuation is the *only* thing that
        # deregisters the connection: an exception would break the promise chain,
        # leave the entry in `%!conns` untouched, and leak one registration per
        # connection for the life of the process -- with no symptom other than a
        # counter that only ever grows.
        {
            if $p.status == Kept {
                self!on-message($conn, $p.result);
            }
            else {
                # The cause matters: 'connection closed' is an ordinary keep-alive
                # teardown, anything else is a framing/protocol failure. Logging
                # only "dropped" is what made the M6 EOF hunt guesswork.
                self!drop($conn, why => "read failed: {cause-text($p.cause)}");
            }
            CATCH {
                default {
                    try self!drop($conn, why => "frame callback died: {.message}");
                }
            }
        }
    };

    $conn.next-message.then($on-frame);
}

method !on-message(HTTP::Core::Connection $conn, HTTP::Core::Framing::Outcome $out --> Nil) {
    my $req = $out.request;

    if $req.defined {
        my $keep = $req.keep-alive;

        self!dbg("conn id={$conn.transport.id}: {$req.method} {$req.path-only} keep={$keep}");

        my $response;
        my $err;
        {
            $response = self!dispatch($req);
            CATCH { default { $err = $_ } }
        }

        if $err.defined {
            # `!dispatch` already answers handler failures with a 500. Getting
            # here means the failure was in building the response itself, so
            # the socket cannot be trusted to carry another message.
            self!dbg("conn id={$conn.transport.id}: dispatch died: {$err.message}; dropping");
            self!drop($conn, why => "dispatch died: {$err.message}");
            return;
        }

        my $wire;
        my $perr;
        {
            $wire = $response.payload($keep);
            CATCH { default { $perr = $_ } }
        }

        if $perr.defined {
            self!dbg("conn id={$conn.transport.id}: serialisation died: {$perr.message}; dropping");
            self!drop($conn, why => "serialisation died: {$perr.message}");
            return;
        }

        $conn.write($wire);

        $keep ?? self!listen($conn)
              !! self!drop($conn, why => 'client asked for close');
        return;
    }

    self!dbg("conn id={$conn.transport.id}: framing error '{$out.error}' "
           ~ "(consumed {$out.consumed} bytes)");

    if $out.error eq 'internal' {
        self!drop($conn, why => 'framing internal error');
        return;
    }

    my $answer = %REJECT{$out.error} // (400, 'Bad Request');
    self!reject($conn, $answer[0], $answer[1]);
}

method !reject(HTTP::Core::Connection $conn, Int $status, Str $text --> Nil) {
    $conn.write(HTTP::Core::Response.new(:$status, :body($text)).payload(False));
    self!drop($conn, why => "rejected with {$status}");
}

# Close one connection and deregister it.
#
# The key is the connection's own serial, which is never handed out twice, so a
# late callback for a dead connection can no longer land on a live one's entry.
# The `===` check stays as a belt-and-braces guard: `!drop` is reachable from a
# read failure, a write failure, a protocol rejection and a dying callback, and
# the second one through must not unregister anything.
method !drop(HTTP::Core::Connection $conn, Str :$why = 'unspecified' --> Nil) {
    my Int $key = $conn.serial;
    my Bool $owned = $!conns-lock.protect({
        my Bool $mine = %!conns{$key}:exists && %!conns{$key} === $conn;
        %!conns{$key}:delete if $mine;
        $mine;
    });

    self!dbg("drop id={$conn.transport.id} conn#{$key}: {$why}"
           ~ ($owned ?? '' !! ' [entry absent or owned by another connection]'));

    $conn.close;
}

# --- dispatch -------------------------------------------------------------

# Public entry point: run one already-parsed request through the router and
# build a Response, without touching a socket.
#
# This exists so the framing cost (routing + serialisation) can be measured
# separately from the transport cost. Benchmarks and embedders use it; the
# connection loop calls !dispatch directly.
method handle(HTTP::Core::Request $req --> HTTP::Core::Response) {
    self!dispatch($req);
}

method !dispatch(HTTP::Core::Request $req --> HTTP::Core::Response) {
    my $result;

    {
        my $hit = $!router.match($req.method, $req.path-only);

        if $hit.defined {
            # Unpack into scalars: binding the Hash slot directly (`my %params`)
            # makes Raku reinterpret the Hash as a list of pairs, which dies on
            # the empty-params case.
            my ($handler, $params) = $hit;

            # ':405' is the router's way of saying "path known, method not".
            if $handler ~~ Str && $handler eq ':405' {
                $result = HTTP::Core::Response.new(
                    status  => 405,
                    body    => 'Method Not Allowed',
                    headers => %( Allow => $!router.allowed-methods($req.path-only).join(', ') ),
                );
            }
            else {
                $result = self!coerce($handler($req, $params));
            }
        }
        else {
            $result = HTTP::Core::Response.new(status => 404, body => 'Not Found');
        }

        # A handler that dies must not take the connection state machine with
        # it. CATCH lives inside this block so that normal flow continues to
        # the return below; a CATCH in the method body would become the return
        # value and hand back an undefined response.
        CATCH {
            default {
                say "HTTP::Core dispatch error: {.message}" if $!debug;
                $result = HTTP::Core::Response.new(status => 500, body => 'Internal Server Error');
            }
        }
    }

    $result // HTTP::Core::Response.new(status => 500, body => 'Internal Server Error');
}

# Let handlers be lazy: a plain string or a Blob becomes a 200 response.
# Text needs an explicit Content-Type, otherwise clients fall back to treating
# the body as opaque bytes.
method !coerce($out --> HTTP::Core::Response) {
    return $out if $out ~~ HTTP::Core::Response;

    if $out ~~ Str {
        return HTTP::Core::Response.new(
            body    => $out,
            headers => %( Content-Type => 'text/plain; charset=utf-8' ),
        );
    }
    return HTTP::Core::Response.new(body => $out) if $out ~~ Blob;
    return HTTP::Core::Response.new(body => ~$out) if $out.defined;

    HTTP::Core::Response.new(body => '');
}
