use v6.d;
use HTTP::Core::X;

# ---------------------------------------------------------------------------
# Just enough URL to drive a client: scheme, host, port, path, query.
#
# Why hand-rolled at all, given the design memo says "use URI from the
# ecosystem": this file is the subset of URI that a request line and a Host
# header need, with no dependency, and it is exercised by the tests. The moment
# anything here needs more than splitting on `://`, `/`, `?` -- percent-encoding
# normalisation, IDNs, userinfo for Basic auth -- it should be replaced by `URI`
# rather than grown.
#
# What it does have, and what the redirect logic cannot work without:
#
#   * RFC 3986 §5 relative reference resolution (Location: /a/b, ../c, ?q, //h/p)
#   * dot-segment removal, which is what makes `/a/b/../c` collapse to `/a/c`
#   * `origin` -- scheme+host+port, the only honest key for a connection pool
#     (path and query must NOT be part of it, or every URL gets its own pool)
# ---------------------------------------------------------------------------

unit class HTTP::Core::Client::URL;

has Str $.scheme = 'http';
has Str $.host   = '';
has Int $.port   = 80;
has Str $.path   = '/';
has Str $.query  = '';

my constant %DEFAULT-PORT = http => 80, https => 443;

# Where the last redirect came from, for error messages. Not used for resolution
# (resolution has already happened by the time a URL object exists).
has Str $.referer;

# --- parsing --------------------------------------------------------------

method parse(HTTP::Core::Client::URL:U: Str $text, HTTP::Core::Client::URL $base? --> HTTP::Core::Client::URL) {
    my Str $ref = $text.trim;
    die HTTP::Core::X::InvalidUrl.new(reason => 'empty URL') unless $ref.chars;

    # A fragment never reaches the wire.
    my Int $hash = $ref.index('#');
    $ref = $ref.substr(0, $hash) if $hash.defined;

    # "//host/path" is scheme-relative: rare from Origin, common from CDNs.
    if $ref.starts-with('//') {
        die HTTP::Core::X::InvalidUrl.new(reason => "scheme-relative URL '{$text}' with no base URL")
            unless $base.defined;
        return self.parse($base.scheme ~ ':' ~ $ref);
    }

    my Int $sep = $ref.index('://');
    return self!parse-relative($ref, $base, $text) if !$sep.defined || $sep < 1;

    # --- absolute ---------------------------------------------------------
    my Str $scheme = $ref.substr(0, $sep).lc;
    die HTTP::Core::X::InvalidUrl.new(reason => "unsupported scheme '{$scheme}' in '{$text}'")
        unless %DEFAULT-PORT{$scheme}:exists;

    my Str $rest = $ref.substr($sep + 3);
    my Int $cut  = $rest.chars;
    for '/', '?' -> $ch {
        my Int $i = $rest.index($ch);
        $cut = $i if $i.defined && $i < $cut;
    }

    my Str $authority = $rest.substr(0, $cut);
    my Str $tail      = $rest.substr($cut);

    # Userinfo is accepted and dropped: one client that says "user:pass@" must
    # not make the Host header or the pool key wrong.
    my Int $at = $authority.rindex('@');
    $authority = $authority.substr($at + 1) if $at.defined;

    my Str $host;
    my Str $port-text = '';

    if $authority.starts-with('[') {
        my Int $close = $authority.index(']');
        die HTTP::Core::X::InvalidUrl.new(reason => "unclosed IPv6 literal in '{$text}'")
            unless $close.defined;
        $host = $authority.substr(0, $close + 1);
        my Str $after = $authority.substr($close + 1);
        $port-text = $after.substr(1) if $after.starts-with(':');
    }
    else {
        my Int $colon = $authority.index(':');
        if $colon.defined {
            $host = $authority.substr(0, $colon);
            $port-text = $authority.substr($colon + 1);
        }
        else {
            $host = $authority;
        }
    }

    die HTTP::Core::X::InvalidUrl.new(reason => "no host in '{$text}'") unless $host.chars;

    my Int $port = %DEFAULT-PORT{$scheme};
    if $port-text.chars {
        die HTTP::Core::X::InvalidUrl.new(reason => "bad port '{$port-text}' in '{$text}'")
            unless $port-text ~~ /^ <[0..9]>+ $/;
        $port = $port-text.Int;
        die HTTP::Core::X::InvalidUrl.new(reason => "port {$port} out of range in '{$text}'")
            unless $port > 0 && $port < 65536;
    }

    my ($path, $query) = split-query($tail);

    self.new(
        :$scheme,
        :$host,
        :$port,
        path  => normalise-path($path),
        :$query,
    );
}

# RFC 3986 §5.2.2, the five non-absolute cases that actually occur.
method !parse-relative(Str $ref, HTTP::Core::Client::URL $base, Str $original --> HTTP::Core::Client::URL) {
    die HTTP::Core::X::InvalidUrl.new(reason => "relative URL '{$original}' with no base URL")
        unless $base.defined;

    my ($ref-path, $ref-query) = split-query($ref);

    if $ref-path eq '' {
        # "?a=b" retargets the query of the base; "" is the base itself.
        return self.new(
            scheme => $base.scheme, host => $base.host, port => $base.port,
            path   => $base.path, query => ($ref.contains('?') ?? $ref-query !! $base.query),
            referer => $base.Str,
        );
    }

    my Str $path = $ref-path.starts-with('/')
        ?? normalise-path($ref-path)
        !! normalise-path(merge-path($base.path, $ref-path));

    self.new(
        scheme => $base.scheme, host => $base.host, port => $base.port,
        :$path, query => $ref-query,
        referer => $base.Str,
    );
}

# --- accessors ------------------------------------------------------------

# The pool key. Port is always present so that :80 and :8080 cannot collide,
# and http://h:80 is the same key as http://h/ (which is why the default port is
# filled in at parse time rather than left implicit).
method origin(--> Str) { $!scheme ~ '://' ~ $!host ~ ':' ~ $!port }

# What goes in the Host header: the port is omitted when it is the default,
# because some servers compare the header text and a spurious :80 has broken
# enough real-world virtual hosting.
method host-header(--> Str) {
    my Int $default = %DEFAULT-PORT{$!scheme} // 80;
    return $!host if $!port == $default;
    $!host ~ ':' ~ $!port;
}

# Request target: origin-form, which is what a direct (non-proxy) client sends.
method target(--> Str) {
    my Str $p = $!path.chars ?? $!path !! '/';
    $!query.chars ?? $p ~ '?' ~ $!query !! $p;
}

method secure(--> Bool) { $!scheme eq 'https' }

method Str(--> Str) {
    my Str $p = $!path.chars ?? $!path !! '/';
    my Str $q = $!query.chars ?? '?' ~ $!query !! '';
    $!scheme ~ '://' ~ self.host-header ~ $p ~ $q;
}

# --- helpers --------------------------------------------------------------

sub split-query(Str $s --> List) {
    my Int $q = $s.index('?');
    return ($s, '') unless $q.defined;
    ($s.substr(0, $q), $s.substr($q + 1));
}

sub merge-path(Str $base-path, Str $ref-path --> Str) {
    my Int $slash = $base-path.rindex('/');
    return $ref-path unless $slash.defined;
    $base-path.substr(0, $slash + 1) ~ $ref-path;
}

# "a/./b/../c" -> "a/c". Trailing slashes are preserved because `/dir/` and
# `/dir` are different resources to a lot of servers.
sub normalise-path(Str $in --> Str) {
    my Str $p = $in.chars ?? $in !! '/';

    my Bool $abs      = $p.starts-with('/');
    my Bool $trailing = $p.ends-with('/') || $p.ends-with('/.') || $p.ends-with('/..');

    my @out;
    for $p.split('/') -> $seg {
        next unless $seg.chars;
        next if $seg eq '.';
        if $seg eq '..' {
            @out.pop if @out;
            next;
        }
        @out.push($seg);
    }

    my Str $s = @out.join('/');
    $s = '/' ~ $s if $abs && $s.chars;
    $s = '/' if $s eq '';
    $s = $s ~ '/' if $trailing && !$s.ends-with('/');
    $s;
}
