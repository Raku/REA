use v6.d;

# ---------------------------------------------------------------------------
# Where bytes come from and where they go.
#
# The server used to hard-code `IO::Socket::Async` in `!serve`, which meant the
# parser could never be pointed at anything else: not a TLS socket, not a Unix
# socket, not an in-memory pipe for benchmarks. This role is the seam.
#
# Deliberately tiny. A transport knows three things and nothing more:
#
#   * incoming  -- a Supply of Buf chunks (exactly what IO::Socket::Async hands
#                  you, so the reactor stays libuv's, not ours)
#   * write     -- push bytes, returns the transport's own Promise
#   * close     -- stop the thing
#
# No framing, no parsing, no buffering, no retries live here. Those belong to
# `HTTP::Core::Connection`, so that a TCP, TLS or in-memory transport behaves
# identically from the connection's point of view.
# ---------------------------------------------------------------------------

unit role HTTP::Core::Transport;

# A Supply emitting Buf. Tapped exactly once, by the owning Connection.
method incoming(--> Supply) { ... }

# Accepts any Blob; the transport decides how to serialise the writes.
method write(Blob:D $bytes --> Promise) { ... }

# Idempotent: closing twice must not throw.
method close(--> Nil) { ... }

method closed(--> Bool) { ... }

# Stable identity for bookkeeping (the server keys its connection registry by
# this). Int, not the object, so it survives as a plain hash key.
method id(--> Int) { ... }
