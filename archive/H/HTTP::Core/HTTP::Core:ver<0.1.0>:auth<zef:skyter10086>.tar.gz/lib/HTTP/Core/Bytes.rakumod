use v6.d;
use nqp;

# ---------------------------------------------------------------------------
# Str -> UTF-8 bytes, without Rakudo's per-call transcoder overhead.
#
# `Str.encode('utf-8')` costs ~3.3 us for a 7-byte ASCII body on Rakudo 2026.09,
# and it is the single most expensive thing on the response path: over half of
# `Response.payload`. `nqp::encode` does the same MoarVM transcode with none of
# the surrounding Str/Blob ceremony and comes in at ~0.6 us for the same input.
#
# Why it is allowed to differ from `.encode`:
#
#   * The output is byte-identical. Verified case by case in
#     temp/probe-nqp-encode.raku over ASCII, Latin-1, CJK, combining marks,
#     ZWJ emoji sequences, regional-indicator flags, non-BMP code points,
#     embedded NUL, NBSP, BOM, RTL and CRLF - 16/16 identical. Rakudo strings
#     are NFG, and MoarVM's encoder flattens NFG to code points itself, so
#     skipping Rakudo's normalisation step loses nothing.
#   * The only observable difference is the container class: `.encode` returns
#     `utf8` (a Blob), this returns `Buf[uint8]` (a mutable Buf). Every caller
#     here only reads `.elems` and hands the pointer to C, and a Buf is a Blob.
#
# Trade-off: this is an nqp op, not public API. It is pinned to the Rakudo
# version in README/RESULTS and covered by t/04, which compares this path
# against the pure-Raku builder byte for byte - if a future Rakudo changes the
# op, the test fails loudly rather than shipping wrong bytes.
# ---------------------------------------------------------------------------

sub str-bytes(Str $s --> Buf) is export {
    nqp::encode($s, 'utf8', buf8.new);
}
