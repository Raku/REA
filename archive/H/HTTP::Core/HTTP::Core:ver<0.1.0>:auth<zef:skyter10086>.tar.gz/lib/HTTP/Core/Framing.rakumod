use v6.d;
use HTTP::Core;
use HTTP::Core::X;

# ---------------------------------------------------------------------------
# Message boundaries: "how many bytes of this buffer are one whole message?"
#
# This logic used to be the top half of `Server!pump`, tangled with dispatch,
# socket writes and keep-alive bookkeeping. Pulled out, it is the piece a client
# needs just as much as a server does, and it is the only place that knows about
# `is-complete`, the head cap and the body cap.
#
# Direction-agnostic on purpose: `decode` asks for a *request* only because that
# is the only codec that exists so far. The contract `Connection` relies on is
# narrow — take a Buf, answer with an Outcome that reports how many bytes it
# ate, or with no request at all meaning "need more bytes".
#
# Three answers, no exceptions:
#
#   Outcome.request defined   -> one complete message, consume .consumed
#   Outcome.error   defined   -> the stream is dead, consume everything
#   neither                   -> incomplete, keep the bytes and wait
#
# Using a value instead of throwing keeps the I/O path free of exception
# control flow: a half-received head is the normal case, not an error.
# ---------------------------------------------------------------------------

unit class HTTP::Core::Framing;

# Declared *without* the `HTTP::Core::Framing::` prefix on purpose. Inside
# `unit class HTTP::Core::Framing`, a name that already reads like a full path is
# still resolved relative to the current package, so the old spelling created
# `HTTP::Core::Framing::HTTP::Core::Framing::Outcome` -- a class that every
# caller addressed under a name it did not have. A bare nested name *is*
# `HTTP::Core::Framing::Outcome`, which is what the rest of the tree imports.
class Outcome {
    has $.request;             # HTTP::Core::Request once the message is whole
    has $.response;            # HTTP::Core::Response, the client-side twin
    has Str $.error;           # 'bad-request' | 'head-too-large'
                               # | 'body-too-large' | 'internal'
    has Int $.consumed = 0;    # bytes to drop from the front of the buffer

    # One flag for both directions: the caller only asks "is there a message?".
    # It used to test `$!request` alone, which made every framed *response*
    # report `ready == False` -- a client waiting on that flag waits forever.
    method ready(--> Bool) { $!request.defined || $!response.defined }
    method failed(--> Bool) { $!error.defined }
}

has Int $.max-head = 64 * 1024;
has Int $.max-body = 8 * 1024 * 1024;

# Waiting for more bytes is the common case on a slow link, so the incomplete
# Outcome is one shared frozen instance rather than a fresh object per read.
my constant INCOMPLETE = HTTP::Core::Framing::Outcome.new(consumed => 0);

# `$eof` exists for the client-side framer (until-close bodies, truncation vs.
# waiting). A request never ends at EOF -- a peer that closes mid-head has
# simply gone away -- so it is accepted and ignored here, which keeps one
# decoder signature for Connection.
method decode(Buf:D $buf, Bool :$eof = False --> HTTP::Core::Framing::Outcome) {
    my Int $elems = $buf.elems;

    # An empty buffer reaches the kernel as a NULL pointer and comes back as a
    # parse error; semantically it only means "nothing to chew on yet".
    return INCOMPLETE if $elems == 0;

    my $req;
    my $err;
    {
        $req = parse-request($buf);
        CATCH { default { $err = $_ } }
    }

    if $req.defined {
        # Head is in, body may not be. Waiting here is what keeps a handler from
        # ever seeing a half-read payload.
        return INCOMPLETE unless $req.is-complete;

        if $!max-body > 0 && $req.content-length > $!max-body {
            return HTTP::Core::Framing::Outcome.new(
                consumed => $elems,
                error    => 'body-too-large',
            );
        }

        # `.body` copies the payload out, which is wasteful for a number we can
        # compute directly -- but keeping the exact expression the server used
        # before this refactor is the whole point of M0. M2 owns the rewrite.
        my Int $used = $req.consumed + $req.body.elems;
        $used = $elems if $used > $elems;

        return HTTP::Core::Framing::Outcome.new(request => $req, consumed => $used);
    }

    given $err {
        when HTTP::Core::X::Incomplete {
            # Only a *head* can be refused for size: an incomplete buffer has no
            # body yet, so the same byte count means something different here.
            return HTTP::Core::Framing::Outcome.new(
                consumed => $elems,
                error    => 'head-too-large',
            ) if $elems > $!max-head;

            return INCOMPLETE;
        }
        when HTTP::Core::X::ParseError {
            return HTTP::Core::Framing::Outcome.new(
                consumed => $elems,
                error    => 'bad-request',
            );
        }
        default {
            return HTTP::Core::Framing::Outcome.new(
                consumed => $elems,
                error    => 'internal',
            );
        }
    }
}
