﻿use v6.d;
use HTTP::Core::Transport;
use HTTP::Core::Framing;

# ---------------------------------------------------------------------------
# One connection, as a state machine: bytes in -> messages out -> bytes out.
#
# The shape that matters is *event-driven*. The obvious Raku spelling —
#
#     start { loop { my $chunk = $channel.receive } }
#
# burns one thread-pool thread per connection the moment the peer goes quiet,
# and it fights the reactor the server already owns. So: the transport's Supply
# feeds the buffer, and each caller that wants "the next message" parks a
# Promise. Nothing blocks, nothing is polled, and N idle connections cost N
# buffers instead of N threads.
#
# Two rules the call sites must respect, both of which the client will hit
# harder than the server:
#
#   1. Writes on one connection are serial. A caller must not put a second
#      request in flight before the first response is fully read back.
#   2. A connection may only be reused once the previous message was consumed
#      in full (framing says how many bytes that was). Guessing is how pipelines
#      desynchronise.
#
# The decoder is injected: `HTTP::Core::Framing` for requests today, a response
# framer once the client exists. This class deliberately knows nothing about
# HTTP semantics — not status codes, not routing, not keep-alive policy.
# ---------------------------------------------------------------------------

unit class HTTP::Core::Connection;

# A per-process identity for one connection. Deliberately not derived from the
# transport: `transport.id` is the socket's memory address, which is stable only
# while that socket is alive and gets handed to a later connection once one is
# freed. Anything that has to survive a teardown -- a registry entry, a log
# line, a pool slot -- must key on something that is never reused, and this is
# that something.
my atomicint $CONN-SEQ;

has HTTP::Core::Transport $.transport is required;

has Int $.serial = ++$CONN-SEQ;

# Anything with `.decode(Buf, Bool :$eof --> Framing::Outcome)`. Defaults to the
# request framer, which is what every server connection wants. Writable because
# a client owns a response framer whose `:head` flag changes per request.
has $.decoder is rw;

has Bool $.debug = False;
has Int  $.max-head = 64 * 1024;
has Int  $.max-body = 8 * 1024 * 1024;

# Reachable by the owner: a 'close' request, a framing failure or an EOF that
# leaves bytes unread all mean this socket must not go back into a pool.
has Bool $.reusable = True;

has Buf  $!rbuf    = Buf.new;
has      @!waiters;              # Promises, oldest first
has Bool $!closed  = False;
has Bool $!eof     = False;
has Bool $!pumping = False;

# The state below is written from two threads: the reactor feeds bytes, the
# scheduler asks for messages and runs continuations. Rakudo arrays and Bools
# are not safe to touch unchecked from both sides, and an unsynchronised
# "already pumping" flag does worse than losing a byte -- it loses a *wakeup*,
# which is invisible until a client waits thirty seconds for a response that
# was sitting in the buffer the whole time.
has Lock $!lock .= new;

# Why the last pump stopped: `True` means "the decoder wants more bytes", so
# silence is correct. `False` means the loop ran out of waiters, which means
# anyone arriving during teardown must be re-checked instead of stranded.
has Bool $!starved = False;

has      $!tap;

submethod TWEAK(--> Nil) {
    $!decoder //= HTTP::Core::Framing.new(:$!max-head, :$!max-body);

    # Tapping here (not in `start`) means no byte can arrive before someone is
    # listening for it: anything that shows up early is buffered, not lost.
    $!tap = $!transport.incoming.tap(
        -> Buf $chunk { self!feed($chunk) },
        done => {
            $!eof = True;

            # EOF is an *input to framing*, not just a failure. Without this
            # pump, a response whose head announced 10 bytes and got 3 would be
            # reported as "connection closed" (a network error) instead of as a
            # truncated message, and an HTTP/1.0 until-close body would never be
            # delivered at all. The framer gets one last look at the buffer with
            # :eof, then whatever is still parked is genuinely unrecoverable.
            self!pump;
            self!fail-all('connection closed');
        },
        quit => -> $e {
            $!eof = True;
            self!fail-all($e ~~ Str ?? $e !! $e.message);
        },
    );
}

# --- public ---------------------------------------------------------------

# Resolves to whatever the decoder reported for one whole message. Never hangs:
# a closed or exhausted connection fails the Promise instead, so a caller's
# `.then` always runs exactly once.
method next-message(--> Promise) {
    my $p = Promise.new;

    # Park the waiter and clear `starved` in one critical section. If these
    # were separate, a pump could conclude "nothing to do, bytes are missing"
    # in between and go quiet on a buffer that already holds a whole message.
    my Bool $dead = $!lock.protect({
        if $!closed || ($!eof && $!rbuf.elems == 0) {
            True;
        }
        else {
            @!waiters.push($p);
            $!starved = False;
            False;
        }
    });

    if $dead {
        $p.break('connection closed');
        return $p;
    }

    self!pump;
    $p;
}

method write(Blob:D $bytes --> Promise) {
    return Promise.kept if $!closed;
    $!transport.write($bytes);
}

method close(--> Nil) {
    return if $!closed;

    $!closed   = True;
    $!reusable = False;

    # Stop feeding first: the tap's `done` would otherwise re-enter after the
    # waiters have already been broken.
    try $!tap.close if $!tap.defined;
    $!tap = Any;

    self!fail-all('connection closed');
    $!transport.close;
    Nil;
}

method closed(--> Bool) { $!closed }

# The peer is gone (EOF) even if nobody called .close yet. A pool must treat
# this exactly like `closed`: a connection whose peer said good-bye is not
# reusable no matter what the last response claimed.
method exhausted(--> Bool) { $!closed || $!eof }

method buffered(--> Int) { $!lock.protect({ $!rbuf.elems }) }

# --- plumbing -------------------------------------------------------------

# Pipeline or misbehaving peer: bytes with nobody waiting are kept, not dropped.
method !feed(Buf $chunk --> Nil) {
    # New bytes invalidate the decoder's "need more" verdict. Clearing it here
    # is what stops a pump that is already finishing from standing down on a
    # stale conclusion while the rest of the request has just landed: it would
    # leave the message sitting in the buffer with a waiter parked behind it,
    # and no further event to ever wake them.
    $!lock.protect({
        $!rbuf ~= $chunk;
        $!starved = False;
    });
    self!pump;
}

method !pump(--> Nil) {
    # One pump at a time. Losing the race is harmless *because* the winner
    # re-checks the queue under the lock before it stands down (see the tail
    # of the loop); that handshake is what the previous version was missing.
    loop {
        my $mine = $!lock.protect({
            if $!pumping { False } else { $!pumping = True; True }
        });
        return unless $mine;

        loop {
            my $waiter;
            my $out;

            $!lock.protect({
                if @!waiters {
                    $out = self!try-decode;
                    if $out.defined {
                        $!rbuf = self!consume($out.consumed);
                        $waiter = @!waiters.shift;
                    }
                    else {
                        $!starved = True;
                    }
                }
            });

            if $waiter.defined {
                # Outside the lock on purpose: keeping the promise runs the
                # caller's continuation inline, and that continuation asks for
                # the next message, i.e. takes the same lock.
                $waiter.keep($out);
                next;
            }

            last;
        }

        # Standing down is atomic with the re-check. If a waiter arrived while
        # this pump was finishing, it is visible here either way: if it saw
        # `pumping` still set it returned immediately, so this branch has to
        # pick it up; if it hasn't run yet it will find `pumping` clear.
        my $again = $!lock.protect({
            $!pumping = False;
            @!waiters && !$!starved;
        });

        self!fail-all('connection closed') if $!eof;

        return unless $again;
    }
}

# Returns a defined Outcome when one message (or one fatal error) was framed,
# Nil when the buffer simply needs more bytes. Exceptions out of the decoder
# become 'internal' so a bug in the framing layer cannot wedge a connection.
method !try-decode(--> HTTP::Core::Framing::Outcome) {
    my $out;

    {
        $out = $!decoder.decode($!rbuf, :eof($!eof));
        CATCH {
            default {
                note "HTTP::Core connection: decoder died: {.message}" if $!debug;
                $out = HTTP::Core::Framing::Outcome.new(
                    consumed => $!rbuf.elems,
                    error    => 'internal',
                );
            }
        }
    }

    return Nil unless $out.defined;

    if $out.failed {
        # Never hand back an error that claims zero bytes: that would spin.
        $out = HTTP::Core::Framing::Outcome.new(
            consumed => $!rbuf.elems,
            error    => $out.error,
        ) if $out.consumed == 0;

        $!reusable = False;
        return $out;
    }

    return Nil unless $out.ready && $out.consumed > 0;
    $out;
}

method !consume(Int $used --> Buf) {
    my Int $n = $!rbuf.elems;

    $used = 0  if $used < 0;
    $used = $n if $used > $n;

    return Buf.new if $used >= $n;
    $!rbuf.subbuf($used).Buf;
}

method !fail-all($why --> Nil) {
    my @pending;
    $!lock.protect({
        @pending  = @!waiters;
        @!waiters = ();
    });
    for @pending -> $p { $p.break($why) }
    Nil;

}
