use v6.d;

# Failure hierarchy for HTTP::Core.
#
# Kept in its own module because the classes must live under HTTP::Core::X,
# while Request.rakumod is a `unit class` and would otherwise nest them.
#
# One root, one rule: every failure the stack raises is an HTTP::Core::X::Base
# subclass, so a caller can `CATCH { when HTTP::Core::X::Base }` and get a
# single place to log, retry or map to an application error. The subclasses are
# the *categories* — the design asks for network / timeout / protocol /
# truncation to be distinguishable, not for one catch-all string.
#
# The parse classes predate the client and keep their exact message text: a
# half-received head is normal flow, and the request path turns it into a value
# (Framing::Outcome) rather than an exception, so nothing depends on it today
# other than debugging output.
unit module HTTP::Core::X;

class Base is Exception is export {
    has Str $.reason;

    # Overridden per category; keeps `message` in one place so the categories
    # cannot drift apart in punctuation or prefix.
    method kind(--> Str) { 'parse failure' }

    method message(--> Str) { "HTTP::Core {self.kind}: { $!reason // 'unknown' }" }
}

# The buffer ended inside the request (or response) head. Not an error: append
# more bytes from the socket and parse the extended buffer again.
class Incomplete is Base is export { }

# The head is syntactically invalid: bad start line, or headers the kernel
# refused to read.
class ParseError is Base is export { }

# --- client-side categories ------------------------------------------------
#
# Four shapes, four different reactions, which is why they are four classes and
# not one error with a flag:
#
#   Network    the bytes never got there, or the peer hung up mid-conversation.
#              Retryable *only* for an idle-pooled connection and only for an
#              idempotent method -- the pool decides, not the caller.
#   Timeout    a deadline expired. The connection is poisoned either way, so the
#              pool discards it instead of checking reusability.
#   Protocol   we got bytes, they were not HTTP we can frame. Never retry: the
#              peer is speaking something else.
#   Truncated  a well-formed head announced more body than ever arrived. Also
#              never retry silently -- the peer has a bug worth surfacing.

class Network is Base is export {
    method kind(--> Str) { 'network error' }
}

class Timeout is Base is export {
    # 'connect' | 'read' -- which deadline fired.
    has Str $.phase = 'read';

    method kind(--> Str) { 'timeout' }

    method message(--> Str) {
        "HTTP::Core timeout ({ $!phase }): { self.reason // 'deadline elapsed' }"
    }
}

class Protocol is Base is export {
    method kind(--> Str) { 'protocol error' }
}

class Truncated is Base is export {
    method kind(--> Str) { 'truncated message' }
}

# A redirect chain that never reached a final response, or a Location the URL
# resolver refused. Separate from Protocol because it is a *policy* limit the
# caller can raise (max-redirects), not a malformed peer.
class Redirect is Base is export {
    method kind(--> Str) { 'redirect error' }
}

# The client was closed, or the pool was, before the request could run.
class Closed is Base is export {
    method kind(--> Str) { 'client closed' }
}

# The URL could not be split into scheme/host/port/path. Raised by the client,
# never by the kernel: the kernel sees bytes only.
class InvalidUrl is Base is export {
    method kind(--> Str) { 'invalid URL' }
}
