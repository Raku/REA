use v6.d;
use NativeCall;
use HTTP::Core::Native;
use HTTP::Core::Bytes;

# ---------------------------------------------------------------------------
# A pattern router with zero dependencies: exact segments, :named params and a
# trailing * wildcard. That is enough to build a real API, and small enough to
# read in one sitting.
#
#   $r.get:    '/users/:id', -> $req, %p { ... };
#   $r.post:   '/users',     -> $req, %p { ... };
#   $r.get:    '/files/*',   -> $req, %p { say %p<*> };
#
# Patterns are split into segments once, at registration time. Splitting them
# again on every request was costing ~40 microseconds per dispatch.
#
# Two matchers, same semantics:
#
#   * The exact-path table handles anything without a `:param` or `*`, in one
#     hash probe, with no path split at all.
#   * Everything else goes to the C kernel. Splitting a path in Raku measured
#     ~1.9 us before a single segment was compared, and a params Hash per
#     candidate route on top of that; a twelve-route table cost ~12 us per
#     dynamic dispatch, growing ~1.1 us per route. The kernel walks bytes,
#     rejects on segment count, and reports capture offsets.
#   * The pure-Raku matcher below stays as the source of truth and as the
#     fallback for whatever the kernel declines (a `*` capture, a path with
#     more than 64 segments, an over-long capture list).
#
# t/05-routing-diff.raku pins the two against each other on a few thousand
# generated pattern/path pairs, so the fast path cannot drift silently.
# ---------------------------------------------------------------------------

unit class HTTP::Core::Router;

# Route table as parallel arrays rather than a list of Hashes.
#
# Each entry used to be a Hash, so one pass over three routes cost six `%r<...>`
# lookups (~100 ns each) before match-segs was even called. Integer-indexed
# arrays remove that: they are the same walk, minus the hashing. Measured in
# bench/05-ab-inproc.raku, which loads the old and new router side by side.
has @!r-method;    # Str
has @!r-pattern;   # Str  — only used to rebuild the Allow header / introspection
has @!r-segs;      # List of segment lists
has @!r-nsegs;     # Int
has @!r-wild;      # Bool — pattern contains `*`
has @!r-handler;   # Code

# Literal patterns (no `:name`, no `*`), indexed path => method => entry, so the
# hot request path never splits the URL and never walks the route table.
#
# Indexed by path first, not by method: on a dynamic route (the common case once
# an app has any `:id` route) the probe misses and must be as cheap as possible,
# and one hash miss beats two. A concatenated "METHOD /path" key was worse
# still: building that string alone cost ~1.5 us on every dispatch.
#
# Each entry carries its registration index: when both an exact-method and a
# `*` route are registered for the same path, the older one still wins, exactly
# as in the linear scan.
has %!static;

# The kernel's copy of the same table, flattened to int32 triples and quads so
# it can be handed over without marshalling anything per call:
#
#   @!c-segs    3 per segment: kind (0 literal, 1 :param, 2 *), blob offset,
#               blob length
#   @!c-routes  4 per route: first segment, segment count, method id, flags
#   @!c-names   one capture name per segment, so the kernel can report a
#               segment index and the name costs nothing to look up
#   $!blob      the segment texts, UTF-8, concatenated once at registration
#
# Registration is rare and matching is per request, so all of the flattening
# happens in add().
constant SCRATCH-SLOTS = 1024;

has int32 @!c-segs;
has int32 @!c-routes;
has @!c-names;
has Buf $!blob = Buf.new;

# Method name -> the integer the kernel compares. 0 is reserved for "any",
# which is what `$r.any` registers; every other method, including ones this
# class knows nothing about, gets an id on first sight.
has %!m-id = '*' => 0;

# Caller-owned scratch that the kernel writes its output into. `$!out` is sized
# for 4 header slots plus the kernel's maximum of 16 captures; the scratch is a
# single byte and its capacity is passed as 0, because a `*` capture is handled
# by the Raku matcher instead -- the kernel already told us enough to know it
# would need to rebuild the capture text.
has CArray[size_t] $!out = CArray[size_t].allocate(4 + 4 * 16);

# The kernel rebuilds a `*` capture into this buffer, joined with "/", because
# the text is not contiguous in the request path once empty segments are gone.
# A capture longer than the buffer makes the kernel return -1 and the Raku walk
# takes over, so the size is a speed knob, not a correctness one.
has Buf $!scratch = Buf.new(0 xx SCRATCH-SLOTS);

# Pointers into the flattened tables. Recomputing them on every request costs
# more than the match itself, so they are cached and invalidated by add().
has Pointer $!p-segs;
has Pointer $!p-routes;
has Pointer $!p-blob;
has Bool    $!stale = True;

method add(Str $method, Str $pattern, &handler --> Nil) {
    my $m    = $method.uc;
    my $segs = segments($pattern);
    my $idx  = @!r-method.elems;

    my ($static, $wild) = classify($segs);

    @!r-method.push:  $m;
    @!r-pattern.push: $pattern;
    @!r-segs.push:    $segs;
    @!r-nsegs.push:   $segs.elems;
    @!r-wild.push:    $wild;
    @!r-handler.push: &handler;

    if $static {
        %!static{$pattern}{$m} = %( handler => &handler, idx => $idx );
    }

    # Flatten the same route for the kernel. `%!m-id` is only touched here and
    # in match(), and an unknown method allocates its id on first registration,
    # so a request for 'PROPFIND' can never be mistaken for an `any` route.
    my $mid   = %!m-id{$m} // (%!m-id{$m} = %!m-id.elems);
    my $first = (@!c-segs.elems div 3);

    # `.list` is not decoration: iterating the `$segs` scalar directly hands the
    # whole List to the loop as one item, so every pattern would flatten into a
    # single segment.
    for $segs.list -> $seg {
        my Int $kind;
        my Str $text;

        if $seg eq '*' {
            $kind = 2; $text = '*';
        }
        elsif $seg.starts-with(':') {
            $kind = 1; $text = $seg.substr(1);
        }
        else {
            $kind = 0; $text = $seg;
        }

        my $bytes = str-bytes($text);
        @!c-segs.push: $kind, $!blob.elems, $bytes.elems;
        @!c-names.push: $text;
        $!blob.append: $bytes;
    }

    @!c-routes.push: $first, $segs.elems, $mid.Int, ($wild ?? 1 !! 0);

    $!stale = True;   # the native arrays may have been resized
}

method get(Str $pattern, &handler --> Nil)    { self.add('GET',    $pattern, &handler) }
method post(Str $pattern, &handler --> Nil)   { self.add('POST',   $pattern, &handler) }
method put(Str $pattern, &handler --> Nil)    { self.add('PUT',    $pattern, &handler) }
method patch(Str $pattern, &handler --> Nil)  { self.add('PATCH',  $pattern, &handler) }
method delete(Str $pattern, &handler --> Nil) { self.add('DELETE', $pattern, &handler) }
method any(Str $pattern, &handler --> Nil)    { self.add('*',      $pattern, &handler) }

method routes(--> Int) { @!r-method.elems }

# `:skip-empty` beats `.split('/').grep(*.chars)`: one allocation, not three.
sub segments(Str $path --> List) {
    $path.split('/', :skip-empty).List;
}

# Classify a pattern once, at registration time. Returns (static, wild):
#   static — captures nothing, so it can live in the exact-path table;
#   wild   — contains a `*`, which may swallow any number of trailing segments,
#            so its segment count cannot be used to reject a path early.
sub classify(@segs --> List) {
    my Bool $static = True;
    my Bool $wild   = False;

    for @segs {
        if $_ eq '*' {
            $wild   = True;
            $static = False;
        }
        elsif $_.starts-with(':') {
            $static = False;
        }
    }
    ($static, $wild);
}

# Match pre-split pattern segments against pre-split path segments.
# Returns a Hash of captures on a match, or Nil on a miss. An empty Hash means
# "matched, nothing captured" — always defined, which is why callers must bind
# the result to a scalar rather than a %-sigiled variable.
sub match-segs(@ps, @xs --> Hash) {
    my %params;

    for @ps.kv -> $i, $seg {
        if $seg eq '*' {
            %params<*> = @xs[$i .. *].join('/');
            return %params;
        }
        return Nil if $i >= @xs.elems;

        if $seg.starts-with(':') {
            # :name -> capture by name; a bare colon would be a typo.
            %params{$seg.substr(1)} = @xs[$i];
        }
        elsif $seg ne @xs[$i] {
            return Nil;
        }
    }

    return Nil unless @xs.elems == @ps.elems;
    %params
}

# Convenience wrapper for callers that still have a pattern string, and for
# tests that exercise the matcher directly.
sub match-path(Str $pattern, Str $path --> Hash) {
    match-segs(segments($pattern), segments($path));
}

# Look up a handler. Returns (handler, params) when the method matches,
# (':405', params) when the path exists but the method does not, and Nil for 404.
method match(Str $method, Str $path) {
    my $wanted = $method.uc;

    # Fast path first: one hash probe on the path. A hit needs no URL split, no
    # match-segs and no params Hash; a miss costs ~170 ns, which the linear walk
    # below then recovers by skipping the segment-count-mismatched routes.
    my $slot = %!static{$path};

    if $slot.defined {
        my $exact = $slot{$wanted};

        if $exact.defined {
            # Registration order decides, same as the linear scan below.
            my $w = $slot{'*'};
            return ($w<handler>, %()) if $w.defined && $w<idx> < $exact<idx>;
            return ($exact<handler>, %());
        }
        my $w = $slot{'*'};
        return ($w<handler>, %()) if $w.defined;
    }

    # Hand the rest to the kernel. It answers 'hit', '405' or 'miss' -- and
    # 'fallback' for the few shapes it declines, which then take the pure-Raku
    # walk below. Both matchers agree segment for segment; t/05 proves it.
    my @native = self!native-match($path, $wanted);

    given @native[0] {
        when 'hit'  { return @native[1], @native[2] }
        when '405'  { return (':405', %()) }
        when 'miss' { return Nil }
    }

    my @xs = segments($path);
    my $nx = @xs.elems;
    my $n  = @!r-method.elems;
    my $i  = 0;
    my $seen = False;

    while $i < $n {
        # Segment count alone rejects most candidates before match-segs runs,
        # and skipping that call is worth far more than the two array reads it
        # costs: match-segs allocates a params Hash and walks every segment.
        if @!r-wild[$i] || @!r-nsegs[$i] == $nx {
            my $p = match-segs(@!r-segs[$i], @xs);

            if $p.defined {
                $seen = True;
                my $rm = @!r-method[$i];

                if $rm eq '*' || $rm eq $wanted {
                    return (@!r-handler[$i], $p);
                }
            }
        }
        $i++;
    }

    $seen ?? (':405', %()) !! Nil
}

# Ask the kernel to match. Returns one of:
#
#   ('hit',  &handler, %params)
#   ('405',)                     path exists, method does not
#   ('miss',)                    nothing matched
#   ('fallback',)                the kernel declined; caller runs the Raku walk
#
# The capture *names* never travel: the kernel reports a segment index and the
# name is read straight out of @!c-names. The values are byte offsets into the
# path, which is why a pure-ASCII path is served with a plain substr and only a
# non-ASCII one pays for a decode.
method !native-match(Str $path, Str $wanted --> List) {
    return ('fallback',) unless @!c-routes.elems;

    if $!stale {
        $!p-segs   = nativecast(Pointer[int32], @!c-segs);
        $!p-routes = nativecast(Pointer[int32], @!c-routes);
        $!p-blob   = nativecast(Pointer[uint8], $!blob);
        $!stale    = False;
    }

    my $pb = str-bytes($path);
    my $rc = http_route_match(
        $!p-segs,   (@!c-segs.elems div 3),
        $!p-routes, (@!c-routes.elems div 4),
        $!p-blob,
        nativecast(Pointer[uint8], $pb),       $pb.elems,
        (%!m-id{$wanted} // -1),
        nativecast(Pointer, $!out),            $!out.elems,
        nativecast(Pointer[uint8], $!scratch), $!scratch.elems,
    );

    return ('fallback',) if $rc < 0;
    return ('miss',)     if $rc == 0;
    return ('405',)      if $rc == 2;

    my $n       = $!out[2];
    my $handler = @!r-handler[$!out[1]];

    return ('hit', $handler, %()) if $n == 0;

    my %params;
    my $ascii = $pb.elems == $path.chars;
    my $i     = 0;

    while $i < $n {
        my $name = @!c-names[$!out[4 + $i * 4 + 0]];
        my $off  = $!out[4 + $i * 4 + 1];
        my $len  = $!out[4 + $i * 4 + 2];
        my $wild = $!out[4 + $i * 4 + 3];

        %params{$name} = $wild ?? $!scratch.subbuf($off, $len).decode('utf-8')
                       !! !$ascii ?? $pb.subbuf($off, $len).decode('utf-8')
                       !! $path.substr($off, $len);
        $i++;
    }

    ('hit', $handler, %params);
}

# Every method registered for a path, used to build the Allow header of a 405.
method allowed-methods(Str $path --> List) {
    my @xs = segments($path);
    my @methods;

    for ^@!r-method.elems -> $i {
        next if @!r-method[$i] eq '*';
        next unless match-segs(@!r-segs[$i], @xs).defined;
        @methods.push: @!r-method[$i];
    }

    @methods.unique.sort.List;
}

# Introspection used by tests and by the server's startup log.
method patterns(--> List) { @!r-pattern.List }
