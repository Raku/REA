[[Raku HarfBuzz Project]](https://harfbuzz-raku.github.io)
 / [[HarfBuzz Module]](https://harfbuzz-raku.github.io/HarfBuzz-raku)
 / [HarfBuzz](https://harfbuzz-raku.github.io/HarfBuzz-raku/HarfBuzz)
 :: [Face](https://harfbuzz-raku.github.io/HarfBuzz-raku/HarfBuzz/Face)

class HarfBuzz::Face
--------------------

A context free HarfBuzz font face

