[[Raku HarfBuzz Project]](https://harfbuzz-raku.github.io)
 / [[HarfBuzz Module]](https://harfbuzz-raku.github.io/HarfBuzz-raku)
 / [HarfBuzz](https://harfbuzz-raku.github.io/HarfBuzz-raku/HarfBuzz)
 :: [Blob](https://harfbuzz-raku.github.io/HarfBuzz-raku/HarfBuzz/Blob)

class HarfBuzz::Blob
--------------------

HarfBuzz representation of a Blob

### method Blob

```raku
method Blob() returns Mu
```

Convert to a Raku Blob

