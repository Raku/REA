[[Raku HarfBuzz Project]](https://harfbuzz-raku.github.io)
 / [[HarfBuzz Module]](https://harfbuzz-raku.github.io/HarfBuzz-raku)
 / [HarfBuzz](https://harfbuzz-raku.github.io/HarfBuzz-raku/HarfBuzz)
 :: [Raw](https://harfbuzz-raku.github.io/HarfBuzz-raku/HarfBuzz/Raw)
 :: [Defs](https://harfbuzz-raku.github.io/HarfBuzz-raku/HarfBuzz/Raw/Defs)

module HarfBuzz::Raw::Defs
--------------------------

Native Enums and constants

