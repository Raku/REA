# HTTP::Server::Async::Plugins::Router::Simple

Provides a simple routing mechanism for the common RESTful HTTP methods.  Please check out the test for more examples.


