use v6.d;
unit module HTTP::RequestTarget::Raw:ver<0.1.0>:api<1>:auth<zef:gbx-raw-af-612aa782bd>;

class Target is export {
    has Str $.raw is required;
    has Str $.form is required;
    has Str $.scheme;
    has Str $.authority;
    has Str $.path;
    has Str $.query;

    method has-query(--> Bool:D) { $!query.defined }
}

class InvalidTarget is Exception is export {
    has Str $.reason is required;

    method message(--> Str:D) { 'Invalid request target: ' ~ $!reason }
}

sub invalid(Str:D $reason --> Nil) {
    InvalidTarget.new(:$reason).throw;
}

# Reg-name characters are structural URI characters, not DNS validation.
# Percent spelling is deliberately not inspected or decoded.
sub valid-host-character(Str:D $char --> Bool:D) {
    my $ord = $char.ord;
    (65 <= $ord <= 90) || (97 <= $ord <= 122) || (48 <= $ord <= 57)
        || q[-._~!$&'()*+,;=%].contains($char)
}

sub check-port(Str:D $port --> Nil) {
    invalid('port must contain decimal digits')
        unless $port ~~ /^ <[0..9]>+ $/;
    invalid('port is outside 0..65535') if $port.Int > 65535;
    Nil
}

sub check-authority(Str:D $authority, Bool:D :$require-port = False --> Nil) {
    invalid('authority must not be empty') unless $authority.chars;
    invalid('userinfo is not allowed') if $authority.contains('@');
    invalid('authority contains a delimiter')
        if $authority.contains('/') || $authority.contains('?') || $authority.contains('#');

    my Str $host;
    my Str $port;
    if $authority.starts-with('[') {
        my $close = $authority.index(']');
        invalid('authority brackets are malformed') unless $close.defined;
        $host = $authority.substr(1, $close - 1);
        invalid('host must not be empty') unless $host.chars;
        invalid('authority brackets are malformed')
            if $host.contains('[') || $host.contains(']');
        for $host.comb -> $char {
            invalid('host contains an invalid character')
                unless $char eq ':' || valid-host-character($char);
        }
        my $suffix = $authority.substr($close + 1);
        if $suffix.chars {
            invalid('authority brackets are malformed') unless $suffix.starts-with(':');
            $port = $suffix.substr(1);
        }
    }
    else {
        invalid('authority brackets are malformed')
            if $authority.contains('[') || $authority.contains(']');
        my $colon = $authority.index(':');
        if $colon.defined {
            $host = $authority.substr(0, $colon);
            $port = $authority.substr($colon + 1);
            invalid('unbracketed host contains multiple colons') if $port.contains(':');
        }
        else {
            $host = $authority;
        }
        invalid('host must not be empty') unless $host.chars;
        for $host.comb -> $char {
            invalid('host contains an invalid character') unless valid-host-character($char);
        }
    }

    invalid('authority form requires a port') if $require-port && !$port.defined;
    check-port($port) if $port.defined;
    Nil
}

sub path-and-query(Str:D $value --> List:D) {
    my $question = $value.index('?');
    $question.defined
        ?? ($value.substr(0, $question), $value.substr($question + 1))
        !! ($value, Str)
}

sub parse-request-target(Str:D $raw --> Target:D) is export {
    invalid('target must not be empty') unless $raw.chars;
    for $raw.ords -> $ord {
        invalid('target must contain visible ASCII only') if $ord < 33 || $ord > 126;
    }
    invalid('fragments are not allowed') if $raw.contains('#');

    return Target.new(:$raw, form => 'asterisk') if $raw eq '*';

    if $raw.starts-with('/') {
        my ($path, $query) = path-and-query($raw);
        return Target.new(:$raw, form => 'origin', :$path, :$query);
    }

    my $prefix = $raw.substr(0, 8).lc;
    if $prefix.starts-with('http://') || $prefix.starts-with('https://') {
        my $separator = $raw.index('://');
        my $scheme = $raw.substr(0, $separator);
        my $remainder = $raw.substr($separator + 3);
        my $end = $remainder.chars;
        for '/', '?' -> $delimiter {
            my $position = $remainder.index($delimiter);
            $end = $position if $position.defined && $position < $end;
        }
        my $authority = $remainder.substr(0, $end);
        check-authority($authority);
        my ($path, $query) = path-and-query($remainder.substr($end));
        return Target.new(:$raw, form => 'absolute', :$scheme, :$authority, :$path, :$query);
    }

    invalid('unsupported URI scheme') if $raw.contains('://');
    check-authority($raw, :require-port);
    Target.new(:$raw, form => 'authority', authority => $raw)
}
