prove -e 'perl6 -Ilib ' t/
