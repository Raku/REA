#!/usr/bin/env sh

test_1_x(){
 assert_within_delta 5 3 2
}
test_2_x(){
 assert_within_delta 5 2 2
}

test_3_x(){
  assert_within_delta 5 3.4 2
}
