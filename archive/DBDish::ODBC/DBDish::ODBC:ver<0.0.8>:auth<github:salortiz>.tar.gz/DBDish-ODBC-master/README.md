# DBDish::ODBC

## Native library notes

Requires ODBC library.  If you believe you have a library installed but
see error messages complaining that it is missing, try the
`DBDISH_ODBC_LIB` environment variable.
