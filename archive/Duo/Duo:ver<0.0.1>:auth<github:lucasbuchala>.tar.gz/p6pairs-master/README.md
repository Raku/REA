
# Duo.pm6

A alternative pair object for the Perl 6 language.

    git clone https://github.com/lucasbuchala/p6pairs.git

    zef install Duo

See the **[manpage](manpage.md)**.
