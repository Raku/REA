# Bugs, known limitations and todo list

## Bugs

## Todo

* Keep information when calculated. User request boolean and username/password/authzid tuple must be kept the same. This saves time.
* Channel binding
* reserved mext or extensions
* use of authentication id authzid
* find out if authzid must be normalized the same way a username needs to be normalized.
