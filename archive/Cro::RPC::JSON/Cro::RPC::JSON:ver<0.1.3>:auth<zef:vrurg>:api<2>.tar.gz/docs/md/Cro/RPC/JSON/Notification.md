NAME
====

`Cro::RPC::JSON::Notification` - container for notifications to be pushed to the client

name1
=====

DESCRIPTION

Only makes sense with WebSocket transport.

SEE ALSO
========

[Cro](https://cro.services)

AUTHOR
======

Vadim Belman <vrurg@cpan.org>

LICENSE
=======

Artistic License 2.0

See the LICENSE file in this distribution.

