CHANGELOG
=========

v0.0.2
------

  * Fix `gist` and `Str` methods to only handle definite cases

  * Improve hanlding of enums by utilizing `WWW::GCloud`-provided `gc-enum` trait

