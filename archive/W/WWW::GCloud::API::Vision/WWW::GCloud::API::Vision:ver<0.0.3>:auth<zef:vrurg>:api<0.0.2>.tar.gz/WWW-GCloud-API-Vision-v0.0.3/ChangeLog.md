# CHANGELOG

  - **v0.0.3**
    
      - Switched over to [`JSON::Class:auth<zef:vrurg>`](https://raku.land/zef:vrurg/JSON::Class) framework

  - **v0.0.2**
    
      - Fix `gist` and `Str` methods to only handle definite cases
    
      - Improve hanlding of enums by utilizing `WWW::GCloud`-provided `gc-enum` trait
