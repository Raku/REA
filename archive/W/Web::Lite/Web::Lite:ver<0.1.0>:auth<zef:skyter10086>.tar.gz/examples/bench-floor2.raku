use lib 'lib';

#| 成本分解之二：把 Cro::HTTP::ResponseSerializer 换成手写极简序列化，
#| 看序列化层到底吃掉多少。其余（Source/RequestParser/Transport）不变。
use Cro::Transform;
use Cro::TCP;
use Cro::HTTP::Request;
use Cro::HTTP::Response;
use Web::Lite::Response;
use Web::Lite::Transport;
use Web::Lite::Transport::Memory;

my $N = %*ENV<BENCH_N> // 3000;
my $mode = %*ENV<SER_MODE> // 'cro';   # cro | lite

class LiteSerializer does Cro::Transform {
    my %reason = 200 => 'OK', 201 => 'Created', 204 => 'No Content',
                 301 => 'Moved Permanently', 302 => 'Found', 304 => 'Not Modified',
                 400 => 'Bad Request', 401 => 'Unauthorized', 403 => 'Forbidden',
                 404 => 'Not Found', 405 => 'Method Not Allowed', 500 => 'Internal Server Error';

    method consumes(--> Cro::HTTP::Message) { Cro::HTTP::Response }
    method produces(--> Cro::TCP::Message) { Cro::TCP::Message }

    method transformer(Supply $responses --> Supply) {
        supply {
            whenever $responses -> $resp {
                my $bp = $resp.body-blob;
                my $payload = sub ($body) {
                    my $status = $resp.status;
                    my $head = "HTTP/1.1 $status %reason{$status} // 'OK'\r\n";
                    my $ctype = $resp.header('Content-Type');
                    $head ~= "Content-Type: $ctype\r\n" if $ctype.defined;
                    $head ~= "Content-Length: {$body.bytes}\r\n\r\n";
                    Cro::TCP::Message.new(:data($head.encode('utf-8') ~ $body));
                };
                if $bp.status ~~ Kept {
                    emit $payload($bp.result);
                }
                else {
                    whenever $bp -> $body { emit $payload($body) }
                }
            }
        }
    }
}

my $json = '{"hi":"bench"}';

class FloorApp does Cro::Transform {
    method consumes(--> Cro::HTTP::Message) { Cro::HTTP::Request }
    method produces(--> Cro::HTTP::Message) { Cro::HTTP::Response }
    method transformer(Supply $requests --> Supply) {
        supply {
            whenever $requests -> $req {
                my $r = make-response(200, 'application/json; charset=utf-8', $json);
                $r.request = $req;
                emit $r;
            }
        }
    }
}

my $listener = MemoryListener.new;
my $ser = $mode eq 'lite' ?? LiteSerializer.new !! Cro::HTTP::ResponseSerializer.new;
my $service = assemble($listener, FloorApp.new, $ser);
$service.start;

{
    my $w = MemorySocket.new;
    $listener.connect($w);
    await Promise.in(0.02);
    $w.feed("GET /hello HTTP/1.1\r\nHost: x\r\n\r\n");
    await Promise.in(0.2);
}

my $sock = MemorySocket.new;
$listener.connect($sock);
await Promise.in(0.03);

my $req = "GET /hello HTTP/1.1\r\nHost: x\r\n\r\n";
my $pipeline = $req x $N - 1 ~ "GET /hello HTTP/1.1\r\nHost: x\r\nConnection: close\r\n\r\n";

my $t0 = now;
$sock.feed($pipeline);
loop {
    last if $mode eq 'lite' ?? ($sock.writes >= $N) !! $sock.closed.status ~~ Kept;
    last if (now - $t0) > 90;
    await Promise.in(0.001);
}
my $dt = now - $t0;

printf "SER mode=%s  throughput=%.0f req/s  per-req=%.1f µs  bytes=%d\n",
    $mode, $N / $dt, $dt * 1_000_000 / $N, $sock.bytes-written;

$service.stop;
