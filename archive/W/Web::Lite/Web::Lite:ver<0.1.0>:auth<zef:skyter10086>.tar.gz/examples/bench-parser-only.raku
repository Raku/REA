use lib 'lib';

#| 纯解析器微基准：不接应用、不接序列化、不走 socket，
#| 只把一份 pipeline 字节流灌进 transformer，看每请求解析成本。
use Cro::TCP;
use Cro::HTTP::RequestParser;
use Web::Lite::Parser;

my $N = (%*ENV<BENCH_N> // 5000).Int;
my $mode = %*ENV<P_MODE> // 'cro';   # cro | lite

my $req = "GET /hello HTTP/1.1\r\nHost: x\r\nContent-Type: application/json\r\n\r\n";
my $pipeline = ($req x $N).encode('iso-8859-1');

my $parser = $mode eq 'lite' ?? LiteParser.new !! Cro::HTTP::RequestParser.new;

my $channel = Channel.new;
my $done = 0;

my $t0 = now;
my $sup = $parser.transformer(supply {
    emit Cro::TCP::Message.new(:data($pipeline));
}).tap(-> $r {
    $done++;
    $channel.send(True) if $done == 1;
});
# 消费端：轮询计数到 N 就停
await Promise.anyof(start {
    while $done < $N { await Promise.in(0.0005); }
}, Promise.in(30));
my $dt = now - $t0;

printf "P_MODE=%-5s requests=%d  elapsed=%.3fs  per-req=%.2f µs\n",
    $mode, $done, $dt, $dt * 1_000_000 / $done;
