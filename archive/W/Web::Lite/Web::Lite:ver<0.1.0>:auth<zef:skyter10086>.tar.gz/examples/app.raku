use lib 'lib';

use Web::Lite;
use Web::Lite::Middleware;

# 最小示例：路由 + 中间件 + 若干接口
my $app = Web::Lite.new: :port(3000), :debug(True);

# 前置：记录开始时间；后置：访问日志 + CORS
$app.use: timing;
$app.after: access-log;
$app.after: cors;

# 首页（HTML）
$app.get: '/', -> $c {
    $c.html('<h1>Web::Lite</h1><p>跑起来了。试试 <a href="/api/ping">/api/ping</a></p>');
};

# 纯 JSON 接口
$app.get: '/api/ping', -> $c {
    $c.json: { pong => True, at => DateTime.now.Str };
};

# 路径参数
$app.get: '/api/users/{id}', -> $c {
    my $id = $c.param('id');
    $c.json: { id => $id.Int, name => "user-{$id}" };
};

# 查询串参数
$app.get: '/api/search', -> $c {
    my $q = $c.query-param('q');
    $c.json: { query => $q, hits => [] };
};

# 读 JSON body
$app.post: '/api/echo', -> $c {
    my $payload = await $c.json-body;
    $c.json: { received => $payload }, status => 201;
};

# 异步接口：await 一个 Promise，期间不阻塞其它请求
$app.get: '/api/slow', -> $c {
    my $p = start { sleep 1; 'slept 1s' };
    $c.json: { result => await $p };
};

# 尾部通配
$app.get: '/static/**', -> $c {
    $c.text("static path: { $c.splat }");
};

# 自定义 404
$app.on-not-found: -> $c {
    $c.json: { error => 'not found', path => $c.path }, status => 404;
};

$app.run;
