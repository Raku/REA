use lib 'lib';

#| 成本分解：同一 MemoryTransport 下，区分"路由+Context+序列化"与"中间件"各自的开销
#| BENCH_MW=0 关中间件；BENCH_HANDLER=json|text
use Web::Lite;
use Web::Lite::Middleware;
use Web::Lite::Response;
use Web::Lite::Transport;
use Web::Lite::Transport::Memory;

my $N = %*ENV<BENCH_N> // 3000;
my $mw = %*ENV<BENCH_MW> // '1';
my $kind = %*ENV<BENCH_HANDLER> // 'json';

my $app = Web::Lite.new;
if $mw eq '1' {
    $app.use: timing;
    $app.after: access-log(:sink(-> $m { }));
}
my $fixed;
if $kind eq 'prebuilt' {
    # 复用同一个 Response 对象：用来剥离"构造 Response"的成本
    $fixed = make-response(200, 'application/json', '{"hi":"bench"}');
    $app.get: '/hello', -> $c { $fixed };
}
elsif $kind eq 'json' {
    $app.get: '/hello', -> $c { $c.json({ hi => 'bench' }) };
}
else {
    $app.get: '/hello', -> $c { $c.text('bench') };
}

my $listener = MemoryListener.new;
my $service = assemble($listener, $app);
$service.start;

{
    my $w = MemorySocket.new;
    $listener.connect($w);
    await Promise.in(0.02);
    $w.feed("GET /hello HTTP/1.1\r\nHost: x\r\n\r\n");
    await Promise.in(0.2);
}

my $sock = MemorySocket.new;
$listener.connect($sock);
await Promise.in(0.03);

my $req = "GET /hello HTTP/1.1\r\nHost: x\r\n\r\n";
my $pipeline = $req x $N - 1 ~ "GET /hello HTTP/1.1\r\nHost: x\r\nConnection: close\r\n\r\n";

my $t0 = now;
$sock.feed($pipeline);

await Promise.anyof($sock.closed, Promise.in(90));
my $dt = now - $t0;

printf "mw=%s handler=%s  requests=%d  elapsed=%.3fs  throughput=%.0f req/s  per-req=%.1f µs\n",
    $mw, $kind, $N, $dt, $N / $dt, $dt * 1_000_000 / $N;

$service.stop;
