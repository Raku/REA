use lib 'lib';

#| 成本分解之四：app 直出字节 + 可选 parser。
#|   P_MODE=cro|lite  -> 比较两个解析器在整链里的真实差距
#| 与 floor2（Cro::HTTP::Response + LiteSerializer）对比可算出 Response 对象与序列化成本。
use Cro::Transform;
use Cro::TCP;
use Cro::HTTP::Request;
use Web::Lite::Transport;
use Web::Lite::Transport::Memory;

my $N = (%*ENV<BENCH_N> // 3000).Int;
my $mode = %*ENV<P_MODE> // 'lite';
my $payload = ("HTTP/1.1 200 OK\r\nContent-Type: application/json; charset=utf-8\r\nContent-Length: 14\r\n\r\n" ~ '{"hi":"bench"}').encode('utf-8');

class PassthroughSerializer does Cro::Transform {
    method consumes(--> Cro::TCP::Message) { Cro::TCP::Message }
    method produces(--> Cro::TCP::Message) { Cro::TCP::Message }
    method transformer(Supply $in --> Supply) {
        supply { whenever $in -> $m { emit $m } }
    }
}

class RawApp does Cro::Transform {
    has Int $.n = 0;
    method consumes(--> Cro::HTTP::Message) { Cro::HTTP::Request }
    method produces(--> Cro::TCP::Message) { Cro::TCP::Message }
    method transformer(Supply $requests --> Supply) {
        supply {
            whenever $requests -> $req {
                emit Cro::TCP::Message.new(:data($payload));
                $!n++;
            }
        }
    }
}

my $listener = MemoryListener.new;
my $service = assemble($listener, RawApp.new, PassthroughSerializer.new,
                       :cro-parser($mode eq 'cro'));
$service.start;

{
    my $w = MemorySocket.new;
    $listener.connect($w);
    await Promise.in(0.02);
    $w.feed("GET /hello HTTP/1.1\r\nHost: x\r\n\r\n");
    await Promise.in(0.2);
}

my $sock = MemorySocket.new;
$listener.connect($sock);
await Promise.in(0.03);

my $req = "GET /hello HTTP/1.1\r\nHost: x\r\n\r\n";
my $pipeline = $req x ($N - 1) ~ "GET /hello HTTP/1.1\r\nHost: x\r\nConnection: close\r\n\r\n";

my $expect = $N * $payload.elems;
my $t0 = now;
$sock.feed($pipeline);
loop {
    last if $sock.bytes-written >= $expect;
    last if (now - $t0) > 60;
    await Promise.in(0.001);
}
my $dt = now - $t0;

printf "P_MODE=%-4s +PASSTHROUGH  throughput=%.0f req/s  per-req=%.1f µs  bytes=%d\n",
    $mode, $N / $dt, $dt * 1_000_000 / $N, $sock.bytes-written;

$service.stop;
