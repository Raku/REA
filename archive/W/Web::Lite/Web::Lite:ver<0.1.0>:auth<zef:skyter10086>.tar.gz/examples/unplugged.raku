use lib 'lib';

#| 示例：不用 Cro::HTTP::Server，自己拼 pipeline + 自己的监听器。
#| 这就是将来接自研 C 内核的位置——把 RawListener 换成「C 层 accept 回调」版即可。
use Web::Lite;
use Web::Lite::Middleware;
use Web::Lite::Transport;

my $app = Web::Lite.new;
$app.use: timing;
$app.after: access-log;
$app.get: '/', -> $c { $c.html('<h1>unplugged</h1><p>没有 Cro::HTTP::Server 参与</p>') };
$app.get: '/api/ping', -> $c { $c.json({ pong => True, at => DateTime.now.Str }) };
$app.get: '/api/users/{id}', -> $c { $c.json({ id => $c.param('id').Int }) };

my $service = assemble(RawListener.new(:host('127.0.0.1'), :port(3000)), $app);
$service.start;
note 'Web::Lite 裸管道已启动：http://127.0.0.1:3000 （Cro::HTTP::Server 未参与）';

react {
    whenever signal(SIGINT) {
        $service.stop;
        done
    }
}
