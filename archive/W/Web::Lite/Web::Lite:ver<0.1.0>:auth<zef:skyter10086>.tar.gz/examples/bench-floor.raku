use lib 'lib';

#| 成本下限对照组：同样一条 Cro 皮 + MemoryTransport，但路由层几乎为零
#| MODE=reuse 复用同一个 Response 对象；MODE=build 每请求新建（含 JSON 序列化）
use Cro::Transform;
use Cro::HTTP::Request;
use Cro::HTTP::Response;
use Web::Lite::Response;
use Web::Lite::Transport;
use Web::Lite::Transport::Memory;

my $N = %*ENV<BENCH_N> // 3000;
my $mode = %*ENV<FLOOR_MODE> // 'reuse';

my $json = '{"hi":"bench"}';
my $shared = make-response(200, 'application/json; charset=utf-8', $json);

class FloorApp does Cro::Transform {
    method consumes(--> Cro::HTTP::Message) { Cro::HTTP::Request }
    method produces(--> Cro::HTTP::Message) { Cro::HTTP::Response }
    method transformer(Supply $requests --> Supply) {
        supply {
            whenever $requests -> $req {
                if $mode eq 'reuse' {
                    emit $shared;
                }
                else {
                    my $r = make-response(200, 'application/json; charset=utf-8', $json);
                    $r.request = $req;
                    emit $r;
                }
            }
        }
    }
}

my $listener = MemoryListener.new;
my $service = assemble($listener, FloorApp.new);
$service.start;

{
    my $w = MemorySocket.new;
    $listener.connect($w);
    await Promise.in(0.02);
    $w.feed("GET /hello HTTP/1.1\r\nHost: x\r\n\r\n");
    await Promise.in(0.2);
}

my $sock = MemorySocket.new;
$listener.connect($sock);
await Promise.in(0.03);

my $req = "GET /hello HTTP/1.1\r\nHost: x\r\n\r\n";
my $pipeline = $req x $N - 1 ~ "GET /hello HTTP/1.1\r\nHost: x\r\nConnection: close\r\n\r\n";

my $t0 = now;
$sock.feed($pipeline);

await Promise.anyof($sock.closed, Promise.in(90));
my $dt = now - $t0;

printf "FLOOR mode=%s  throughput=%.0f req/s  per-req=%.1f µs\n",
    $mode, $N / $dt, $dt * 1_000_000 / $N;

$service.stop;
