use lib 'lib';

#| 成本分解之三：app 直接输出字节（Cro::TCP::Message），完全跳过 Response 与序列化，
#| 只保留 Cro 的 RequestParser + 传输层。与 floor(build) 对比即可算出序列化层成本。
use Cro::Transform;
use Cro::TCP;
use Cro::HTTP::Request;
use Web::Lite::Transport;
use Web::Lite::Transport::Memory;

my $N = %*ENV<BENCH_N> // 3000;
my $payload = ("HTTP/1.1 200 OK\r\nContent-Type: application/json; charset=utf-8\r\nContent-Length: 14\r\n\r\n" ~ '{"hi":"bench"}').encode('utf-8');

class PassthroughSerializer does Cro::Transform {
    method consumes(--> Cro::TCP::Message) { Cro::TCP::Message }
    method produces(--> Cro::TCP::Message) { Cro::TCP::Message }
    method transformer(Supply $in --> Supply) {
        supply { whenever $in -> $m { emit $m } }
    }
}

class RawApp does Cro::Transform {
    method consumes(--> Cro::HTTP::Message) { Cro::HTTP::Request }
    method produces(--> Cro::TCP::Message) { Cro::TCP::Message }
    method transformer(Supply $requests --> Supply) {
        my $n = 0;
        supply {
            whenever $requests -> $req {
                emit Cro::TCP::Message.new(:data($payload));
                $n++;
                done if $n >= $N;
            }
        }
    }
}

my $listener = MemoryListener.new;
my $service = assemble($listener, RawApp.new, PassthroughSerializer.new);
$service.start;

{
    my $w = MemorySocket.new;
    $listener.connect($w);
    await Promise.in(0.02);
    $w.feed("GET /hello HTTP/1.1\r\nHost: x\r\n\r\n");
    await Promise.in(0.2);
}

my $sock = MemorySocket.new;
$listener.connect($sock);
await Promise.in(0.03);

my $req = "GET /hello HTTP/1.1\r\nHost: x\r\n\r\n";
my $pipeline = $req x $N - 1 ~ "GET /hello HTTP/1.1\r\nHost: x\r\nConnection: close\r\n\r\n";

my $t0 = now;
$sock.feed($pipeline);
await Promise.anyof($sock.closed, Promise.in(90));
my $dt = now - $t0;

printf "PARSER-ONLY  throughput=%.0f req/s  per-req=%.1f µs  bytes=%d\n",
    $N / $dt, $dt * 1_000_000 / $N, $sock.bytes-written;

$service.stop;
