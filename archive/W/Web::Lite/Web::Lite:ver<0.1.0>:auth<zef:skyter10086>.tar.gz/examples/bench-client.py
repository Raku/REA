"""最小 HTTP/1.1 keep-alive 压测客户端（异步，多连接）"""
import asyncio, sys, time, statistics

HOST = '127.0.0.1'
PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 31991
CONNS = int(sys.argv[2]) if len(sys.argv) > 2 else 32
SECS = float(sys.argv[3]) if len(sys.argv) > 3 else 5.0
REQ = b"GET /hello HTTP/1.1\r\nHost: x\r\n\r\n"


async def worker(stop_at):
    lat = []
    n = 0
    r, w = await asyncio.open_connection(HOST, PORT)
    while time.perf_counter() < stop_at:
        t0 = time.perf_counter()
        w.write(REQ)
        await w.drain()
        hdr = await r.readuntil(b"\r\n\r\n")
        cl = 0
        for line in hdr.split(b"\r\n"):
            if line.lower().startswith(b"content-length:"):
                cl = int(line.split(b":", 1)[1])
        if cl:
            await r.readexactly(cl)
        lat.append((time.perf_counter() - t0) * 1000)
        n += 1
    w.close()
    return n, lat


async def main():
    # 预热
    warm = await asyncio.gather(*[worker(time.perf_counter() + 0.8) for _ in range(CONNS)])
    t0 = time.perf_counter()
    stop_at = t0 + SECS
    res = await asyncio.gather(*[worker(stop_at) for _ in range(CONNS)])
    dt = time.perf_counter() - t0
    total = sum(r[0] for r in res)
    lat = [x for r in res for x in r[1]]
    lat.sort()
    p = lambda q: lat[min(len(lat) - 1, int(len(lat) * q))]
    print(f"conns      : {CONNS}")
    print(f"requests   : {total} in {dt:.2f}s")
    print(f"throughput : {total / dt:.0f} req/s")
    print(f"p50        : {p(0.50):.2f} ms")
    print(f"p99        : {p(0.99):.2f} ms")
    print(f"mean       : {statistics.mean(lat):.2f} ms")


asyncio.run(main())
