use lib 'lib';

#| 阶段 0 性能基线：同样一条 Cro 皮，纯内存喂字节，测每请求 CPU 成本
#| （不含 socket 系统调用与网络 RTT，只反映 Cro 皮 + Web::Lite + 序列化开销）
use Web::Lite;
use Web::Lite::Middleware;
use Web::Lite::Transport;
use Web::Lite::Transport::Memory;

my $N = %*ENV<BENCH_N> // 2000;

my $app = Web::Lite.new;
$app.use: timing;
$app.after: access-log(:sink(-> $m { }));
$app.get: '/hello', -> $c { $c.json({ hi => 'bench' }) };

my $listener = MemoryListener.new;
my $service = assemble($listener, $app);
$service.start;

# 预热
{
    my $w = MemorySocket.new;
    $listener.connect($w);
    await Promise.in(0.02);
    $w.feed("GET /hello HTTP/1.1\r\nHost: x\r\n\r\n");
    await Promise.in(0.2);
}

my $sock = MemorySocket.new;
$listener.connect($sock);
await Promise.in(0.03);

my $req = "GET /hello HTTP/1.1\r\nHost: x\r\n\r\n";
my $pipeline = $req x $N - 1 ~ "GET /hello HTTP/1.1\r\nHost: x\r\nConnection: close\r\n\r\n";

my $t0 = now;
$sock.feed($pipeline);

# 轮询直到全部响应写完（粗粒度 5ms 轮询，只影响结束判定，不影响管道自身耗时）
await Promise.anyof($sock.closed, Promise.in(60));
my $dt = now - $t0;

my $bytes = $sock.bytes-written;
printf "requests   : %d\n", $N;
printf "elapsed    : %.3f s\n", $dt;
printf "throughput : %.0f req/s (单连接串行，无 RTT)\n", $N / $dt;
printf "per-req    : %.1f µs\n", $dt * 1_000_000 / $N;
printf "resp bytes : %d B (%.1f B/req)\n", $bytes, $bytes / $N;

$service.stop;
