use lib 'lib';

# 对照服务：MODE=raw 走裸管道，MODE=cro 走官方 Cro::HTTP::Server
use Web::Lite;
use Web::Lite::Transport;

my $mode = %*ENV<MODE> // 'raw';
my $port = (%*ENV<PORT> // 31991).Int;

my $app = Web::Lite.new;
$app.get: '/hello', -> $c { $c.text('ok') };

if $mode eq 'raw' {
    my $svc = assemble(RawListener.new(:host('127.0.0.1'), :$port), $app);
    $svc.start;
    note "MODE=raw on $port";
    react { whenever signal(SIGINT) { $svc.stop; done } }
} else {
    my $srv = $app.start(:host('127.0.0.1'), :$port);
    note "MODE=cro on $port";
    react { whenever signal(SIGINT) { $srv.stop; done } }
}
