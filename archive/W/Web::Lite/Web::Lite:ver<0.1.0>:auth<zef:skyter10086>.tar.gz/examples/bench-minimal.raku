use lib 'lib';

#| 定位成本归属：把 Web::Lite 换成「最裸的 Cro::Transform」，
#| 只保留 RequestParser + ResponseSerializer，看 Cro 皮自身还剩多少
use Cro::Transform;
use Cro::HTTP::Request;
use Cro::HTTP::Response;
use Web::Lite::Transport;
use Web::Lite::Transport::Memory;

my $N = (%*ENV<BENCH_N> // 3000).Int;

class Mini does Cro::Transform {
    method consumes() { Cro::HTTP::Request }
    method produces() { Cro::HTTP::Response }
    method transformer(Supply $reqs --> Supply) {
        supply {
            whenever $reqs -> $r {
                my $resp = Cro::HTTP::Response.new(status => 200, body => 'ok',
                    content-type => 'text/plain');
                $resp.request = $r;
                emit $resp;
            }
        }
    }
}

my $listener = MemoryListener.new;
my $service = assemble($listener, Mini.new);
$service.start;

{
    my $w = MemorySocket.new;
    $listener.connect($w);
    await Promise.in(0.02);
    $w.feed("GET /hello HTTP/1.1\r\nHost: x\r\n\r\n");
    await Promise.in(0.2);
}

my $sock = MemorySocket.new;
$listener.connect($sock);
await Promise.in(0.03);

my $pipeline = ("GET /hello HTTP/1.1\r\nHost: x\r\n\r\n" x $N - 1)
    ~ "GET /hello HTTP/1.1\r\nHost: x\r\nConnection: close\r\n\r\n";

my $t0 = now;
$sock.feed($pipeline);
loop {
    last if $sock.output.comb('HTTP/1.1 ').elems >= $N;
    last if (now - $t0) > 60;
    await Promise.in(0.005);
}
my $dt = now - $t0;

printf "minimal-transform : %d reqs in %.3fs => %.0f req/s, %.1f µs/req\n",
    $N, $dt, $N / $dt, $dt * 1_000_000 / $N;

$service.stop;
