use lib 'lib';

#| 剥离测量：把中间件、JSON 都去掉，只留 Route 匹配 + 固定文本响应
#| 用来看「Cro 皮本身」的每请求成本有多少
use Web::Lite;
use Web::Lite::Transport;
use Web::Lite::Transport::Memory;

my $N = %*ENV<BENCH_N> // 2000;

my $app = Web::Lite.new;
$app.get: '/hello', -> $c { $c.text('ok') };

my $listener = MemoryListener.new;
my $service = assemble($listener, $app);
$service.start;

{
    my $w = MemorySocket.new;
    $listener.connect($w);
    await Promise.in(0.02);
    $w.feed("GET /hello HTTP/1.1\r\nHost: x\r\n\r\n");
    await Promise.in(0.2);
}

my $sock = MemorySocket.new;
$listener.connect($sock);
await Promise.in(0.03);

my $pipeline = ("GET /hello HTTP/1.1\r\nHost: x\r\n\r\n" x $N - 1)
    ~ "GET /hello HTTP/1.1\r\nHost: x\r\nConnection: close\r\n\r\n";

my $t0 = now;
$sock.feed($pipeline);
loop {
    last if $sock.output.comb('HTTP/1.1 ').elems >= $N;
    last if (now - $t0) > 60;
    await Promise.in(0.005);
}
my $dt = now - $t0;

printf "requests   : %d\n", $N;
printf "elapsed    : %.3f s\n", $dt;
printf "throughput : %.0f req/s\n", $N / $dt;
printf "per-req    : %.1f µs\n", $dt * 1_000_000 / $N;

$service.stop;
