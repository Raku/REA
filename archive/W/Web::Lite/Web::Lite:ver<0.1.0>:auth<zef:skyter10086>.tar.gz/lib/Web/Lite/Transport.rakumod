#| 传输层可插拔验证：不经过 Cro::HTTP::Server，自己装配 pipeline。
#|
#| Cro 对传输层的要求其实只有三条契约：
#|   1. Source.incoming  —— 每来一个连接就 emit 一个 connection 对象
#|   2. Connection.incoming —— 从该连接读出字节，emit Cro::TCP::Message(:data)
#|   3. Connection.replier  —— 一个 Cro::Sink，接收 Cro::TCP::Message 并把
#|                              $.data 写回对端，管道关闭时收尾
#| 只要对象鸭式具备 Supply(:bin)/write/close 三个方法，管道不关心 bottom 是
#| IO::Socket::Async 还是 C 库回调。这就是将来接自研内核的接缝。
unit module Web::Lite::Transport;

use Cro;
use Cro::Service;
use Cro::Source;
use Cro::Sink;
use Cro::Connection;
use Cro::Replyable;
use Cro::TCP;
use Cro::HTTP::RequestParser;
use Cro::HTTP::ResponseSerializer;
use Web::Lite::Serializer;
use Web::Lite::Parser;

#| 把「任意 Source」和「应用」拼成一条可 start/stop 的服务管道
#| $parser / $serializer 均可替换：
#|   - parser 默认 LiteParser（自研精简解析器），:cro-parser 回退 Cro 官方实现
#|   - serializer 默认 LiteSerializer，:cro-serializer 回退 Cro 官方实现
sub assemble(Cro::Source $source, $app, $serializer?, $parser?,
             Bool :$cro-serializer = False, Bool :$cro-parser = False
             --> Cro::Service) is export {
    my $ser = $serializer
        // ($cro-serializer ?? Cro::HTTP::ResponseSerializer.new !! LiteSerializer.new);
    my $par = $parser
        // ($cro-parser ?? Cro::HTTP::RequestParser.new !! LiteParser.new);
    Cro.compose(
        service-type => Cro::Service,
        $source,
        $par,
        $app,
        $ser,
    );
}

#| 把序列化后的字节写回 socket；这是 Cro 侧唯一的「出口」
class RawReplier does Cro::Sink {
    has $!sock;

    submethod BUILD(:$!sock) { }

    method consumes() { Cro::TCP::Message }

    method sinker(Supply:D $pipeline) returns Supply:D {
        supply {
            whenever $pipeline -> Cro::TCP::Message $msg {
                # 不 await 写入完成：每条请求都为一个 write Promise 建 supply 上下文
                # 约 40~50 us，小响应下得不偿失。IO::Socket::Async.write 自身按调用
                # 顺序排队，且底层缓冲区负责背压，故这里丢弃返回值是安全的。
                $!sock.write($msg.data);
            }
            CLOSE $!sock.close;
        }
    }
}

#| 一个连接 = 一路字节流 + 一个回写口；不关心 $!sock 是谁
class RawConnection does Cro::Connection does Cro::Replyable is export {
    has $!sock;
    has $.replier;
    #| 连接结束（对端关闭 / pipeline 被关）时回调，供监听器做连接计数
    has $!on-close;

    submethod BUILD(:$!sock, :$on-close) {
        $!replier = RawReplier.new(:$!sock);
        $!on-close = $on-close;
    }

    method produces() { Cro::TCP::Message }

    method incoming() {
        supply {
            whenever $!sock.Supply(:bin) -> $data {
                emit Cro::TCP::Message.new(:$data);
            }
            # CLOSE 在对端关闭、或下游提前 done（如 Connection: close）时都会走，
            # 是唯一可靠的「这条连接没了」时机
            CLOSE {
                $!on-close.() with $!on-close;
            }
        }
    }
}

#| 监听器替代品：用 IO::Socket::Async.listen 收连接（阶段 0 里的「假 Source」）
class RawListener does Cro::Source is export {
    has Str $.host = '127.0.0.1';
    has Int $.port is required;
    has $!listener;

    #| 关闭流程的状态：$!accepting 为假后新连接一律立即关掉
    has Bool $!accepting = True;
    #| 存活连接表：id => socket，优雅关闭靠它判断「排空了没有」
    has %!conns;
    has int $!seq = 0;
    has Lock $!lock .= new;

    method produces() { RawConnection }

    method incoming() {
        supply {
            $!listener = IO::Socket::Async.listen($!host, $!port);
            whenever $!listener -> $sock {
                unless $!accepting {
                    # 排空期到达的连接：直接关，不给应用层
                    try $sock.close;
                    next;
                }
                my $id = $!lock.protect: { ++$!seq };
                $!lock.protect: { %!conns{$id} = $sock };
                emit RawConnection.new(:$sock, on-close => -> {
                    $!lock.protect: { %!conns{$id}:delete };
                });
            }
        }
    }

    #| 当前存活连接数（优雅关闭的排空判据）
    method connection-count(--> Int) {
        $!lock.protect: { %!conns.elems }
    }

    #| 停止接收新连接：关掉监听 supply 即可，已建立的连接不受影响
    method stop-accepting(--> Nil) {
        $!accepting = False;
        with $!listener {
            try .close;
            $!listener = Nil;
        }
        Nil
    }

    #| 强制断开所有存活连接（宽限期用完时的兜底）
    method close-connections(--> Nil) {
        my @socks = $!lock.protect: { %!conns.values.List };
        $!lock.protect: { %!conns = () };
        for @socks { try .close }
        Nil
    }

    #| Cro::Service 逆序 stop 时调用：不再接新连接，并释放监听端口与已有连接
    method stop() {
        self.stop-accepting;
        self.close-connections;
        Nil
    }
}
