#| 纯内存传输层：完全没有 socket、没有端口、没有网络栈。
#| 用途有两个：CI 里稳定跑「裸 pipeline」测试；以及当压测/验证自研内核时，
#| 用它当参照系（同样的 Cro 皮，字节进、字节出）。
unit module Web::Lite::Transport::Memory;

use Cro::Source;
use Web::Lite::Transport;

#| 只实现 transport 契约要求的三件事：读 Supply、写、关
class MemorySocket is export {
    has Supplier $!in .= new;
    has @!out;
    has int $!written = 0;
    has int $!writes = 0;
    has Promise $!closed-promise = Promise.new;

    method Supply(:$bin) { $!in.Supply }

    method write($buf) { @!out.push: $buf; $!written += $buf.bytes; $!writes++; Promise.kept }

    method close() { try $!in.done; $!closed-promise.keep(True) unless $!closed-promise.status ~~ Kept; Nil }

    #| 连接关闭信号：bench 用它判定"所有响应已写完"，避免轮询拼接字符串污染计时
    method closed(--> Promise) { $!closed-promise }

    #|--- 测试侧 ---------------------------------------------------------
    method feed(Str $raw) { $!in.emit($raw.encode('utf-8')); Nil }

    method feed-blob(Blob $bytes) { $!in.emit($bytes); Nil }

    method output(--> Str) { [~] @!out.map(*.decode('utf-8')) }

    method bytes-written(--> Int) { $!written }

    #| write 调用次数：一个响应写一次，用于 bench 精确判定完成
    method writes(--> Int) { $!writes }

    method responses(--> List) {
        # 按 "HTTP/" 切开，粗略数响应条数
        self.output.split('HTTP/1.').grep({ .chars }).List;
    }
}

#| 手工喂连接的 Source：谁来连由测试代码决定
class MemoryListener does Cro::Source is export {
    has Supplier $!conns .= new;

    method produces() { RawConnection }

    method incoming() { $!conns.Supply }

    method connect($sock) { $!conns.emit(RawConnection.new(:$sock)); Nil }
}

#| 一次「无网络请求」：返回写出的原始字节文本
sub http-roundtrip(MemoryListener $listener, Str $raw, :$split = 0, :$wait = 0.25 --> Str) is export {
    my $sock = MemorySocket.new;
    $listener.connect($sock);
    await Promise.in(0.02);
    if $split > 0 && $split < $raw.chars {
        $sock.feed($raw.substr(0, $split));
        await Promise.in(0.05);
        $sock.feed($raw.substr($split));
    } else {
        $sock.feed($raw);
    }
    await Promise.in($wait);
    $sock.output;
}
