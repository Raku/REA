unit class Web::Lite::Route;

#| 一条路由记录：方法 + 路径模式 + 处理函数
has Str $.method is required;
has Str $.pattern is required;
has &.handler is required;
has $.name;  # 命名路由（可选）

has @.segments;

submethod TWEAK() {
    @!segments = $!pattern.split('/').grep(*.chars).list;
}

#| 路径段的 percent-decode（%XX -> 字节 -> UTF-8）。
#| 只处理 %XX，不处理 '+'：'+' 在 query 里才是空格，路径里是字面加号。
#| 用 our 暴露出去：Context 的 query 解码复用同一实现，避免两套解码行为不一致。
#| 单个十六进制字节 -> 数值；非 hex 返回 Int（未定义）
our sub hexval(Int $b --> Int) {
    return $b - 0x30 if $b >= 0x30 && $b <= 0x39;
    return $b - 0x61 + 10 if $b >= 0x61 && $b <= 0x66;
    return $b - 0x41 + 10 if $b >= 0x41 && $b <= 0x46;
    Int;
}

our sub pct-decode(Str $s --> Str) {
    return $s unless $s.contains('%');
    my $in = $s.encode('utf-8');
    my Buf $out .= new;
    my $i = 0;
    my $n = $in.elems;
    while $i < $n {
        my $b = $in[$i];
        if $b == 0x25 && $i + 2 < $n {
            my $hi = hexval($in[$i + 1]);
            my $lo = hexval($in[$i + 2]);
            if $hi.defined && $lo.defined {
                $out.push($hi * 16 + $lo);
                $i += 3;
                next;
            }
        }
        $out.push($b);
        $i++;
    }
    $out.decode('utf-8');
}

#| 路径段的百分号编码：只放行 unreserved（A-Z a-z 0-9 - . _ ~），
#| 其余按 UTF-8 字节逐字节 %XX。刻意不编码 '/'，调用方按段传值即可。
our sub pct-encode(Str $s --> Str) {
    my Buf $out .= new;
    for $s.encode('utf-8').list -> $b {
        my Bool $safe = ($b >= 0x30 && $b <= 0x39) || ($b >= 0x41 && $b <= 0x5A)
            || ($b >= 0x61 && $b <= 0x7A)
            || $b == 0x2D || $b == 0x2E || $b == 0x5F || $b == 0x7E;
        if $safe {
            $out.push($b);
        }
        else {
            $out.push($_) for ('%' ~ sprintf('%02X', $b)).encode('ascii').list;
        }
    }
    $out.decode('ascii');
}

#| 把路由模式反向填成 URL：'/user/{id}' + { id => 5 } => '/user/5'。
#| `*` 按出现顺序消费 _splat（List 或单个值），`**` 吃掉剩下的全部。
#| 缺参数直接 die —— 拼出半个 URL 让请求 404 更难查。
our sub fill-pattern(Str $pattern, %params --> Str) {
    my @out;
    my $splat = %params<_splat>;
    my @rest = $splat ~~ Positional ?? $splat.List !! ($splat.defined ?? ($splat,) !! ());

    for $pattern.split('/') -> $seg is copy {
        next unless $seg.chars;
        if $seg.starts-with('{') && $seg.ends-with('}') {
            my Str $key = $seg.substr(1, $seg.chars - 2);
            my $v = %params{$key};
            die X::AdHoc.new(
                payload => "url-for: 模式 {$pattern} 缺少参数 '{$key}'"
            ) unless $v.defined;
            @out.push: pct-encode($v.Str);
        }
        elsif $seg eq '*' {
            die X::AdHoc.new(payload => "url-for: 模式 {$pattern} 的 * 缺少 _splat")
                unless @rest.elems;
            @out.push: pct-encode(@rest.shift.Str);
        }
        elsif $seg eq '**' {
            @out.push: @rest.map({ pct-encode($_.Str) }).join('/');
            @rest = ();
        }
        else {
            @out.push: $seg;
        }
    }

    my Str $tail = @out.join('/');
    $pattern.starts-with('/') ?? '/' ~ $tail !! $tail;
}

#| 用路径段尝试匹配。命中返回参数 Hash（可能为空），未命中返回 Nil。
#| 支持三种段：字面量、{name} 单段参数、* 单段通配；** 为尾段通配。
method match(@path) {
    my @pat = @!segments;
    my %params;
    my @splat;

    my $pi = 0;
    while $pi < @pat.elems {
        my $seg = @pat[$pi];

        if $seg eq '**' {
            # 尾段通配：剩余路径全部塞进 _splat。
            # 必须逐段 pct-decode，否则 %2e%2e 这类编码穿越会绕过下游的 '..' 检查。
            %params<_splat> = @path[$pi .. *-1].map({ pct-decode($_) }).join('/');
            return %params;
        }

        my $val = @path[$pi];
        return Nil without $val;

        if $seg eq '*' {
            # 单段通配：吃掉一段，收集到 _splat
            return Nil if $val eq '';
            @splat.push: pct-decode($val);
        }
        elsif $seg.starts-with('{') && $seg.ends-with('}') {
            my $key = $seg.substr(1, $seg.chars - 2);
            return Nil if $val eq '';
            %params{$key} = pct-decode($val);
        }
        elsif $seg ne pct-decode($val) {
            return Nil;
        }
        $pi++;
    }

    return Nil unless @path.elems == @pat.elems;
    %params<_splat> = @splat.join('/') if @splat;
    return %params;
}

method gist(--> Str) {
    "{ $!method } { $!pattern }";
}
