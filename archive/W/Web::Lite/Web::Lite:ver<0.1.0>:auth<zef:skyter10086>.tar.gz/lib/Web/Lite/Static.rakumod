#| 静态文件响应：MIME 推断、条件请求（304）、send_file 与静态目录挂载。
#|
#| 定位是「够用」而不是「像 nginx」：
#|   - 一次性把文件读进内存再发，不做 sendfile / 分块流式。中小静态资源足够，
#|     大文件（视频）请自行换 Cro 的 static 中间件。默认 32MB 上限兜住误操作。
#|   - ETag 用弱校验（大小 + mtime 秒），不读内容算哈希，省一次全文件扫描。
#|   - 不做 Range / 206，断点续传不在本框架目标里。
unit module Web::Lite::Static;

use Web::Lite::Response;
use Web::Lite::Serializer;   # format-http-date

#| 扩展名 -> MIME。只收常见项，其余按 application/octet-stream 处理。
my constant %MIME =
    css   => 'text/css; charset=utf-8',
    js    => 'text/javascript; charset=utf-8',
    mjs   => 'text/javascript; charset=utf-8',
    json  => 'application/json; charset=utf-8',
    map   => 'application/json; charset=utf-8',
    html  => 'text/html; charset=utf-8',
    htm   => 'text/html; charset=utf-8',
    txt   => 'text/plain; charset=utf-8',
    md    => 'text/plain; charset=utf-8',
    csv   => 'text/csv; charset=utf-8',
    xml   => 'application/xml; charset=utf-8',
    svg   => 'image/svg+xml',
    png   => 'image/png',
    jpg   => 'image/jpeg',
    jpeg  => 'image/jpeg',
    gif   => 'image/gif',
    webp  => 'image/webp',
    avif  => 'image/avif',
    ico   => 'image/x-icon',
    woff  => 'font/woff',
    woff2 => 'font/woff2',
    ttf   => 'font/ttf',
    otf   => 'font/otf',
    eot   => 'application/vnd.ms-fontobject',
    pdf   => 'application/pdf',
    zip   => 'application/zip',
    gz    => 'application/gzip',
    wasm  => 'application/wasm',
    mp4   => 'video/mp4',
    webm  => 'video/webm',
    mp3   => 'audio/mpeg',
    wav   => 'audio/wav';

#| 按扩展名推 MIME，推不出按二进制流
our sub mime-type(Str $path --> Str) is export {
    my $ext = $path.IO.extension;
    return 'application/octet-stream' unless $ext.defined && $ext.chars;
    %MIME{$ext.lc} // 'application/octet-stream';
}

#| 弱 ETag：大小 + mtime 秒。改动必然导致二者之一变化，够挡住浏览器重复下载。
sub weak-etag(IO::Path $f --> Str) {
    'W/"' ~ $f.s ~ '-' ~ $f.modified.Instant.Int ~ '"';
}

#| 条件请求检查：命中则调用方回 304，不必读文件
sub not-modified(IO::Path $f, Str $etag, $request --> Bool) {
    return False unless $request.defined;
    my $inm = try { $request.header('If-None-Match') };
    return True if $inm.defined && ($inm eq $etag || $inm eq '*');
    my $ims = try { $request.header('If-Modified-Since') };
    if $ims.defined {
        my $since = try { DateTime.new($ims) };
        # HTTP-date 精度只到秒，比较时把 mtime 也压到秒
        return True if $since.defined && $f.modified.Instant.Int <= $since.Instant.Int;
    }
    False;
}

#| 把一个文件做成响应。
#|   :$download-name 给定时加 Content-Disposition: attachment（触发浏览器下载）
#|   :$max-file-bytes 超过就 500，而不是默默把内存吃光
our sub send-file-response(
    IO::Path $file,
    Str :$content-type,
    Str :$download-name,
    :$request,
    Bool :$cache = True,
    Int :$max-file-bytes = 32 * 1024 * 1024,
    --> LiteResponse
) is export {
    unless $file.e {
        return make-response(404, 'text/plain; charset=utf-8', 'Not Found');
    }
    if $file.d {
        return make-response(404, 'text/plain; charset=utf-8', 'Not Found');
    }

    my $size = $file.s;
    if $size > $max-file-bytes {
        return make-response(500, 'text/plain; charset=utf-8',
            "File too large for send-file ({$size} bytes > {$max-file-bytes}).");
    }

    my Str $etag = weak-etag($file);
    my Str $last-modified = format-http-date($file.modified.DateTime);
    my Str $ct = $content-type // mime-type($file.basename);

    if $cache && not-modified($file, $etag, $request) {
        my $r = make-empty-response(304);
        $r.append-header('ETag', $etag);
        $r.append-header('Last-Modified', $last-modified);
        return $r;
    }

    my $blob = $file.slurp(:bin);
    my $r = LiteResponse.new(:status(200));
    $r.append-header('Content-Type', $ct);
    $r.append-header('ETag', $etag);
    $r.append-header('Last-Modified', $last-modified);
    $r.append-header('Accept-Ranges', 'none');
    $r.append-header('Cache-Control', 'no-cache') unless $cache;
    if $download-name.defined && $download-name.chars {
        # 文件名里的引号与换行会破坏头结构，一律剔除
        my Str $safe = $download-name.subst(/<["\r\n\\]>/ , '', :g);
        # Cro 的头值必须是 ASCII，中文名走 RFC 5987 的 filename*，
        # 同时给一个 ASCII 兜底 filename="..." 照顾老客户端。
        my Str $ascii = $safe.subst(/<-[\x20..\x7E]>/, '_', :g);
        my Str $pct = $safe.encode('utf-8').list.map(-> $b {
            (($b >= 0x30 && $b <= 0x39) || ($b >= 0x41 && $b <= 0x5A)
             || ($b >= 0x61 && $b <= 0x7A)
             || $b == 0x2E || $b == 0x2D || $b == 0x5F)
                ?? $b.chr !! sprintf('%%%02X', $b);
        }).join;
        $r.append-header('Content-Disposition',
            'attachment; filename="' ~ $ascii ~ q{; filename*=UTF-8''} ~ $pct);
    }
    $r.set-body($blob);
    $r.set-lite-body($blob);
    $r;
}

#| 生成一个静态目录的 handler，挂到某条 `**` 路由上。
#|
#| 安全要点：`**` 捕获的每一段都已经过百分号解码，`%2e%2e` 在这里已经是 `..`，
#| 所以逐段检查能拦住所有穿越写法；最后再把绝对路径前缀比一遍做双保险。
our sub static-handler(
    IO::Path $root,
    Bool :$cache = True,
    Int :$max-file-bytes = 32 * 1024 * 1024,
    --> Callable
) is export {
    my Str $base = $root.absolute;
    # 用 sub 而不是 -> {}：块里的 return 在 Raku 里会报
    # "Attempt to return outside of any Routine"，匿名 sub 才允许提前返回。
    sub ($c) {
        my Str $rel = $c.splat // '';
        my @segs = $rel.split('/').grep({ .chars });
        if @segs.first({ $_ eq '..' || $_ eq '.' }) {
            return $c.text('Forbidden', :status(403));
        }

        my $target = $root;
        $target = $target.add($_) for @segs;
        # 双保险：拼完再比一次绝对路径前缀（Windows 用 \ 分隔，Unix 用 /）
        my Str $abs = $target.absolute;
        my Str $bslash = '\\';
        unless $abs eq $base
            || $abs.starts-with($base ~ '/')
            || $abs.starts-with($base ~ $bslash) {
            return $c.text('Forbidden', :status(403));
        }

        my $file = $target;
        # 目录：只认 index.html，不做目录列表（列出目录等于泄露文件结构）
        if $file.d {
            my $index = $file.add('index.html');
            return $c.text('Not Found', :status(404)) unless $index.e;
            $file = $index;
        }

        my $resp = send-file-response(
            $file, request => $c.request, :$cache, :$max-file-bytes,
        );
        # 上面拿的是裸响应，Set-Cookie 之类的上下文头由这里补上
        $c.adopt($resp);
    }
}
