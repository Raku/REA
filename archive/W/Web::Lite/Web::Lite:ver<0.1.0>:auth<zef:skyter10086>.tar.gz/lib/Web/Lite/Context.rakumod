unit class Web::Lite::Context;

use Cro::HTTP::Request;
use Cro::HTTP::Response;
use JSON::Fast;
use Web::Lite::Response;
use Web::Lite::Control;
use Web::Lite::Route;        # 只为复用 pct-decode
use Web::Lite::Parser;       # 只为复用 body-bytes
use Web::Lite::Static;       # send-file
use Web::Lite::Serializer;   # format-http-date
use Web::Lite::Multipart;    # form / field / file

#| 单个请求的上下文对象，handler 与中间件共用
has Cro::HTTP::Request $.request is required;

#| 路径参数（来自路由模式 {name}）
has %.params;

#| 中间件与 handler 之间共享数据的袋子
has %.stash;

#| 所属应用
has $.app;

#| 缓存：path / query / body / cookie 每次解析都要切串、解码，handler 里反复取同一值很常见。
#| 用「是否已算过」的布尔量做惰性缓存，Nil 也是合法结果，不能用 defined 判断。
has Str $!path-cache;
has Bool $!path-cached = False;
has %!query-cache;
has Bool $!query-cached = False;
has Blob $!body-cache;
has Bool $!body-cached = False;
has %!cookie-cache;
has Bool $!cookie-cached = False;
has $!form-cache;
has Bool $!form-cached = False;

#| 待写入本次响应的 Set-Cookie 行（handler 里可以多次 set-cookie）
has @!set-cookies;

#| 已经贴到响应上的 Set-Cookie 条数。!with-headers 与 adopt 都会走到，
#| finish 阶段还会兜底 adopt 一次 —— 记条数而不是布尔，
#| 才能做到「贴过的不重复贴、后来新加的还能补上」（session 就是后置钩子里才写 cookie）。
has Int $!cookies-flushed = 0;

#|--- 基础信息 -------------------------------------------------------------

method method(--> Str) { $!request.method.uc }

method path(--> Str) {
    return $!path-cache if $!path-cached;
    # Cro 的 target.path 返回 IO::Path 且可能带 ?query，这里统一走 path-segments
    my Str $t = ~$!request.target;
    $t = $t.subst(/^ <[a..zA..Z]>+ '://' <-[/?#]>*/, '');
    $t = $t.subst(/ [ '?' || '#' ] .* $/, '');
    my @s = $t.split('/').grep({ .chars });
    $!path-cache = @s.elems ?? '/' ~ @s.join('/') !! '/';
    $!path-cached = True;
    $!path-cache;
}

method http-version(--> Str) { $!request.version // '1.1' }

method header(Str $name --> Str) {
    $!request.has-header($name) ?? ($!request.header($name) // '') !! ''
}

#|--- 参数 ---------------------------------------------------------------

#| 路径参数优先，其次查询串参数
method param(Str $name --> Str) {
    return %!params{$name} if %!params{$name}:exists;
    return self.query-param($name);
}

#| %XX 与 + 解码：%XX 部分复用 Route 的字节级实现（能正确处理 UTF-8 多字节），
#| 这里只额外负责 query 语义里的 '+' -> 空格
sub uri-decode(Str $s --> Str) {
    Web::Lite::Route::pct-decode($s.contains('+') ?? $s.subst('+', ' ', :g) !! $s);
}

#| 查询串 -> Hash；同名参数变成 List。结果做惰性缓存，handler 反复取参不再重复解析。
method query-hash(--> Hash) {
    return %!query-cache.clone if $!query-cached;
    my Str $t = ~$!request.target;
    my $q = '';
    if $t.contains('?') {
        $q = $t.split('?', 2)[1];
        $q = $q.subst(/ '#' .* $/, '');
    }
    my %h;
    for $q.split('&').grep({ .chars }) -> $pair {
        my ($k, $v) = $pair.split('=', 2);
        my $key = uri-decode($k // '');
        my $val = uri-decode($v // '');
        next unless $key.chars;
        %h{$key}:exists
            ?? (%h{$key} = %h{$key} ~~ Positional ?? (|%h{$key}, $val).Array !! [%h{$key}, $val])
            !! (%h{$key} = $val);
    }
    %!query-cache = %h;
    $!query-cached = True;
    %h;
}

method query-param(Str $name --> Str) {
    # 走缓存，不重复解析；只读不需要 clone
    self.query-hash unless $!query-cached;
    return '' unless %!query-cache{$name}:exists;
    my $v = %!query-cache{$name};
    $v ~~ Positional ?? ($v.tail // '') !! $v.Str;
}

method splat(--> Str) { %!params<_splat> // '' }

#|--- Cookie -------------------------------------------------------------

#| cookie 值编码：只放行 RFC 6265 的 cookie-octet，其余按字节百分号编码。
#| 必须按字节处理——直接把中文塞进 Set-Cookie 会写出非 ASCII 头，客户端解析失败。
sub cookie-encode(Str $s --> Str) {
    my $bytes = $s.encode('utf-8');
    my Str $out = '';
    for $bytes.list -> $b {
        # any(...) 会产生 Junction，必须 so 收敛成 Bool 才能塞进 Bool 变量
        my Bool $safe = so (
            ($b >= 0x30 && $b <= 0x39) || ($b >= 0x41 && $b <= 0x5A) || ($b >= 0x61 && $b <= 0x7A)
            || $b == any(0x21, 0x23, 0x24, 0x25, 0x26, 0x27, 0x2A, 0x2B, 0x2D, 0x2E,
                         0x5E, 0x5F, 0x60, 0x7C, 0x7E)
        );
        $out ~= $safe ?? $b.chr !! sprintf '%%%02X', $b;
    }
    $out;
}

#| 全部请求 cookie -> Hash。惰性缓存：Cookie 头是长串，handler 里连取几个不该重复切。
method cookies(--> Hash) {
    return %!cookie-cache.clone if $!cookie-cached;
    my %h;
    for self.header('Cookie').split(';') -> $part {
        my Str $p = $part.trim;
        next unless $p.chars;
        my $eq = $p.index('=');
        if $eq.defined {
            my Str $k = $p.substr(0, $eq).trim;
            next unless $k.chars;
            %h{$k} = $p.substr($eq + 1).trim;
        }
        else {
            %h{$p} = '';        # 只有名字没有值（标志位型 cookie）
        }
    }
    %!cookie-cache = %h;
    $!cookie-cached = True;
    %h;
}

#| 取单个 cookie 值。默认做百分号解码（与 set-cookie 的编码对称），
#| :raw 则原样返回，便于自己处理特殊编码的旧数据。
method cookie(Str $name, Bool :$raw = False --> Str) {
    my $v = self.cookies{$name};
    return '' unless $v.defined;
    $raw ?? $v !! Web::Lite::Route::pct-decode($v);
}

#| 给本次响应追加一条 Set-Cookie。handler 里可以多次调用，响应生成时一并带上。
#| 默认 Path=/ 且 HttpOnly：前者避开「cookie 只在 /api 下生效」的经典坑，
#| 后者是默认就该开的安全项（JS 读不到，能挡掉大部分 XSS 偷 token）。
method set-cookie(
    Str $name,
    Str $value = '',
    Str :$path = '/',
    Str :$domain,
    Int :$max-age,
    Instant :$expires,
    Bool :$secure = False,
    Bool :$http-only = True,
    Str :$same-site,        # Lax / Strict / None
    Bool :$raw = False,     # True 则不做百分号编码，原样写入
    --> Nil
) {
    my Str $n = $raw ?? $name  !! cookie-encode($name);
    my Str $v = $raw ?? $value !! cookie-encode($value);
    my Str $c = "$n=$v";
    $c ~= '; Path='    ~ $path   if $path.defined   && $path.chars;
    $c ~= '; Domain='  ~ $domain if $domain.defined && $domain.chars;
    $c ~= '; Max-Age=' ~ $max-age if $max-age.defined;
    $c ~= '; Expires=' ~ Web::Lite::Serializer::format-http-date($expires.DateTime)
        if $expires.defined;
    $c ~= '; Secure'   if $secure;
    $c ~= '; HttpOnly' if $http-only;
    $c ~= '; SameSite=' ~ $same-site if $same-site.defined && $same-site.chars;
    @!set-cookies.push($c);
    Nil;
}

#| 让浏览器丢掉某条 cookie：值清空 + Max-Age=0 + Expires 设为过去
method delete-cookie(
    Str $name,
    Str :$path = '/',
    Str :$domain,
    Bool :$http-only = True,
    --> Nil
) {
    self.set-cookie($name, '', :$path, :$domain, :$http-only,
        max-age => 0, expires => now - 86400);
    Nil;
}

#|--- 请求体 -------------------------------------------------------------

#| 同步取原始 body 字节。
#|
#| raw transport 下 LiteParser 已经把整块字节缓冲好，直接读，零等待；cro transport
#| 下 body 是流式的，这里返回空 Blob，请改用异步的 text-body。空 body 与「流式」
#| 在语义上没有区别（都读不到东西），调用方不用区分。
method body(--> Blob) {
    return $!body-cache if $!body-cached;
    $!body-cached = True;
    $!body-cache = Web::Lite::Parser::body-bytes($!request);
}

#| 从 Content-Type 里取 charset，缺省 utf-8
sub body-charset(Str $ct --> Str) {
    my $m = $ct.match(rx:i/ 'charset=' \s* \"? (<-[\";\s]>+) /);
    $m ?? $m[0].Str.lc !! 'utf-8';
}

#| 同步取 body 文本。按声明的 charset 解码，解不动（乱码 charset 或二进制）就退回 utf-8。
method body-str(--> Str) {
    my $b = self.body;
    return '' unless $b.defined && $b.bytes;
    my Str $cs = body-charset(self.header('Content-Type'));
    my Str $out = '';
    if $cs ne 'utf-8' {
        {
            $out = $b.decode($cs);
            CATCH { default { $out = '' } }
        }
    }
    return $out if $out.chars;
    my Str $fallback = '';
    {
        $fallback = $b.decode('utf-8');
        CATCH { default { $fallback = $b.decode('utf-8', :replacement) } }
    }
    $fallback;
}

#| 同步把 body 解析成 JSON 结构。空 body 返回空 Hash（与 json-body 一致）
method body-json() {
    my Str $s = self.body-str;
    $s.trim eq '' ?? %() !! from-json($s);
}

#| 原始文本 body（异步）。body 已缓冲时直接返回，不再走一遍供给流——
#| 供给流只能消费一次，重复 await 会静默拿到空串。
method text-body(--> Promise) {
    my $b = self.body;
    return Promise.kept(self.body-str) if $b.defined && $b.bytes;
    start {
        my $t = '';
        try { $t = await $!request.body-text; }
        $t // '';
    }
}

#| 解析为 JSON 的 body（异步）：空 body 返回空 Hash
method json-body(--> Promise) {
    start {
        my $t = await self.text-body;
        $t.trim eq '' ?? %() !! from-json($t);
    }
}

#|--- stash --------------------------------------------------------------

method set(Str $key, $value --> Nil) { %!stash{$key} = $value }
method stash-get(Str $key) { %!stash{$key} }

#|--- 表单 --------------------------------------------------------------

#| 表单视图。multipart/form-data 与 x-www-form-urlencoded 都走这里，
#| 其它 Content-Type 返回空 Form（不抛）—— handler 里可以无脑取字段。
method form(--> Web::Lite::Multipart::Form) {
    return $!form-cache if $!form-cached;
    $!form-cached = True;
    $!form-cache = Web::Lite::Multipart::parse-form(self.body, self.header('Content-Type'));
}

method multipart(--> Bool) { self.form.multipart }

#| 单个字段：同名多个时返回 List，否则返回 Str；没有返回 Any
method field(Str $name) { self.form.field($name) }

#| 单个上传文件：返回 Part / List / Any
method file(Str $name) { self.form.file($name) }

method files(--> List) { self.form.all-files }

#|--- session ------------------------------------------------------------

#| 本次请求的会话视图。没调用 $app.session 就取会直接报错 ——
#| 静默返回一个永不落盘的空会话只会让人更难查。
method session() {
    my $s = %!stash{'__weblite.session'};
    die X::AdHoc.new(payload => 'session 未启用：先 $app.session(secret => "...")') unless $s.defined;
    $s;
}

#|--- 响应构造 -----------------------------------------------------------

method !with-headers(Cro::HTTP::Response $r, %headers --> Cro::HTTP::Response) {
    for %headers.kv -> $k, $v { $r.append-header($k, $v.Str) }
    self!attach-cookies($r);
    $r;
}

method !attach-cookies(Cro::HTTP::Response $r --> Nil) {
    while $!cookies-flushed < @!set-cookies.elems {
        $r.append-header('Set-Cookie', @!set-cookies[$!cookies-flushed]);
        $!cookies-flushed++;
    }
    Nil;
}

#| 接管一个外部构造的响应：把本次累积的 Set-Cookie 等上下文头补上后返回。
#| send-file / 静态目录这类「响应不是本方法造的」场景必须走一次，否则 cookie 会丢。
#| 幂等：框架在 finish 阶段会兜底再调一次，重复调用不会重复发头。
method adopt(Cro::HTTP::Response $r --> Cro::HTTP::Response) {
    self!attach-cookies($r);
    $r;
}

#| 直接回一个磁盘文件。
#|   :download-name 给定则作为附件下载
#|   :cache(False) 关掉 ETag/304 协商
#|   :max-file-bytes 超过按 500 处理（一次性读进内存，别拿它发视频）
method send-file(
    Str $path,
    Str :$content-type,
    Str :$download-name,
    Bool :$cache = True,
    Int :$max-file-bytes = 32 * 1024 * 1024,
    --> Cro::HTTP::Response
) {
    my $resp = Web::Lite::Static::send-file-response(
        $path.IO, :$content-type, :$download-name, request => $!request,
        :$cache, :$max-file-bytes,
    );
    self.adopt($resp);
}

method json($data, Int :$status = 200, :%headers --> Cro::HTTP::Response) {
    my $body = $data ~~ Str ?? $data !! to-json($data);
    my $r = make-response($status, 'application/json; charset=utf-8', $body);
    self!with-headers($r, %headers);
}

method text(Str $body, Int :$status = 200, Str :$content-type = 'text/plain; charset=utf-8', :%headers --> Cro::HTTP::Response) {
    my $r = make-response($status, $content-type, $body);
    self!with-headers($r, %headers);
}

method html(Str $body, Int :$status = 200, :%headers --> Cro::HTTP::Response) {
    self.text($body, :$status, content-type => 'text/html; charset=utf-8', :%headers);
}

method redirect(Str $url, Int :$status = 302 --> Cro::HTTP::Response) {
    my $r = make-empty-response($status);
    $r.append-header('Location', $url);
    self.adopt($r);
}

#|--- 控制流 -------------------------------------------------------------

#| 立即中断：跳过后续中间件与 handler，$value 当响应返回（后置钩子仍会执行）
method halt($value --> Halt) { Web::Lite::Control::halt($value) }

#| 交回上一层：中间件里等价于什么都不做，让处理继续
method pass(--> Pass) { Web::Lite::Control::pass() }
