#| multipart/form-data 与 application/x-www-form-urlencoded 的请求体解析。
#|
#| 设计取向：
#| - 全程在「latin-1 字符串」上做扫描。latin-1 是字节到字符的双射，index/substr
#|   这类内置方法就能按字节精确切分，二进制文件也不会被 UTF-8 解码破坏；
#|   只有真正要交出去的时候才 decode('utf-8')。
#| - 不做流式解析，依赖上游 max-body-bytes 兜住内存（默认 2MB，超了在此之前就 413）。
#| - 解析失败一律抛 X::Web::Lite::Multipart，由调用方决定转 400 还是 500。
unit module Web::Lite::Multipart;

use Web::Lite::Route;       # pct-decode
use JSON::Fast;

#| 请求体格式不对（缺 boundary / 缺结束标记 / part 头坏了……）
class X::Web::Lite::Multipart is Exception is export {
    has Str $.reason;

    method message(--> Str) { "multipart: {$!reason}" }
}

#| 单个 part。带 filename 的按上传文件看待，否则按普通字段。
class Part is export {
    has Str $.name = '';
    #| 有值即视为文件（空串按「未选文件」丢弃）。不加 Str 约束：
    #| 「没有文件名」用未定义表示，硬加类型会让 Part.new 在无 filename 时炸掉。
    has $.filename;
    has Str $.content-type;
    has %.headers;                   # 小写头名 -> 值
    has Blob $.data;
    has Str $!text-cache;
    has Bool $!text-cached = False;

    method is-file(--> Bool) { $!filename.defined && $!filename.chars > 0 }

    #| 文本内容。非法 UTF-8 用替换字符兜住，不让 a 上传就把整个请求炸掉。
    method text(--> Str) {
        return $!text-cache if $!text-cached;
        $!text-cache = ($!data // Blob).decode('utf-8');
        $!text-cached = True;
        $!text-cache;
    }

    method Str(--> Str) { self.text }

    method header(Str $n --> Str) { %!headers{$n.lc} // '' }

    method size(--> Int) { ($!data // Blob).elems }
}

#| 解析结果。fields 是普通字段（同名多个聚成 List），files 是上传文件。
class Form is export {
    has %.fields;
    has @.files;                     # List of Part
    has %.file-map;                  # name => Part | List
    has Bool $.multipart = False;

    method field(Str $name) { %!fields{$name} }

    method file(Str $name) { %!file-map{$name} }

    method all-files(--> List) { @!files.List }

    #| form 优先，其次文件（Flask 里叫 request.values 的味道）
    method param(Str $name) {
        my $f = %!fields{$name};
        return $f if $f.defined;
        %!file-map{$name};
    }

    method has-field(Str $name --> Bool) { %!fields{$name}:exists }

    method keys(--> List) { %!fields.keys.sort }
}

#|--- 内部工具 -------------------------------------------------------------

#| 从 Content-Type 里揪 boundary，支持带引号
sub boundary-of(Str $content-type --> Str) {
    for $content-type.split(';') -> $seg is copy {
        $seg = $seg.trim;
        next unless $seg.lc.starts-with('boundary=');
        my Str $v = $seg.substr(9).trim;
        $v = $v.substr(1, $v.chars - 2) if $v.chars >= 2 && $v.starts-with('"') && $v.ends-with('"');
        return $v;
    }
    '';
}

#| 按 ';' 切 but 尊重引号，用于 Content-Disposition 参数
sub split-params(Str $s --> List) {
    my @out;
    my Str $cur = '';
    my Bool $in-q = False;
    for $s.comb -> $ch {
        if $ch eq '"' { $in-q = !$in-q; $cur ~= $ch }
        elsif $ch eq ';' && !$in-q { @out.push($cur.trim) if $cur.trim.chars; $cur = '' }
        else { $cur ~= $ch }
    }
    @out.push($cur.trim) if $cur.trim.chars;
    @out.List;
}

#| 拆 "form-data; name=\"a\"; filename=\"b.txt\""，返回 (type, %params)
sub parse-disposition(Str $v --> List) {
    my @segs = split-params($v);
    my Str $type = @segs.elems ?? @segs[0].lc !! '';
    my %p;
    for @segs[1..*] -> $seg is copy {
        my Int $eq = $seg.index('=') // -1;
        next if $eq < 0;
        my Str $k = $seg.substr(0, $eq).trim.lc;
        my Str $val = $seg.substr($eq + 1).trim;
        if $val.chars >= 2 && $val.starts-with('"') && $val.ends-with('"') {
            $val = $val.substr(1, $val.chars - 2);
            # 引号内的 \" 与 \\ 反转义
            $val = $val.subst('\\"', '"', :g).subst('\\\\', '\\', :g);
        }
        %p{$k} = $val;
    }
    ($type, %p);
}

#| RFC 5987 的 filename*=UTF-8''%E4%B8%AD.txt -> 中文.txt
sub decode-ext-value(Str $v --> Str) {
    my @segs = $v.split("'");
    my Str $raw = @segs.elems >= 3 ?? @segs[2] !! $v;
    Web::Lite::Route::pct-decode($raw);
}

#| latin-1 字符串（字节双射）还原成 Blob。绝不能写成 $s.encode('utf-8')。
sub bytes-of(Str $latin1 --> Blob) { $latin1.encode('iso-8859-1') }

#| part 头里的 name/filename 是从字节串按 latin-1 读出来的，浏览器实际发的是
#| UTF-8 字节。这里做一次「还原字节 -> 按 UTF-8 解码」，非 UTF-8 就原样返回。
sub utf8-of(Str $latin1 --> Str) {
    return $latin1 unless $latin1.contains(/ <[\x80..\xFF]> /);
    my $r = try { bytes-of($latin1).decode('utf-8') };
    ($r.defined && !$r.contains("\x[FFFD]")) ?? $r !! $latin1;
}

#|--- 解析 ---------------------------------------------------------------

#| 解析 multipart 请求体。$content-type 必须是 multipart/form-data。
our sub parse-multipart(Blob $body, Str $content-type --> Form) is export {
    my Str $boundary = boundary-of($content-type);
    die X::Web::Lite::Multipart.new(reason => 'Content-Type 缺少 boundary')
        unless $boundary.chars;
    die X::Web::Lite::Multipart.new(reason => 'boundary 过长或含非法字符')
        if $boundary.chars > 200 || $boundary.contains("\r") || $boundary.contains("\n");

    my Str $raw = ($body // Blob).decode('iso-8859-1');
    my Str $dash = '--' ~ $boundary;
    my Str $sep = "\r\n" ~ $dash;

    my Int $start = $raw.index($dash) // -1;
    die X::Web::Lite::Multipart.new(reason => '找不到起始 boundary')
        if $start < 0;

    my @parts;
    my Int $pos = $start;
    my Bool $closed = False;

    loop {
        $pos += $dash.chars;
        last if $pos >= $raw.chars;

        # 结束标记 "--"
        if $raw.substr($pos, 2) eq '--' { $closed = True; last }
        # 跳过 "--boundary" 之后的 CRLF。
        # 注意：Raku 里 "\r\n" 是**单个 grapheme**，所以 substr 只取 1 位，偏移也按 1 走。
        if $raw.substr($pos, 1) eq "\r\n" { $pos += 1 }
        elsif $raw.substr($pos, 1) eq "\n" { $pos += 1 }
        else {
            die X::Web::Lite::Multipart.new(reason => "boundary 后出现非法字节");
        }

        my Int $hdr-end = $raw.index("\r\n\r\n", $pos) // -1;
        die X::Web::Lite::Multipart.new(reason => 'part 头未以空行结束')
            if $hdr-end < 0;

        my Str $hdr-block = $raw.substr($pos, $hdr-end - $pos);
        # "\r\n\r\n" 是两个 grapheme，不是四个字符
        my Int $cstart = $hdr-end + 2;

        my Int $cend = $raw.index($sep, $cstart) // -1;
        die X::Web::Lite::Multipart.new(reason => 'part 内容未以 boundary 结束')
            if $cend < 0;

        my Str $content = $raw.substr($cstart, $cend - $cstart);
        @parts.push: build-part($hdr-block, bytes-of($content));
        $pos = $cend + 1;        # 跨过 CRLF，停在 "--boundary" 的 '-' 上
    }

    die X::Web::Lite::Multipart.new(reason => '缺少结束 boundary（--boundary--）')
        unless $closed;

    my %fields;
    my @files;
    my %file-map;

    for @parts -> $p {
        my Str $nm = $p.name;
        next unless $nm.chars;
        if $p.is-file {
            @files.push: $p;
            %file-map{$nm}:exists
                ?? (%file-map{$nm} = %file-map{$nm} ~~ Positional
                        ?? (|%file-map{$nm}, $p).Array !! [%file-map{$nm}, $p].Array)
                !! (%file-map{$nm} = $p);
        }
        else {
            my Str $v = $p.text;
            %fields{$nm}:exists
                ?? (%fields{$nm} = %fields{$nm} ~~ Positional
                        ?? (|%fields{$nm}, $v).Array !! [%fields{$nm}, $v].Array)
                !! (%fields{$nm} = $v);
        }
    }

    Form.new(fields => %fields, files => @files, file-map => %file-map, multipart => True);
}

#| 单个 part：解析头块 + 内容
sub build-part(Str $hdr-block, Blob $data --> Part) {
    my %h;
    for $hdr-block.split("\r\n") -> $line is copy {
        next unless $line.chars;
        my Int $colon = $line.index(':') // -1;
        next if $colon <= 0;
        my Str $k = $line.substr(0, $colon).trim.lc;
        my Str $v = $line.substr($colon + 1).trim;
        %h{$k} = %h{$k}:exists ?? %h{$k} ~ ', ' ~ $v !! $v;
    }

    my Str $name = '';
    my $filename;
    my Str $ctype;
    if %h<content-disposition>:exists {
        my @d = parse-disposition(%h<content-disposition>);
        my Str $type = @d[0] // '';
        my %dp = @d[1];
        $name = utf8-of(%dp<name> // '');
        if %dp<filename*>:exists {
            $filename = decode-ext-value(%dp<filename*>);
        }
        elsif %dp<filename>:exists {
            $filename = utf8-of(%dp<filename>);
        }
        # 空 filename 表示浏览器「没选文件」，当普通字段处理才符合直觉
        $filename = Nil if $filename.defined && !$filename.chars;
    }
    $ctype = %h<content-type> if %h<content-type>:exists;

    # 属性名带连字符，命名参数必须写全 'content-type'，写成 :$ctype 会被静默忽略
    Part.new(:$name, :$filename, content-type => $ctype, headers => %h, data => $data);
}

#| 解析 application/x-www-form-urlencoded（HTML 表单的默认编码）
our sub parse-urlencoded(Blob $body --> Form) {
    my Str $raw = ($body // Blob).decode('utf-8');
    my %fields;
    for $raw.split('&').grep({ .chars }) -> $pair {
        my @kv = $pair.split('=', 2);
        my Str $k = Web::Lite::Route::pct-decode((@kv[0] // '').subst('+', ' ', :g));
        my Str $v = Web::Lite::Route::pct-decode((@kv[1] // '').subst('+', ' ', :g));
        next unless $k.chars;
        %fields{$k}:exists
            ?? (%fields{$k} = %fields{$k} ~~ Positional
                    ?? (|%fields{$k}, $v).Array !! [%fields{$k}, $v].Array)
            !! (%fields{$k} = $v);
    }
    Form.new(fields => %fields);
}

#| 统一入口：按 Content-Type 选解析器。非表单类型返回空 Form（不抛，方便 handler 直接取）。
our sub parse-form(Blob $body, Str $content-type --> Form) is export {
    my Str $ct = $content-type.lc;
    my Str $mt = $ct.split(';', 2)[0].trim;
    if $mt eq 'multipart/form-data' {
        parse-multipart($body, $content-type);
    }
    elsif $mt eq 'application/x-www-form-urlencoded' {
        parse-urlencoded($body);
    }
    else {
        Form.new;
    }
}
