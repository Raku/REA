unit module Web::Lite::Middleware;

use Cro::HTTP::Response;
use Web::Lite::Response;

#| 记录请求开始时间（配合 access-log 使用）
sub timing() is export {
    -> $ctx {
        $ctx.set('request-start', now);
        Nil;
    }
}

#| 打印访问日志，并补上 X-Response-Time 响应头
sub access-log(:$sink = &note, Bool :$header = True) is export {
    -> $ctx, $response {
        my $start = $ctx.stash-get('request-start');
        my $ms = $start.defined ?? ((now - $start) * 1000).round !! 0;
        $sink(join ' ', $ctx.method, $ctx.path, ($response.status // '?'), "{$ms}ms");
        $response.append-header('X-Response-Time', "{$ms}ms") if $header;
        $response;
    }
}

#| 简单 CORS 响应头（预检 OPTIONS 未单独处理）
sub cors(Str :$origin = '*', Str :$methods = 'GET, POST, PUT, PATCH, DELETE',
         Str :$headers = 'Content-Type, Authorization') is export {
    -> $ctx, $response {
        $response.append-header('Access-Control-Allow-Origin', $origin);
        $response.append-header('Access-Control-Allow-Methods', $methods);
        $response.append-header('Access-Control-Allow-Headers', $headers);
        $response;
    }
}

#| Bearer token 校验（演示中间件短路：不满足条件时直接返回响应）
sub bearer-auth(Str $token is copy) is export {
    -> $ctx {
        my $auth = $ctx.header('Authorization');
        # 注意：闭包里不能用 return（会跳出外层 routine），一律用表达式产出
        $auth eq "Bearer {$token}" ?? Nil !! do {
            my $resp = make-response(401, 'application/json; charset=utf-8',
                                     '{"error":"unauthorized"}');
            $resp.append-header('WWW-Authenticate', 'Bearer');
            $resp;
        }
    }
}
