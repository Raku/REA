#| 极简 Session：把会话数据整个塞进一个签名 cookie，服务端不存任何状态。
#|
#| 取舍：无状态 -> 水平扩容/重启零成本，代价是数据量受限（cookie ~4KB）
#| 且客户端能看到明文（base64 不是加密）。所以这里只适合放 user-id、
#| flash 消息这类不敏感的小数据，别往里塞密码。
#|
#| 签名：HMAC-SHA1(secret, payload-b64)，值形如 "<payload-b64>.<sig-b64>"，
#| 两段都用 base64url 字母表（- _），末尾 padding 去掉，省得在 cookie 里做转义。
unit module Web::Lite::Session;

use Digest::HMAC;
use Digest::SHA1;
use JSON::Fast;

#| 一次请求内的会话视图。改它不会立刻发 cookie，由 after 钩子在响应前统一写回。
class Session is export {
    has %.data;
    has Bool $.dirty = False;

    method get(Str $k, $default?) { %!data{$k}:exists ?? %!data{$k} !! $default }

    method set(Str $k, $v --> Nil) {
        %!data{$k} = $v;
        $!dirty = True;
        Nil;
    }

    method remove(Str $k --> Nil) {
        %!data{$k}:delete;
        $!dirty = True;
        Nil;
    }

    method clear(--> Nil) {
        %!data = ();
        $!dirty = True;
        Nil;
    }

    method hash(--> Hash) { %!data }
    method keys(--> List) { %!data.keys.sort.List }
    method elems(--> Int) { %!data.elems }
    method is-empty(--> Bool) { %!data.elems == 0 }
    method mark-dirty(--> Nil) { $!dirty = True; Nil }
    method reset-dirty(--> Nil) { $!dirty = False; Nil }

    # 关联下标：$c.session<uid> 读写都能用，写入自动标脏
    method AT-KEY($k) { %!data{$k} }
    method ASSIGN-KEY($k, $v) {
        $!dirty = True;
        %!data{$k} = $v;
    }
    method EXISTS-KEY($k --> Bool) { %!data{$k}:exists }
    method DELETE-KEY($k --> Nil) {
        $!dirty = True;
        %!data{$k}:delete;
        Nil;
    }
}

#| base64url 字母表：- _ 代替 + /，且不写 padding。
#| 这里手写而不是用 Base64 模块，是因为它的 encode/decode 在不同调用形态下
#| 返回 Seq / Str / Buf 三种类型，:uri 分支尤其不稳定，手写 30 行一劳永逸。
my constant B64URL = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_';

sub b64-encode(Blob $b --> Str) {
    my @bytes = $b.list;
    my Int $n = @bytes.elems;
    my @out;
    my Int $i = 0;
    while $i < $n {
        my Int $b0 = @bytes[$i];
        my Int $b1 = ($i + 1 < $n) ?? @bytes[$i + 1] !! 0;
        my Int $b2 = ($i + 2 < $n) ?? @bytes[$i + 2] !! 0;
        my Int $v = ($b0 +< 16) +| ($b1 +< 8) +| $b2;
        @out.push: B64URL.substr(($v +> 18) +& 0x3F, 1);
        @out.push: B64URL.substr(($v +> 12) +& 0x3F, 1);
        @out.push: B64URL.substr(($v +> 6) +& 0x3F, 1) if $i + 1 < $n;
        @out.push: B64URL.substr($v +& 0x3F, 1) if $i + 2 < $n;
        $i += 3;
    }
    @out.join;
}

sub b64-decode(Str $s --> Blob) {
    my Int %idx;
    for ^B64URL.chars -> $i { %idx{B64URL.substr($i, 1)} = $i }
    my @c = $s.comb.grep({ %idx{$_}:exists });
    my Int $n = @c.elems;
    my @bytes;
    my Int $i = 0;
    while $i < $n {
        my Int $v = (%idx{@c[$i]} +< 18) +| (($i + 1 < $n) ?? (%idx{@c[$i + 1]} +< 12) !! 0);
        my Bool $has2 = $i + 2 < $n;
        my Bool $has3 = $i + 3 < $n;
        $v +|= (%idx{@c[$i + 2]} +< 6) if $has2;
        $v +|= %idx{@c[$i + 3]} if $has3;
        @bytes.push: ($v +> 16) +& 0xFF;
        @bytes.push: ($v +> 8) +& 0xFF if $has2;
        @bytes.push: $v +& 0xFF if $has3;
        $i += 4;
    }
    Blob.new(@bytes);
}

#| 定长比较：xor 累积，别用 eq —— 比较短路的时序差足以被拿去测签名
sub constant-time-eq(Str $a, Str $b --> Bool) {
    return False if $a.chars != $b.chars;
    my Int $acc = 0;
    my @x = $a.ords;
    my @y = $b.ords;
    for ^@x.elems -> $i { $acc +|= abs(@x[$i] - @y[$i]) }
    $acc == 0;
}

#| 签名/验签 + cookie 属性。一个 store 对应一条 cookie。
class SessionStore is export {
    has Str $.secret is required;
    has Str $.cookie-name = 'weblite.session';
    has Int $.max-age = 604800;          # 7 天
    has Str $.path = '/';
    has $.domain;
    has Bool $.secure = False;
    has Bool $.http-only = True;
    has Str $.same-site = 'Lax';

    method !sign(Str $payload --> Str) {
        b64-encode(hmac($!secret, $payload, &sha1));
    }

    method encode(%data --> Str) {
        my Str $payload = b64-encode(to-json(%data).encode('utf-8'));
        $payload ~ '.' ~ self!sign($payload);
    }

    #| 验签通过才返回 Session，否则当空会话（伪造/过期都走这条路，不报错打扰业务）
    method decode(Str $raw) {
        my @parts = $raw.split('.');
        return Session.new unless @parts.elems == 2;
        my Str $payload = @parts[0];
        my Str $sig = @parts[1];
        return Session.new unless constant-time-eq($sig, self!sign($payload));

        my $json = try { b64-decode($payload).decode('utf-8') };
        return Session.new without $json;
        my $data = try { from-json($json) };
        return Session.new unless $data ~~ Hash;
        Session.new(data => $data);
    }
}
