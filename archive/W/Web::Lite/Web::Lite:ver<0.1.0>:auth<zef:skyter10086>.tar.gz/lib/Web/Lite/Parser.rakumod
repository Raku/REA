#| 精简 HTTP/1.1 请求解析器
#|
#| 与 Cro::HTTP::RequestParser 的差异：
#|   - 不逐字符喂编码器解码器，而是整块字节按 latin-1 解码后用 index 找头部边界
#|   - 请求行用 index(' ') + substr 直接切，头部用 lines 逐行切，不用 grammar
#|   - body 定界支持 Content-Length 与 chunked，均在字节层面处理
#|
#| 注意：Raku 的 .chars/.index/.substr 以「字素」为单位，CRLF 会被合并成一个字素。
#| 因此字素索引绝不能直接当字节索引用，必须经 encode('iso-8859-1').elems 换算。
unit module Web::Lite::Parser;

use Cro::Transform;
use Cro::TCP;
use Cro::HTTP::Request;
use Cro::HTTP::Response;
use Cro::HTTP::Header;
use Cro::HTTP::Exception;

#| 解析失败时发出的「占位请求」：应用层看到它就直接回状态码并关连接，
#| 而不是让异常穿透 pipeline（穿透的表现是客户端零响应、连接悬挂）。
class LiteBadRequest is Cro::HTTP::Request is export {
    has UInt $.lite-status = 400;

    submethod TWEAK() {
        self.method = 'GET';
        self.target = '/';
        self.http-version = '1.1';
    }
}

#| 同步取出「已缓冲」的请求体字节。
#|
#| Cro::MessageWithBody 只给了两个异步入口（body-blob 返回 Promise、body-byte-stream
#| 返回 Supply），没有同步访问器。而 LiteParser 一定是「凑够字节后整块 set-body」，
#| body 早就在内存里躺着了，为它再走一遍 Promise 纯属浪费——更糟的是 Supply 只能
#| 消费一次，handler 里第二次取 body 会静默拿到空串。
#|
#| 这里用属性反射直接读 $!body。拿到 Blob 说明已缓冲、可同步使用；拿到 Nil 说明
#| 是流式的（Cro 自带 parser 的路径），调用方自行降级到 body-text。属性对象缓存到
#| 模块级变量，避免每个请求都遍历一遍属性表。
my $body-attr;
our sub body-bytes(Cro::HTTP::Request $req --> Blob) is export {
    $body-attr //= $req.^attributes.first({ .name eq '$!body' });
    return Blob unless $body-attr.defined;
    my $b = $body-attr.get_value($req);
    ($b.defined && $b ~~ Blob) ?? $b !! Blob;
}

class LiteParser does Cro::Transform is export {
    #| 头部上限：超过即 431（防止慢速/超大头部把内存吃光）
    has Int $.max-header-bytes = 32768;

    #| 请求体上限：超过即 413，且不等 body 收全就拒（否则单客户端能靠一条请求吃满内存）
    has Int $.max-body-bytes = 2 * 1024 * 1024;

    #| 请求头读超时（秒）：从「出现半截请求」那一刻起算，超时回 408 并关连接。
    #| 没有这条，slowloris 只要发半个头就不再动，连接可以被永久占住。
    #| 0 表示不限制。
    has Real $.read-timeout = 15;

    #| 请求体读超时（秒）：头收全、body 声明了长度却迟迟传不完时按 408 断。
    #| 比头部宽松，避免误伤大文件慢速上传。
    has Real $.body-timeout = 60;

    #| 请求行上限：超过即 414
    has Int $.max-line-bytes = 8192;

    #| 头部条数上限：超过即 431（单条头部很小但数量极大的攻击同样吃内存）
    has Int $.max-header-count = 100;

    method consumes(--> Cro::TCP::Message) { Cro::TCP::Message }
    method produces(--> Cro::HTTP::Message) { Cro::HTTP::Request }

    my constant CRLFCRLF = "\r\n\r\n";

    method transformer(Supply $in --> Supply) {
        supply {
            my Buf $buf .= new;
            my Bool $failed = False;

            # 「半截请求」的起始时刻：buf 一旦有残留就记下，收全清空才复位。
            # 读超时按这个绝对时刻算，而不是「距上次收到数据的间隔」——
            # 否则每秒滴一个字节的 trickle 攻击永远等不到超时。
            my Instant $stall-since;

            whenever $in -> $packet {
                next if $failed;

                {
                $buf.append: $packet.data;

                loop {
                    # ---- 0. 忽略请求行前的空行 ----
                    # 少数老客户端/代理会在请求前多发一个 CRLF，RFC 7230 §3.5 要求服务端忽略。
                    # 不处理的话，首个 "\r\n\r\n" 直接命中空头部，请求行变成空串 -> 400。
                    while $buf.elems >= 2 && $buf[0] == 13 && $buf[1] == 10 {
                        $buf = $buf.elems > 2 ?? $buf.subbuf(2) !! Buf.new;
                    }
                    last unless $buf.elems;

                    # ---- 1. 找头部结束 ----
                    # pipeline 场景下 $buf 可能积压上千条请求，绝不能整块 decode。
                    # 常规请求头 < 512B，先只解这么多；找不到再放窗口，最后才全量。
                    my int $total = $buf.elems;
                    my int $scan-len = $total < 512 ?? $total !! 512;
                    my Str $s = $buf.subbuf(0, $scan-len).decode('iso-8859-1');
                    my $gend = $s.index(CRLFCRLF);
                    if !$gend.defined && $total > $scan-len {
                        $scan-len = $total < 4096 ?? $total !! 4096;
                        $s = $buf.subbuf(0, $scan-len).decode('iso-8859-1');
                        $gend = $s.index(CRLFCRLF);
                        if !$gend.defined && $total > $scan-len {
                            # 先判上限再整块 decode：否则超大头部会把 CPU 和内存一起拖垮
                            http-error(431, 'Request Header Fields Too Large')
                                if $total > self.max-header-bytes;
                            $s = $buf.decode('iso-8859-1');
                            $gend = $s.index(CRLFCRLF);
                        }
                    }
                    last unless $gend.defined;               # 头部未收全，等下一块

                    my Str $head = $s.substr(0, $gend);
                    # 字素索引 -> 字节索引（head 为纯 ASCII，编码后长度即字节数）
                    my int $head-len = $head.encode('iso-8859-1').elems;
                    my int $body-start = $head-len + 4;

                    # ---- 2. 请求行 ----
                    # CRLF 在 Raku 中是一个字素，须整体匹配（index("\n") 找不到）
                    my $nl = $head.index("\r\n");
                    my Str $first = ($nl.defined ?? $head.substr(0, $nl) !! $head).trim;

                    # 请求行过长（典型是超长 query/URL）：414，而不是让它进路由层拖慢切段
                    http-error(414, 'URI Too Long')
                        if $first.encode('iso-8859-1').elems > self.max-line-bytes;

                    my @parts = $first.split(' ');
                    unless @parts.elems == 3 {
                        bad-request('Malformed request line');
                    }
                    my Str $method = @parts[0];
                    my Str $target = @parts[1];
                    my Str $version = @parts[2];
                    unless $method ~~ /^ <[A..Z]>+ $/ {
                        bad-request('Malformed method');
                    }
                    unless $target ~~ /^ <[\x21..\x7E]>+ $/ {
                        bad-request('Malformed target');
                    }
                    unless $version.starts-with('HTTP/1.') && $version.chars == 8 {
                        if $version.starts-with('HTTP/2') {
                            die Cro::HTTP::Exception.new(:505status, message => 'Unsupported HTTP version');
                        }
                        bad-request('Malformed HTTP version');
                    }

                    my $req = Cro::HTTP::Request.new;
                    $req.connection = $packet.connection with $packet.?connection;
                    $req.method = $method;
                    $req.target = $target;
                    $req.http-version = $version.substr(5);

                    # ---- 3. 头部 ----
                    # 顺手记下 body 定界相关头部：$req.header() 每次要约 11 us，这里一次都不查。
                    my $te;
                    my $cl;
                    my int $hcount = 0;
                    if $nl.defined {
                        for $head.substr($nl + 2).lines -> $line {
                            next unless $line.chars;

                            # obs-fold（续行以空格/Tab 开头）在 RFC 7230 已废弃，明确拒绝，
                            # 否则头会被静默丢弃，后端看到的是不完整的请求
                            bad-request('Obsolete line folding in header')
                                if $line.starts-with(' ') || $line.starts-with("\t");

                            my $colon = $line.index(':');
                            # 无冒号的行以前被 next 静默跳过，等于吞掉客户端数据，一律拒绝
                            bad-request('Malformed header line') unless $colon.defined;

                            my Str $name = $line.substr(0, $colon).trim;
                            bad-request('Empty header name') unless $name.chars;
                            # 头部名不允许出现空格（"GET / HTTP/1.1" 之类混淆）
                            bad-request('Invalid header name')
                                if $name ~~ /\s/;

                            $hcount++;
                            http-error(431, 'Too Many Headers')
                                if $hcount > self.max-header-count;

                            my Str $value = $line.substr($colon + 1).trim;
                            my $lname = $name.lc;
                            if $lname eq 'content-length' {
                                # 重复且不一致是典型请求走私手法，直接 400
                                bad-request('Conflicting Content-Length')
                                    if $cl.defined && $cl ne $value;
                                bad-request('Invalid Content-Length')
                                    unless $value ~~ /^ <[0..9]>+ $/;
                                $cl = $value;
                            }
                            elsif $lname eq 'transfer-encoding' { $te = $value }
                            $req.append-header(Cro::HTTP::Header.new(:$name, :$value));
                        }
                    }

                    # ---- 4. body ----
                    my int $consumed;

                    # Content-Length 与 Transfer-Encoding 并存时定界有歧义（走私向量），拒绝
                    bad-request('Both Content-Length and Transfer-Encoding present')
                        if $cl.defined && $te.defined;

                    if $te.defined && $te.lc.contains('chunked') {
                        my $chunked = decode-chunked($buf, $body-start, self.max-body-bytes);
                        last unless $chunked.defined;        # 块数据未收全
                        $req.set-body($chunked<body>);
                        $consumed = $chunked<consumed>;
                    }
                    elsif $cl.defined {
                        my int $need = $cl.Int;
                        http-error(413, 'Payload Too Large') if $need > self.max-body-bytes;
                        last if $buf.elems < $body-start + $need;
                        $req.set-body($buf.subbuf($body-start, $need));
                        $consumed = $body-start + $need;
                    }
                    else {
                        $consumed = $body-start;
                    }

                    $buf = $buf.elems > $consumed ?? $buf.subbuf($consumed) !! Buf.new;
                    emit $req;
                    last unless $buf.elems;                  # 余料不足以构成新请求
                }

                CATCH {
                    default {
                        # 解析失败不能让异常穿透 pipeline：那样客户端拿到的是
                        # 零响应 + 悬挂连接。这里改发一个带状态码的占位请求。
                        $failed = True;
                        my $status = 400;
                        if $_ ~~ Cro::HTTP::Exception {
                            $status = $_.status // 400;
                        }
                        my $bad = LiteBadRequest.new(:lite-status($status));
                        $bad.connection = $packet.connection with $packet.?connection;
                        emit $bad;
                    }
                }
                }

                # 还有残留 = 这条请求没读完，开始（或继续）计时；收全了就复位
                if $buf.elems && !$failed {
                    $stall-since //= now;
                }
                else {
                    $stall-since = Nil;
                }
            }

            # ---- slowloris 防护：半截请求超过时限则回 408 并结束这条连接 ----
            # 头部阶段用 read-timeout（严格），头部收全后等 body 用 body-timeout（宽松）。
            # 两者都为 0 时完全不装定时器，零开销。
            if $!read-timeout > 0 || $!body-timeout > 0 {
                my Real $tick = ($!read-timeout > 0 ?? ($!read-timeout min 1) !! 1) max 0.05;
                whenever Supply.interval($tick) -> $ {
                    next if $failed || !$buf.elems || !$stall-since.defined;
                    my Real $limit = head-complete($buf) ?? $!body-timeout !! $!read-timeout;
                    next unless $limit > 0;
                    next if now - $stall-since < $limit;

                    $failed = True;
                    $buf = Buf.new;
                    # 408 走的仍是 LiteBadRequest 通道，由应用层统一回 Connection: close
                    emit LiteBadRequest.new(lite-status => 408);
                }
            }
        }
    }

    #| 头部是否已收全（只看前 4KB，够区分「等头」和「等 body」即可）
    sub head-complete(Buf $buf --> Bool) {
        my int $n = $buf.elems < 4096 ?? $buf.elems !! 4096;
        # 这里不引用类体内的 CRLFCRLF 常量（词法作用域在类体，模块级 sub 看不到）
        $buf.subbuf(0, $n).decode('iso-8859-1').contains("\r\n\r\n");
    }

    #| 在 $buf 上从 $start 字节处解码 chunked 正文。
    #| 返回 { body => Blob, consumed => Int }，数据不足返回 Nil。
    #| 只对 chunk 的尺寸行/trailer 做字节扫描，块数据直接 subbuf，不做逐字节遍历。
    sub decode-chunked(Buf $buf, int $start, Int $max = 16 * 1024 * 1024) {
        my int $i = $start;
        my Buf $body .= new;
        loop {
            my int $eol = find-crlf($buf, $i);
            return Nil if $eol < 0;

            my Str $size-str = $buf.subbuf($i, $eol - $i).decode('iso-8859-1').trim;
            my $semi = $size-str.index(';');
            $size-str = $size-str.substr(0, $semi) if $semi.defined;
            $size-str = $size-str.trim;
            return Nil unless $size-str.chars && $size-str ~~ /^ <[0..9 a..f A..F]>+ $/;
            my int $n = :16($size-str);

            # 累计超限即拒：否则分块「少量多次」就能绕过单块上限把内存吃穿
            http-error(413, 'Payload Too Large') if $body.elems + $n > $max;

            $i = $eol + 2;
            if $n == 0 {
                # 末块：其后为可选 trailer，结束于一个空行
                my int $end = find-crlf($buf, $i);
                return Nil if $end < 0;
                $i = $end + 2;
                return { body => $body, consumed => $i };
            }

            return Nil if $buf.elems < $i + $n + 2;
            $body.append: $buf.subbuf($i, $n);
            $i += $n + 2;
            return Nil if $buf.elems < $i + 1;           # 还需后续尺寸行
        }
    }

    #| 从 $from 开始找 CRLF，返回 '\r' 的字节下标；未找到返回 -1
    sub find-crlf(Buf $buf, int $from --> Int) {
        my int $i = $from;
        my int $last = $buf.elems - 1;
        while $i < $last {
            if $buf[$i] == 13 && $buf[$i + 1] == 10 {
                return $i;
            }
            $i++;
        }
        -1
    }

    sub bad-request($message) {
        die Cro::HTTP::Exception.new(:400status, :$message);
    }

    #| 抛带状态码的 Cro 异常；transformer 的 CATCH 会把它转成 LiteBadRequest
    sub http-error(Int $status, $message) {
        die Cro::HTTP::Exception.new(status => $status, :$message);
    }
}
