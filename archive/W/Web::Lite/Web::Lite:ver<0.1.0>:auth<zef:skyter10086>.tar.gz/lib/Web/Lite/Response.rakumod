#| 响应对象与构造器。
#|
#| LiteResponse 是 Cro::HTTP::Response 的子类，额外带一份「已编码好的字节体」。
#| 原因：Cro 的 $resp.body-blob 每调用一次要造 Promise / 挂供应流，实测约 190 us/次，
#| 而一次请求只需要取一次字节体。子类仍然 is-a Cro::HTTP::Response，所以
#| 中间件、Cro 原生 ResponseSerializer 都能照常吃，只是自家序列化器改走 $.lite-body 快路。
unit module Web::Lite::Response;

use Cro::HTTP::Response;

class LiteResponse is Cro::HTTP::Response is export {
    has $.lite-body;      # Blob，已 UTF-8 编码的响应体

    method set-lite-body(Blob $b) {
        $!lite-body = $b;
        self;
    }
}

#| 构造一个带文本体的响应。
#| Cro::HTTP::Response 的 content-type 是从 header 派生的只读属性，
#| body 必须经 set-body 设置（new 不接收 body-blob），故统一封装。
our sub make-response(
    Int $status,
    Str $content-type,
    Str $body --> LiteResponse
) is export {
    my $buf = $body.encode('utf-8');
    my $r = LiteResponse.new(:$status);
    $r.append-header('Content-Type', $content-type) if $content-type.chars;
    $r.set-body($buf);
    $r.set-lite-body($buf);
    $r;
}

#| 构造一个无体的响应（如 204）。
our sub make-empty-response(Int $status --> LiteResponse) is export {
    my $r = LiteResponse.new(:$status);
    $r.set-lite-body(Buf);
    $r;
}
