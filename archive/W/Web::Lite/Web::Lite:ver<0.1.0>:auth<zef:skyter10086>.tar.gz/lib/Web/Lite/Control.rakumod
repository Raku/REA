#| 控制流标记对象：halt 立刻结束处理并直接采用给定响应，pass 表示"本层不处理，继续往下走"。
#|
#| 为什么用标记对象而不是异常：异常在异步链（Promise）里会变成 broken Promise，
#| 要额外兜底一次；标记对象是普通返回值，同步异步两条路径都能被 !bind 直接识别。
unit module Web::Lite::Control;

#| halt 的载体：$.value 是最终响应（Response / Str / Hash / Nil）
class Halt is export {
    has $.value;
}

#| pass 的载体：单例
class Pass is export {
    method gist(--> Str) { 'Pass' }
}

my $PASS = Pass.new;

#| 中断处理，用 $value 作为最终响应
our sub halt($value --> Halt) is export {
    Halt.new(:$value);
}

#| 交回上一层继续处理
our sub pass(--> Pass) is export {
    $PASS;
}
