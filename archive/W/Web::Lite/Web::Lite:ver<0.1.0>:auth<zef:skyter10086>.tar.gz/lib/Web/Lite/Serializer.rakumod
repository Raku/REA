#| 轻量响应序列化器：把响应直接拼成字节，绕开 Cro 的 ResponseSerializer。
#|
#| 两处快路：
#| 1) 响应体走 Web::Lite::Response::LiteResponse 的 $.lite-body（已编码字节），
#|    避开 Cro $resp.body-blob 每次约 190 us 的 Promise / 供应流开销；
#| 2) Date 头秒级缓存，同一秒内共用一个字符串。
#| 契约和 Cro 一致：consumes Cro::HTTP::Response，produces Cro::TCP::Message，
#| 未带 lite-body 的普通 Cro::HTTP::Response 自动回退到 body-blob 路径。
#|
#| 具体拼装逻辑以 serialize-response / close-required 两个导出 sub 的形式给出，
#| 供 LiteSerializer 与合并版 Web::Lite::Combined 共用，避免两份实现走偏。
unit module Web::Lite::Serializer;

use Cro::Transform;
use Cro::TCP;
use Cro::HTTP::Request;
use Cro::HTTP::Response;
use Web::Lite::Response;

my constant %REASON =
    100 => 'Continue', 101 => 'Switching Protocols',
    200 => 'OK', 201 => 'Created', 202 => 'Accepted', 204 => 'No Content',
    206 => 'Partial Content',
    301 => 'Moved Permanently', 302 => 'Found', 303 => 'See Other',
    304 => 'Not Modified', 307 => 'Temporary Redirect', 308 => 'Permanent Redirect',
    400 => 'Bad Request', 401 => 'Unauthorized', 403 => 'Forbidden', 404 => 'Not Found',
    405 => 'Method Not Allowed', 406 => 'Not Acceptable', 408 => 'Request Timeout',
    409 => 'Conflict',
    413 => 'Payload Too Large', 414 => 'URI Too Long', 415 => 'Unsupported Media Type',
    431 => 'Request Header Fields Too Large',
    422 => 'Unprocessable Entity', 429 => 'Too Many Requests',
    500 => 'Internal Server Error', 501 => 'Not Implemented',
    502 => 'Bad Gateway', 503 => 'Service Unavailable', 504 => 'Gateway Timeout';

my $cached-date = '';
my $cached-sec = -1;
my @DOW = <Sun Mon Tue Wed Thu Fri Sat>;
my @MON = <Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec>;

#| 任意时刻 -> RFC 7231 HTTP-date（Cookie 的 Expires 等场景要用）
our sub format-http-date(DateTime $dt --> Str) is export {
    my $u = $dt.utc;
    sprintf '%s, %02d %s %04d %02d:%02d:%02d GMT',
        @DOW[$u.day-of-week % 7], $u.day, @MON[$u.month - 1], $u.year,
        $u.hour, $u.minute, $u.second;
}

sub http-date(--> Str) {
    my $now = DateTime.now.utc;
    my $sec = $now.posix.Int;
    if $sec != $cached-sec {
        $cached-sec = $sec;
        $cached-date = format-http-date($now);
    }
    $cached-date;
}

#| 该响应结束后是否需要关闭连接（HTTP/1.0 无 keep-alive、或任一端要求 close）
sub close-required(Cro::HTTP::Response $resp --> Bool) is export {
    my $req = $resp.request;
    my $close = False;
    if $req.defined {
        my $hc = $req.header('Connection');
        $close = True if ($hc.defined && $hc.lc.contains('close'));
        $close = True if $req.http-version eq '1.0' && !($hc.defined && $hc.lc.contains('keep-alive'));
    }
    my $conn = $resp.header('Connection');
    $close = True if $conn.defined && $conn.lc.contains('close');
    $close;
}

#| 把响应 + 已编码的 body 拼成一条 TCP 报文
sub build-message(Cro::HTTP::Response $resp, $body --> Cro::TCP::Message) is export {
    my $status = $resp.status;
    my $req = $resp.request;

    # HEAD：头部照发（含真实的 Content-Length），但一个字节的体都不能发，
    # 否则 keep-alive 连接上的下一条响应会被客户端当成前一条的体，直接错位。
    my $is-head = $req.defined && $req.method.uc eq 'HEAD';

    my $close = close-required($resp);
    my $head = "HTTP/1.1 $status " ~ (%REASON{$status} // 'Unknown') ~ "\r\n";
    my $has-date = False;
    my $has-length = False;
    my $has-conn = False;
    for $resp.headers -> $h {
        my $lc = $h.name.lc;
        $has-date = True if $lc eq 'date';
        $has-length = True if $lc eq 'content-length';
        $has-conn = True if $lc eq 'connection';
        $head ~= $h.name ~ ': ' ~ $h.value ~ "\r\n";
    }
    $head ~= 'Date: ' ~ http-date() ~ "\r\n" unless $has-date;
    my $n = $body.defined ?? $body.bytes !! 0;
    $head ~= 'Content-Length: ' ~ $n ~ "\r\n" unless $has-length;

    # 关闭意图必须写进响应头，否则客户端只能靠 EOF 猜
    unless $has-conn {
        if $close {
            $head ~= "Connection: close\r\n";
        }
        elsif $req.defined && $req.http-version eq '1.0' {
            $head ~= "Connection: keep-alive\r\n";
        }
    }

    $head ~= "\r\n";
    my $payload = ($is-head || !$body.defined) ?? Buf.new !! $body;
    Cro::TCP::Message.new(:data($head.encode('utf-8') ~ $payload));
}

#| 同步序列化：响应体已就位（LiteResponse 或已 Kept 的 body-blob）时一步到位。
#| 无法同步取体时返回 Nil，调用方自行走异步路径。
sub serialize-response(Cro::HTTP::Response $resp --> Cro::TCP::Message) is export {
    my $lite = $resp ~~ LiteResponse ?? $resp.lite-body !! Nil;
    return build-message($resp, $lite) if $lite.defined;
    my $bp = $resp.body-blob;
    return Nil unless $bp.status ~~ Kept;
    build-message($resp, $bp.result);
}

class LiteSerializer does Cro::Transform is export {
    method consumes(--> Cro::HTTP::Message) { Cro::HTTP::Response }
    method produces(--> Cro::TCP::Message) { Cro::TCP::Message }

    method transformer(Supply $responses --> Supply) {
        supply {
            whenever $responses -> $resp {
                my $close = close-required($resp);
                my $msg = serialize-response($resp);
                if $msg.defined {
                    emit $msg;
                }
                else {
                    whenever $resp.body-blob -> $body {
                        emit build-message($resp, $body);
                    }
                }
                done if $close;
            }
        }
    }
}
