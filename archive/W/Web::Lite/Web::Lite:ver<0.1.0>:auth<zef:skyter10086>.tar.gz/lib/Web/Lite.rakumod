use Cro::Transform;
use Cro::HTTP::Request;
use Cro::HTTP::Response;

unit class Web::Lite does Cro::Transform;

use Web::Lite::Route;
use Web::Lite::Context;
use Web::Lite::Response;
use Web::Lite::Control;
use Cro::HTTP::Server;
use Web::Lite::Transport;
use Web::Lite::Parser;
use Web::Lite::Serializer;
use Web::Lite::Static;
use Web::Lite::Session;
use JSON::Fast;

#| 坏请求/解析错误的默认文案（不进路由，直接按状态码回话）
my constant %BAD-TEXT =
    400 => 'Bad Request',
    408 => 'Request Timeout',
    413 => 'Payload Too Large',
    414 => 'URI Too Long',
    431 => 'Request Header Fields Too Large',
    500 => 'Internal Server Error',
    504 => 'Gateway Timeout',
    505 => 'HTTP Version Not Supported';

#| 注册的路由（按注册顺序，用于自省）
has @!routes;

#| 静态路由索引：%!static{method}{canonical-path} => Route —— 热路径一次哈希查找
has %!static;

#| 已知路径表：%!known-path{path}{method} = True —— 供 405 的 Allow 头
has %!known-path;

#| 动态路由（含 {param} 或 * 通配），保持注册顺序
has @!dynamic;

#| 前置中间件：-> $ctx { }，返回 Nil 继续，返回 Response 短路
has @!middleware;

#| 后置钩子：-> $ctx, $response { }，返回 Response 则替换
has @!after-hooks;

has &!not-found;
has &!on-error;

#| $app.session 建的 store，Nil 表示没开会话
has $!session-store;

#| DSL 前缀（scope 块内注册的路由自动带前缀）
has Str $!prefix = '';

#| 全站已注册的方法集合，供 OPTIONS * 用
has %!methods;

#| 自动 OPTIONS 开关
has Bool $.auto-options = True;

has Str $.host = '0.0.0.0';
has Int $.port = 3000;
has Bool $.debug = False;

#| 单个请求的处理上限（秒）。超时回 504 并关连接，避免慢 handler 把连接永久占住。
#| 0 表示不限制（不建议暴露到公网时使用）。
has Real $.timeout = 30;

#| 请求头读超时（秒）：半截请求停滞超过此值回 408，防 slowloris。0 = 不限制。
has Real $.read-timeout = 15;

#| 请求体读超时（秒）：头已收全、body 迟迟传不完则回 408。0 = 不限制。
has Real $.body-timeout = 60;

#| 请求体上限（字节）：超出回 413，且不等 body 收完就拒。
#| 默认 2 MB —— 无上限时单个客户端发一个大 body 就能把进程内存吃掉。
has Int $.max-body-bytes = 2 * 1024 * 1024;

#| 优雅关闭的宽限期（秒）：先停止接收新连接，等已有连接把手上请求处理完，
#| 超时再强制断开。0 表示立刻断（等同旧行为）。
has Real $.shutdown-grace = 10;

#| 关停中？为真时所有响应都带 Connection: close，逼客户端在本次响应后断开
has Bool $!draining = False;

#| start 出来的对象引用，供 shutdown 用
has $!listener;
has $!server;

#|--- 路径工具（热路径不用正则） -----------------------------------------

#| 规整路径：去 scheme/authority、去 query/fragment、压缩重复斜杠、去尾部斜杠
sub canonical(Str $p is copy --> Str) {
    if $p.contains('://') {
        my $i = $p.index('://');
        my $j = $p.index('/', $i + 3);
        $p = $j.defined ?? $p.substr($j) !! '/';
    }
    my $q = $p.index('?');
    $p = $p.substr(0, $q) if $q.defined;
    $q = $p.index('#');
    $p = $p.substr(0, $q) if $q.defined;
    $p = '/' unless $p.chars;
    $p = $p.subst(/'//'+/, '/', :g) if $p.contains('//');
    $p = $p.substr(0, $p.chars - 1) while $p.chars > 1 && $p.ends-with('/');
    $p;
}

#| 无参数、无通配的路径走静态表
sub is-static-pattern(Str $p --> Bool) {
    !($p.contains('{') || $p.contains('*'))
}

#| canonical 路径切段（忽略空段）
sub path-segments(Str $p --> List) {
    $p eq '/' ?? List.new !! $p.substr(1).split('/').grep({ .chars }).List;
}

#|--- 注册 ---------------------------------------------------------------

method use(&mw --> Nil) { @!middleware.push(&mw) }

#| use 的别名，语义更贴近「前置中间件」
method before(&mw --> Nil) { @!middleware.push(&mw) }

method after(&hook --> Nil) { @!after-hooks.push(&hook) }

method on-not-found(&h --> Nil) { &!not-found = &h }

method on-server-error(&h --> Nil) { &!on-error = &h }

method !add(Str $method, Str $path, &handler, $name) {
    my Str $p = $!prefix.chars ?? canonical($!prefix ~ '/' ~ $path) !! $path;
    my $route = Web::Lite::Route.new(:$method, pattern => $p, :&handler, :$name);
    @!routes.push: $route;
    %!methods{$method} = True;

    if is-static-pattern($p) {
        my $key = canonical($p);
        %!static{$method}{$key} = $route;
        %!known-path{$key}{$method} = True;
    }
    else {
        @!dynamic.push: $route;
    }
    Nil
}

method get(Str $path, &handler, :$name)     { self!add('GET',     $path, &handler, $name) }
method post(Str $path, &handler, :$name)    { self!add('POST',    $path, &handler, $name) }
method put(Str $path, &handler, :$name)     { self!add('PUT',     $path, &handler, $name) }
method patch(Str $path, &handler, :$name)   { self!add('PATCH',   $path, &handler, $name) }
method delete(Str $path, &handler, :$name)  { self!add('DELETE',  $path, &handler, $name) }
method head(Str $path, &handler, :$name)    { self!add('HEAD',    $path, &handler, $name) }
method options(Str $path, &handler, :$name) { self!add('OPTIONS', $path, &handler, $name) }

#| any 注册同一处理器到常用的全部方法上
method any(Str $path, &handler, :$name) {
    self!add($_, $path, &handler, $name) for <GET POST PUT PATCH DELETE HEAD OPTIONS>;
    Nil
}

#| 前缀分组：scope '/api' => { .get('/x', &h) }，块参数是被调用者的 self
method scope(Str $path, &block --> Nil) {
    my Str $prev = $!prefix;
    $!prefix = $prev.chars ?? canonical($prev ~ '/' ~ $path) !! canonical($path);
    {
        CATCH { default { $!prefix = $prev; .rethrow } }
        block(self);
    }();
    $!prefix = $prev;
    Nil
}

method routes(--> List) { @!routes.List }

#| 反向生成 URL：$app.url-for('user-detail', id => 5) => '/user/5'
#|
#| 传路由名时按 name 查表；查不到就把入参当模式本身处理，
#| 于是 $app.url-for('/post/{slug}/**', slug => 'a', _splat => <x y>) 也能用。
#| 同名路由取最先注册的那条（静态目录的 name 都是 'static'，只认首个）。
method url-for(Str $name-or-pattern, *%params --> Str) {
    my $route = @!routes.first({ $_.name.defined && $_.name eq $name-or-pattern });
    my Str $pattern = $route.defined ?? $route.pattern !! $name-or-pattern;
    Web::Lite::Route::fill-pattern($pattern, %params);
}

#| 按名字取路由（调试用），没有则 Nil
method route-named(Str $name) {
    @!routes.first({ $_.name.defined && $_.name eq $name });
}

#| 挂一个静态目录：$app.static('/assets', 'public')
#|
#| 只注册 GET，HEAD 会自动回落到 GET 并由序列化层剥掉响应体；
#| 目录本身只认 index.html，不做目录列表（列目录等于泄露文件结构）。
#| 访问路径里的 `..` 穿越、以及解码后跳出根目录的写法，在 handler 里逐段拦掉。
method static(
    Str $prefix,
    Str $dir,
    Bool :$cache = True,
    Int :$max-file-bytes = 32 * 1024 * 1024,
    --> Nil
) {
    my &handler = Web::Lite::Static::static-handler(
        $dir.IO, :$cache, :$max-file-bytes,
    );
    my Str $p = canonical($prefix);
    self.get($p, &handler, name => 'static');
    self.get(canonical($p ~ '/**'), &handler, name => 'static');
    Nil;
}

#| 开启签名 cookie 会话：$app.session(secret => 'xxx')
#|
#| 数据整个存在 cookie 里（无服务端存储），所以只适合放 user-id、flash 这类小东西。
#| 实现上注册两段：前置中间件读 cookie 建 Session 塞进 stash，
#| 后置钩子发现 Session 被改过就把新值写回 Set-Cookie。
#| 注意钩子块里一律用表达式结尾，不能写 return（Block 里 return 会抛异常）。
method session(
    Str :$secret!,
    Str :$cookie-name = 'weblite.session',
    Int :$max-age = 604800,
    Str :$path = '/',
    Str :$domain,
    Bool :$secure = False,
    Bool :$http-only = True,
    Str :$same-site = 'Lax',
    --> Nil
) {
    die X::AdHoc.new(payload => 'session: secret 不能为空') unless $secret.chars;

    my $store = Web::Lite::Session::SessionStore.new(
        :$secret, :$cookie-name, :$max-age, :$path, :$domain,
        :$secure, :$http-only, :$same-site,
    );
    $!session-store = $store;

    self.use(-> $ctx {
        my Str $raw = $ctx.cookie($store.cookie-name);
        my $s = $raw.chars ?? $store.decode($raw) !! Web::Lite::Session::Session.new;
        $ctx.set('__weblite.session', $s);
        Nil;
    });

    self.after(-> $ctx, $resp {
        my $s = $ctx.stash-get('__weblite.session');
        if $s.defined && $s.dirty {
            $ctx.set-cookie(
                $store.cookie-name,
                $store.encode($s.data),
                path      => $store.path,
                domain    => $store.domain,
                max-age   => $store.max-age,
                secure    => $store.secure,
                http-only => $store.http-only,
                same-site => $store.same-site,
            );
            $s.reset-dirty;
        }
        $resp;
    });

    Nil;
}

#| 当前会话配置（调试/取 cookie 名用），未开启则 Nil
method session-store() { $!session-store }

#| 路由表构成（调试用）
method route-stats(--> Hash) {
    static  => @!routes.grep({ is-static-pattern(.pattern) }).elems,
    dynamic => @!dynamic.elems,
    total   => @!routes.elems,
}

#|--- 分发：同步优先 -----------------------------------------------------

#| 对外 API：始终返回 Promise<Response>（保持既有签名）
method handle(Str $method, Cro::HTTP::Request $request, @path --> Promise) {
    start {
        my $r = self!run($method, $request, @path.List);
        $r ~~ Promise ?? await $r !! $r;
    }
}

#| 路由查找：静态表优先（一次哈希），未命中再按注册顺序扫动态路由。
#| 静态/动态两套逻辑原先在快慢路径里各写一份，这里收成唯一入口。
#| 返回 ( $route, %params )；未命中返回 ( Any, %() )。
method !match-route(Str $method, Str $path) {
    if %!static{$method} -> %by-path {
        my $hit = %by-path{$path};
        return ($hit, %()) if $hit.defined;
    }
    my $segs = path-segments($path);
    for @!dynamic -> $r {
        next unless $r.method eq $method;
        my $p = $r.match($segs);
        return ($r, $p) if $p.defined;
    }
    (Any, %());
}

#| 热路径：全同步时直接返回 Response，链路含异步才返回 Promise<Response>
method !run(Str $method, Cro::HTTP::Request $request, @path) {
    my Str $path = @path.elems ?? '/' ~ @path.join('/') !! canonical(~$request.target);

    # HEAD：显式注册的 HEAD 路由优先，没注册才回落到 GET（响应体由序列化层剥掉）
    my @tries = $method eq 'HEAD' ?? ('HEAD', 'GET') !! ($method,);

    my $route;
    my %params;
    for @tries -> $m {
        my @found = self!match-route($m, $path);
        $route = @found[0];
        # 注意别写成 ($route, %params) = ...：列表解构把 Hash 当成单个值元素塞进 %params，
        # 会直接抛「Odd number of elements found where hash initializer expected」
        %params = @found[1] // %();
        last if $route.defined;
    }

    unless $route.defined {
        # OPTIONS 且无显式路由：按该路径已注册的方法自动回 Allow + 204
        return self!auto-options($request, $path) if $method eq 'OPTIONS' && $!auto-options;
        return self!not-found-path($method, $request, $path);
    }

    # 注意这里必须 params => %params：写成 :%params 会把参数 Hash 展开成命名参数，
    # 路由参数 id 就变成「不存在的属性 id」，直接炸在 Context 构造上
    my $ctx = Web::Lite::Context.new(:$request, params => %params, app => self);

    # ---- 快路径：无中间件、无后置钩子、同步 handler ----
    # 省掉 !invoke / !bind / !finish 三层闭包调用，是每请求固定成本的大头
    if !@!middleware.elems && !@!after-hooks.elems {
        my $err;
        my $out = do {
            CATCH { default { $err = $_ } }
            $route.handler.($ctx);
        };
        return self!server-error($ctx, $err) if $err.defined;
        return $out if $out ~~ Promise;
        my $resp = self!coerce($out ~~ Halt ?? $out.value !! $out);
        $resp.request = $request;
        # handler 里 set-cookie 但返回的不是 $c.xxx 造出来的响应时，这里兜底贴上
        $ctx.adopt($resp);
        return $resp;
    }

    self!invoke($ctx, $route);
}

#| 中间件 -> handler -> 后置钩子；任何一步返回 Promise 才转成 Promise 链
method !invoke(Web::Lite::Context $ctx, $route --> Mu) {
    my $mw = self!run-middleware($ctx);

    self!bind($mw, -> $short {
        # halt：跳过 handler，直接用给定值作响应（后置钩子照常跑）
        # 注意：回调块内一律用表达式，禁止 return —— Block 里 return 会抛
        # "Attempt to return outside of any Routine"，在异步链上直接变成零响应。
        if $short ~~ Halt {
            self!finish($ctx, self!coerce($short.value))
        }
        elsif $short ~~ Cro::HTTP::Response {
            self!finish($ctx, $short)
        }
        else {
            my $err;
            my $out = do {
                CATCH { default { $err = $_ } }
                $route.handler.($ctx);
            };
            if $err.defined {
                self!server-error($ctx, $err)
            }
            else {
                self!bind($out, -> $value {
                    my $resp = self!coerce($value ~~ Halt ?? $value.value !! $value);
                    self!finish($ctx, $resp);
                });
            }
        }
    });
}

#| 前置中间件；返回 Nil/pass（继续）/ Halt 或 Response（短路）/ Promise
method !run-middleware(Web::Lite::Context $ctx, Int $idx is copy = 0 --> Mu) {
    while $idx < @!middleware.elems {
        my &mw = @!middleware[$idx];
        my $res = mw($ctx);
        if $res ~~ Promise {
            my $next = $idx + 1;
            return $res.then({
                my $v = $_.result;
                $v ~~ Halt ?? $v
                    !! ($v ~~ Cro::HTTP::Response ?? $v !! self!run-middleware($ctx, $next));
            });
        }
        return $res if $res ~~ Halt;
        return $res if $res ~~ Cro::HTTP::Response;
        $idx++;   # nil / pass 都继续往下走
    }
    Nil;
}

#| 后置钩子 + 把 request 挂回 response（序列化器需要）
method !finish(Web::Lite::Context $ctx, Cro::HTTP::Response $resp --> Mu) {
    my $hook = self!run-hooks($ctx, $resp, 0);
    self!bind($hook, -> $final {
        my $r = $final ~~ Cro::HTTP::Response ?? $final !! $resp;
        $r.request = $ctx.request;
        # 后置钩子（session 等）可能在这之后才 set-cookie，
        # 而 !with-headers 早在 handler 返回时就跑过了，这里兜底贴一次。
        # adopt 幂等，已经贴过不会重复。
        $ctx.adopt($r);
    });
}

method !run-hooks(Web::Lite::Context $ctx, $resp, Int $idx) {
    return $resp if $idx >= @!after-hooks.elems;
    my &hook = @!after-hooks[$idx];
    my $r = hook($ctx, $resp);
    self!bind($r, -> $v {
        self!run-hooks($ctx, ($v ~~ Cro::HTTP::Response ?? $v !! $resp), $idx + 1);
    });
}

#| 同步/异步粘合：$v 是 Promise 就 then（Raku 的 then 自动摊平返回的 Promise）
method !bind($v, &next --> Mu) {
    return $v.then({ next($_.result) }) if $v ~~ Promise;
    next($v);
}

#| handler 返回值归一：Halt 取内层值，Response 原样，Str 当文本，Hash/List 当 JSON，其余 toString
method !coerce($value --> Cro::HTTP::Response) {
    $value = $value.value if $value ~~ Halt;
    return $value if $value ~~ Cro::HTTP::Response;
    return make-empty-response(204) without $value;
    if $value ~~ Hash || $value ~~ List {
        return make-response(200, 'application/json; charset=utf-8', to-json($value));
    }
    make-response(200, 'text/plain; charset=utf-8', $value.Str);
}

#| 错误响应统一出口：!server-error（同步链路）与 transformer（异步链路）都走这里，
#| 避免两套实现给出不一样的状态码/headers。
#| 约定：on-server-error 注册的回调必须**同步**返回（Str/Hash/Response），
#| 返回 Promise 会被忽略并回落到默认 500 —— 在 loop 线程上 await 会直接卡死连接。
method !error-response(Cro::HTTP::Request $request, $err, Web::Lite::Context $ctx? --> Cro::HTTP::Response) {
    note "Web::Lite handler error: { $err.message }" if $!debug;

    my $handler = &!on-error;
    if $handler {
        my $out;
        my $handler-died = False;
        {
            CATCH { default { $handler-died = True } }
            my $c = $ctx // Web::Lite::Context.new(:$request, params => %(), app => self);
            $out = $handler($c, $err);
        }
        if !$handler-died && !($out ~~ Promise) {
            my $resp;
            my $coerce-died = False;
            {
                CATCH { default { $coerce-died = True } }
                $resp = self!coerce($out);
            }
            if !$coerce-died && $resp.defined {
                # on-error 回 Hash/Str 时 !coerce 会当 200 处理，但这是错误分支，必须 500
                $resp.status = 500
                    if !($out ~~ Cro::HTTP::Response) && $resp.status == 200;
                $resp.request = $request;
                return $resp;
            }
        }
    }

    my $resp = make-response(500, 'text/plain; charset=utf-8',
                             "500 Internal Server Error\n");
    $resp.request = $request;
    $resp;
}

#| 同步链路上的服务端错误：走统一出口，再经后置钩子
method !server-error(Web::Lite::Context $ctx, $err --> Mu) {
    self!finish($ctx, self!error-response($ctx.request, $err, $ctx));
}

#| 把「可能断链的 Promise」收成一个永不 broken 的 Promise：
#| broken 一律转成兜底 500；成功值一律归一成 Response（异步 handler 返回 Str/Hash 也成立）。
#| $!timeout > 0 时与定时器竞速，超时先到则回 504 + Connection: close。
method !settle(Cro::HTTP::Request $request, Promise $p --> Promise) {
    my $done = $p.then({
        my $value;
        my $err;
        {
            CATCH { default { $err = $_ } }
            $value = $_.result;
        }
        # 回调块内禁止 return，见 !invoke 处说明
        if $err.defined {
            self!error-response($request, $err)
        }
        else {
            my $resp;
            my $cerr;
            {
                CATCH { default { $cerr = $_ } }
                $resp = self!coerce($value);
            }
            if $cerr.defined {
                self!error-response($request, $cerr)
            }
            else {
                $resp.request = $request unless $resp.request.defined;
                $resp;
            }
        }
    });

    return $done if $!timeout <= 0;

    Promise.anyof($done, Promise.in($!timeout)).then({
        # 超时判定：$done 尚未完成即视为超时；已完成则用它自己的结果
        if $done.status ~~ Kept {
            $done.result
        }
        else {
            note "Web::Lite request timeout after { $!timeout }s" if $!debug;
            my $resp = make-response(504, 'text/plain; charset=utf-8',
                                     "504 Gateway Timeout\n");
            # 超时的 handler 可能still在跑，响应体长度不可信，连接必须关
            $resp.append-header('Connection', 'close');
            $resp.request = $request;
            $resp;
        }
    });
}

#| 排空期（shutdown 已开始）给每条响应打上 Connection: close：
#| keep-alive 客户端拿到后会在本次响应结束时主动断开，优雅关闭才可能等到
#| 连接归零；否则只能靠宽限期硬断，等于没优雅。
method !drain-mark($resp) {
    return $resp unless $!draining;
    return $resp unless $resp ~~ Cro::HTTP::Response;
    try $resp.remove-header('Connection');
    $resp.append-header('Connection', 'close');
    $resp;
}

#| 解析失败的兜底响应：状态码照实回，并声明关闭连接（流里的残留字节已不可信）
method !bad-request-response(Cro::HTTP::Request $request, Int $status --> Cro::HTTP::Response) {
    my $text = %BAD-TEXT{$status} // 'Bad Request';
    my $resp = make-response($status, 'text/plain; charset=utf-8', "$status $text\n");
    $resp.append-header('Connection', 'close');
    $resp.request = $request;
    $resp;
}

#| 该路径允许的方法集合：静态索引优先，其次扫动态路由
method !allow-for(Str $path --> List) {
    my @allow = %!known-path{$path}.defined ?? %!known-path{$path}.keys.sort !! ();
    if !@allow {
        my $segs = path-segments($path);
        @allow = @!dynamic.grep({ .match($segs).defined }).map(*.method).unique.sort;
    }
    @allow.List;
}

#| 自动 OPTIONS：OPTIONS * 回全站方法集合，否则回该路径的方法集合；什么都没有则按 404 走
method !auto-options(Cro::HTTP::Request $request, Str $path --> Mu) {
    my Str $t = ~$request.target;
    my @allow = ($t eq '*' || $t eq '/*') ?? %!methods.keys.sort !! self!allow-for($path);
    return self!not-found-path('OPTIONS', $request, $path) unless @allow.elems;

    my %m = @allow.map({ $_ => True }).Hash;
    %m<HEAD> = True if %m<GET>;
    %m<OPTIONS> = True;

    my $resp = make-empty-response(204);
    $resp.append-header('Allow', %m.keys.sort.join(', '));
    $resp.request = $request;
    $resp;
}

#| 未命中：同路径别的动词给 405（Allow 里补 HEAD / OPTIONS），否则 404
method !not-found-path(Str $method, Cro::HTTP::Request $request, Str $path --> Mu) {
    my @allow = self!allow-for($path);

    my Bool $allowed = False;
    for @allow -> $m {
        $allowed = True if $m eq $method;
        $allowed = True if $method eq 'HEAD' && $m eq 'GET';
    }

    if @allow.elems && !$allowed {
        my %m = @allow.map({ $_ => True }).Hash;
        %m<HEAD> = True if %m<GET>;
        %m<OPTIONS> = True if $!auto-options;

        my $resp = make-response(405, 'text/plain; charset=utf-8',
                                 "405 Method Not Allowed\n");
        $resp.append-header('Allow', %m.keys.sort.join(', '));
        $resp.request = $request;
        return $resp;
    }

    my $ctx = Web::Lite::Context.new(:$request, params => %(), app => self);
    my $custom = &!not-found;
    return self!finish($ctx, make-response(404, 'text/plain; charset=utf-8',
                                           "404 Not Found\n")) unless $custom;

    my $r = $custom($ctx);
    self!bind($r, -> $v { self!finish($ctx, self!coerce($v)) });
}

#|--- Cro::Transform 接入 -------------------------------------------------

method consumes(--> Cro::HTTP::Message) { Cro::HTTP::Request }

method produces(--> Cro::HTTP::Message) { Cro::HTTP::Response }

#| 把请求路径切成段（保留给外部调用方）
method !segments(Cro::HTTP::Request $request --> List) {
    path-segments(canonical(~$request.target));
}

method transformer(Supply $requests --> Supply) {
    supply {
        # 无 body 的请求在 loop 线程内直接跑完（零线程、零 Promise）；
        # 带 body 的请求必须让出 loop 线程，否则读取 body 会与 loop 自身死锁。
        my $pending;

        whenever $requests -> $request {
            # 解析层（LiteParser）判定为坏请求：不进路由，直接回状态码并关连接。
            # 少了这条，坏请求的表现是「客户端零响应 + 连接挂在半空」。
            if $request ~~ LiteBadRequest {
                emit self!drain-mark(self!bad-request-response($request, $request.lite-status.Int));
                next;
            }

            my $busy = $pending.defined && $pending.status !~~ Kept;

            if !$busy && !$request.has-body {
                my $err;
                my $out = do {
                    CATCH { default { $err = $_ } }
                    self!run($request.method, $request, List.new);
                };
                if $err.defined {
                    emit self!drain-mark(self!error-response($request, $err));
                }
                elsif $out ~~ Promise {
                    # handler 自己返回了 Promise（异步业务逻辑）：断链必须兜底成 500，
                    # 让 broken 的 Promise 穿透 supply 会让整条连接再也发不出响应
                    my $safe = self!settle($request, $out);
                    $pending = $safe;
                    whenever $safe -> $response { emit self!drain-mark($response) }
                }
                else {
                    emit self!drain-mark($out);
                }
            }
            else {
                # 同一连接上响应必须保序：排在上一个请求之后
                my $prev = $pending;
                my $p = start {
                    await $prev if $prev.defined;
                    my $err;
                    my $out = do {
                        CATCH { default { $err = $_ } }
                        self!run($request.method, $request, List.new);
                    };
                    if $err.defined {
                        self!error-response($request, $err);
                    }
                    elsif $out ~~ Promise {
                        await $out;
                    }
                    else {
                        $out;
                    }
                };
                my $safe = self!settle($request, $p);
                $pending = $safe;
                whenever $safe -> $response { emit self!drain-mark($response) }
            }
        }
    }
}

#| 启动并返回 server 对象（不阻塞，便于测试/嵌入）
#| 解析层参数（读超时 / body 上限）从这里透传给 LiteParser —— 应用层的
#| 配置是唯一入口，避免两处默认值各说各话。
method start(Str :$host = $!host, Int :$port = $!port, Str :$transport = 'raw') {
    my $server;
    if $transport eq 'cro' {
        $server = Cro::HTTP::Server.new(
            host => $host, port => $port, application => self
        );
    }
    else {
        my $listener = RawListener.new(:$host, :$port);
        $!listener = $listener;
        $server = assemble(
            $listener,
            self,
            LiteSerializer.new,
            LiteParser.new(
                :max-body-bytes($!max-body-bytes),
                :read-timeout($!read-timeout),
                :body-timeout($!body-timeout),
            ),
        );
    }
    $!server = $server;
    $server.start;
    $server;
}

#| 优雅关闭：停收新连接 -> 等已有连接把手上请求处理完 -> 强制断开剩余。
#| 返回 True 表示在宽限期内自然排空（没有靠强制断开收尾）。
#| 关停期间所有响应都会带 Connection: close，正常客户端拿到就断开，
#| 所以等待通常远短于 $grace。
method shutdown(Real :$grace = $!shutdown-grace --> Bool) {
    # 幂等：重复调用（如 run 的 signal 处理器 + 测试的 LEAVE）直接返回，
    # 否则会对已经停掉的 service 再 stop 一次，Cro 会打警告
    return True if $!draining;
    $!draining = True;

    # 1) 不再接收新连接；已建立的连接继续服务
    with $!listener { .stop-accepting }

    # 2) 等连接自然结束
    my $deadline = now + $grace;
    my Bool $drained = False;
    loop {
        my Int $n = $!listener.defined ?? $!listener.connection-count !! 0;
        if $n == 0 { $drained = True; last }
        last if now >= $deadline;
        sleep 0.02;
    }

    # 3) 兜底：宽限期到了还有连接（客户端耍赖 / 正在传大 body）就硬断
    with $!listener { .close-connections }
    with $!server { .stop }
    $drained;
}

#| 是否处于关停中
method draining(--> Bool) { $!draining }

#| 启动并阻塞，Ctrl-C 优雅退出
method run(Str :$host = $!host, Int :$port = $!port, Str :$transport = 'raw' --> Nil) {
    self.start(:$host, :$port, :$transport);
    note "Web::Lite listening on http://{ $host }:{ $port }  ("
        ~ @!routes.elems ~ " routes, " ~ @!middleware.elems ~ " middleware)";
    react {
        whenever signal(SIGINT) {
            note "Web::Lite shutting down (grace { $!shutdown-grace }s)...";
            my $drained = self.shutdown;
            note $drained ?? "Web::Lite drained cleanly." !! "Web::Lite grace expired, forced close.";
            done
        }
    }
}
