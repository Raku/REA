use lib $?FILE.IO.parent.parent.absolute ~ '/lib';
use Web::Lite::Route;

my $h = sub { 1 };

my $r = Web::Lite::Route.new(method => 'GET', pattern => '/t/{id}/*/x', handler => $h);
say 'A: ' ~ $r.match(('t', 'a%20b', 'zz', 'x')).raku;   # expect id=a b, _splat=zz
say 'B: ' ~ $r.match(('t', 'a', 'b', 'y')).raku;        # expect Nil

my $r2 = Web::Lite::Route.new(method => 'GET', pattern => '/files/*', handler => $h);
say 'C: ' ~ $r2.match(('files', 'a%2Fb')).raku;         # expect _splat=a/b (decoded)
say 'D: ' ~ $r2.match(('files',)).raku;                 # expect Nil

my $r3 = Web::Lite::Route.new(method => 'GET', pattern => '/x/**', handler => $h);
say 'E: ' ~ $r3.match(('x', 'p', 'q')).raku;            # expect _splat=p/q

my $r4 = Web::Lite::Route.new(method => 'GET', pattern => '/päth/{name}', handler => $h);
say 'F: ' ~ $r4.match(('päth', '%E4%B8%AD')).raku;      # expect name=中
