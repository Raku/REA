use lib $?FILE.IO.parent.parent.absolute ~ '/lib';
use Web::Lite;

# P0 regression probe over real TCP (synchronous client: no thread-pool starvation).
# Checks: HEAD body stripping / async die fallback / bad request response / Connection header.

my $app = Web::Lite.new;
$app.get('/', -> $ctx { 'HELLOBODY' });
$app.get('/ok', -> $ctx { 'OK' });
$app.get('/aerr', -> $ctx {
    my $p = Promise.new;
    start { $p.break('async boom') }
    $p;
});
$app.get('/serr', -> $ctx { die 'sync boom' });

my $port = 18234;
my $server = $app.start(host => '127.0.0.1', :$port);
sleep 1;

my @results;

sub probe(Str $wire) {
    my $sock = IO::Socket::INET.new(:host<127.0.0.1>, :port($port));
    $sock.write($wire.encode('utf-8'));
    my $got = '';
    loop {
        my $chunk = $sock.recv(8192);
        last unless $chunk.chars;
        $got ~= $chunk;
    }
    $sock.close;
    $got;
}

sub brief(Str $s) {
    my $t = $s.subst("\r\n", '|', :g);
    $t.chars > 120 ?? $t.substr(0, 120) !! $t;
}

sub check(Str $name, $pass, Str $detail) {
    @results.push: ?$pass;
    say ($pass ?? 'PASS' !! 'FAIL') ~ '  ' ~ $name ~ '  --  ' ~ $detail;
}

# 1. HEAD must not send body, but keeps Content-Length
my $r1 = probe("HEAD / HTTP/1.1\r\nHost: x\r\nConnection: close\r\n\r\n");
check('P0-1 HEAD strips body', $r1.contains('Content-Length: 9') && !$r1.contains('HELLOBODY'),
      'raw=' ~ brief($r1));

# 2. HEAD followed by GET on same connection must not desync
my $r2 = probe("HEAD / HTTP/1.1\r\nHost: x\r\n\r\nGET /ok HTTP/1.1\r\nHost: x\r\nConnection: close\r\n\r\n");
check('P0-1b pipelined HEAD+GET stays in sync',
      $r2.contains('HTTP/1.1 200') && $r2.contains('OK') && !$r2.contains('HELLOBODY'),
      'raw=' ~ brief($r2));

# 3. async handler breaking its promise -> 500, never zero response
my $r3 = probe("GET /aerr HTTP/1.1\r\nHost: x\r\nConnection: close\r\n\r\n");
check('P0-2 async die fallback', $r3.contains('HTTP/1.1 500'), 'raw=' ~ brief($r3));

# 4. sync handler die -> 500
my $r4 = probe("GET /serr HTTP/1.1\r\nHost: x\r\nConnection: close\r\n\r\n");
check('P0-2b sync die fallback', $r4.contains('HTTP/1.1 500'), 'raw=' ~ brief($r4));

# 5. garbage request line -> 400 with body
my $r5 = probe("GARBAGE\r\n\r\n");
check('P0-3 bad request -> 400',
      $r5.contains('HTTP/1.1 400') && $r5.contains('Bad Request'), 'raw=' ~ brief($r5));

# 6. bad HTTP version -> 400
my $r6 = probe("GET / HTTP/9.9\r\nHost: x\r\n\r\n");
check('P0-3b bad version -> 400', $r6.contains('HTTP/1.1 400'), 'raw=' ~ brief($r6));

# 7. Connection: close request -> response carries Connection header
my $r7 = probe("GET /ok HTTP/1.1\r\nHost: x\r\nConnection: close\r\n\r\n");
check('P0-4 Connection header on close request',
      $r7.contains('Connection: close') && $r7.contains('OK'), 'raw=' ~ brief($r7));

# 8. two keep-alive requests on one connection, both answered
my $r8 = probe("GET /ok HTTP/1.1\r\nHost: x\r\n\r\nGET /ok HTTP/1.1\r\nHost: x\r\nConnection: close\r\n\r\n");
check('P0-4b keep-alive reuse', $r8.comb('HTTP/1.1 200').elems == 2,
      'responses=' ~ $r8.comb('HTTP/1.1 200').elems);

$server.stop;

my $fails = @results.grep({ !$_ }).elems;
say '';
say '===== P0 summary: ' ~ (@results.elems - $fails) ~ ' passed, ' ~ $fails ~ ' failed / ' ~ @results.elems;
exit($fails ?? 1 !! 0);

