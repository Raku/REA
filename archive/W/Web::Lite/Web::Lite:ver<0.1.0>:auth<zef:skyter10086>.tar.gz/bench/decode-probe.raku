# 百分号解码算法基准：单趟 Buf 扫描，多字节序列按字节还原，最后统一 utf-8 解码
my constant %HEX = flat(
    (('0'..'9') Z=> (0..9)),
    (('a'..'f') Z=> (10..15)),
    (('A'..'F') Z=> (10..15)),
);

say 'hexkeys: ' ~ %HEX.keys.elems ~ ' (expect 22)';
say 'hex2: ' ~ (%HEX{'2'} // 'undef') ~ ' (expect 2)';

sub pct-decode(Str $s --> Str) {
    return $s unless $s.contains('%');
    my $in = $s.encode('utf-8');
    my Buf $out .= new;
    my $i = 0;
    my $n = $in.elems;
    while $i < $n {
        my $b = $in[$i];
        if $b == 0x25 && $i + 2 < $n {
            my $hi = %HEX{$in[$i + 1].chr};
            my $lo = %HEX{$in[$i + 2].chr};
            if $hi.defined && $lo.defined {
                $out.push($hi * 16 + $lo);
                $i += 3;
                next;
            }
        }
        $out.push($b);
        $i++;
    }
    $out.decode('utf-8');
}

say 'A: ' ~ pct-decode('a%20b');
say 'B: ' ~ pct-decode('%E4%B8%AD');
say 'C: ' ~ pct-decode('plain');
