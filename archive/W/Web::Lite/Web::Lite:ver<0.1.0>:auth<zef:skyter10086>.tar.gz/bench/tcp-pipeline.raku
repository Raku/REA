# TCP pipeline 吞吐：单连接一次性灌 N 个 keep-alive 请求，统计总耗时
use lib $?FILE.IO.parent.parent.absolute ~ '/lib';
use Web::Lite;

my $app = Web::Lite.new;
$app.get('/hello', -> $c { $c.text('ok') });
$app.get('/u/{id}', -> $c { $c.text('id=' ~ $c.param('id')) });

my int $port = 18330;
my $server = $app.start(host => '127.0.0.1', :$port);
sleep 1.5;

sub bench(Str $path, Int $n) {
    my $sock = IO::Socket::INET.new(:host<127.0.0.1>, :port($port));
    my Str $wire = "GET $path HTTP/1.1\r\nHost: x\r\n\r\n";
    my $t0 = now;
    $sock.write(($wire x $n).encode('latin-1'));
    my int $seen = 0;
    while $seen < $n {
        my $chunk = $sock.recv(1048576);
        last unless $chunk.elems;
        # 只统计本次 chunk 内状态行出现次数，避免对累积串反复正则（客户端会变成 O(n^2)）
        $seen += $chunk.comb('HTTP/1.1 200').elems;
    }
    my $dt = now - $t0;
    $sock.close;
    printf "%-12s %6d reqs in %6.3fs -> %7.0f req/s  (%.1f us/req)\n",
           $path, $n, $dt, $n / $dt, $dt * 1e6 / $n;
}

# 每次灌入的请求数：命令行第一个参数可覆盖（默认 3000）
my Int $n = (@*ARGS[0] // 3000).Int;
say "n = $n per run";
bench('/hello', $n);
bench('/u/123', $n);
bench('/hello', $n);
$server.stop;
