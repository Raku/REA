# P1 探针：halt/pass、* 与 ** 通配、参数解码、自动 OPTIONS、DSL
# 走内存 transport（无 socket），比 TCP 快且确定
use lib $?FILE.IO.parent.parent.absolute ~ '/lib';
use Web::Lite;
use Web::Lite::Control;
use Web::Lite::Transport;
use Web::Lite::Transport::Memory;

my int $pass = 0;
my int $fail = 0;

sub check(Str $name, Bool $ok, Str $got) {
    if $ok {
        $pass++;
        say "PASS  $name";
    }
    else {
        $fail++;
        say "FAIL  $name   --> " ~ $got.lines[0];
    }
}

my $app = Web::Lite.new;

# --- halt / pass ---
my $hit-handler = False;
$app.get('/halt', -> $ctx { Web::Lite::Control::halt($ctx.text('halted', :status(418))) });
$app.get('/halt-ctx', -> $ctx { $ctx.halt('ctx-halt') });
$app.get('/halt-str', -> $ctx { halt('plain-halt') });
$app.get('/after-halt', -> $ctx { $hit-handler = True; 'should not run' });

$app.use(-> $ctx {
    if $ctx.path eq '/after-halt' {
        $ctx.halt($ctx.json({ :blocked(1) }, :status(401)))
    }
    elsif $ctx.path eq '/opt' {
        pass()
    }
    else {
        Nil
    }
});

my $opt-handler-ran = False;
$app.get('/opt', -> $ctx { $opt-handler-ran = True; 'opt-ok' });

# --- 通配与解码 ---
$app.get('/files/*', -> $ctx { $ctx.json({ one => $ctx.param('_splat') }) });
$app.get('/files/*/**', -> $ctx { $ctx.json({ rest => $ctx.splat }) });
$app.get('/u/{name}', -> $ctx { $ctx.json({ name => $ctx.param('name') }) });

# --- OPTIONS / 405 ---
$app.get('/api/thing', -> $ctx { 'get' });
$app.post('/api/thing', -> $ctx { 'post' });

# --- DSL ---
$app.any('/multi', -> $ctx { 'any-' ~ $ctx.method });
$app.head('/h-only', -> $ctx { 'head-body' });
$app.scope('/v1', -> $s {
    $s.get('/ping', -> $ctx { 'v1-pong' });
    $s.scope('/deep', -> $s2 {
        $s2.get('/x', -> $ctx { 'v1-deep-x' });
    });
});

my $listener = MemoryListener.new;
my $server = assemble($listener, $app);
$server.start;

sub req(Str $raw --> Str) { http-roundtrip($listener, $raw) }

my $r = req("GET /halt HTTP/1.1\r\nHost: x\r\nConnection: close\r\n\r\n");
check '1 halt 418 短路', $r.contains(' 418 ') && $r.contains('halted'), $r;

$r = req("GET /halt-ctx HTTP/1.1\r\nHost: x\r\nConnection: close\r\n\r\n");
check '2 ctx.halt 生效', $r.contains(' 200 ') && $r.contains('ctx-halt'), $r;

$r = req("GET /halt-str HTTP/1.1\r\nHost: x\r\nConnection: close\r\n\r\n");
check '3 halt(str) 生效', $r.contains('plain-halt'), $r;

$r = req("GET /after-halt HTTP/1.1\r\nHost: x\r\nConnection: close\r\n\r\n");
check '4 中间件 halt 拦下 handler', $r.contains(' 401 ') && $r.contains('"blocked": 1') && !$hit-handler, $r;

$r = req("GET /opt HTTP/1.1\r\nHost: x\r\nConnection: close\r\n\r\n");
check '5 中间件 pass 继续', $opt-handler-ran && $r.contains('opt-ok'), $r;

$r = req("GET /files/a HTTP/1.1\r\nHost: x\r\nConnection: close\r\n\r\n");
check '6 * 单段通配命中', $r.contains('"one": "a"'), $r;

$r = req("GET /files/a%20b HTTP/1.1\r\nHost: x\r\nConnection: close\r\n\r\n");
check '7 * 通配参数解码', $r.contains('"one": "a b"'), $r;

$r = req("GET /files/a/b/c HTTP/1.1\r\nHost: x\r\nConnection: close\r\n\r\n");
check '8 */** 组合匹配', $r.contains('"rest": "b/c"'), $r;

$r = req("GET /u/%E4%B8%AD HTTP/1.1\r\nHost: x\r\nConnection: close\r\n\r\n");
check '9 {name} UTF-8 解码', $r.contains('"name": "中"'), $r;

$r = req("OPTIONS /api/thing HTTP/1.1\r\nHost: x\r\nConnection: close\r\n\r\n");
check '10 自动 OPTIONS 204', $r.contains(' 204 ') && $r.contains('Allow: GET, HEAD, OPTIONS, POST'), $r;

$r = req("OPTIONS * HTTP/1.1\r\nHost: x\r\n\r\n");
check '11 OPTIONS * 全站 Allow', $r.contains('Allow:') && $r.contains('OPTIONS') && $r.contains('POST'), $r;

$r = req("PUT /api/thing HTTP/1.1\r\nHost: x\r\nConnection: close\r\n\r\n");
check '12 405 Allow 带 HEAD/OPTIONS', $r.contains(' 405 ') && $r.contains('Allow: GET, HEAD, OPTIONS, POST'), $r;

$r = req("GET /multi HTTP/1.1\r\nHost: x\r\nConnection: close\r\n\r\n");
check '13 any GET', $r.contains('any-GET'), $r;

$r = req("PUT /multi HTTP/1.1\r\nHost: x\r\nConnection: close\r\n\r\n");
check '14 any PUT', $r.contains('any-PUT'), $r;

$r = req("HEAD /h-only HTTP/1.1\r\nHost: x\r\nConnection: close\r\n\r\n");
check '15 head 路由无体', $r.contains(' 200 ') && !$r.contains('head-body'), $r;

$r = req("GET /v1/ping HTTP/1.1\r\nHost: x\r\nConnection: close\r\n\r\n");
check '16 scope 前缀', $r.contains('v1-pong'), $r;

$r = req("GET /v1/deep/x HTTP/1.1\r\nHost: x\r\nConnection: close\r\n\r\n");
check '17 嵌套 scope', $r.contains('v1-deep-x'), $r;

$r = req("GET /nope HTTP/1.1\r\nHost: x\r\nConnection: close\r\n\r\n");
check '18 未知路径 404', $r.contains(' 404 '), $r;

say '';
say "== P1: $pass passed / $fail failed ==";
$server.stop;
exit($fail ?? 1 !! 0);
