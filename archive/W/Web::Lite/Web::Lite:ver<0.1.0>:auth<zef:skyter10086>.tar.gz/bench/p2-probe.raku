# P2 探针：超时上限、Parser 边界、Context 缓存、错误接口统一
# 走真实 TCP（超时行为必须端到端验证）
use lib $?FILE.IO.parent.parent.absolute ~ '/lib';
use Web::Lite;
use Web::Lite::Control;

my int $pass = 0;
my int $fail = 0;

sub check(Str $name, Bool $ok, Str $got) {
    if $ok {
        $pass++;
        say "PASS  $name";
    }
    else {
        $fail++;
        say "FAIL  $name   --> " ~ $got.lines[0];
    }
}

my $app = Web::Lite.new: :timeout(1);

$app.get('/', -> $ctx { 'HELLO' });
$app.post('/echo', -> $ctx { 'echoed' });
$app.get('/u/{id}', -> $ctx {
    my $a = $ctx.query-param('q');
    my $b = $ctx.query-param('q');
    my $h1 = $ctx.query-hash<q>;
    $ctx.query-hash<q> = 'MUTATED';        # 改返回值不应污染内部缓存
    my $c = $ctx.query-param('q');
    $ctx.json({
        :$a, :$b, :$c,
        h1 => $h1,
        same-path => ($ctx.path eq $ctx.path),
        id => $ctx.param('id'),
        uni => $ctx.query-param('cn'),
    });
});

# 超时：异步 handler 拖过 1s
$app.get('/slow', -> $ctx {
    my $p = Promise.new;
    start { sleep 3; $p.keep('late') }
    $p;
});

# 快返回的异步 handler 不受超时影响
$app.get('/fast', -> $ctx {
    my $p = Promise.new;
    start { $p.keep('quick') }
    $p;
});

# 错误接口统一
$app.on-server-error(-> $ctx, $err { { :error('handled'), :msg($err.message) } });
$app.get('/boom', -> $ctx { die 'sync boom' });
$app.get('/aboom', -> $ctx {
    my $p = Promise.new;
    start { $p.break('async boom') }
    $p;
});

my int $port = 18241;
my $server = $app.start(host => '127.0.0.1', :$port);
sleep 1;

sub probe(Str $wire) {
    my $sock = IO::Socket::INET.new(:host<127.0.0.1>, :port($port));
    $sock.write($wire.encode('latin-1'));
    my Str $got = '';
    loop {
        my $chunk = $sock.recv(8192);
        last unless $chunk.chars;
        $got ~= $chunk;
    }
    $sock.close;
    $got;
}

sub cl(Str $s) { "Connection: close\r\n" ~ $s }

# ---- 超时 ----
my $t0 = now;
my $r = probe("GET /slow HTTP/1.1\r\nHost: x\r\n" ~ cl('') ~ "\r\n");
my $dt = now - $t0;
check "1 超时回 504 且约 1s（实测 {$dt.Int}s）",
      $r.contains(' 504 ') && $dt < 2.5, $r;

$r = probe("GET /fast HTTP/1.1\r\nHost: x\r\n" ~ cl('') ~ "\r\n");
check '2 快速异步不受超时影响', $r.contains(' 200 ') && $r.contains('quick'), $r;

# ---- Parser 边界 ----
my Str $long = 'a' x 9000;
$r = probe("GET /$long HTTP/1.1\r\nHost: x\r\n" ~ cl('') ~ "\r\n");
check '3 超长请求行 -> 414', $r.contains(' 414 '), $r;

$r = probe("GET / HTTP/1.1\r\nHost: x\r\nBadHeaderNoColon\r\n" ~ cl('') ~ "\r\n");
check '4 无冒号头部 -> 400', $r.contains(' 400 '), $r;

my Str $many = '';
$many ~= "X-H{$_}: {$_}\r\n" for ^101;
$r = probe("GET / HTTP/1.1\r\nHost: x\r\n$many" ~ cl('') ~ "\r\n");
check '5 头部过多 -> 431', $r.contains(' 431 '), $r;

$r = probe("POST /echo HTTP/1.1\r\nHost: x\r\nContent-Length: abc\r\n" ~ cl('') ~ "\r\n");
check '6 Content-Length 非数字 -> 400', $r.contains(' 400 '), $r;

$r = probe("POST /echo HTTP/1.1\r\nHost: x\r\nContent-Length: 3\r\nTransfer-Encoding: chunked\r\n" ~ cl('') ~ "\r\n");
check '7 CL 与 TE 并存 -> 400', $r.contains(' 400 '), $r;

$r = probe("\r\nGET / HTTP/1.1\r\nHost: x\r\n" ~ cl('') ~ "\r\n");
check '8 前导空行被忽略', $r.contains(' 200 ') && $r.contains('HELLO'), $r;

$r = probe("GET / HTTP/1.1\r\nHost: x\r\nX-A: 1\r\n  folded\r\n" ~ cl('') ~ "\r\n");
check '9 obs-fold -> 400', $r.contains(' 400 '), $r;

$r = probe("GET / HTTP/1.1\r\nHost: x\r\nContent-Length: 0\r\nContent-Length: 5\r\n" ~ cl('') ~ "\r\n");
check '10 CL 冲突 -> 400', $r.contains(' 400 '), $r;

# ---- Context 缓存 ----
$r = probe("GET /u/42?q=hi&cn=%E4%B8%AD%E6%96%87 HTTP/1.1\r\nHost: x\r\n" ~ cl('') ~ "\r\n");
check '11 query 缓存与克隆隔离',
      $r.contains('"a": "hi"') && $r.contains('"b": "hi"') && $r.contains('"c": "hi"')
      && $r.contains('"h1": "hi"') && $r.contains('"same-path": true'), $r;
check '12 query 中文解码正确', $r.contains('"uni": "中文"'), $r;

# ---- 错误接口统一 ----
$r = probe("GET /boom HTTP/1.1\r\nHost: x\r\n" ~ cl('') ~ "\r\n");
my Bool $sync-json = $r.contains('application/json') && $r.contains('"error": "handled"');
check '13 同步异常走统一出口（500+JSON）', $r.contains(' 500 ') && $sync-json, $r;

$r = probe("GET /aboom HTTP/1.1\r\nHost: x\r\n" ~ cl('') ~ "\r\n");
check '14 异步异常走同一出口（500+JSON）',
      $r.contains(' 500 ') && $r.contains('application/json') && $r.contains('"error": "handled"'), $r;

say '';
say "== P2: $pass passed / $fail failed ==";
$server.stop;
exit($fail ?? 1 !! 0);
