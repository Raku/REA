use lib $?FILE.IO.parent.parent.absolute ~ '/lib';
use Web::Lite::Response;
use Web::Lite::Serializer;
use Cro::HTTP::Request;

my $rq = Cro::HTTP::Request.new(:method<GET>, :target</>, :http-version<1.1>);
$rq.append-header('Connection', 'close');

my $r = make-response(500, 'text/plain; charset=utf-8', "500 Internal Server Error\n");
$r.request = $rq;

say 'request-set: ' ~ $r.request.defined;
say 'close-required: ' ~ close-required($r);
my $msg = build-message($r, $r.lite-body);
say 'wire: ' ~ $msg.data.decode('utf-8').subst("\r\n", '|', :g);

my $r2 = make-response(200, 'text/plain; charset=utf-8', 'OK');
$r2.request = $rq;
say 'ok-close-required: ' ~ close-required($r2);
