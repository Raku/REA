# bench

`t/` 是 `prove6` 跑的 TAP 正式测试；`bench/` 放的是**开发期手动探针与吞吐基准**：断言更细、带原始报文回显、可反复单跑定位回归。

所有脚本里的 `use lib` 都通过 `$?FILE` 解析回仓库 `lib/`，因此在仓库根、`bench/`、甚至仓库外目录执行都可以，不依赖当前工作目录。

## 运行

```bash
raku bench/p0-probe.raku            # 退出码 0 = 全绿，非 0 = 有 FAIL
raku bench/p1-probe.raku
raku bench/p2-probe.raku            # 含一条 1s 超时用例，整体约 3s

raku bench/tcp-pipeline.raku        # 默认每轮灌 3000 个请求
raku bench/tcp-pipeline.raku 5000   # 自定义每轮请求数

raku bench/route-probe.raku         # 对照式输出
raku bench/decode-probe.raku
raku bench/close-probe.raku
```

依赖 Rakudo Star 2026.09（本机 `C:\rakudo\bin\raku.exe`）。

## 清单

| 脚本 | 类型 | 覆盖点 | 传输 |
| --- | --- | --- | --- |
| `p0-probe.raku` | 回归（PASS/FAIL） | HEAD 不发送响应体但保留 Content-Length、pipeline 的 HEAD+GET 不黏连、异步/同步 handler die 均回 500、坏请求与畸形 HTTP 版本回 400、`Connection: close` 响应头、单连接 keep-alive 复用 | 真实 TCP |
| `p1-probe.raku` | 回归（PASS/FAIL） | `halt`/`pass` 短路与放行、`*` 单段与 `**` 多段通配及参数解码、`{name}` UTF-8 解码、自动 `OPTIONS`、405 带 Allow、`any` 方法、`scope` 嵌套前缀、404 | 内存 transport |
| `p2-probe.raku` | 回归（PASS/FAIL） | 超时统一 504 且约等于设定值、快速异步不受超时影响、Parser 边界（超长请求行 414、头部过多 431、无冒号头/CL 非数字/CL 冲突/CL+TE/obs-fold 均 400、前导空行忽略）、`query-hash` 克隆隔离、同步与异步异常走同一错误出口 | 真实 TCP |
| `route-probe.raku` | 对照输出 | Route 层匹配：`{id}/*` 组合、`%20` 解码、`%2F` 不跨段、`**` 多段、非 ASCII 字面段 | 无 |
| `decode-probe.raku` | 对照输出 | 百分号解码算法：单趟 Buf 扫描 + 多字节按字节还原 + 末段 utf-8 解码 | 无 |
| `close-probe.raku` | 对照输出 | Response 序列化与 `close-required` 判定（请求侧 `Connection: close` 时响应必须带该头） | 无 |
| `tcp-pipeline.raku` | 吞吐基准 | 单连接一次性灌 N 个 keep-alive 请求，统计总耗时与 us/req | 真实 TCP |

对照输出型脚本不设断言，人工核对注释里的期望值即可。

## 实测基线

`raku bench/tcp-pipeline.raku`（每轮 3000 请求，Rakudo 2026.09 / Windows 11 本机）：

```
/hello         3000 reqs in  1.147s ->    2616 req/s  (382.2 us/req)
/u/123         3000 reqs in  1.359s ->    2208 req/s  (453.0 us/req)
/hello         3000 reqs in  1.029s ->    2914 req/s  (343.1 us/req)
```

（上一版基线为 2423 / 2175 / 2558 req/s；补完读超时与优雅关闭后再测仍是同一水平，
说明「半截请求计时器」在有流量时几乎零成本——buf 空就直接 next，不触发任何计算。
补完 Cookie / send-file / 静态目录后再测为 2223~2808 / 2084~2185 / 2528~2532 req/s，
波动在测量误差内，`body-bytes` 同步快路未伤吞吐。）

首轮偏慢是 MoarVM JIT 未热，重复跑第二、三轮数据更稳，比较时以同机同轮次为准。

## 已知坑

- **内存 transport 不能用来测吞吐**。`Web::Lite::Transport::Memory` 的 `http-roundtrip` 内部有 `await Promise.in(0.02) / (0.05) / ($wait=0.25)` 三段等待，单次调用固定耗掉约 0.3s，测出来的是等待时间而非框架开销（曾据此写过 `hot-path.raku`，实测 294ms/req，已删除）。要测每请求成本请用 `tcp-pipeline.raku`，它按 chunk 内状态行计数，避免对累积串反复正则导致客户端自身 O(n²)。
- 真实 TCP 探针的端口固定（p0=18234、p2=18241、tcp-pipeline=18330、t/05-limits=18350、t/06-features=18360），并行跑会撞端口，串行执行。
- `p2-probe.raku` 的超时用例依赖 `:timeout(1)`，机器高负载时第 1 条断言里的 `dt < 2.5` 偶尔抖动，属测量误差而非框架回归。
