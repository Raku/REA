# Web::Lite · HANDOFF 交接文档

> 一句话：读完这份文档，你能在不问原作者的前提下复现环境、跑通 120 项测试、找到该改的模块、
> 知道哪些坑已经踩过、哪些事现在千万不要做。

## 0. 交接状态牌（2026-11-05 实测）

| 项 | 值 |
| --- | --- |
| 仓库路径 | `C:\Users\Admin\raku-WebLite` |
| 远程 | `origin` = `https://gitee.com/skyter10086/web-lite.git` |
| 分支 / HEAD | `master` @ `09bb2f0`，与 `origin/master` 同步，工作区干净 |
| 版本 | `META6.json` name=`Web::Lite`、version=`0.1.0`、api=`0`、auth=`zef:skyter10086` |
| 代码量 | `lib/` 13 个模块共 2741 行；`t/` 7 个文件共 981 行；`bench/` 7 个探针脚本 + README |
| 测试 | `prove6 -Ilib t/` → `Files=7, Tests=120, 21 wallclock secs ... Result: PASS` |
| 吞吐 | 单连接 pipeline：**2085 / 2084 / 2577 req/s**（388~480 µs/req，`bench/tcp-pipeline.raku 2000`） |
| 定位 | **应用层框架**，网络与协议解析全部交给 `Cro::HTTP`；不碰 socket、不碰 HTTP parser 标准实现 |
| 交付状态 | 可用、可测、可上；缺模板引擎与多核扩展（见 §12） |

### 按目的选读

| 你想做的事 | 直接看 |
| --- | --- |
| 5 分钟内把服务跑起来 | §5.2 → §5.3 |
| 跑测试 / 判断改动有没有退步 | §7 |
| 改路由、Context、序列化 | §4 模块地图 → §6 执行链 |
| 搞清"为什么这么写、能不能改成那样" | §9 踩坑清单（**必读**） |
| 在 Windows 上动这个仓库 | §10 工具链红线（**必读**） |
| 提交 / 发布 / 装到 zef | §11 |
| 判断下一件事该不该现在做 | §12 欠账与下一步 |
| 刚接手，问"我该干什么" | §13 交接动作清单 |

---

## 1. 这是什么，以及为什么是这个形态

### 1.1 来由

作者先手写过 `raku-HTTP-Core`（C 内核 + NativeCall 的协议栈研究项目）。往应用层走时评估了三条路：

| 方案 | 内容 | 结论 |
| --- | --- | --- |
| A | 在自研协议栈上直接做框架 | 工作量=重写 actix 级网络库，周期不可控 |
| B | 以 `Cro::HTTP` 为底座，只用 `Cro::Transform` 直出 `Response`，绕过 Cro Router | **采用** |
| C | 直接用 `Cro` 的路由与 DSL | 不够 Sinatra，且路由层成本与语义都不受控 |

所以本项目是「**B 方案瘦皮**」：保留 Cro 成熟的传输层、HTTP 解析基础设施与生态，把路由、上下文、序列化、运维防护自己接管，
换来「一行一条路由 + 天然异步」。

### 1.2 三条红线（不因需求变更而松动的部分）

1. **不重写协议栈**。socket / TCP / TLS 复用 Cro；`raku-HTTP-Core` 是另一条独立研究线，**不参与本项目的运行路径**。
2. **必须异步非阻塞**。禁止在框架内部引入阻塞调用（`sleep`、同步 IO）；`Promise.in` / `Promise.timer` 替代 `sleep`。
3. **保持 Sinatra/Flask 手感**。API 走 `$app.get('/x', -> $c { ... })` + `$c.json/text/html`，不做 Rails 式约定层。

---

## 2. 基线

### 2.1 运行环境（本机实况）

| 项 | 值 |
| --- | --- |
| 系统 | Windows 11 (Build 26300) |
| Rakudo | Rakudo Star **2026.09** / MoarVM 2026.09 |
| `raku` | `C:\rakudo\bin\raku.exe` |
| `prove6` | `C:\rakudo\share\perl6\site\bin\prove6.exe`（**不在 `C:\rakudo\bin`**，PATH 里也没有） |
| 控制台编码 | 跑测试前先 `chcp 65001`，否则中文断言输出会乱码 |
| 依赖 | `Cro::HTTP`、`JSON::Fast`（test-depends：`Cro::HTTP::Client`） |

### 2.2 提交链（近期，倒序）

```
09bb2f0  feat(web-lite): multipart 表单解析 / 签名 Cookie Session / url_for 命名路由   ← HEAD
e19518f  feat(web-lite): Cookie / send-file / 静态目录 / 同步请求体
cbe05a4  feat(web-lite): 补齐请求读超时、body 上限与优雅关闭
3ef4a90  test(web-lite): 收纳 P0-P2 探针与吞吐基准到 bench/
9e9d880  fix(web-lite): P0-P2 骨架硬化——协议正确性、控制流、解析边界
5de7ef0  perf(web-lite): 自研精简 HTTP/1.1 parser，同口径单请求 555→277us（2.0x）
1bfeaf6  perf(web-lite): B方案瘦皮——LiteSerializer + raw 传输 + 零中间件快路径
```

提交信息一律中文语义化（`type(scope): 说明`），不含署名尾注。

### 2.3 META6 关键字段

```json
{ "name": "Web::Lite", "version": "0.1.0", "auth": "zef:skyter10086",
  "license": "Artistic-2.0", "api": "0",
  "depends": ["Cro::HTTP", "JSON::Fast"],
  "test-depends": ["Cro::HTTP::Client"] }
```

`provides` 已登记全部 13 个模块（含 `Multipart` / `Session` / `Static`），新增模块时**必须**同步登记，否则 zef 安装后 `use` 不到。

---

## 3. 能力范围

### 3.1 已经具备（可直接用）

| 域 | 能力 |
| --- | --- |
| 路由 | `get/post/put/patch/delete/head/options`、`any`、`scope` 前缀分组、`{name}` 路径参数、`*` 单段通配、`**` 剩余通配、命名路由 `name =>`、`url-for` 反查、`route-named`、`routes`、`route-stats` |
| 语义 | 已知路径但方法不符 → 405 + `Allow`；无显式 OPTIONS 路由 → 自动 `Allow` + 204（`:!auto-options` 可关）；HEAD 优先显式路由、否则回落 GET |
| Context | `method/path/http-version/param/query-param/query-hash/splat/header`、`body/body-str/body-json`（同步）、`text-body/json-body`（Promise）、`set/stash-get`、`json/text/html/redirect`、`send-file`、`cookie/cookies/set-cookie/delete-cookie`、`form/multipart/field/file/files`、`session` |
| 表单 | `multipart/form-data` 与 `x-www-form-urlencoded` 统一走 `$c.form`；同名多值保序追加；RFC 5987 中文文件名还原；非表单 Content-Type 返回空 Form 而非抛错 |
| 会话 | 无状态签名 cookie（payload.b64url + HMAC-SHA1 + 常量时间比较）；只读请求不下发 `Set-Cookie`；解不开当空会话 |
| 静态与文件 | `$app.static(prefix, dir, :cache, :max-file-bytes)`；ETag / Last-Modified / 304；`..` 与解码后越界拦 403；`send-file` 带 `download-name` |
| 中间件 | `use`（前置，返回 Response 即短路）、`after`（后置，可换响应）、内置 `timing` / `access-log` / `cors` / `bearer-auth` |
| 控制流 | `Halt`（短路并结算值）、`Pass`（放弃当前路由）、`on-not-found`、`on-server-error`、handler 可返回 `Hash`（转 JSON）/`Str`（转 text）/`Nil`（204）/`Promise` |
| 运维防护 | `timeout`(30, 504) / `read-timeout`(15, 408) / `body-timeout`(60, 408) / `max-body-bytes`(2MB, 413) / `shutdown-grace`(10)；`shutdown` 三步排空并返回是否自然排空；`run` 接 Ctrl-C 自动排空 |
| 传输 | `start(:transport('raw'))` 走自研 `RawListener` + `LiteParser` + `LiteSerializer`（默认，性能路径）；`:'cro'` 走 `Cro::HTTP::Server`（兼容/对照用）；`Transport::Memory` 供单测注入 |

### 3.2 明确没做（别假设存在）

- **模板引擎**（无 ERB/Jinja 等价物，现在只能 `html()` 拼串）
- **正则路由**（只有 `{name}`、`*`、`**` 三种）
- **WebSocket / SSE / 流式响应体**（所有响应体一次性在内存里成型；`send-file` 也是整文件读入）
- **内容协商 / gzip / ETag 规范化**（ETag 只有静态与 send-file 路径有）
- **多进程 / 多核**（单进程单 reactor，见 §8 天花板说明）
- **HTTP/2**（raw 传输只实现 HTTP/1.1，未验证 h2）
- **LICENSE 文件**（`META6.json` 声明 Artistic-2.0，仓库根目录没有 LICENSE 文本）
- **CI**（无 `.github` / `.gitlab-ci.yml`，回归全靠手工 `prove6`）

---

## 4. 模块地图（`lib/` 13 个，2741 行）

| 模块 | 行数 | 职责 / 改动时注意 |
| --- | --- | --- |
| `Web/Lite.rakumod` | 767 | 主类：路由注册与查找、`transformer` 主链、`!run` 快慢路径、`!settle` 超时、`!error-response` 统一错误出口、`static` / `session` / `url-for` / `start` / `shutdown` / `run`。**改这块要先读 §6** |
| `Web/Lite/Context.rakumod` | 381 | 请求视图 + 响应构造。惰性解析 query / cookie / body / form / session；`adopt` 负责贴头与 cookie |
| `Web/Lite/Parser.rakumod` | 343 | 自研 HTTP/1.1 解析（`Cro::Transform`，TCP→Request）。字节级扫描，支持 Content-Length 与 chunked；`LiteBadRequest` 表示解析层拒收；导出 `body-bytes` |
| `Web/Lite/Multipart.rakumod` | 288 | boundary 字节扫描、`Part`/`Form`、RFC 5987、urlencoded 解析 |
| `Web/Lite/Static.rakumod` | 182 | 静态目录 handler、`weak-etag`、`not-modified`、路径穿越拦截 |
| `Web/Lite/Transport.rakumod` | 155 | `RawListener` / `RawConnection` / `RawReplier` / `assemble`：TCP 字节 ↔ Cro pipeline 的粘合层，负责连接计数、停收、硬断 |
| `Web/Lite/Session.rakumod` | 150 | 手写 base64url + HMAC-SHA1 + 常量时间比较；`Session` / `SessionStore` |
| `Web/Lite/Route.rakumod` | 147 | 单条路由：`match`、`pct-encode`、`fill-pattern`（`url-for` 用） |
| `Web/Lite/Serializer.rakumod` | 143 | Response → TCP 字节。`set-body` 体、Header 折叠、`close-required`、`http-date` |
| `Web/Lite/Transport/Memory.rakumod` | 69 | 测试用内存 socket；**含人为延时，不能做吞吐基准**（见 §9.16） |
| `Web/Lite/Middleware.rakumod` | 48 | `timing` / `access-log` / `cors` / `bearer-auth` |
| `Web/Lite/Response.rakumod` | 41 | `LiteResponse`（Cro Response 子类）+ `set-lite-body`，解决 Cro 的 body 设置坑 |
| `Web/Lite/Control.rakumod` | 27 | `Halt` / `Pass` 两个控制流异常 |

读代码顺序建议：`Lite.rakumod` 的 `transformer`(629) → `!run`(307) → `!invoke`(355) → `!settle`(493) → `Serializer` → `Parser`。
先看主链，再按需下钻，不要从 Parser 开始读。

---

## 5. 从零跑起来

### 5.1 装依赖

```powershell
cd C:\Users\Admin\raku-WebLite
C:\rakudo\bin\raku.exe -Ilib -e "use Web::Lite; say 'ok'"
```

能打印 `ok` 就说明 `Cro::HTTP` / `JSON::Fast` 已就位。缺依赖时：

```powershell
zef install --deps-only .
```

### 5.2 起示例服务

```powershell
chcp 65001
C:\rakudo\bin\raku.exe -Ilib examples\app.raku
```

`examples/app.raku` 自带 7 条路由（首页 HTML / JSON / 路径参数 / 查询串 / POST 读 body / 1 秒异步 / `**` 通配），端口 3000。

验证（另开一个终端）：

```powershell
curl.exe -s http://127.0.0.1:3000/api/ping
curl.exe -s http://127.0.0.1:3000/api/users/42
curl.exe -s -X POST http://127.0.0.1:3000/api/echo -H "Content-Type: application/json" -d '{\"a\":1}'
```

异步验证：两个终端同时打 `/api/slow`，总耗时应约 1.0~1.1 秒；若变成 2 秒，说明有人把 `sleep` 写进了 handler 或调度被阻塞。

### 5.3 最小可跑样例

```raku
use lib 'lib';
use Web::Lite;

my $app = Web::Lite.new: :port(3000);
$app.get: '/', -> $c { $c.html('<h1>hi</h1>') };
$app.get: '/api/ping', -> $c { $c.json({ pong => True }) };
$app.run;
```

`run` 阻塞并接管 Ctrl-C；嵌入测试时用 `$app.start(...)`（不阻塞、返回 server）配 `$app.shutdown`。

---

## 6. 执行链（改代码前必须知道）

### 6.1 请求主链

```
TCP 字节
 └─ RawListener.incoming            (Transport)
     └─ RawConnection.incoming      (Transport)
         └─ LiteParser.transformer  (Parser)  ── 解析失败 → LiteBadRequest 事件
             └─ Web::Lite.transformer (Lite.rakumod:629)
                 ├─ LiteBadRequest → bad-request-response（不回路由，直接状态码 + 关连接）
                 ├─ 无 body 且上一条已完结 → 在 loop 线程内同步跑 !run
                 └─ 否则 → start { await 上一条; ... } 串行化（保序）
                       └─ !run (307)
                            ├─ !match-route：静态表哈希命中 → 动态路由按注册顺序扫
                            ├─ 未命中 → auto-options / not-found-path（405 带 Allow）
                            ├─ 无中间件且无 after 钩子 → **快路径**：直接调 handler
                            └─ 否则 !invoke → 中间件链 → handler → after 钩子（!finish）
                       └─ !settle (493)  ── timeout>0 时与 Promise.in 竞速，输者 504 + Connection: close
                       └─ !drain-mark    ── 关停中给响应补 Connection: close
             └─ LiteSerializer.transformer  (Serializer) → TCP 字节
```

### 6.2 三个必须理解的决策

1. **快路径与慢路径是两份实现**。快路径条件严格：`无 @!middleware && 无 @!after-hooks`。
   两条路径都必须在末尾 `return $resp`——历史上就因为快路径漏了一个 `return`，handler 每请求执行两次（见 §9.13）。
   加钩子会自动降级到慢路径，所以「性能突然变差」先看是不是有人 `use` 了中间件。
2. **无 body 的请求在 loop 线程内同步跑完，带 body 的必须让出 loop 线程**。
   在 loop 线程内 `await` body 会与 loop 自身死锁。这条注释在代码里，改动时不要"优化"掉。
3. **同连接响应必须保序**。`transformer` 里用 `$pending` 串成 Promise 链，后一个请求 `await` 前一个。
   绕开它（比如直接 `emit`）会在 keep-alive 下串包：第二个请求收到第一个的 body。

### 6.3 三个统一出口

| 出口 | 位置 | 作用 |
| --- | --- | --- |
| `!coerce` | 436 | handler 返回值 → `Cro::HTTP::Response`（Hash→JSON、Str→text、Nil→204） |
| `!error-response` | 450 | 所有异常的唯一归宿（`debug` 时打 stderr，否则 500 / 自定义） |
| `!settle` | 493 | 所有 Promise 结果的唯一归宿 + 超时裁决 |

改错误处理只要动 `!error-response`；改超时只动 `!settle`；不要在各个 handler 分支里散着写。

---

## 7. 测试与验证口径

### 7.1 怎么跑

```powershell
chcp 65001
cd C:\Users\Admin\raku-WebLite
C:\rakudo\share\perl6\site\bin\prove6.exe -Ilib t/
# 单文件
C:\rakudo\bin\raku.exe -Ilib t\07-multipart-session.rakutest
```

当前基线：**`Files=7, Tests=120, 21 wallclock secs, Result: PASS`**。改动后先跑全量，数字对不上就是退步。

### 7.2 覆盖分布

| 文件 | 项数 | 覆盖 | 端口 |
| --- | --- | --- | --- |
| `01-basic` | 17 | 路由、参数、body、405/404、通配、中间件短路、异步 | 动态申请空闲端口 |
| `02-async` | 3 | 并发非阻塞（两条独立裸连接）、同连接保序不串包 | 31995 固定 |
| `03-transport` | 6 | 裸管道、拆包重组、keep-alive 保序 | 内存 transport，不占端口 |
| `04-hardening` | 10 | Parser 边界、错误出口、query 解码 | 内存 transport，不占端口 |
| `05-limits` | 10 | 读超时 408、body 上限 413、slowloris、优雅关闭 | 18350 |
| `06-features` | 38 | 同步 body、Cookie 编解码、send-file/ETag/304、静态目录与穿越 | 18360 |
| `07-multipart-session` | 36 | multipart 中文名/多值保序、urlencoded、Session 签发与篡改、url_for | 18370 |
| **合计** | **120** | | |

### 7.3 纪律

- **必须串行跑**。`prove6 -j` 会撞固定端口。
- 新增能力 = 新增 `t/` 项 + 更新本表项数 + 更新 README「跑测试」段的项数，三处对齐。
- 端口冲突时先 `Get-NetTCPConnection -LocalPort 18350` 查残留进程，别改端口掩盖问题（改端口会同步改 §7.2）。
- `bench/` 是开发期手动探针，**不进 CI、不算验收**；正式回归只认 `t/`。

---

## 8. 性能结论与测量方法

### 8.1 当前数字

`bench/tcp-pipeline.raku 2000`（单连接一次灌 2000 个 keep-alive 请求，2026-11-05 本机实测）：

| 路径 | 请求数 | 耗时 | 吞吐 | 单请求 |
| --- | --- | --- | --- | --- |
| `/hello`（静态命中） | 2000 | 0.959s | 2085 req/s | 479.7 µs |
| `/u/123`（动态参数） | 2000 | 0.960s | 2084 req/s | 479.9 µs |
| `/hello`（复测） | 2000 | 0.776s | 2577 req/s | 388.1 µs |

历史口径（同一脚本、同一机器族，波动区间 2084~2914 req/s）：静态命中与动态参数差异在噪声内，
**说明动态路由的匹配成本已经不在瓶颈里**。

### 8.2 优化历程（既然数字是这个量级，别重复劳动）

| 阶段 | 口径 | 改动 | 结果 |
| --- | --- | --- | --- |
| 阶段 0 | 内存管道 | 裸管道 vs 官方 Server 对照，定位成本归属 | 建立归属基线 |
| 瘦皮 | 真实 TCP，8 连接 | 自研 `LiteSerializer` + raw 传输 + 零中间件快路径 | 202.9 → 72.6 µs/req（2.79x，13.8k req/s 场景） |
| 精简 Parser | 内存管道 | 自研 HTTP/1.1 parser 替换 Cro parser | 555.6 → 276.9 µs/req（2.01x） |

### 8.3 天花板与测量纪律

- **单连接单 reactor，单核**。8 → 64 连接吞吐不再上涨，瓶颈是 reactor 线程而不是每请求成本。
  要再上一个量级只能多进程/多核（见 §12），继续抠 per-request 微优化收益已经很小。
- **不要用 `Transport::Memory` 做吞吐基准**：`http-roundtrip` 内置 `Promise.in(0.02)/(0.05)/0.25` 三段等待，
  实测 ≈0.29 s/req，1000 次要 294 秒。它是**功能**测试替身，不是性能工具。
- 更贴近生产的口径未做：多连接并发 + 前置 Nginx 复用长连接 + 固定 CPU 绑定。现在的高并发数据都不代表真实部署。

---

## 9. 踩坑清单（按症状查）

README「实现要点」1~15 条是最常复发的坑，**读一遍再动手**。下面按症状补充代码里已经躺着的陷阱（16~22），
每一条都是真实踩过的：

| # | 症状 | 根因 / 正确做法 |
| --- | --- | --- |
| 1 | 响应体为空 / body 不生效 | 必须 `set-body`，`new(:body-blob(...))` 无效；统一走 `Web::Lite::Response` |
| 2 | `Cannot look up attributes in type object` | 自产 Response 必须挂 `$resp.request = $request` |
| 3 | keep-alive 下第二个请求收到第一个的 body | 同连接响应要 Promise 串行化保序 |
| 4 | `request.target` 没有 `path-segments` | 它是 Str（origin-form），自己剥 `?` / `#` 再切段 |
| 5 | `Unsupported use of - as character range` | Raku 字符类写 `<[0..9]>`，不是 `0-9` |
| 6 | 切头体时 body 前两字符被吃掉 | `"\r\n\r\n"` 在 Raku 只占 2 个位置（CRLF 单 grapheme），用 `split(..., 2)` |
| 7 | `Attempt to return outside of any Routine` | Block 内不能 `return`；要提前返回写匿名 `sub ($c) { }`；中间件/钩子同理 |
| 8 | `Type check failed ... Bool` | `any(...)` 是 Junction，套 `so (...)` |
| 9 | `Malformed header value` | Cro 拒非 ASCII 头值，中文文件名走 RFC 5987 `filename*=UTF-8''%XX` |
| 10 | `No such method 'request' for invocant of type 'Pair'` | 写 `request => $c.request`，不能写 `:$c.request`；`Part.new(:$ctype)` 同理静默失效 |
| 11 | 并发全变串行 / 定时器不准 | `sleep` 阻塞调度线程，用 `Promise.in` / `Promise.timer` |
| 12 | base64 往返崩 | `Base64` 模块对字节不友好，本项目手写 base64url（`B64URL` 表、无 padding） |
| 13 | handler 每请求被执行两次、耗时翻倍但断言全绿 | 快路径末尾漏 `return $resp`，控制流落到 `!invoke`。**GET 幂等所以测试抓不住** |
| 14 | 后置钩子追加的 cookie 消失 | `Set-Cookie` 贴头用计数 `$!cookies-flushed`，不能用 Bool |
| 15 | `"\x{FFFD}"` 报错 / 同名多值表单顺序反了 | 写 `"\x[FFFD]"`；多值一律**追加** `[|旧, 新]` |
| 16 | 性能基准里每次请求慢 0.29 秒 | `Transport::Memory::http-roundtrip` 内置三段人为等待，它只能测功能 |
| 17 | `Odd number of elements found where hash initializer expected` | `($route, %params) = @found` 列表解构会把 Hash 当单值，必须分开赋值 |
| 18 | 路由参数 `id` 报「不存在的属性」 | Context 构造写 `params => %params`，写成 `:%params` 会被展开成命名参数 |
| 19 | 客户端零响应、连接挂在半空 | Parser 判坏请求时必须走 `bad-request-response` 发状态码并关连接，不能静默丢弃 |
| 20 | handler 返回 broken Promise 后整条连接再也发不出响应 | 必须在 `!settle` 里兜底成 500，broken Promise 不能穿透 supply |
| 21 | 504 之后客户端卡住 | 超时响应的 body 长度不可信，必须补 `Connection: close` |
| 22 | 重复 `shutdown` 打 Cro 警告 | `shutdown` 用 `$!draining` 做幂等，先置位再动作 |

---

## 10. 工具链红线（Windows，违反会毁文件或卡死）

1. **绝对不要用 PowerShell `Set-Content` / `Select-String` 的 `-replace` 往返写含中文的 Raku 源文件**。
   `Get-Content -Encoding UTF8` 读出来经 `Set-Content` 回去会变乱码（已在别的仓库烧过一次）。
   编辑器/Agent 一律用 `edit_file` / `write_file`。
2. **写文件统一 UTF-8 无 BOM**。BOM 会污染提交（曾带进 commit message 与 `.rakumod` 首行）。
   提交前可检查：`Format-Hex -Path lib\Web\Lite.rakumod -Count 3` 不应是 `EF BB BF`。
3. **中文 commit message 用 `git commit -F <msgfile>`**，msgfile 用 `[System.Text.UTF8Encoding]::new($false)` 写；
   直接 `git commit -m "中文"` 在 PowerShell 下有编码风险。
4. **不要 `Start-Process` 起服务再长 `sleep`**：会撞工具 600s 超时。起服务前先 `Test-NetConnection` 确认端口空闲，
   确认监听后再继续；验证完必须 `shutdown` / 停进程，不留残留监听。
5. **改完必须自己跑一次 `prove6 -Ilib t/`**，不要以「看着没问题」结项。
6. **临时脚本放 `temp/`**（已在 `.gitignore`），`_*.txt` / `temp_*.txt` / `.precomp/` 同样忽略；
   根目录现有 `_a.txt` / `_e.txt` / `_e2.txt` / `_o.txt` / `_r.txt` / `temp_compile.txt` 是历史调试残留，可按需清理（未入库）。

---

## 11. Git 与发布

- 分支模型：单人主干，`master` 直推；无 PR 流程。
- 提交粒度：一个能力/一次修复一次提交，message 用 `type(scope): 中文说明`。
- 推送：`git push origin master`。当前工作区与远程一致，无未推提交。
- 安装：`zef install .` 可用，但**仓库根目录缺 LICENSE 文件**，对外发布前需补。
- **已知不一致（待修）**：`META6.json` 的 `source-url` / `support.source` 写的是
  `https://gitee.com/skyter10086/raku-WebLite.git`，而真实远程是
  `https://gitee.com/skyter10086/web-lite.git`。zef 元数据抓取会 404，接手后**第一件事建议改掉**。

---

## 12. 欠账与下一步

### 12.1 功能欠账（按优先级）

| 优先级 | 事项 | 说明 |
| --- | --- | --- |
| P2 | 模板引擎 | 目前只有 `html()` 拼串；最小可行版本 = 占位符替换 + 布局，不必上完整 Mustache |
| P2 | 路由 `prefix` 已可用，缺「路由级中间件」 | `scope` 只做前缀，无法给一组路由挂鉴权 |
| P2 | 正则路由 | 现在只有 `{name}` / `*` / `**`，复杂约束只能进 handler 里手判 |
| P3 | 流式响应 / SSE | 所有响应体现状都是整块成型；SSE 需要 Serializer 支持分块输出 |
| P3 | 内容协商 / gzip / ETag 统一化 | ETag 只在静态与 send-file 路径 |
| P3 | chunked 响应输出 | 请求侧 chunked 已支持（`decode-chunked`），响应侧未做 |

### 12.2 工程化欠账

1. **多进程 / 多核**：单 reactor 已到单核天花板（8→64 连接吞吐不涨）。可选路线：pre-fork（每核一个进程，`SO_REUSEPORT`）+ 前置 Nginx。
2. **正经压测口径**：多连接 + 长连接复用 + Nginx 前置，才反映部署水平。现有 `bench/tcp-pipeline` 只测单连接 pipeline。
3. **仓库卫生**：`examples/` 下还留着 10 个历史 `bench-*.raku` 探针（`bench-floor*`、`bench-memory` 等），
   已被 `bench/` 取代，建议清理或明确标注"历史归档"。`temp/` 有若干脚本，其中有价值的应整理进 `bench/` 或 `t/`。
4. **CI**：无。最小方案 = Gitee Go / GitHub Actions 跑 `prove6 -Ilib t/`（注意串行与 21s 耗时）。
5. **LICENSE 文件缺失**、`META6.json` 的 source-url 与真实远程不一致（见 §11）。

### 12.3 需要拍板的定位问题

**纯自用 还是 对外发布？** 影响面：
- 纯自用 → 可砍掉 chunked 请求支持、multipart 边界场景、RFC 5987，维护面大幅缩小。
- 对外 → 必须保留 chunked，且要补 LICENSE、CI、模板引擎、文档站。

**当前代码按「能对外」标准实现**（chunked 与 multipart 都在）。这个决定悬着，会直接影响 P2 优先级，接手后应尽快定。

---

## 13. 接手动作清单

### 13.1 第一小时

1. 读本文件 §0 → §6 → §9。
2. 跑 `prove6 -Ilib t/`，确认 `Tests=120 / PASS`。
3. 跑 `examples\app.raku`，用 curl 打通 7 条路由，重点验证 `/api/slow` 并发不串行。
4. 跑 `bench\tcp-pipeline.raku 2000`，记下本机数字（作为你自己的性能基线）。
5. 改 `META6.json` 的 `source-url` 为真实远程。

### 13.2 改代码前查表

| 想改的东西 | 必读 | 常见错误 |
| --- | --- | --- |
| 路由匹配 / 405 / OPTIONS | §6.1、`!match-route`、`!allow-for` | 忘了 `%!known-path` 也要更新，导致 Allow 头少方法 |
| handler 返回值语义 | `!coerce` | 在新分支里又写一遍转换，出现两套语义 |
| 错误处理 | `!error-response` | 在 handler 里自己 `rescue` 拼 500，绕过统一出口 |
| 任何性能相关 | §8、§9.13 | 只测一次、用 Memory transport、忘了快/慢路径条件 |
| 新增模块 | §4、§2.3 | 忘了在 `META6.json provides` 登记 |
| 新增能力 | §7.3 | 没加 `t/` 项、没同步 README 与本文档项数 |

### 13.3 提交前

- [ ] `prove6 -Ilib t/` 全绿，项数 = 120 + 本次新增
- [ ] 文件是无 BOM UTF-8，中文没变乱码
- [ ] `META6.json` 已登记新模块
- [ ] README「跑测试」项数、本文档 §7.2 项数同步
- [ ] 没有把 `temp/` 或 `_*.txt` 误提交（`git status` 自查）
- [ ] commit message 中文、`type(scope): 说明` 格式

### 13.4 移交方 / 接手方

| 移交方（原作者） | 接手方（你） |
| --- | --- |
| 确认 `origin/master` 已同步、工作区干净 | 拉代码后先跑全量测试 |
| 交代 §12.3 的定位拍板结论 | 拍板结论落进 README 或本文档 |
| 说明哪些 `temp/` 脚本还有价值 | 有价值的整理进 `bench/` 或 `t/` |
| 交代已知坑不重犯（§9） | 新踩的坑**回填进 §9**，不要只留在聊天记录里 |
| 说明 §8 数字的测量口径 | 以自己的实测数字替换，别引用旧值 |

---

## 14. 红线一页纸

1. **不重写协议栈**，socket/TLS/解析基础复用 Cro。
2. **不引入阻塞调用**，`sleep` 一律换 `Promise`。
3. **同连接响应保序**不可绕。
4. **快路径漏 `return`** 是历史上最隐蔽的 bug（测试抓不到，只有耗时翻倍）。
5. **不改 `Transport::Memory` 的人为延时**来"提速"测试，它是故意慢的替身。
6. **不用 PowerShell 往返写含中文的源文件**；一律 UTF-8 无 BOM。
7. **临时产物进 `temp/`**，正式测试进 `t/`，探针进 `bench/`，三者不混。
8. **默认防护值不调低**（`timeout` / `read-timeout` / `max-body-bytes` 等），它们是"默认就能上公网"的基础。
9. **改完必须自己跑全量测试**，不接受"看着对"。

---

*本文档基于 2026-11-05 的 `master@09bb2f0` 实测编写；数字、路径、项数均为当次真实输出。*
