CHANGELOG
=========

head
====

v.0.0.2

  * Lock-protect access to API objects hash

