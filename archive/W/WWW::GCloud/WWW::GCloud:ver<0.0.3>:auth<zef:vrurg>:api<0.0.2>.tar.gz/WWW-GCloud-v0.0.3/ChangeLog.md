CHANGELOG
=========

head
====

v0.0.3

  * Fix deserialization of nominalizables and comples hashes or arrays when there are type maps specified

head
====

v0.0.2

  * Lock-protect access to API objects hash

