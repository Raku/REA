CHANGELOG
=========

head
====

v0.0.4

  * Mostly fix serialization of enums

  * Added `gc-enum` trait to mark enums meant for serialization

  * Added `gc-ctx-wrap`/`gc-context-wrap` methods to `WWW::GCloud::Config`

head
====

v0.0.3

  * Fix deserialization of nominalizables and comples hashes or arrays when there are type maps specified

head
====

v0.0.2

  * Lock-protect access to API objects hash

