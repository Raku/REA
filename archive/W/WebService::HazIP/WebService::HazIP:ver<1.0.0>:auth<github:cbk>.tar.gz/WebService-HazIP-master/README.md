# perl6-WebService-HazIP [![Build Status](https://travis-ci.org/cbk/WebService-HazIP.svg?branch=master)](https://travis-ci.org/cbk/WebService-HazIP)


## SYNOPSIS
 Simple Internet web service used to obtain the
 host's current public addressable IP address.
 Connects to the canihazip.com web site using LWP::Simple
 and returns the data.  Validates the returned data to
 ensure there is a valid IPv4 address.  

## TODO
 * Add other services other then www.canihazip.com
 * Add domains.google.com IP service

## Methods
 * returnIP()

## Returns
* Valid IPv4 address if successful.
* "ERROR! - No Internet connection." on a invalid response.

## Example
    use WebService::HazIP;
    my $ipObj = WebService::HazIP.new;
    say "My public IP address is: " ~ $ipObj.returnIP();
