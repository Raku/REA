## Whateverable

The Whateverables are a collection of IRC bots primarily useful for
Perl 6 developers. They are written in Perl 6 and are based on
[IRC::Client](https://github.com/zoffixznet/perl6-IRC-Client). Many of
the use cases involve running Perl 6 code using pre-built versions of
the [Rakudo](https://github.com/rakudo/rakudo) Perl 6 compiler for
each commit.


### Usage

See [wiki](https://github.com/perl6/whateverable/wiki) for more information.


### Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md).


### Installation

See [wiki/installation](https://github.com/perl6/whateverable/wiki/Installation).
