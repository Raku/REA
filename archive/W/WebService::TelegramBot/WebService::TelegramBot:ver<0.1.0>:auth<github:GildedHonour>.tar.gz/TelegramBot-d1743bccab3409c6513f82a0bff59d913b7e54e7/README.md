# TelegramBot
A genuine Perl 6 client for [Telegram's Bot API](https://core.telegram.org/bots).
