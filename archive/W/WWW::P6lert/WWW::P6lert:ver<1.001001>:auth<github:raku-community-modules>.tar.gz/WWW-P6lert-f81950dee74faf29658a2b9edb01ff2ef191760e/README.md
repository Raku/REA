[![Build Status](https://travis-ci.org/zoffixznet/perl6-WWW-P6lert.svg)](https://travis-ci.org/zoffixznet/perl6-WWW-P6lert)

# NAME

`WWW::P6lert` - Implementation of [alerts.perl6.org](https://alerts.perl6.org) API

# SYNOPSIS

# DESCRIPTION

----

#### REPOSITORY

Fork this module on GitHub:
https://github.com/zoffixznet/perl6-WWW-P6lert

#### BUGS

To report bugs or request features, please use
https://github.com/zoffixznet/perl6-WWW-P6lert/issues

#### AUTHOR

Zoffix Znet (http://perl6.party/)

#### LICENSE

You can use and distribute this module under the terms of the
The Artistic License 2.0. See the `LICENSE` file included in this
distribution for complete details.

The `META6.json` file of this distribution may be distributed and modified
without restrictions or attribution.
