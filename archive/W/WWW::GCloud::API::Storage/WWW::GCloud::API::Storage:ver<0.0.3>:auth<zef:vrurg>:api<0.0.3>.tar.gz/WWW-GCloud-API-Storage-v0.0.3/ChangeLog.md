CHANGELOG
=========

v0.0.3
------

  * Added support for Google Cloud Storage URI (*gs://...*) to the Objects resource method `exists`

