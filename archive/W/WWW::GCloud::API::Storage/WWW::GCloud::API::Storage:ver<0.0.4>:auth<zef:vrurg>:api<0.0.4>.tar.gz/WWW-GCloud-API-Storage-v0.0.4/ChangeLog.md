# CHANGELOG

  - **v0.0.4**
    
      - Switched over to [`JSON::Class:auth<zef:vrurg>`](https://raku.land/zef:vrurg/JSON::Class) framework

  - **v0.0.3**
    
      - Added support for Google Cloud Storage URI (*gs://...*) to the Objects resource method `exists`
