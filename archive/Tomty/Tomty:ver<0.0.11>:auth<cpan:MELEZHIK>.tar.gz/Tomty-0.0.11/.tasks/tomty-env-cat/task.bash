tomty --env-cat dev
