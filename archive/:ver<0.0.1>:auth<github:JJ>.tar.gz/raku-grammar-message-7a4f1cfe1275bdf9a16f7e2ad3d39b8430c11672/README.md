# Raku Distribution Template

Template for Raku modules, classes, roles, to be distributed as a
single package in the ecosystem. Fill this README with your
instructions.

## Installing


<-- Fill your prerequisites here, how to install using zef, how to
install from source -->

## Running

<-- Some examples, or pointing to a directory with them -->

## See also

<-- Related stuff -->

## License
<-- 
This module will be licensed, by default, under the Artistic 2.0 License (the same as Raku itself). You can change it by using a different LICENSE file, as well as changing the license field in META6.json -->
