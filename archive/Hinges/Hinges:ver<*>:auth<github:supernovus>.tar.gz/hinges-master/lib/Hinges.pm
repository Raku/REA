use v6;

use Hinges::XMLParser;
use Hinges::Markup;

class Hinges::DocType::HTML5 {
}
