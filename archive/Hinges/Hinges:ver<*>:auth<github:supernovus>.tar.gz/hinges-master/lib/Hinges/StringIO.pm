use v6;

class Hinges::StringIO {
}

