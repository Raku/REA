# Hinges

## Introduction

Hinges is a Genshi-like template engine for Perl 6.
It's a modular system based on XML SAX streams, it allows for combining
(X)HTML and Perl 6 code in the same template.

## Authors

[Carl Mäsak](https://github.com/masak/)

