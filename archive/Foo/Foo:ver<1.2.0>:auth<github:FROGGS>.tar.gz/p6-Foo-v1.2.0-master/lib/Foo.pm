unit class Foo;

method ver { v1.2 }
