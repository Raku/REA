## `--Foo::--Foo`

A module with `--` in its name.
