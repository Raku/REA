class Mu $
----------

The class for which to build MAIN.

class Mu $
----------

Smartmatcher naming methods to make available on the command-line.

