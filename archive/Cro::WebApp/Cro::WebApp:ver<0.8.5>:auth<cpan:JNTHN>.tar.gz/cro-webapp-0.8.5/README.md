# Cro::WebApp ![Build Status](https://github.com/croservices/cro-webapp/actions/workflows/ci.yml/badge.svg)

This is a library to make it easier to build server-side web applications using
Cro. See the [Cro website](http://cro.services/) for further information and
documentation.