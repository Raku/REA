NAME
====

HTTP::API::Pingdom

AUTHOR
======

Patrick Spek <p.spek@tyil.work>

VERSION
=======

0.0.0

Description
===========

A Perl 6 library to interface with the [Pingdom API](https://www.pingdom.com/api/2.1/).

Installation
============

Install this module through [zef](https://github.com/ugexe/zef):

```sh
zef install HTTP::API::Pingdom
```

Documentation
=============

Documentation is supplied as POD6 in the module itself. You can read this documentation by opening the files manually, or using a tool such as [p6man](https://git.tyil.nl/perl6/p6man) (`p6man HTTP::API::Pingdom`).

License
=======

This module is distributed under the terms of the EUPL-1.2.

