# Xmav::JSON

[![Build Status](https://travis-ci.org/shintakezou/Xmav-JSON.svg?branch=master)](https://travis-ci.org/shintakezou/Xmav-JSON)

A Perl6 JSON module which deserializes (`from-json`) a JSON.

## TODO

- Proper errors handling,
- serialization (`to-json`),
- more tests,
- documentation.

## Notes

It is born as an exercise to try the *grammar* feature, and now it is
also a taste of module packaging and publishing, and Travis CI.


