Symbol
======

ECMAScript 2015's primitive type `Symbol` for Perl 6.

# Synopsis

    use Symbol;
    my Symbol $foo .= new(:name('foo'));
    # A s:symbol notation is exported
    say s:foo;
