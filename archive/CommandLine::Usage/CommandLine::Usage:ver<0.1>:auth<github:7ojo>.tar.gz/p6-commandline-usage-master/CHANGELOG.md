# Change Log
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/)
and this project adheres to [Semantic Versioning](http://semver.org/).

## [Unreleased]
### Added
- Added support for integer type and default value 

## [0.1]
### Added
- Initial release

[Unreleased]: https://github.com/7ojo/p6-commandline-usage/compare/0.1...HEAD
[0.1]: https://github.com/7ojo/p6-commandline-usage/compare/0.1
