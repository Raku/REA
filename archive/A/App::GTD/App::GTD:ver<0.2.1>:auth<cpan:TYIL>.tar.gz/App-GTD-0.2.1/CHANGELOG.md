# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/en/1.0.0/)
and this project adheres to [Semantic
Versioning](http://semver.org/spec/v2.0.0.html).

## [0.2.1] - 2020-02-03

### Added

- Missing dependency `Terminal::ANSIColor` was added to the dependencies in
  `META6.json`.

## [0.2.0] - 2020-02-02

### Added

- A `clean` command will now sort the file on labels, in addition to the
  sorting it already had.

- Documentation has been added to the `App::GTD` and `App::GTD::Config`
  modules. You can use a module like `p6doc` or `App::Rakuman` to read them
  directly in the terminal.

### Changed

- Before trying to read the `todo.txt`, a check will be made to see if the file
  is there in the first place. If it does not exist, the attempt to read it
  will be skipped. This solves a Raku error when trying to read a non-existent
  file, which would occur if the user tries to check their inbox before adding
  any items to it.

- Parsing of the `todo.txt` file is now done line-by-line. This should make the
  application be less error-prone, as incorrect lines (such as empty ones) are
  now skipped. A `gtd clean` should now remove all incorrect lines, this should
  be documented.

## [0.1.0] - 2020-01-17

- Initial release
