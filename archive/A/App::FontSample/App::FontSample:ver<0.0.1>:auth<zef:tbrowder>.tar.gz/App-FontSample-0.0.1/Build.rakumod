# Put this file in the top level of the module's repo directory
class Build {
    # $dist-path is: repo dir
    method build($dist-path) {
        # the executable used to build output:
        my $bfile = "current-capabilities.raku";
        # the build script:
        my $script = $dist-path.IO.add("examples/$bfile").absolute;

        # We need to set this if our script uses any dependencies that
        # may not yet be installed but are in the process of being
        # installed (such as the dist this comes with in lib/).
        my @libs = "$dist-path", $*REPO.repo-chain.map(*.path-spec).flat;

        # do it (note additional args may be placed after the executable 
        #   $script)
        my $proc = run :cwd($dist-path), $*EXECUTABLE, @libs.map({"-I$_"}).flat, 
                   $script, "build";
        exit $proc.exitcode;
    }

    # need a second step to place html links in the /pdf directory

}
