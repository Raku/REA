use v6.d;
use App::FontSample::Layout;
use App::FontSample::SampleText;

unit class App::FontSample::Layout::Specimen
    does App::FontSample::Layout;

my constant @DEFAULT-SIZES =
    8, 10, 12, 16, 20, 28, 36;

my constant $DEFAULT-PANGRAM =
    'The quick brown fox jumps over the lazy dog.';

my constant $DEFAULT-ALPHABET =
    'ABCDEFGHIJKLMNOPQRSTUVWXYZ  abcdefghijklmnopqrstuvwxyz';

my constant $DEFAULT-NUMBERS =
    '0123456789  ! ? & @ # $ % ( ) [ ] { } / \\ + − × =';

method render-page(
    :$pdf!,
    :$page!,
    :$entry!,
    :$paper!,
    :$label-font!,
    :%options!,
    --> Nil
) {
    my Numeric $left = $paper.margin;
    my Numeric $right =
        $paper.width - $paper.margin;

    my Numeric $y =
        $paper.height - $paper.margin;

    my Bool $explicit-pangram =
        %options<pangram>:exists;

    my Str $language =
        %options<language> // 'en';

    if $explicit-pangram
        and (not %options<language>:exists) {
        die 'A specimen pangram requires a language code for its label';
    }

    my Str $pangram =
        %options<pangram> // $DEFAULT-PANGRAM;

    my Str $pangram-label =
        App::FontSample::SampleText.new.pangram-label(
            $language
        );

    my Str $sample-text =
        %options<text> // $pangram;

    my @sizes = %options<sizes>:exists
        ?? %options<sizes>.List
        !! @DEFAULT-SIZES.List;

    my Str $display-name =
        $entry.display-name;

    $page.gfx.graphics: -> $gfx {
        $gfx.text: {
            .font = $label-font, 9;
            .text-position = [$left, $y];
            .say: (%options<title> // 'FONT SPECIMEN')
                ~ " — $display-name";

            $y -= 30;

            .font = $entry.font, 28;
            .text-position = [$left, $y];
            .say: $display-name,
                :width($paper.usable-width);

            $y -= 34;

            if $display-name ne $entry.name {
                .font = $label-font, 8;
                .text-position = [$left, $y];
                .say: "Font file/name: {$entry.name}";

                $y -= 26;
            }

            .font = $label-font, 8;
            .text-position = [$left, $y];
            .say: 'ALPHABET — 15 pt';

            $y -= 25;

            .font = $entry.font, 15;
            .text-position = [$left, $y];
            .say: $DEFAULT-ALPHABET,
                :width($paper.usable-width);

            $y -= 30;

            .font = $label-font, 8;
            .text-position = [$left, $y];
            .say: 'NUMERALS AND PUNCTUATION — 14 pt';

            $y -= 25;

            .font = $entry.font, 14;
            .text-position = [$left, $y];
            .say: $DEFAULT-NUMBERS,
                :width($paper.usable-width);

            $y -= 32;

            .font = $label-font, 8;
            .text-position = [$left, $y];
            .say: $pangram-label.uc ~ ' — 18 pt';

            $y -= 30;

            .font = $entry.font, 18;
            .text-position = [$left, $y];
            .say: $pangram,
                :width($paper.usable-width);

            $y -= 38;

            .font = $label-font, 8;
            .text-position = [$left, $y];
            .say: 'SIZE WATERFALL — point size shown at left';

            $y -= 24;

            for @sizes -> $size {
                my Numeric $line-height =
                    $size * 1.20 + 13;

                last
                    if $y - $line-height
                    < $paper.margin;

                .font = $label-font, 7;
                .text-position = [$left, $y];
                .print: $size.Str ~ ' pt';

                my Numeric $sample-left =
                    $left + 34;

                .font = $entry.font, $size;
                .text-position = [$sample-left, $y];
                .say: $sample-text,
                    :width(
                        $right - $sample-left
                    ),
                    :height($line-height);

                $y -= $line-height;
            }
        }
    }

    return;
}
