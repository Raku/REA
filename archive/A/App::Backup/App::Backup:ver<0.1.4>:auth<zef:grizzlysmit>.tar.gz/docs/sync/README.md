App::Sync
=========

Table of Contents
-----------------

  * [NAME](#name)

  * [AUTHOR](#author)

  * [VERSION](#version)

  * [TITLE](#title)

  * [SUBTITLE](#subtitle)

  * [COPYRIGHT](#copyright)

  * [Introduction](#introduction)

    * [sync.raku](#syncraku)

NAME
====

sync.raku 

AUTHOR
======

Francis Grizzly Smit (grizzly@smit.id.au)

VERSION
=======

0.1.3

TITLE
=====

sync.raku

SUBTITLE
========

A **Raku** application for synchronising a set of boxes.

COPYRIGHT
=========

LGPL V3.0+ [LICENSE](https://github.com/grizzlysmit/backup/blob/main/LICENSE)

[Top of Document](#table-of-contents)

Introduction
============

    A B<Raku> application for synchronising a set of boxes.

sync.raku
=========

```bash
sync.raku --help
Usage:
  sync.raku -- Synchronise systems in hosts file.
```

