App::Backup
===========

Table of Contents
-----------------

  * [NAME](#name)

  * [AUTHOR](#author)

  * [VERSION](#version)

  * [TITLE](#title)

  * [SUBTITLE](#subtitle)

  * [COPYRIGHT](#copyright)

  * [Introduction](#introduction)

    * [backup.raku specials](#backupraku-specials)

NAME
====

Backup 

AUTHOR
======

Francis Grizzly Smit (grizzly@smit.id.au)

VERSION
=======

0.1.3

TITLE
=====

Backup

SUBTITLE
========

A **Raku** application for backing up a box.

COPYRIGHT
=========

LGPL V3.0+ [LICENSE](https://github.com/grizzlysmit/backup/blob/main/LICENSE)

[Top of Document](#table-of-contents)

Introduction
============

    A B<Raku> application for backing up a box.

backup.raku specials
====================

```bash
backup.raku specials --help
Usage:
  backup.raku specials -- backup special files and directories to per system special location.
```

[Top of Document](#table-of-contents)

