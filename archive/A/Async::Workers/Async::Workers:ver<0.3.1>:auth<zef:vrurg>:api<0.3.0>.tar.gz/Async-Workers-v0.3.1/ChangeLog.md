CHANGELOG
=========

  * **v0.3.1**

      * Another race condition must not happen now

      * `do-async` don't let pass arguments to its code anymore, but it lets giving jobs names now with `:name` argument.

  * **v0.2.3**

      * Added method `messages`

  * **v0.2.2**

      * Migrate to build-tools and zef ecosystem

