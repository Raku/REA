# rakudoc

# AttrX::Mooish Document Pages

  - [`..::ChangeLog`](../../ChangeLog.md)

  - [`AttrX::Mooish`](AttrX/Mooish.md)

  - [`README`](../../README.md)

# COPYRIGHT

(c) 2023, Vadim Belman <vrurg@cpan.org>

# LICENSE

Artistic License 2.0

See the [*LICENSE*](../../LICENSE) file in this distribution.
