class Simple {

    method doit {
        say "we doit";

    }

    method dothat {
        say "we dothat";

    }

}
