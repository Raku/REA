class Simple {

    method do-it {
        say "we doit";

    }

    method do-that {
        say "we dothat";

    }

}
