NAME
====

Samaki::Plugout::Duckview -- Display CSV data in the terminal using DuckDB

DESCRIPTION
===========

Display CSV output in the terminal pane using the DuckDB CLI.

