NAME
====

Samaki::Plugout::Raw -- Open output with the system default application

DESCRIPTION
===========

Open the output file using the system's default application (via `open` on macOS or `xdg-open` on Linux).

