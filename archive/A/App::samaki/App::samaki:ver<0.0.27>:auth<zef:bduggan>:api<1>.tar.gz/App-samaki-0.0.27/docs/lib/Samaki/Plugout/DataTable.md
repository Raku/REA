NAME
====

Samaki::Plugout::DataTable -- Interactive HTML table view

DESCRIPTION
===========

Display CSV data as an interactive HTML table in the browser. Supports sorting, searching, pagination, and expandable cells for long content.

