unit role Samaki::Plugin;

use Terminal::ANSI::OO 't';
use Prettier::Table;
use Duckie;
use Duckie::Result;
use Samaki::Conf;
use Log::Async;
use Samaki::Cell;
use Samaki::Page;
use Timezone::Simple;

method name { ... }
method description { ... }

has $.is-enabled is rw = True;

#| Action to run when the cell is selected
method select-action { 'run' }

#| Wrap words?
method wrap { 'none' }

#| Stream output as it is produced?
has $.stream-output is rw = True;

#| Clear the output pane before running?
method clear-stream-before { True }

method setup(Samaki::Conf :$conf) { }

#| Default extension for output files
method output-ext { '' }

#| Write output to file?
method write-output { True }

has $.output; # Str or array
has Channel $.output-stream = Channel.new;

method set-output($value) { $!output = $value }
method clear-output { $!output = Nil }

multi method stream(:$txt!, :$level!, :$meta) {
  self.stream: %( :$txt, :$meta, :$level )
}

multi method stream(:$txt!, :$meta) {
  self.stream: %( :$txt, :$meta )
}

multi method stream($stuff) {
  $!output-stream.send: $stuff;
}

method info(Str $what) {
  self.stream: txt => [color('info') => $what], level => 'info';
  #self.stream: [color('info') => $what];
}

method error(Str $what) {
  self.stream: [color('error') => $what]
}

method warn(Str $what) {
  self.stream: [color('warn') => $what]
}

#| Run shutdown actions
method shutdown {
}

has Str $.errors is rw;
has $.res;

method execute(Samaki::Cell :$cell, Samaki::Page :$page, Str :$mode, IO::Handle :$out, :$pane, Str :$action) {
  ... 
}

my $tz = tz-local;

sub format-cell($cell) {
  given $cell.^name {
    when 'Str' { $cell.fmt('%-15s ') }
    when 'Int' { $cell.fmt('%-15d ') }
    when 'Num' { $cell.fmt('%-15.4f ') }
    when 'Date' { tz-fmt($tz, $cell) }
    when 'DateTime' { tz-fmt($tz, $cell) }
    when 'Bool' { $cell ?? 'true'.fmt('%-15s ') !! 'false'.fmt('%-15s ') }
    when 'Nil' { 'NULL' }
    when 'Any' { 'NULL' }
    default  { $cell.raku.fmt('%-15s ') }
  }
}

sub format-row(@row) {
  @row.map({ format-cell($_) })
}

multi method output-duckie(Duckie::Result $result-set, :$max-rows = 100) {
  my $table = Prettier::Table.new(
    field-names => $result-set.column-names.map(*.subst(:g,"\n","\\n")),
    align => 'l',
  );
  my $row-count = $result-set.row-count;
  my $cols = $result-set.column-names;
  my @row-data;
  my $i = 0;
  my $truncated = False;
  for $result-set.rows(:arrays) -> @row {
    @row-data.push: @row;
    $table.add-row(format-row(@row));
    if ++$i > $max-rows {
      $truncated = True;
      last;
    }
  }

  my sub pl(Int $count,Str $str) { $count ~ ' ' ~ $str ~ ($count == 1 ?? '' !! 's') }

  my @lines = ( pl($row-count,'row') ~ ', ' ~ pl($cols.elems,'column') );
  my $row = 0;
  for $table.gist.lines -> $txt {
    if $row == 1 { # columns
      @lines.push: %( :$txt, meta => %( action => 'view_row', row_data => [ '' xx @$cols ] , :$cols ) );
      next;
    }
    if $row < 3 { # header
       @lines.push: $txt;
       next;
    }
    @lines.push: %( :$txt, meta => %( action => 'view_row', row_data => @row-data[$row - 3], :$cols ) );
    NEXT { $row++ }
  }
  if $truncated {
    @lines.push: "... output truncated from $row-count to $max-rows rows ...";
  }
  return @lines;
}

multi method output-duckie(IO::Path $path) {
  $!res = Duckie.new.query("select * from read_csv('{$path}');");
  self.stream:
    txt => [ color('normal') => 'wrote to ', color('button') => "[{ $path.basename }]" ],
    meta => %( action => 'do_output', :$path );

  return self.output-duckie($!res);
}

method write-duckie(Duckie::Result $result-set, IO::Handle :$out) {
  my $cols = $result-set.column-names;
  my sub esc($str) {
    return '' without $str;
    my $s = ~$str;
    return $s unless $s.contains(','|'"'|"\n");
    '"' ~ $s.subst(:g,'"','""') ~ '"';
  }
  $out.put: $cols.map({ esc($_) }).join(',');
  for $result-set.rows(:arrays) -> @row {
    $out.put: @row.map({ esc($_) }).join(',');
  }
}

