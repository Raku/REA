NAME
====

Samaki::Plugout::HTML -- Open HTML output in the browser

DESCRIPTION
===========

Open an HTML output file directly in the default browser.

