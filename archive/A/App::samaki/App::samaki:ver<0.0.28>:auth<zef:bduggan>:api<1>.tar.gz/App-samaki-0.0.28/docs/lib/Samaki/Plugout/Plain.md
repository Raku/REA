NAME
====

Samaki::Plugout::Plain -- Display plain text in the browser

DESCRIPTION
===========

Display plain text output in the browser as preformatted text with word wrapping.

