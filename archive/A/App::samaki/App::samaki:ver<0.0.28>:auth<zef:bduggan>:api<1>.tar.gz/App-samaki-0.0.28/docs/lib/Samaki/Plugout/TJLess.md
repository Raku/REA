NAME
====

Samaki::Plugout::TJLess -- View JSON with jless in a tmux window

DESCRIPTION
===========

Open JSON output in jless (an interactive JSON viewer) in a new tmux window.

