NAME
====

Samaki::Plugout::JSON -- Display JSON in the terminal

DESCRIPTION
===========

Pretty-print JSON output to the terminal pane.

