### method select-action

```raku
method select-action() returns Mu
```

Action to run when the cell is selected

### method wrap

```raku
method wrap() returns Mu
```

Wrap words?

### method stream-output

```raku
method stream-output() returns Mu
```

Stream output as it is produced?

### method clear-stream-before

```raku
method clear-stream-before() returns Mu
```

Clear the output pane before running?

### method output-ext

```raku
method output-ext() returns Mu
```

Default extension for output files

### method write-output

```raku
method write-output() returns Mu
```

Write output to file?

### method shutdown

```raku
method shutdown() returns Mu
```

Run shutdown actions

