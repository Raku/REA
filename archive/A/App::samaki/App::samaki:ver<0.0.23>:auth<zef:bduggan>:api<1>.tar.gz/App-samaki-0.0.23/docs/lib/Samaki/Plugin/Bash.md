NAME
====

Samaki::Plugin::Bash -- Run the cell as a bash script.

DESCRIPTION
===========

The cell contents are piped to stdin. Output is streamed to the pane and also sent to the output file.

OPTIONS
=======

* `quietly` -- do not send to the pane, if this is true.

