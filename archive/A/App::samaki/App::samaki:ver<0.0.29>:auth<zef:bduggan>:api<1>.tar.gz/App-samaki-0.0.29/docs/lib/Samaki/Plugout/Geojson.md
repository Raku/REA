NAME
====

Samaki::Plugout::Geojson -- Display GeoJSON on an interactive map

DESCRIPTION
===========

Display GeoJSON output on an interactive Leaflet map in the browser.

