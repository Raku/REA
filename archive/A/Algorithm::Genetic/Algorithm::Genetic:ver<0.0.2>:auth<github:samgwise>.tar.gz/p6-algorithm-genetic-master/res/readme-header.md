[![Build Status](https://travis-ci.org/samgwise/p6-algorithm-genetic.svg?branch=master)](https://travis-ci.org/samgwise/p6-algorithm-genetic)
