[![Actions Status](https://github.com/FCO/Acme-Overreact/actions/workflows/test.yml/badge.svg)](https://github.com/FCO/Acme-Overreact/actions)

NAME
====

Acme::Overreact - Make your code overreact

SYNOPSIS
========

```raku
use Acme::Overreact;

CHECK overreact;

say 42; # prints '42!!!'
```

DESCRIPTION
===========

Acme::Overreact is just a joke, please do not use that in production code

AUTHOR
======

Fernando Corrêa de Oliveira <fernando.correa@humanstate.com>

COPYRIGHT AND LICENSE
=====================

Copyright 2024 Fernando Corrêa de Oliveira

This library is free software; you can redistribute it and/or modify it under the Artistic License 2.0.

