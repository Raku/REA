class Build {
    method build($dist-path) {
        # do build stuff to your module
        # which is located at $dist-path
        dd %?RESOURCES;
        my IO::Path $CWD = $*CWD;
        my Str:D $path = "/usr/lib/perl6/site/bin";
        chdir($path.IO);
        my Proc $r = run 'ln', '-sf', "urls.raku",              "urls"               unless "urls".IO              ~~ :e;
        $r = run         'ln', '-sf', "urls.raku-j",            "urls-j"             unless "urls-j".IO            ~~ :e;
        $r = run         'ln', '-sf', "urls.raku-js",           "urls-js"            unless "urls-js".IO           ~~ :e;
        $r = run         'ln', '-sf', "urls.raku-m",            "urls-m"             unless "urls-m".IO            ~~ :e;
        chdir("/usr/local/bin/".IO);
        $r = run         'ln', '-sf', "$path/urls.raku",        "urls.raku"          unless "urls.raku".IO         ~~ :e;
        $r = run         'ln', '-sf', "$path/urls.raku-j",      "urls.raku-j"        unless "urls.raku-j".IO       ~~ :e;
        $r = run         'ln', '-sf', "$path/urls.raku-js",     "urls.raku-js"       unless "urls.raku-js".IO      ~~ :e;
        $r = run         'ln', '-sf', "$path/urls.raku-m",      "urls.raku-m"        unless "urls.raku-m".IO       ~~ :e;
        $r = run         'ln', '-sf', "$path/urls",             "urls"               unless "urls".IO              ~~ :e;
        $r = run         'ln', '-sf', "$path/urls-j",           "urls-j"             unless "urls-j".IO            ~~ :e;
        $r = run         'ln', '-sf', "$path/urls-js",          "urls-js"            unless "urls-js".IO           ~~ :e;
        $r = run         'ln', '-sf', "$path/urls-m",           "urls-m"             unless "urls-m".IO            ~~ :e;
        $r = run         'apt-get', 'reinstall', '--yes', "libdbi-perl";
        $r = run         'apt-get', 'reinstall', '--yes', "libcrypt-pbkdf2-perl";
        $r = run         'apt-get', 'reinstall', '--yes', "libapache-session-perl";
        $r = run         'apt-get', 'reinstall', '--yes', "libapache-session-wrapper-perl";
        $r = run         'apt-get', 'reinstall', '--yes', "libreadline8";
        $r = run         'apt-get', 'reinstall', '--yes', "libreadline-dev";
        $r = run         'apt-get', 'reinstall', '--yes', "libperl-dev";
        $r = run         'apt-get', 'reinstall', '--yes', "libperl-version-perl";
        $r = run         'apt-get', 'reinstall', '--yes', "libdbd-mysql-perl", "libdbd-odbc-perl", "libdbd-mariadb-perl", "libdbd-excel-perl";
        $r = run         'apt-get', 'reinstall', '--yes', "libdbd-csv-perl", "libdbd-ldap-perl", "libdbd-freetds", "libdbd-odbc-perl";
        $r = run         'apt-get', 'reinstall', '--yes', "libdbd-sqlite3-perl", "libdbd-sybase-perl", "libdbd-pg-perl";
        $r = run         'apt-get', 'reinstall', '--yes', "libpgobject-perl";
        $r = run         'apt-get', 'reinstall', '--yes', "libanyevent-dbd-pg-perl";
        $r = run         'apt-get', 'reinstall', '--yes', "libdbd-firebird-perl";
        $r = run         'apt-get', 'reinstall', '--yes', "libdbd-cassandra-perl";
        chdir($CWD);
        my $Init_session = q:to/ENDPERL/;
        
        package Init_session;
        #
        #===============================================================================
        #
        #         FILE: init_session.pm
        #
        #  DESCRIPTION: 
        #
        #        FILES: ---
        #         BUGS: ---
        #        NOTES: ---
        #       AUTHOR: Francis Grizzly Smit (FGJS), grizzly@smit.id.au
        # ORGANIZATION: 
        #      VERSION: 1.1.14
        #      CREATED: 2022-12-06 10:16:33
        #     REVISION: ---
        #===============================================================================
        
        use parent 'Exporter';
        use strict;
        use warnings;
        use v5.34.0;
        use Apache::Session::Postgres;
        use DBI;
        #use Exporter;
        
        #our @ISA = qw(Exporter);
        
        our @EXPORT = qw(tiehash_without_id tiehash_with_id);
        our @EXPORT_OK = qw(tiehash_without_id tiehash_with_id);
        
        sub tiehash_without_id {
            my ($args) = @_;
            return Apache::Session::Postgres->TIEHASH(undef(), $args);
        } ## --- end sub tiehash_without_id
        
        
        sub tiehash_with_id {
            my ($session_id, $args) = @_;
            return Apache::Session::Postgres->TIEHASH($session_id, $args);
        } ## --- end sub tiehash_with_id
        
        return 1;
                
        ENDPERL

        my Str:D $lib-path = "/usr/share/perl5";
        $lib-path.IO.mkdir: 0o777;
        "$lib-path/Init_session.pm".IO.spurt($Init_session);
    }
}

