Table of Contents
-----------------

  * [NAME](#name)

  * [AUTHOR](#author)

  * [VERSION](#version)

  * [TITLE](#title)

  * [SUBTITLE](#subtitle)

  * [COPYRIGHT](#copyright)

  * [Introduction](#introduction)

  * [Introduction](#1-introduction)

  * [Command Line](#2-command-line)

  * [Web Page](#3-web-page)

NAME
====

Urls 

AUTHOR
======

Francis Grizzly Smit (grizzly@smit.id.au)

VERSION
=======

v0.1.21

TITLE
=====

Urls

SUBTITLE
========

Urls is a command line interface to my urls PostgreSQL database.

COPYRIGHT
=========

LGPL V3.0+ [LICENSE](https://github.com/grizzlysmit/URLs/blob/main/LICENSE)

The Url Stuff
=============

1. Introduction
---------------

Manage your URLs that you cannot get or cannot easily get with google. Basically a bookmark manager, but searchable and organisable.

the docs are still a bit raw and rough

2. Command Line 
----------------

Built in [Raku](https://raku.org/)

3. Web Page
-----------

Built in [`Mod_Perl`](https://perl.apache.org/)

[Top of Document](#table-of-contents)

### multi sub MAIN

```raku
multi sub MAIN(
    "reconfigure",
    "db",
    Str $prefix = "",
    Bool:D :v(:$version) = Bool::False,
    Bool:D :h(:$help) = Bool::False,
    Bool:D :s(:$syntax) = Bool::False,
    Bool:D :n(:nocolor(:$nocolour)) is copy = Bool::False,
    Bool:D :c(:color(:$colour)) is copy = Code.new
) returns Int
```

# list all the links if prefix is supplied list all links prefixed by it.

### multi sub MAIN

```raku
multi sub MAIN(
    "list",
    "links",
    Str $prefix = "",
    Bool:D :v(:$version) = Bool::False,
    Bool:D :h(:$help) = Bool::False,
    Bool:D :s(:$syntax) = Bool::False,
    Bool:D :n(:nocolor(:$nocolour)) is copy = Bool::False,
    Bool:D :c(:color(:$colour)) is copy = Code.new
) returns Int
```

# list all the links if prefix is supplied list all links prefixed by it.

### multi sub MAIN

```raku
multi sub MAIN(
    "list",
    "aliases",
    Str $prefix = "",
    Bool:D :v(:$version) = Bool::False,
    Bool:D :h(:$help) = Bool::False,
    Bool:D :s(:$syntax) = Bool::False,
    Bool:D :n(:nocolor(:$nocolour)) is copy = Bool::False,
    Bool:D :c(:color(:$colour)) is copy = Code.new
) returns Int
```

# list all the aliasses if prefix is supplied list all aliasses prefixed by it.

### multi sub MAIN

```raku
multi sub MAIN(
    "list",
    "pages",
    Str $page-name = "",
    Str $prefix = "",
    Bool:D :v(:$version) = Bool::False,
    Bool:D :h(:$help) = Bool::False,
    Bool:D :s(:$syntax) = Bool::False,
    Bool:D :n(:nocolor(:$nocolour)) is copy = Bool::False,
    Bool:D :c(:color(:$colour)) is copy = Code.new
) returns Int
```

# list all the pages if prefix is supplied list all pages prefixed by it.

### multi sub MAIN

```raku
multi sub MAIN(
    "add",
    "page",
    Str $page where { ... },
    Str :$name = "",
    Bool:D :v(:$version) = Bool::False,
    Bool:D :h(:$help) = Bool::False,
    Bool:D :s(:$syntax) = Bool::False,
    Bool:D :n(:nocolor(:$nocolour)) is copy = Bool::False,
    Bool:D :c(:color(:$colour)) is copy = Code.new,
    *@links
) returns Int
```

# add the page if supplied

### multi sub MAIN

```raku
multi sub MAIN(
    "add",
    "links",
    Str $link-section where { ... },
    Bool:D :v(:$version) = Bool::False,
    Bool:D :h(:$help) = Bool::False,
    Bool:D :s(:$syntax) = Bool::False,
    Bool:D :n(:nocolor(:$nocolour)) is copy = Bool::False,
    Bool:D :c(:color(:$colour)) is copy = Code.new,
    *%links where { ... }
) returns Int
```

# list all the links if prefix is supplied list all links prefixed by it.

### multi sub MAIN

```raku
multi sub MAIN(
    Str:D $key,
    Bool:D :v(:$version) = Bool::False,
    Bool:D :h(:$help) = Bool::False,
    Bool:D :s(:$syntax) = Bool::False,
    Bool:D :n(:nocolor(:$nocolour)) is copy = Bool::False,
    Bool:D :c(:color(:$colour)) is copy = Code.new
) returns int
```

# basic key signature.

