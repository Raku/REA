use Air::Functional :BASE;
use Air::Base;
use Air::Form;
use Net::SMTP;

class X::Air::MailForm::SendFailed is Exception {
    has Str $.reason;
    method message { "MailForm send failed — { $.reason }" }
}

class Air::Plugin::MailForm does Form {

    method do-form-attrs {
        self.form-attrs: {:submit-button-text('Send Message')}
    }

    method validate-form { }

    method mail-message(Str $from, Str $to, Str $subject --> Str) { '' }

    method submit-form(Air::Plugin::MailForm $form) {
        if $form.is-valid {
            note "MailForm submission";
            my $mail = start { send-mail-form($form) };
            await Promise.anyof($mail, Promise.in(30));

            if $mail.status == Kept {
                self.finish: '<p style="text-align:center"><em><u>Thank you — your message has been sent!</u></em></p>'
            }
            elsif $mail.status == Planned {
                note "MailForm: SMTP timed out after 30s";
                self.finish: '<p style="text-align:center"><em>Sorry — the mail server timed out. Please try again later.</em></p>'
            }
            else {
                note "MailForm: { $mail.cause.message }";
                self.finish: '<p style="text-align:center"><em>Sorry — your message could not be sent. Please try again later.</em></p>'
            }
        }
        else {
            self.retry: $form
        }
    }
}

class Air::Plugin::ContactForm is Air::Plugin::MailForm {
    has Str $.name    is validated(%va<names>) is required;
    has Str $.email   is validated(%va<email>) is email is required;
    has Str $.message is multiline(:5rows, :60cols);

    method mail-message(Str $from, Str $to, Str $subject --> Str) {
        qq:to/END/;
        From:    $from
        To:      $to
        Subject: $subject

        Name:    { $.name  }
        Email:   { $.email }

        { $.message }
        END
    }

    method form-routes {
        self.init;
        self.submit: -> Air::Plugin::ContactForm $form {
            self.submit-form($form)
        }
    }
}

our $mail-form is export = Air::Plugin::ContactForm.empty;

sub send-mail-form(Air::Plugin::MailForm $form) {
    CATCH {
        default { X::Air::MailForm::SendFailed.new(:reason(.message)).throw }
    }

    my $host    = %*ENV<SMTP_HOST>;
    my $port    = %*ENV<SMTP_PORT>   // '587';
    my $user    = %*ENV<SMTP_USER>;
    my $pass    = %*ENV<SMTP_PASS>;
    my $from    = %*ENV<MAIL_FROM>;
    my $to      = %*ENV<MAIL_TO>;
    my $bcc     = %*ENV<MAIL_BCC>;
    my $subject = %*ENV<MAIL_SUBJECT> // 'Contact Form Submission';

    my $message = $form.mail-message($from, $to, $subject);

    my @to = "<$to>", ({"<$_>"} with $bcc);
    my $smtp = Net::SMTP.new(:server($host), :$port);
    $smtp.auth($user, $pass);
    $smtp.send("<$from>", @to, $message);
    $smtp.quit;
}
