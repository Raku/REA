NAME
====

Algorithm::Trie::libdatrie - blah blah blah

SYNOPSIS
========

    use Algorithm::Trie::libdatrie;

DESCRIPTION
===========

Algorithm::Trie::libdatrie is ...

AUTHOR
======

zengargoyle <zengargoyle@gmail.com>

COPYRIGHT AND LICENSE
=====================

Copyright 2015 zengargoyle

This library is free software; you can redistribute it and/or modify it under the Artistic License 2.0.
