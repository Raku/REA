[![Build Status](https://travis-ci.org/skaji/perl6-Acme-Test-Module.svg?branch=master)](https://travis-ci.org/skaji/perl6-Acme-Test-Module)

NAME
====

Acme::Test::Module - a test module

SYNOPSIS
========

    use Acme::Test::Module;

DESCRIPTION
===========

Acme::Test::Module is a test module.

AUTHOR
======

Shoichi Kaji <skaji@cpan.org>

COPYRIGHT AND LICENSE
=====================

Copyright 2017 Shoichi Kaji

This library is free software; you can redistribute it and/or modify it under the Artistic License 2.0.

