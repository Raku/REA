# AI-NLP

A Natural Language Processing package mostly for IRC bots but useful elsewhere
