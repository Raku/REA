[![Actions Status](https://github.com/librasteve/Air-Plugin-Rakudoc/actions/workflows/test.yml/badge.svg)](https://github.com/librasteve/Air-Plugin-Rakudoc/actions)



