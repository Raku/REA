unit module Air::Plugin::Rakudoc;

use Air::Functional :BASE;
use Air::Base;
use Air::Plugin::Hilite;

sub inline-to-md(Str $text --> Str) {
    my $r = $text;
    $r = $r.subst(/ 'B<' (<-[>]>+) '>' /, { "**$0**" }, :g);
    $r = $r.subst(/ 'C<' (<-[>]>+) '>' /, { "`$0`" }, :g);
    $r = $r.subst(/ 'L<' (<-[|>]>+) '|' (<-[>]>+) '>' /, { "[$0]($1)" }, :g);
    $r = $r.subst(/ 'L<' (<-[>]>+) '>' /,              { "[$0]($0)" }, :g);
    $r
}

sub rakudoc(Str $pod --> Content) is export {
    my @parts;
    my @buf;
    my ($block-type, $block-lang) = '', '';
    my $in-block = False;

    sub flush-text {
        return unless @buf.join('').trim;
        @parts.push: markdown @buf.join("\n");
        @buf = ();
    }

    for $pod.lines.grep({ $_ ne '=begin pod' && $_ ne '=end pod' }) -> $line {
        if !$in-block && $line ~~ /^ '=begin ' (\w+) [\s+ (.+)]? $/ {
            flush-text();
            $block-type = ~$0;
            my $attrs   = ~($1 // '');
            $block-lang = ($attrs ~~ / ':lang<' (\w+) '>' /) ?? ~$0 !! '';
            $in-block   = True;
        }
        elsif $in-block && $line eq "=end $block-type" {
            my $code = @buf.join("\n");
            @buf     = ();
            $in-block = False;
            @parts.push: $block-lang eq 'raku'
                ?? hilite $code
                !! pre code $code
            if $block-type eq 'code';
            $block-type = '';
            $block-lang = '';
        }
        elsif $in-block {
            @buf.push: $line;
        }
        else {
            given $line {
                when /^ '=head1 ' (.+) $/ { flush-text(); @parts.push: h1 inline-to-md(~$0) }
                when /^ '=head2 ' (.+) $/ { flush-text(); @parts.push: h2 inline-to-md(~$0) }
                when /^ '=head3 ' (.+) $/ { flush-text(); @parts.push: h3 inline-to-md(~$0) }
                when /^ '=head4 ' (.+) $/ { flush-text(); @parts.push: h4 inline-to-md(~$0) }
                when /^ '=item '  (.+) $/ { @buf.push: "* " ~ inline-to-md(~$0) }
                default                   { @buf.push: inline-to-md($line) }
            }
        }
    }
    flush-text();

    content [|@parts]
}
