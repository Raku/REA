[![Actions Status](https://github.com/lizmat/AccountableBagHash/actions/workflows/linux.yml/badge.svg)](https://github.com/lizmat/AccountableBagHash/actions) [![Actions Status](https://github.com/lizmat/AccountableBagHash/actions/workflows/macos.yml/badge.svg)](https://github.com/lizmat/AccountableBagHash/actions) [![Actions Status](https://github.com/lizmat/AccountableBagHash/actions/workflows/windows.yml/badge.svg)](https://github.com/lizmat/AccountableBagHash/actions)

NAME
====

AccountableBagHash - be an accountable BagHash / MixHash

SYNOPSIS
========

```raku
use AccountableBagHash;

my %abh is AccountableBagHash = a => 42, b => 666;
%abh<a> =  5; # ok
%abh<a> = -1; # throws

my %amh is AccountableMixHash = a => 3.14, b => 666;
%amh<a> =  6.28; # ok
%amh<a> = -1;    # throws

CATCH {
    when X::BagHash::Acountable {
        say "You do not have enough {.key}";
        .resume
    }
}
```

DESCRIPTION
===========

This module makes an `AccountableBagHash` / `AccountableMixHash` class available that can be used instead of the normal `BagHash` / `MixHash`. The only difference with a normal `BagHash` / `MixHash` is, is that if an attempt is made to set the value of a key to **less than 0**, that an exception is thrown rather than just deleting the key from the `BagHash` / `MixHash`.

Also exports a `X::BagHash::Accountable` error class that will be thrown if an attempt is made to set the value to below 0.

AUTHOR
======

Elizabeth Mattijsen <liz@raku.rocks>

Source can be located at: https://codeberg.org/lizmat/AccountableBagHash . Comments and Pull Requests are welcome.

If you like this module, or what I'm doing more generally, committing to a [small sponsorship](https://github.com/sponsors/lizmat/) would mean a great deal to me!

COPYRIGHT AND LICENSE
=====================

Copyright 2018, 2020, 2021, 2022, 2025, 2026 Elizabeth Mattijsen

This library is free software; you can redistribute it and/or modify it under the Artistic License 2.0.

