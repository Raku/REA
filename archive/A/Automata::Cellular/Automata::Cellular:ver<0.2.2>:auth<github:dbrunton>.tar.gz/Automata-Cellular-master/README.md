Automata::Cellular [![Build Status](https://travis-ci.org/dbrunton/Automata-Cellular.svg?branch=master)](https://travis-ci.org/dbrunton/Automata-Cellular)
==================

Wolfram elementary cellular automata in Perl6.

See http://mathworld.wolfram.com/ElementaryCellularAutomaton.html
