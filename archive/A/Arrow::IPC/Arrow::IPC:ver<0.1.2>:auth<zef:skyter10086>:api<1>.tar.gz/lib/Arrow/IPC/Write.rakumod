use v6.d;
use NativeCall;
use Arrow::IPC::FlatBuf;
use Arrow::IPC::Format;
use Arrow::IPC::CData;

#| 把 Arrow C data interface 的 schema/chunk 视图写成 Arrow IPC 字节流。
#| 鸭子接口：输入对象只需 `.schema` / `.chunks(&code)`，schema 节点需
#| `.format/.name/.n-children/.column/.addr/.dictionary`，chunk 列需
#| `.length/.null-count/.buffer/.children/.addr`。不依赖任何具体驱动。
unit module Arrow::IPC::Write;

#| 写一个 Type table，返回它的偏移。
#|
#| 空 table（Bool / Utf8 / List / Struct_ …）也真的写一张 0 字段的 table，
#| 因为 union 的值必须是一个有效指针。
sub build-type(Arrow::IPC::FlatBuf::FlatBuf $fb, %t --> Int) {
    my Int $tag = %t<tag>;

    if $tag == 2 {                                  # Int
        $fb.start-table(2);
        $fb.prepend-i8(%t<signed> ?? 1 !! 0); $fb.slot(1);
        $fb.prepend-i32(%t<bitwidth>);        $fb.slot(0);
        return $fb.end-table;
    }
    if $tag == 3 {                                  # FloatingPoint
        $fb.start-table(1);
        # precision 默认 0（HALF），所以 HALF 时不写
        if %t<precision> != 0 {
            $fb.prepend-i16(%t<precision>); $fb.slot(0);
        }
        return $fb.end-table;
    }
    if $tag == 7 {                                  # Decimal
        $fb.start-table(3);
        # bitWidth 默认 128，等于默认值时省略
        if %t<bitwidth> != 128 {
            $fb.prepend-i32(%t<bitwidth>); $fb.slot(2);
        }
        $fb.prepend-i32(%t<scale>);     $fb.slot(1);
        $fb.prepend-i32(%t<precision>); $fb.slot(0);
        return $fb.end-table;
    }
    if $tag == 8 {                                  # Date
        $fb.start-table(1);
        # Date.unit 的默认值是 MILLISECOND，不是 DAY —— 省略就等于
        # 声明 date64，于是 4 字节的 date32 会被当成 8 字节读，日期飞到几千年后。
        $fb.prepend-i16(%t<unit>); $fb.slot(0);
        return $fb.end-table;
    }
    if $tag == 9 {                                  # Time
        # Arrow fbs: Time.unit 默认 MILLISECOND(1)，不是 SECOND(0)。
        # 省略 0 会让 reader 读回 1；写 1 虽合法但没必要。
        $fb.start-table(2);
        $fb.prepend-i32(%t<bitwidth>); $fb.slot(1);
        if %t<unit> != 1 { $fb.prepend-i16(%t<unit>); $fb.slot(0) }
        return $fb.end-table;
    }
    if $tag == 10 {                                 # Timestamp
        # Timestamp.timezone 是 string 字段：FlatBuffers 里必须先写字符串
        # 拿到它的偏移，再用 prepend-uoffset 在 table 槽位放一个 uoffset
        # 引用。原来直接 `prepend-string($tz); slot(1)` 把字符串长度前缀
        # 当成字段值，reader 解引用时拿到的是 13（"Asia/Shanghai" 长度），
        # 指向缓冲区外 -> "Invalid flatbuffers message" / SIGSEGV。
        my Str $tz = %t<timezone> // '';
        my Int $tz-off = 0;
        if $tz.chars {
            $fb.prepend-string($tz);
            $tz-off = $fb.size;
        }
        $fb.start-table(2);
        if $tz-off { $fb.prepend-uoffset($tz-off); $fb.slot(1) }
        # fbs 里 Timestamp.unit 没有默认值（必填），必须总是写；
        # 漏掉 SECOND(0) 会让 reader 从相邻字节读出随机 unit。
        $fb.prepend-i16(%t<unit>); $fb.slot(0);
        return $fb.end-table;
    }
    if $tag == 11 {                                 # Interval
        $fb.start-table(1);
        # Interval.unit 无默认值，必须写。
        $fb.prepend-i16(%t<unit>); $fb.slot(0);
        return $fb.end-table;
    }
    if $tag == 18 {                                 # Duration
        $fb.start-table(1);
        # Duration.unit 默认 MILLISECOND(1)。
        if %t<unit> != 1 { $fb.prepend-i16(%t<unit>); $fb.slot(0) }
        return $fb.end-table;
    }
    if $tag == 15 {                                 # FixedSizeBinary
        $fb.start-table(1);
        $fb.prepend-i32(%t<size>); $fb.slot(0);
        return $fb.end-table;
    }
    if $tag == 17 {                                 # Map
        $fb.start-table(1);                         # keysSorted 默认 false
        return $fb.end-table;
    }
    die "arrow-ipc: unsupported Arrow type tag $tag" unless $tag == 1 || $tag == 4
        || $tag == 5 || $tag == 6 || $tag == 12 || $tag == 13 || $tag == 19
        || $tag == 20 || $tag == 21;

    $fb.start-table(0);                             # Null / Bool / Utf8 / …
    $fb.end-table;
}

#| 写一张 DictionaryEncoding，返回它的偏移。
#|
#| DuckDB 的 ENUM 在 C data interface 里表现为「索引数组 + dictionary 指针」：
#| 列本身的 format 是 `C`（uint8），值类型在 `dictionary` 指向的 schema 里。
#| 照着写出来，pyarrow 才会把它读成真正的字典类型而不是一堆数字。
sub build-dictionary-encoding(Arrow::IPC::FlatBuf::FlatBuf $fb, Int $id --> Int) {
    $fb.start-table(2);                     # Int { bitWidth, is_signed }
    $fb.prepend-i32(8); $fb.slot(0);        # is_signed 默认 false，省略
    my Int $index-type = $fb.end-table;

    $fb.start-table(4);
    $fb.prepend-uoffset($index-type); $fb.slot(1);
    $fb.prepend-i64($id);             $fb.slot(0);
    $fb.end-table;
}

#| 写一个 Field table（含递归子字段），返回它的偏移。
#|
#| `:$of` 用来告诉嵌套字段它们处在哪种父类型里：list 的元素名默认
#| `item`，map 的 entries 必须不可空且键不可空 —— 这两条 pyarrow 会校验。
sub build-field(Arrow::IPC::FlatBuf::FlatBuf $fb, %dict-info, $node, Str :$of = '', Bool :$nullable = True,
                Bool :$map-entries = False --> Int) {
    # 字典列要特别对待：Field.type 描述的是**值**的类型（比如 utf8），
    # 索引类型另有 DictionaryEncoding.indexType 说明。照列自己的 format（C）
    # 写，pyarrow 会认定字典值是 uint8，读出满屏数字。
    my $dinfo = %dict-info{$node.addr.Int};
    my $dict-id = $dinfo ?? $dinfo<id> !! Nil;
    my Str $fmt = $dinfo ?? $dinfo<format> !! $node.format;
    my %t = Arrow::IPC::Format::parse-format($fmt);

    my Str $name = $node.name;
    my Bool $null = $nullable;
    if $of eq 'map' {
        $name = 'entries' if $name eq '';
        $null = False;
    }
    elsif $of eq 'list' || $of eq 'large-list' {
        $name = 'item' if $name eq '';
    }

    # 子字段必须先写（从后往前写，子内容在前）
    my @child-offs;
    my Bool $is-map = %t<kind> eq 'map';
    for ^$node.n-children -> int $i {
        # Arrow 对 map 的布局要求很硬：唯一的子字段 entries 是不可空的
        # struct，而 entries 的第一个子字段（key）也必须不可空。少一条
        # pyarrow 就直接拒收：「Map's keys must be non-nullable」。
        my Bool $cn = True;
        $cn = False if $is-map;
        $cn = False if $map-entries && $i == 0;
        my $kid = $node.column($i);
        @child-offs.push: build-field($fb, %dict-info, $kid,
                                      of => %t<kind>,
                                      nullable => $cn,
                                      map-entries => $is-map);
    }
    my Int $type-off = build-type($fb, %t);
    my Int $dict-off = $dict-id.defined
        ?? build-dictionary-encoding($fb, $dict-id) !! 0;

    $fb.prepend-string($name);
    my Int $name-off = $fb.size;

    my Int $children-vec = 0;
    if @child-offs.elems {
        $fb.start-vector(@child-offs.elems, 4, 4);
        for @child-offs.reverse -> $o { $fb.prepend-uoffset($o) }
        $children-vec = $fb.end-vector(@child-offs.elems);
    }

    $fb.start-table(7);
    $fb.prepend-uoffset($name-off);  $fb.slot(0);
    if $null { $fb.prepend-i8(1); $fb.slot(1) }     # nullable 默认 false
    $fb.prepend-i8(%t<tag>); $fb.slot(2);           # type_type
    $fb.prepend-uoffset($type-off); $fb.slot(3);
    if $children-vec {
        $fb.prepend-uoffset($children-vec); $fb.slot(5);
    }
    if $dict-off {
        $fb.prepend-uoffset($dict-off); $fb.slot(4);
    }
    $fb.end-table;
}

#| 写一张 Schema table，返回它的偏移。
sub build-schema(Arrow::IPC::FlatBuf::FlatBuf $fb, $root, %dict-info --> Int) {
    my @field-offs;
    for ^$root.n-children -> int $i {
        my $node = $root.column($i);
        @field-offs.push: build-field($fb, %dict-info, $node);
    }
    my Int $vec = 0;
    if @field-offs.elems {
        $fb.start-vector(@field-offs.elems, 4, 4);
        for @field-offs.reverse -> $o { $fb.prepend-uoffset($o) }
        $vec = $fb.end-vector(@field-offs.elems);
    }

    $fb.start-table(4);
    # endianness 默认 Little(0)，不写
    if $vec { $fb.prepend-uoffset($vec); $fb.slot(1) }
    $fb.end-table;
}

# ============================================================
# 一条 IPC message 的 metadata
# ============================================================

my constant MSG-SCHEMA       = 1;
my constant MSG-RECORD-BATCH = 3;
my constant METADATA-V5      = 4;

#| Schema message（body 为空）。
sub schema-message($root-schema, %dict-info --> Buf) {
    my $fb = Arrow::IPC::FlatBuf::FlatBuf.new;
    $fb.align(8);                       # 保证产物长度是 8 的倍数
    my Int $schema-off = build-schema($fb, $root-schema, %dict-info);

    $fb.start-table(4);
    $fb.prepend-i16(METADATA-V5); $fb.slot(0);
    $fb.prepend-i8(MSG-SCHEMA);   $fb.slot(1);
    $fb.prepend-uoffset($schema-off); $fb.slot(2);
    my Int $msg = $fb.end-table;
    $fb.finish($msg);
}

#| 写一张 RecordBatch table，返回它的偏移。
sub build-record-batch(Arrow::IPC::FlatBuf::FlatBuf $fb, Int $length, @nodes, @buffers --> Int) {
    # struct FieldNode { int64 length; int64 null_count; }  —— 16 字节 / 对齐 8
    $fb.start-vector(@nodes.elems, 16, 8);
    for @nodes.reverse -> $nd {
        $fb.prepend-i64($nd[1]);
        $fb.prepend-i64($nd[0]);
    }
    my Int $nodes-vec = $fb.end-vector(@nodes.elems);

    # struct Buffer { int64 offset; int64 length; }
    $fb.start-vector(@buffers.elems, 16, 8);
    for @buffers.reverse -> $bf {
        $fb.prepend-i64($bf[1]);
        $fb.prepend-i64($bf[0]);
    }
    my Int $buffers-vec = $fb.end-vector(@buffers.elems);

    $fb.start-table(5);
    $fb.prepend-i64($length);          $fb.slot(0);
    $fb.prepend-uoffset($nodes-vec);   $fb.slot(1);
    $fb.prepend-uoffset($buffers-vec); $fb.slot(2);
    $fb.end-table;
}

#| RecordBatch message。`@nodes` 是 (长度, 空值数)，`@buffers` 是 (偏移, 长度)。
sub batch-message(Int $length, @nodes, @buffers, Int $body-len --> Buf) {
    my $fb = Arrow::IPC::FlatBuf::FlatBuf.new;
    $fb.align(8);
    my Int $batch = build-record-batch($fb, $length, @nodes, @buffers);

    $fb.start-table(4);
    $fb.prepend-i64($body-len);        $fb.slot(3);
    $fb.prepend-i16(METADATA-V5);      $fb.slot(0);
    $fb.prepend-i8(MSG-RECORD-BATCH);  $fb.slot(1);
    $fb.prepend-uoffset($batch);       $fb.slot(2);
    my Int $msg = $fb.end-table;
    $fb.finish($msg);
}

#| DictionaryBatch message：字典值本身也是一个 RecordBatch，只是挂在 `data` 上。
#|
#| 必须排在所有引用它的 RecordBatch **之前**，否则读到第一条批次时字典还没到。
sub dictionary-batch-message(Int $id, Int $length, @nodes, @buffers,
                             Int $body-len --> Buf) {
    my $fb = Arrow::IPC::FlatBuf::FlatBuf.new;
    $fb.align(8);
    my Int $batch = build-record-batch($fb, $length, @nodes, @buffers);

    $fb.start-table(3);
    $fb.prepend-i64($id);        $fb.slot(0);
    $fb.prepend-uoffset($batch); $fb.slot(1);
    my Int $db = $fb.end-table;

    $fb.start-table(4);
    $fb.prepend-i64($body-len);   $fb.slot(3);
    $fb.prepend-i16(METADATA-V5); $fb.slot(0);
    $fb.prepend-i8(2);            $fb.slot(1);   # MessageHeader.DictionaryBatch
    $fb.prepend-uoffset($db);     $fb.slot(2);
    my Int $msg = $fb.end-table;
    $fb.finish($msg);
}

#| Footer（file 格式才有）。
sub footer-message($root-schema, %dict-info, @dict-blocks, @blocks --> Buf) {
    my $fb = Arrow::IPC::FlatBuf::FlatBuf.new;
    $fb.align(8);

    my Int $schema-off = build-schema($fb, $root-schema, %dict-info);

    my Int $dict-vec = 0;
    if @dict-blocks.elems {
        $fb.start-vector(@dict-blocks.elems, 24, 8);
        for @dict-blocks.reverse -> $b {
            $fb.prepend-i64($b[2]); $fb.pad(4);
            $fb.prepend-i32($b[1]);
            $fb.prepend-i64($b[0]);
        }
        $dict-vec = $fb.end-vector(@dict-blocks.elems);
    }

    # struct Block { int64 offset; int32 metaDataLength; int64 bodyLength; }
    # 声明顺序 8 + 4 + (4 填充) + 8 = 24 字节，对齐 8。
    $fb.start-vector(@blocks.elems, 24, 8);
    for @blocks.reverse -> $b {
        $fb.prepend-i64($b[2]);        # bodyLength   @16
        $fb.pad(4);                    # 结构体内部的填充 @12
        $fb.prepend-i32($b[1]);        # metaDataLength @8
        $fb.prepend-i64($b[0]);        # offset       @0
    }
    my Int $blocks-vec = $fb.end-vector(@blocks.elems);

    $fb.start-table(5);
    $fb.prepend-i16(METADATA-V5);      $fb.slot(0);
    $fb.prepend-uoffset($schema-off);  $fb.slot(1);
    if $dict-vec {
        $fb.prepend-uoffset($dict-vec); $fb.slot(2);
    }
    if @blocks.elems {
        $fb.prepend-uoffset($blocks-vec); $fb.slot(3);
    }
    my Int $footer = $fb.end-table;
    $fb.finish($footer);
}

# ============================================================
# body：把每个 array 的 buffer 拷进一段连续内存
# ============================================================

class BodyAcc {
    has Buf $!data = Buf.new;
    has @!nodes;
    has @!descs;

    #| 记一个 FieldNode。
    method node(Int $length, Int $null-count --> Nil) {
        @!nodes.push: ($length, $null-count);
    }

    # ---- 就地改写（给 null 槽规范化用）----

    method byte-at(Int $pos --> Int) { $!data[$pos] }

    method zero-range(Int $off, Int $from, Int $to --> Nil) {
        for $from ..^ $to -> int $k { $!data[$off + $k] = 0 }
    }

    method zero-slots(Int $off, Int $w, $undef --> Nil) {
        for $undef.keys -> $i { self.zero-range($off, $i * $w, ($i + 1) * $w) }
    }

    method clear-bits(Int $off, $undef --> Nil) {
        for $undef.keys -> $i {
            my Int $b = $off + ($i div 8);
            $!data[$b] = $!data[$b] +& ~(1 +< ($i % 8));
        }
    }

    method write-offset(Int $off, Int $i, Int $v, Int $w --> Nil) {
        my Buf $b = Arrow::IPC::FlatBuf::le-bytes($v, $w);
        for ^$w -> int $k { $!data[$off + $i * $w + $k] = $b[$k] }
    }

    #| 追加一个 buffer（8 字节对齐），记下 (offset, length)，返回 offset。
    #|
    #| `:$bits` 给位图类 buffer（有效位、bool 数据）用：末尾那个字节里超出
    #| `$bits` 的高位在 Arrow 里是未定义的，DuckDB 会原样留着上一位的残留。
    #| 不清掉的话同一份数据两次写出的字节就不同 —— 内容合法但不可复现，
    #| 校验和、缓存、逐字节对比全都会失效。
    method add(Pointer $p, Int $len, Int :$bits --> Int) {
        while $!data.elems % 8 > 0 { $!data.push: 0 }
        my Int $off = $!data.elems;
        if $len > 0 && $p.defined && $p.Int {
            my $tmp = Buf.allocate($len);
            Arrow::IPC::FlatBuf::c-memcpy(nativecast(Pointer, $tmp), $p, $len);
            $!data.append($tmp);
        }
        if $bits.defined && $len > 0 {
            my Int $rem = $bits % 8;
            if $rem {
                my Int $last = $!data.elems - 1;
                $!data[$last] = $!data[$last] +& ((1 +< $rem) - 1);
            }
        }
        @!descs.push: ($off, $len);
        $off;
    }

    #| 补齐到 8 字节。IPC 要求每条 message 的 body 长度是 8 的倍数，
    #| 否则后面那条 message 的起点就歪了 —— 报的是「Unaligned block」。
    method padded(--> Buf) {
        my $out = Buf.new($!data);
        $out.push: 0 while $out.elems % 8;
        $out;
    }

    method nodes(--> List)   { @!nodes.List }
    method descs(--> List)   { @!descs.List }
    method bytes(--> Buf)    { $!data }
}

#| 读变长类型 offsets 的第 `k` 个值。
sub off-at(Pointer $p, Int $k, Int $width --> Int) {
    return 0 unless $p.defined && $p.Int;
    return $width == 8 ?? nativecast(CArray[int64], $p)[$k]
                        !! nativecast(CArray[int32], $p)[$k];
}

#| 读变长类型 offsets 的最后一个值，用来算数据段真实长度。
sub last-offset(Pointer $p, Int $n, Int $width --> Int) {
    return 0 unless $p.defined && $p.Int;
    return $width == 8 ?? nativecast(CArray[int64], $p)[$n]
                        !! nativecast(CArray[int32], $p)[$n];
}

#| 深度优先走一棵列：每层写 FieldNode，再按类型顺序写它自己的 buffers。
#|
#| 顺序必须和 schema 的字段顺序完全一致，否则 pyarrow 会把 offset 和
#| 数据段错配 —— 报错往往指向别处，很难查。
#|
#| # null 槽规范化
#|
#| Arrow 规定「空值所在的那一格内容未定义」，所以缓冲区里那一格可以是任何
#| 垃圾 —— DuckDB 目前的实现多数时候会顺手清掉，但规范并不保证，也不同版本
#| 一致。唯一能确定的是「语义相同」，不是「字节相同」。
#|
#| 于是这里在拷贝之后做一遍归一：
#|
#| * 定长：null 槽那 `$w` 字节清零；
#| * 位图（bool 数据）：null 位清零；
#| * 变长：先把 null 槽真正指向的那段数据清零，再把它的 offset 改成
#|   「长度 0」（`off[i] = off[i+1]`），于是连未被引用的空洞都不存在；
#| * 复合类型：父级为空时，子级对应的槽同样是未定义的，用 `$mask`
#|   把这份「未定义」传下去。
#|
#| 归一之后同一份数据必然写出逐字节相同的文件。
sub walk-node($sch, $col, BodyAcc $body, $mask? --> Nil) {
    my Str $fmt = $sch.format;
    my %t = Arrow::IPC::Format::parse-format($fmt);
    my Int $n = $col.length;
    my Int $nc = $col.null-count;

    $body.node($n, $nc);

    # 有效位图：没有空值就写一条 0 长度的 buffer
    my Int $vlen = $nc > 0 ?? (($n + 7) div 8) !! 0;
    my Int $voff = $body.add($col.buffer(0), $vlen, bits => $n);

    # 逻辑上未定义的槽 = 自己为空 ∪ 父级为空
    my Set $undef = Set.new;
    if $vlen {
        my @nulls;
        for ^$n -> int $i {
            my Int $bit = $body.byte-at($voff + ($i div 8)) +& (1 +< ($i % 8));
            @nulls.push: $i unless $bit;
        }
        $undef = Set.new(@nulls);
    }
    $undef = $undef (|) $mask if $mask.defined;

    given %t<kind> {
        when 'null' { }

        when 'bool' {
            my Int $boff = $body.add($col.buffer(1), ($n + 7) div 8, bits => $n);
            $body.clear-bits($boff, $undef) if $undef.elems;
        }

        when 'fixed' {
            my Int $w = %t<bytes>;
            my Int $off = $body.add($col.buffer(1), $n * $w);
            $body.zero-slots($off, $w, $undef) if $undef.elems;
        }

        when 'utf8' | 'binary' {
            my Int $w = %t<width>;
            my $op = $col.buffer(1);
            my Int $last = last-offset($op, $n, $w);
            my Int $ooff = $body.add($op, ($n + 1) * $w);
            my Int $doff = $body.add($col.buffer(2), $last);
            for $undef.keys -> $i {
                my Int $a = off-at($op, $i, $w);
                my Int $b = off-at($op, $i + 1, $w);
                $body.zero-range($doff, $a, $b) if $b > $a;
                $body.write-offset($ooff, $i, $b, $w);
            }
        }

        when 'list' | 'map' | 'struct' {
            my $kid-mask;
            if %t<kind> ne 'struct' {
                my Int $w = %t<width>;
                my $op = $col.buffer(1);
                my Int $ooff = $body.add($op, ($n + 1) * $w);
                my @kid-undef;
                for $undef.keys -> $i {
                    my Int $a = off-at($op, $i, $w);
                    my Int $b = off-at($op, $i + 1, $w);
                    @kid-undef.append: $a ..^ $b;
                    # 空容器覆盖的元素区间可以是任意垃圾，缩成「不占格子」
                    $body.write-offset($ooff, $i, $b, $w);
                }
                $kid-mask = Set.new(@kid-undef) if @kid-undef.elems;
            }
            elsif $undef.elems {
                # Struct 的子列与父列等长，索引直接对上
                $kid-mask = $undef;
            }

            my @kids = $col.children;
            my @sch-kids = $sch.children;
            for ^@kids.elems -> int $i {
                walk-node(@sch-kids[$i], @kids[$i], $body, $kid-mask);
            }
        }

        default {
            die "arrow-ipc: unsupported Arrow format '$fmt'";
        }
    }
}

# ============================================================
# 对外：写文件 / 写字节
# ============================================================

our constant MAGIC = Buf.new(0x41, 0x52, 0x52, 0x4F, 0x57, 0x31);   # "ARROW1"

#| 一条 encapsulated message：`ffffffff` + 长度 + metadata + body。
sub encapsulated(Buf $meta --> Buf) {
    my $head = Buf.new(0xFF, 0xFF, 0xFF, 0xFF) ~ Arrow::IPC::FlatBuf::le-bytes($meta.elems, 4);
    $head ~ $meta;
}

#| 把一张 Arrow 视图编码成 IPC 字节流，一块一块交给 `&sink`。
#|
#| 参数用鸭子类型（只需要 `.schema` 和 `.chunks(&code)`），不 `use`
#| Duckula::Arrow —— 那个模块会反过来 use 本模块。
#|
#| 落盘还是留在内存由 sink 决定，编码逻辑只此一份：`write-ipc` 把块写进
#| 文件句柄，`ipc-buf` 把块追加进 Buf。
our sub emit-ipc($arrow, Str:D $format, &sink --> Nil) {
    die "arrow-ipc: unknown format '$format' (file|stream)"
        unless $format eq 'file' || $format eq 'stream';

    my Bool $is-file = $format eq 'file';
    my $schema = $arrow.schema;

    # 字典要先摸清楚：schema 里要给每个字典列编号，数据侧还要按同一顺序
    # 先把字典批次发出去。
    my @dicts = Arrow::IPC::CData::dict-scan($schema);
    my %dict-info;
    for @dicts -> %d { %dict-info{%d<node-addr>} = %d; }

    my Int $pos = 0;
    my @blocks;
    my @dict-blocks;

    my sub put(Buf $b --> Nil) {
        sink($b);
        $pos += $b.elems;
    }

    # file 格式开头是 magic + 2 字节补零（magic 本身 6 字节）
    put(MAGIC ~ Buf.new(0, 0)) if $is-file;

    my Buf $schema-msg = schema-message($schema, %dict-info);
    put(encapsulated($schema-msg));

    my Bool $dicts-written = False;

    $arrow.chunks: -> $chunk {
        unless $dicts-written {
            $dicts-written = True;
            for @dicts -> %d {
                my $col = Arrow::IPC::CData::array-at($chunk, %d<path>);
                my $darr = nativecast(Arrow::IPC::CData::ArrowArray, $col.dictionary);
                next unless $darr.defined && $darr.release-fn.Int;

                my $dbody = BodyAcc.new;
                walk-node(Arrow::IPC::CData::schema-node-of(Pointer.new(%d<schema-addr>)),
                          Arrow::IPC::CData::ArrayView.new(arr => $darr), $dbody);
                my Buf $dbb = $dbody.padded;
                my Buf $dmeta = dictionary-batch-message(
                    %d<id>, $darr.length, $dbody.nodes, $dbody.descs, $dbb.elems);
                my Int $dstart = $pos;
                put(encapsulated($dmeta));
                put($dbb);
                @dict-blocks.push: ($dstart, 8 + $dmeta.elems, $dbb.elems);
            }
        }

        my $body = BodyAcc.new;
        my Int $ncol = $schema.n-children;
        for ^$ncol -> int $i {
            walk-node($schema.column($i), $chunk.column($i), $body);
        }

        my Buf $bb = $body.padded;
        my Buf $meta = batch-message($chunk.length, $body.nodes, $body.descs,
                                     $bb.elems);
        my Int $start = $pos;
        put(encapsulated($meta));
        put($bb);
        @blocks.push: ($start, 8 + $meta.elems, $bb.elems);
    }

    if $is-file {
        # 尾部布局：<footer flatbuffer><int32 footer 长度><magic>
        my Buf $footer = footer-message($schema, %dict-info, @dict-blocks, @blocks);
        put($footer);
        put(Arrow::IPC::FlatBuf::le-bytes($footer.elems, 4));
        put(MAGIC);
    }
    else {
        put(Buf.new(0xFF, 0xFF, 0xFF, 0xFF) ~ Arrow::IPC::FlatBuf::le-bytes(0, 4));
    }
    Nil;
}

#| 把一张 Arrow 视图写成 IPC 文件。
#|
#|     write-ipc($arrow, 'x.arrow');                   # file 格式（默认）
#|     write-ipc($arrow, 'x.arrows', :format<stream>); # stream 格式
our sub write-ipc($arrow, Str:D $path, Str:D :$format = 'file' --> Nil) {
    my $fh = $path.IO.open(:w, :bin);
    LEAVE { $fh.close if $fh.defined }
    emit-ipc($arrow, $format, -> Buf $b { $fh.write($b) });
    Nil;
}

#| 把一张 Arrow 视图编码成内存里的 IPC 字节。
#|
#| 这是给**别的进程**的出口。C data interface 的裸指针只在本进程有效，
#| 而 IPC 字节是可以塞进管道、写进 socket、交给 `Inline::Python` 的：
#|
#|     my Buf $bytes = $df.arrow.ipc-buf;      # stream 格式（默认）
#|     # Python: pa.ipc.open_stream(bytes).read_all()
#|
#| 默认 `stream` 而不是 `file`：在内存里没人需要 footer 索引，而 stream
#| 格式的开销就是每条 message 一个 8 字节前缀，另外省掉收尾的 magic 和
#| footer。要随机访问才显式 `:format<file>`。
our sub ipc-buf($arrow, Str:D :$format = 'stream' --> Buf) {
    my Buf $out = Buf.new;
    emit-ipc($arrow, $format, -> Buf $b { $out.append($b) });
    $out;
}
