# Arrow::IPC

纯 Raku 的 Arrow IPC（FlatBuffers）编解码包，**不依赖 DuckDB / Duckula / 任何 Arrow 扩展**。

采用 Arrow C Data Interface 的标准 C 结构声明（自带，只依赖 `NativeCall`），
写侧接受任何实现鸭子接口的 schema/chunk 视图；读侧输出 Raku 值和 Arrow format
字符串，类型系统映射交给调用方。因此 Rakuish、DB::DuckDB、Duckula 或其他项目
都可以依赖本包，而不必互相依赖。

## 安装

```bash
zef install Arrow::IPC
```

## 用法

```raku
use Arrow::IPC;

# 写侧：$arrow 只需提供 .schema 与 .chunks(&code)
write-ipc($arrow, 'out.arrow');                    # file 格式（默认）
write-ipc($arrow, 'out.arrows', :format<stream>);  # stream 格式
my Buf $bytes = ipc-buf($arrow);                   # 内存字节，默认 stream

# 读侧
my %info = describe-ipc('out.arrow');
say %info<format>;    # file | stream
say %info<rows>;
say %info<fields>.map(*.name);

my %data = decode-ipc('out.arrow');
say %data<names>.raku;
say %data<formats>.raku;    # Arrow format 串：l / u / +l / +s / +m ...
say %data<cols>.raku;       # 逐列 Raku 值，Any 表示 NULL
```

## 支持范围

- 基本类型：null / bool / int / float / decimal / date / time / timestamp / interval / fixed-size binary；
- 变长：utf8 / large-utf8 / binary / large-binary；
- 嵌套：list / large-list / struct / map（任意互相嵌套）；
- 字典编码：DictionaryBatch，ENUM 往返。
- `FixedSizeList` / `Union` / `RunEndEncoded` 明确报错并指出列名。

## 模块

| 模块 | 职责 |
|---|---|
| `Arrow::IPC` | 统一入口与导出 API |
| `Arrow::IPC::FlatBuf` | 最小 FlatBuffers 构造器（小端、从后往前写） |
| `Arrow::IPC::Format` | Arrow format 串 <-> Type union 标签 |
| `Arrow::IPC::CData` | Arrow C Data Interface 结构声明与鸭子视图 |
| `Arrow::IPC::Write` | IPC 写出（schema/record/dictionary batch + footer） |
| `Arrow::IPC::Read` | IPC 解码（`Bytes` / `Tbl` / `AField` / 列值） |

## 测试

```bash
raku -Ilib t/01-ipc.rakutest      # 读侧，不依赖任何驱动
raku -Ilib t/02-write.rakutest    # 写侧，用 DB::DuckDB 作为 test-depends
raku -Ilib t/03-timestamp-tz.rakutest  # timestamptz 写出回归
raku -Ilib t/04-bounds.rakutest   # 坏输入只报错、不段错误
```

## 变更

- **0.1.2**：读侧全面加边界校验（issue `IKXKJU`）。之前 `decode-ipc` /
  `describe-ipc` 直接按文件里给的偏移、长度去读 `nativecast` 出来的裸指针，
  越界就是 SIGSEGV（rc=139），Raku 的 `try` / `CATCH` 根本接不住 —— 宿主
  收到一个坏 `.arrow` 就直接退出。现在：
  - `Bytes` 的每一次取字节（含 `ptr-at` 拿到的 float/double 指针）都先过
    边界断言，越界统一 `die "arrow-ipc: ..."`；
  - `Tbl` 校验 soffset / vtable 位置与长度、字段偏移、string 长度、vector
    长度与元素位置；
  - 消息层校验 continuation、metadata 长度、body 长度，并要求流里的消息
    必须推进读游标（否则坏文件会把循环挂死）；
  - file 格式额外校验首尾 `ARROW1` magic、footer 位置与 schema 引用；
  - file / stream 两种封装合并成同一个 `open-ipc`，`decode-ipc` 与
    `describe-ipc` 共用一份校验（此前两份拷贝里有一份漏了 footer 校验）；
  - `field-format` 不再把结构性错误改写成「这一列的类型不支持」。
  新增 `t/04-bounds.rakutest`（12 项：issue 原文那份 320 字节坏文件 + 截断、
  坏 magic、坏 footer 长度、坏 root offset），并加一条 META6 与模块常量
  版本一致性断言。
- **0.1.1**：修复 `ipc-buf` 对 `TIMESTAMP WITH TIME ZONE` 产出非法
  FlatBuffers 字节流（Duckula issue `IKXKJW`）。`Timestamp.timezone` 是
  string 字段，必须为它写 uoffset 引用而不是把字符串内容直接塞进 table
  槽位；同时按 Arrow fbs 修正 Time/Timestamp/Interval/Duration 的
  `unit` 默认值与必填性。新增 `t/03-timestamp-tz.rakutest`。
- **0.1.0**：初版。
