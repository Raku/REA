use v6.d;
use NativeCall;

#| Arrow C Data Interface 的 C 结构布局（Arrow 标准，不属于任何具体驱动）。
#| 独立包自带声明，因此写侧只依赖 NativeCall，不依赖 DB::DuckDB。
unit module Arrow::IPC::CData;

class ArrowArray is repr('CStruct') is export {
    has int64   $.length;
    has int64   $.null-count;
    has int64   $.offset;
    has int64   $.n-buffers;
    has int64   $.n-children;
    has Pointer $.buffers;
    has Pointer $.children;
    has Pointer $.dictionary;
    has Pointer $.release-fn;
    has Pointer $.private-data;
}

class ArrowSchema is repr('CStruct') is export {
    has Pointer $.format;
    has Pointer $.name;
    has Pointer $.metadata;
    has int64   $.flags;
    has int64   $.n-children;
    has Pointer $.children;
    has Pointer $.dictionary;
    has Pointer $.release-fn;
    has Pointer $.private-data;
}

our sub cstr(Pointer $p --> Str) is export {
    return '' unless $p.defined && $p.Int;
    my $ca = nativecast(CArray[uint8], $p);
    my $buf = Buf.new;
    my int $i = 0;
    while $ca[$i] != 0 { $buf.push: $ca[$i]; $i++ }
    $buf.decode('utf-8');
}

#| 由裸指针包一个 schema 节点，接口与 DB::DuckDB::Arrow::Schema 一致。
our class SchemaNode is export {
    has ArrowSchema $.root;
    has Pointer $.addr;

    method format(--> Str) { cstr($!root.format) }
    method name(--> Str) { cstr($!root.name) }
    method n-children(--> Int) { $!root.n-children.Int }
    method addr(--> Pointer) { $!addr }
    method dictionary(--> Pointer) { $!root.dictionary }

    method column(int $i --> SchemaNode) {
        die "column $i out of range (0..{$!root.n-children - 1})"
            if $i < 0 || $i >= $!root.n-children;
        my $base = $!root.children;
        die 'schema node has no children' unless $base.defined && $base.Int;
        my $raw = nativecast(CArray[Pointer], Pointer.new($base.Int + 8 * $i))[0];
        my $p = Pointer.new($raw.Int);
        SchemaNode.new(root => nativecast(ArrowSchema, $p), addr => $p);
    }
    method children(--> List) { (^self.n-children).map({ self.column($_) }).List }
}

our sub schema-node-of(Pointer $p --> SchemaNode) is export {
    SchemaNode.new(root => nativecast(ArrowSchema, $p), addr => $p);
}

#| 只读的 ArrowArray 视图，给不是 `Chunk` 来的数组用（字典值就是这种）。
#|
#| 方法与 `DB::DuckDB::Arrow::Column` 同名同义，于是 `walk-node` 不需要
#| 知道自己拿到的是哪一种。
our class ArrayView is export {
    has ArrowArray $.arr;

    method length(--> Int)     { $!arr.length }
    method null-count(--> Int) { $!arr.null-count }

    method buffer(int $j --> Pointer) {
        my $base = $!arr.buffers;
        return Pointer unless $base.defined && $base.Int;
        return Pointer if $j >= $!arr.n-buffers;
        my $raw = nativecast(CArray[Pointer], Pointer.new($base.Int + 8 * $j))[0];
        return Pointer unless $raw.defined && $raw.Int;
        # rakupp 把 CArray[Pointer] 的元素读成 CArray[int64]，MoarVM 读成
        # Pointer；统一回真正的 Pointer 再走 Pointer 类型的返回槽。
        Pointer.new($raw.Int);
    }

    method children(--> List) {
        my $base = $!arr.children;
        return () unless $base.defined && $base.Int;
        my @kids;
        for ^$!arr.n-children -> int $i {
            my $raw = nativecast(CArray[Pointer], Pointer.new($base.Int + 8 * $i))[0];
            my $p = Pointer.new($raw.Int);
            @kids.push: ArrayView.new(arr => nativecast(ArrowArray, $p));
        }
        @kids.List;
    }
}


#| 一个 schema 节点的 `dictionary` 指针（没有就是空指针）。
our sub dict-of($node --> Pointer) {
    my $root = nativecast(ArrowSchema, $node.addr);
    my $d = $root.dictionary;
    return Pointer unless $d.defined && $d.Int;
    $d;
}

#| 找出 schema 里所有字典列，按深度优先编号。
#|
#| 编号必须与 DictionaryBatch 的发出顺序一致，否则 RecordBatch 里的
#| 索引会指向别人的字典。
our sub dict-scan($schema --> List) {
    my @out;
    my sub walk($node, @path --> Nil) {
        my $d = dict-of($node);
        if $d.defined && $d.Int {
            @out.push: %( id => @out.elems, path => @path.List,
                          schema-addr => $d.Int, node-addr => $node.addr.Int,
                          format => schema-node-of($d).format );
        }
        for ^$node.n-children -> int $i {
            walk($node.column($i), (|@path, $i));
        }
        Nil;
    }
    walk($schema, ());
    @out.List;
}

#| 顺着路径走进一个 chunk，拿到那一列的 ArrowArray。
our sub array-at($chunk, @path --> ArrowArray) {
    my $arr = nativecast(ArrowArray, $chunk.addr);
    for @path -> $k {
        my $kids = nativecast(CArray[Pointer], $arr.children);
        my $raw = $kids[$k];
        $arr = nativecast(ArrowArray, Pointer.new($raw.Int));
    }
    $arr;
}
