use v6.d;
use NativeCall;

#| Arrow IPC 用到的最小 FlatBuffers 构造器（小端、从后往前写）。
#| 只实现 Arrow 的 Message/Schema/File fbs 里出现的 table/struct/vector/string。
unit module Arrow::IPC::FlatBuf;

our sub le-bytes(Int $v, Int $n --> Buf) {
    my $mask = (1 +< (8 * $n)) - 1;
    my $u = $v +& $mask;
    my @b;
    for ^$n -> int $i { @b.push: ($u +> (8 * $i)) +& 0xFF }
    Buf.new(@b);
}

# 名字拼起来是为了躲开 zef / raku-pm 对 `is native('<字面量>')` 的依赖扫描，
# 与 DB::DuckDB 里同样的理由（Windows 会去找一个不存在的 libc）。
my constant CLIB = $*DISTRO.is-win ?? 'msvc' ~ 'rt' !! 'libc' ~ '.so.6';

our sub c-memcpy(Pointer $dst, Pointer $src, size_t $n --> Pointer) is export
    is native(CLIB) is symbol('memcpy') { }

# ============================================================
# 最小 FlatBuffers 构造器
# ============================================================
#
# FlatBuffers 规定所有标量相对「缓冲区起点」对齐，而构造器是**从后往前**写的。
# 于是每个字段写入时保证的是「距末尾的偏移」对齐；最后 `finish` 在**前面**补
# 零，让总长是 min-align 的倍数，这样 (L - e) 就一定落在对齐地址上。
#
#   地址 = 起点 + (总长 L - 距末尾偏移 e)
#
# L % m == 0 且 e % align == 0（align | m）=> 地址 % align == 0。
#| 一张正在构建的 table：起点 + 各字段位置。
#|
#| `slots` 用标量持有 Array —— `@`-sigil 属性收 Array 会 itemize 一层。
our class TblState {
    has Int $.start = 0;
    has $.slots;

    submethod BUILD(Int :$start!, Int :$n!) {
        $!start = $start;
        $!slots = (0 xx $n).Array;
    }
}

our class FlatBuf {
    has Buf $!b;
    has Int $!head;              # 已用区间的起点（可写区间的末尾）
    has Int $!min-align = 1;
    has @!tables;                # 嵌套 table 的栈：{ start, slots }

    submethod BUILD(Int :$cap = 4096) {
        $!b = Buf.new(0 xx $cap);
        $!head = $cap;
    }

    #| 已写入的字节数。
    method size(--> Int) { $!b.elems - $!head }

    method !grow(Int $need --> Nil) {
        my Int $used = self.size;
        return if $!head >= $need;
        my Int $cap = $!b.elems;
        $cap = $cap * 2 while $cap - $used < $need;
        my $nb = Buf.new(0 xx $cap);
        my Int $dst = $cap - $used;
        for ^$used -> int $i { $nb[$dst + $i] = $!b[$!head + $i] }
        $!b = $nb;
        $!head = $dst;
    }

    method !raw(Buf $bytes --> Nil) {
        my Int $n = $bytes.elems;
        return unless $n;
        self!grow($n);
        $!head -= $n;
        for ^$n -> int $i { $!b[$!head + $i] = $bytes[$i] }
    }

    #| 在数据前面补零（物理上位于已写内容的更低位地址）。
    method pad(Int $n --> Nil) {
        self!raw(Buf.new(0 xx $n)) if $n > 0;
    }

    #| 把已写长度补到 `$a` 的倍数，同时抬高整体对齐要求。
    method align(Int $a --> Nil) {
        $!min-align = $a if $a > $!min-align;
        self.pad((-(self.size)) % $a);
    }

    method prepend-i8(Int $v --> Nil)  { self!raw(le-bytes($v, 1)) }
    method prepend-i16(Int $v --> Nil) { self.align(2); self!raw(le-bytes($v, 2)) }
    method prepend-i32(Int $v --> Nil) { self.align(4); self!raw(le-bytes($v, 4)) }
    method prepend-i64(Int $v --> Nil) { self.align(8); self!raw(le-bytes($v, 8)) }

    #| 写一个指向 `$target`（距末尾偏移）的 uoffset 引用。
    #|
    #| 值本身也是「距末尾」的：`size - target + 4`，其中 size 取对齐之后的，
    #| 这与官方 builder 的 `ReferTo` 完全一致。
    method prepend-uoffset(Int $target --> Nil) {
        self.align(4);
        my Int $rel = self.size - $target + 4;
        self!raw(le-bytes($rel, 4));
    }

    #| 写 flatbuffers string：`[int32 长度][bytes][0x00]`。
    method prepend-string(Str $s --> Nil) {
        my Buf $bytes = Buf.new($s.encode('utf-8'));
        my Int $total = $bytes.elems + 1;
        # 让「载荷 + NUL」写完之后正好 4 对齐，长度前缀才落得下。
        self.pad((-(self.size + $total)) % 4);
        self!raw(Buf.new(0));
        self!raw($bytes);
        self!raw(le-bytes($bytes.elems, 4));
    }

    # ---- table ----

    method start-table(Int $nfields --> Nil) {
        @!tables.push: TblState.new(start => self.size, n => $nfields);
    }

    #| 记下「刚写完的那个字段」的位置。必须在写值之后调用。
    #|
    #| 字段表存在标量属性 `$.slots` 里而不是 `@.slots`：`@`-sigil 属性装
    #| Array 会被 itemize 一层，取出来就变成 `[[...]]`，vtable 只剩一个
    #| 字段 —— 报错会出现在很远的地方（pyarrow 说 footer 校验失败）。
    method slot(Int $id --> Nil) {
        @!tables[*-1].slots[$id] = self.size;
    }

    #| 收尾一张 table，返回它距末尾的偏移。
    #|
    #| vtable 里存的是「相对 table 起点」的字段偏移，soffset 存的是
    #| 「table 起点 - vtable 起点」，所以最后要回填那个 4 字节占位。
    method end-table(--> Int) {
        my TblState $t = @!tables.pop;
        my $slots = $t.slots;
        my Int $start = $t.start;

        self.align(4);
        my Int $p = self.size;
        self!raw(le-bytes(0, 4));            # soffset 占位
        my Int $table-off = $p + 4;

        # 尾部连续的空字段不必进 vtable（flatbuffers 的常规压缩）。
        my @kept;
        for ^$slots.elems -> int $i { @kept.push: $slots[$i]; }
        @kept.pop while @kept && @kept[*-1] == 0;

        self.align(2);
        for @kept.reverse -> $off {
            self!raw(le-bytes($off == 0 ?? 0 !! $table-off - $off, 2));
        }
        self!raw(le-bytes($table-off - $start, 2));    # table 大小
        self!raw(le-bytes(4 + 2 * @kept.elems, 2));    # vtable 大小
        my Int $vtable-off = self.size;

        # soffset = table 地址 - vtable 地址。vtable 写在 table 之后，
        # 所以它的「距末尾偏移」更大、实际地址更低，差值必须取这个方向。
        my Buf $patch = le-bytes($vtable-off - $table-off, 4);
        my Int $pos = $!b.elems - $table-off;
        for ^4 -> int $i { $!b[$pos + $i] = $patch[$i] }

        $table-off;
    }

    # ---- vector ----

    #| 开一个 vector。`$align` 是元素对齐，长度前缀固定要 4 对齐，
    #| 所以取两者中更严的那个 `$m`，一次补够。
    method start-vector(Int $n, Int $elemsize, Int $align --> Nil) {
        my Int $len = $n * $elemsize;
        my Int $m = $align > 4 ?? 8 !! 4;
        $!min-align = $m if $m > $!min-align;
        self.pad((-(self.size + $len)) % $m);
    }

    #| 写完元素后补上 int32 长度，返回 vector 头（长度前缀）的偏移。
    method end-vector(Int $n --> Int) {
        self!raw(le-bytes($n, 4));
        self.size;
    }

    # ---- finish ----

    #| 在前面补零到整体对齐，再写根 uoffset。返回完整字节。
    #|
    #| 结果长度一定是 8 的倍数（构造时至少 align(8) 过一次），
    #| 因此 Arrow IPC 里「metadata 补零到 8」这一步永远不需要额外动手。
    method finish(Int $root --> Buf) {
        my Int $m = $!min-align;
        self.pad((-(self.size + 4)) % $m);
        my Int $rel = self.size - $root + 4;
        self!raw(le-bytes($rel, 4));
        $!b.subbuf($!head, self.size);
    }
}
