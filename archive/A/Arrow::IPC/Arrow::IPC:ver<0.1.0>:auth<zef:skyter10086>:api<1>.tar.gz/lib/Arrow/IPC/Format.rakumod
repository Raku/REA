use v6.d;

#| Arrow format 字符串 <-> Type union 标签。写侧构造 Type table、读侧把
#| Type union 还原成 format 字符串，都只用这一份映射。
unit module Arrow::IPC::Format;

my constant %INT-CODES = (
    'c' => (8,  True),  'C' => (8,  False),
    's' => (16, True),  'S' => (16, False),
    'i' => (32, True),  'I' => (32, False),
    'l' => (64, True),  'L' => (64, False),
);
my constant %FLOAT-CODES = ('e' => 0, 'f' => 1, 'g' => 2);
my constant %TIME-UNIT   = ('s' => 0, 'm' => 1, 'u' => 2, 'n' => 3);

#| 把一个 Arrow format 字符串解析成构造 Type table 需要的全部信息。
#|
#| `kind` 决定 body 里怎么算 buffer 长度，`tag` 决定 Message 里写哪种 Type。
#| 读侧（`Duckula::ArrowRead`）反着用同一个函数：从 FlatBuffers 的 Type
#| union 拼出 format 字符串，再交给它统一成同一套 `kind` 词汇。
our sub parse-format(Str:D $f --> Hash) is export {
    return %(tag => 1, kind => 'null')                    if $f eq 'n';
    return %(tag => 6, kind => 'bool')                    if $f eq 'b';
    return %(tag => 5, kind => 'utf8', width => 4)        if $f eq 'u';
    return %(tag => 20, kind => 'utf8', width => 8)       if $f eq 'U';
    return %(tag => 4, kind => 'binary', width => 4)      if $f eq 'z';
    return %(tag => 19, kind => 'binary', width => 8)     if $f eq 'Z';
    return %(tag => 13, kind => 'struct')                 if $f eq '+s';
    return %(tag => 12, kind => 'list', width => 4)       if $f eq '+l';
    return %(tag => 21, kind => 'list', width => 8)       if $f eq '+L';
    return %(tag => 17, kind => 'map', width => 4)        if $f eq '+m';

    if %INT-CODES{$f} -> ($bw, $sgn) {
        return %(tag => 2, kind => 'fixed', bitwidth => $bw,
                 signed => $sgn, bytes => $bw div 8);
    }
    # 注意：HALF 的 precision 是 0，所以不能写 `if %FLOAT-CODES{$f} -> $p`
    # —— 那个 0 是假值，会把 'e' 漏进下面的 die。也不能写
    # `if %FLOAT-CODES{$f}.defined -> $p` —— 那绑定的是 defined 的返回值
    # （True），不是映射出来的 precision。
    my $prec = %FLOAT-CODES{$f};
    if $prec.defined {
        my Int $bytes = $prec == 0 ?? 2 !! ($prec == 1 ?? 4 !! 8);
        return %(tag => 3, kind => 'fixed', precision => $prec, bytes => $bytes);
    }

    return %(tag => 8, kind => 'fixed', unit => 0, bytes => 4) if $f eq 'tdD';
    return %(tag => 8, kind => 'fixed', unit => 1, bytes => 8) if $f eq 'tdm';

    if $f ~~ /^ 'tt' $<u>=<[smun]> $/ {
        my Str $u = ~$<u>;
        my Int $bw = ($u eq 's' || $u eq 'm') ?? 32 !! 64;
        return %(tag => 9, kind => 'fixed', unit => %TIME-UNIT{$u},
                 bitwidth => $bw, bytes => $bw div 8);
    }
    if $f ~~ /^ 'ts' $<u>=<[smun]> ':' $<tz>=.* $/ {
        my Str $u = ~$<u>;
        return %(tag => 10, kind => 'fixed', unit => %TIME-UNIT{$u},
                 timezone => ~$<tz>, bytes => 8);
    }
    if $f ~~ /^ 'tD' $<u>=<[smun]> $/ {
        return %(tag => 18, kind => 'fixed', unit => %TIME-UNIT{~$<u>}, bytes => 8);
    }
    return %(tag => 11, kind => 'fixed', unit => 0, bytes => 4)  if $f eq 'tiM';
    return %(tag => 11, kind => 'fixed', unit => 1, bytes => 8)  if $f eq 'tiD';
    return %(tag => 11, kind => 'fixed', unit => 2, bytes => 16) if $f eq 'tin';

    if $f ~~ /^ 'd:' $<p>=\d+ ',' $<s>=\d+ [ ',' $<bw>=\d+ ]? $/ {
        my Int $bw = $<bw>.defined ?? +$<bw> !! 128;
        return %(tag => 7, kind => 'fixed', precision => +$<p>, scale => +$<s>,
                 bitwidth => $bw, bytes => $bw div 8);
    }
    if $f ~~ /^ 'w:' $<n>=\d+ $/ {
        return %(tag => 15, kind => 'fixed', size => +$<n>, bytes => +$<n>);
    }

    die "arrow-ipc: unsupported Arrow format string '$f'";
}

# ============================================================
# Type / Field / Schema -> FlatBuffers
# ============================================================
