use v6.d;
need Arrow::IPC::Format;
need Arrow::IPC::Write;
need Arrow::IPC::Read;

#| Arrow IPC：纯 Raku 的 FlatBuffers 编解码，不依赖 DuckDB / Duckula。
#|
#| 写侧接受任何实现了 Arrow C Data Interface 鸭子接口的 schema/chunk 视图，
#| 读侧把 IPC 字节解成 Raku 值 + Arrow format 字符串。类型系统映射、建表等
#| 由调用方负责，因此 Rakuish / DB::DuckDB / Duckula 都能依赖本包。
unit module Arrow::IPC;

our $VERSION = '0.1.0';

=begin pod

=head1 NAME

Arrow::IPC — pure-Raku Arrow IPC (FlatBuffers) reader and writer

=head1 SYNOPSIS

    use Arrow::IPC;

    # 写：对象只需 .schema / .chunks(&code)
    write-ipc($arrow, 'out.arrow');
    my Buf $bytes = ipc-buf($arrow, :format<stream>);

    # 读：只看结构 / 解码成 Raku 值 + Arrow format 串
    my %info = describe-ipc('out.arrow');
    my %data = decode-ipc('out.arrow');
    say %data<names>.raku;
    say %data<formats>.raku;
    say %data<cols>.raku;

=head1 API

=item C<write-ipc($arrow, $path, :$format)> — file（默认）/ stream 格式。

=item C<ipc-buf($arrow, :$format)> — 默认 stream 格式。

=item C<describe-ipc($path)> — `%(format, fields, batches, rows)`，fields 是 AField 对象。

=item C<decode-ipc($path)> — `%(names, formats, cols, fields)`；formats 是 Arrow format 串。

=item C<parse-format($fmt)> — Arrow format 串 -> `%(tag, kind, ...)`。

=end pod

our sub parse-format(Str:D $f --> Hash) is export {
    Arrow::IPC::Format::parse-format($f)
}
our sub write-ipc($arrow, Str:D $path, Str:D :$format = 'file') is export {
    Arrow::IPC::Write::write-ipc($arrow, $path, :$format)
}
our sub ipc-buf($arrow, Str:D :$format = 'stream' --> Buf) is export {
    Arrow::IPC::Write::ipc-buf($arrow, :$format)
}
our sub describe-ipc(Str:D $path --> Hash) is export {
    Arrow::IPC::Read::describe-ipc($path)
}
our sub decode-ipc(Str:D $path --> Hash) is export {
    Arrow::IPC::Read::decode-ipc($path)
}
