# Arrow::IPC

纯 Raku 的 Arrow IPC（FlatBuffers）编解码包，**不依赖 DuckDB / Duckula / 任何 Arrow 扩展**。

采用 Arrow C Data Interface 的标准 C 结构声明（自带，只依赖 `NativeCall`），
写侧接受任何实现鸭子接口的 schema/chunk 视图；读侧输出 Raku 值和 Arrow format
字符串，类型系统映射交给调用方。因此 Rakuish、DB::DuckDB、Duckula 或其他项目
都可以依赖本包，而不必互相依赖。

## 安装

```bash
zef install Arrow::IPC
```

## 用法

```raku
use Arrow::IPC;

# 写侧：$arrow 只需提供 .schema 与 .chunks(&code)
write-ipc($arrow, 'out.arrow');                    # file 格式（默认）
write-ipc($arrow, 'out.arrows', :format<stream>);  # stream 格式
my Buf $bytes = ipc-buf($arrow);                   # 内存字节，默认 stream

# 读侧
my %info = describe-ipc('out.arrow');
say %info<format>;    # file | stream
say %info<rows>;
say %info<fields>.map(*.name);

my %data = decode-ipc('out.arrow');
say %data<names>.raku;
say %data<formats>.raku;    # Arrow format 串：l / u / +l / +s / +m ...
say %data<cols>.raku;       # 逐列 Raku 值，Any 表示 NULL
```

## 支持范围

- 基本类型：null / bool / int / float / decimal / date / time / timestamp / interval / fixed-size binary；
- 变长：utf8 / large-utf8 / binary / large-binary；
- 嵌套：list / large-list / struct / map（任意互相嵌套）；
- 字典编码：DictionaryBatch，ENUM 往返。
- `FixedSizeList` / `Union` / `RunEndEncoded` 明确报错并指出列名。

## 模块

| 模块 | 职责 |
|---|---|
| `Arrow::IPC` | 统一入口与导出 API |
| `Arrow::IPC::FlatBuf` | 最小 FlatBuffers 构造器（小端、从后往前写） |
| `Arrow::IPC::Format` | Arrow format 串 <-> Type union 标签 |
| `Arrow::IPC::CData` | Arrow C Data Interface 结构声明与鸭子视图 |
| `Arrow::IPC::Write` | IPC 写出（schema/record/dictionary batch + footer） |
| `Arrow::IPC::Read` | IPC 解码（`Bytes` / `Tbl` / `AField` / 列值） |

## 测试

```bash
raku -Ilib t/01-ipc.rakutest     # 读侧，不依赖任何驱动
raku -Ilib t/02-write.rakutest   # 写侧，用 DB::DuckDB 作为 test-depends
```
