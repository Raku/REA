[![Actions Status](https://github.com/lizmat/auto-dynamic/actions/workflows/linux.yml/badge.svg)](https://github.com/lizmat/auto-dynamic/actions) [![Actions Status](https://github.com/lizmat/auto-dynamic/actions/workflows/macos.yml/badge.svg)](https://github.com/lizmat/auto-dynamic/actions) [![Actions Status](https://github.com/lizmat/auto-dynamic/actions/workflows/windows.yml/badge.svg)](https://github.com/lizmat/auto-dynamic/actions)

NAME
====

auto-dynamic - automatically vivify dynamic variables

SYNOPSIS
========

THIS FUNCTIONALITY DEPENDED ON RAKUDO INTERNAL FEATURES THAT WILL NOT BE AVAILABLE IN THE 6.E LANGUAGE VERSION. SO ANY ATTEMPT TO INSTALL THIS MODULE WILL FAIL.

If you are running on older pre-6.e Rakudo's, then please install version [`0.0.2`](https://raku.land/zef:lizmat/auto-dynamic?v=0.0.2) of this module.

AUTHOR
======

Elizabeth Mattijsen <liz@raku.rocks>

Source can be located at: https://codeberg.org/lizmat/auto-dynamic . Comments and Pull Requests are welcome.

If you like this module, or what I'm doing more generally, committing to a [small sponsorship](https://github.com/sponsors/lizmat/) would mean a great deal to me!

COPYRIGHT AND LICENSE
=====================

Copyright 2024, 2026 Elizabeth Mattijsen

This library is free software; you can redistribute it and/or modify it under the Artistic License 2.0.

