my sub DYNAMIC(str $key) is raw is export {
    state %LOCAL;  # UNCOVERABLE
    my \value = %LOCAL{$key} // &CORE::DYNAMIC($key);

    if value ~~ Failure {
        %LOCAL{$key} := (my str $sigil = $key.substr(0,1)) eq '@'
          ?? []
          !! $sigil eq '%'
            ?? %()
            !! $sigil eq '&'
              ?? (my Callable $)
              !! (my $)
    }
    else {
        value
    }
}

# vim: expandtab shiftwidth=4
