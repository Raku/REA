note "This functionality is no longer available.  Please install
      version 0.0.2 of this module if you still want to attempt
      using this module.".naive-word-wrapper;
exit 1;

# vim: expandtab shiftwidth=4
