## ADDED Requirements

### Requirement: Static Stripe donation panel

The plugin SHALL render a Pico-styled panel with a heading and a plain link (Stripe wordmark plus label text) to a Stripe Payment Link URL, given a `$.key` short id passed at construction. The plugin SHALL make no network calls, require no environment variables, and register no HTTP routes.

#### Scenario: Default rendering
- **WHEN** `donate(:key<abc123XYZ>)` is constructed
- **THEN** `.HTML` renders an `<article>` containing an `<h3>` with the default heading and a plain `<a target="_blank" href="https://donate.stripe.com/abc123XYZ">` (no `role="button"`) wrapping the inline Stripe wordmark SVG and the label text — blurb, methods, and note are omitted when not provided
- **AND** `:!logo` suppresses the wordmark, leaving a text-only link

#### Scenario: Custom heading/blurb/label
- **WHEN** `donate(:key<abc123XYZ>, :heading<Support us>, :blurb<Thanks!>, :label<Give>)` is constructed
- **THEN** `.HTML` uses the provided heading and button label, and renders the blurb as a `<p>` above the button

#### Scenario: Codeberg-style payment methods and note
- **WHEN** `donate(:key<abc>, :methods['Credit Card', 'iDEAL'], :note('Fees apply.'))` is constructed
- **THEN** `.HTML` renders a plain-text `<p>Payment Methods:</p>` followed by an unbulleted `<ul>` of `<li>` items below the link, all center-aligned like the Codeberg panel
- **AND** renders the note last as `<p><em>Fees apply.</em></p>`

#### Scenario: Missing key
- **WHEN** `donate()` is constructed without `:key`
- **THEN** construction fails, since `$.key` is a required attribute

#### Scenario: Inline use with no registration
- **WHEN** `donate(:key<abc123XYZ>)` is placed directly in a page tree (e.g. `main [ donate(:key<abc123XYZ>) ]`)
- **THEN** it renders correctly without being passed to `site :register[...]`, since it defines no routes
