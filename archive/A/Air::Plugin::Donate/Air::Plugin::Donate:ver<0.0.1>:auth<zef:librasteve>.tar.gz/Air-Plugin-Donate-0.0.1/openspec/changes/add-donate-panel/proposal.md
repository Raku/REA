## Why

Site owners running Air-based sites want a simple way to accept donations, similar to the panel used on donate.codeberg.org. A full Stripe Checkout Sessions integration (server-side session creation, webhooks, environment-variable secrets) is unnecessary overhead: Stripe already hosts a permanent, dashboard-created "Payment Link" page per donation target. A lightweight static-link panel widget covers the need with zero server-side logic.

## What Changes

- Add a new Raku module `Air::Plugin::Donate`: a `does Tag` widget (no routes, no registration in `site :register[...]`) that renders a Pico-styled `<article>` panel with a heading, blurb, and a "Donate" button linking to `https://donate.stripe.com/<key>`
- `$.key` constructor attribute holds the Stripe Payment Link's trailing id, mirroring the `Air::Base::Tools` `Analytics`/Umami `$.key` convention — no env vars, no secrets, no API calls, no webhooks
- Exported factory sub `donate(*@a,*%h)` for inline use, e.g. `main [ donate(:key<abc123XYZ>) ]`
- Full mi6-style project scaffold: META6.json, dist.ini, LICENSE (Artistic-2.0), Changes, README.md (including Stripe account / Payment Link setup instructions), test suite, GitHub Actions CI

## Capabilities

### New Capabilities
- `donate-panel`: Static Stripe donation panel widget for Air sites — renders a heading/blurb/button linking to a pre-created Stripe Payment Link, with no backend logic.

## Impact

- New repo `Air-Plugin-Donate/` (independent git repo, `depends: ["Air"]` only — no `Cro::HTTP`)
- No changes to Air core or sibling plugins
- No webhooks, no environment variables, no Stripe API calls of any kind
