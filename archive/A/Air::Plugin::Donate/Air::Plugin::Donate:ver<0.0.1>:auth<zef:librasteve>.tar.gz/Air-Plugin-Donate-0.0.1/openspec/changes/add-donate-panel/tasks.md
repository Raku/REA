## 1. Scaffold project files

- [x] 1.1 `.gitignore` (copy verbatim from Air-Plugin-Hilite)
- [x] 1.2 `.github/workflows/test.yml` (`actions/checkout@v6`, matches MailForm/Rakudoc convention)
- [x] 1.3 `LICENSE` (Artistic License 2.0, verbatim)
- [x] 1.4 `dist.ini` (`name = Air::Plugin::Donate`; `[ReadmeFromPod] enabled = false`; `[UploadToZef]`; `[Badges] provider = github-actions/test.yml`)
- [x] 1.5 `META6.json` (`depends: ["Air"]`, `provides: {"Air::Plugin::Donate": "lib/Air/Plugin/Donate.rakumod"}`, tags `["air","donate","stripe","html","web"]`)
- [x] 1.6 `Changes` (`Revision history for Air::Plugin::Donate\n\n{{$NEXT}}\n`)

## 2. Implement plugin

- [x] 2.1 `lib/Air/Plugin/Donate.rakumod` — `role Air::Plugin::Donate does Tag`, `has Str $.key is required`, `$.heading`/`$.blurb`/`$.label` defaults, `multi method HTML` rendering `article [ h3 ...; p ...; a :href("https://donate.stripe.com/$!key"), :role<button>, :target<_blank>, ... ]`, exported `sub donate(*@a,*%h) is export {...}`

## 3. Tests

- [x] 3.1 `t/01-basic.rakutest` — construct `donate(:key<test_123>)`, `isa-ok` check, assert `.HTML` contains the Stripe link

## 4. Docs

- [x] 4.1 `README.md` — Synopsis, Description, **Stripe Account Setup** (create account → Payment Links → New → configure amount → copy trailing id → pass as `:key<...>` → go-live steps → optional receipt emails), Installation, Author, Copyright/License

## 5. Git

- [x] 5.1 `git init` + create/check out a new working branch (not `main`) — do not commit

## 6. Verify

- [x] 6.1 `raku -Ilib -e 'use Air::Plugin::Donate'` compiles cleanly
- [x] 6.2 `prove6 -I. t` passes
- [x] 6.3 Manual render check: Pico `<article>` card with correct `<a role="button" href="https://donate.stripe.com/test">Donate</a>` link
