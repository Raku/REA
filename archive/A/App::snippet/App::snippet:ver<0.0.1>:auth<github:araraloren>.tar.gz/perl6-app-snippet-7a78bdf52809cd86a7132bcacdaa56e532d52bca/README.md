# perl-app-snippet
run c/cpp or other language snippet code
