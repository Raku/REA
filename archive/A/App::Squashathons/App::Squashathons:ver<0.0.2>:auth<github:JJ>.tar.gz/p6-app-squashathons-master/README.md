[![Build Status](https://travis-ci.org/JJ/p6-app-squashathons.svg?branch=master)](https://travis-ci.org/JJ/p6-app-squashathons)

NAME w App::Squashathons - blah blah blah
=========================================

SYNOPSIS
========

    use App::Squashathons;

DESCRIPTION
===========

App::Squashathons is ...

AUTHOR
======

JJ Merelo <jjmerelo@gmail.com>

COPYRIGHT AND LICENSE
=====================

Copyright 2019 JJ Merelo

This library is free software; you can redistribute it and/or modify it under the Artistic License 2.0.

