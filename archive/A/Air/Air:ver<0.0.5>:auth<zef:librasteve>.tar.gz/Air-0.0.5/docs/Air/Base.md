Air::Base
=========

This raku module is one of the core libraries of the raku **Air** module.

It exports HTML tags as raku subs that can be composed as functional code within a raku program.

It replaces the HTML::Functional module by the same author.

SYNOPSIS
========

Here's a regular HTML page:

```html
<div class="jumbotron">
  <h1>Welcome to Dunder Mifflin!</h1>
  <p>
    Dunder Mifflin Inc. (stock symbol <strong>DMI</strong>) is
    a micro-cap regional paper and office supply distributor with
    an emphasis on servicing small-business clients.
  </p>
</div>
```

And here is the same page using Air::Functional:

```raku
use Air::Functional;

div :class<jumbotron>, [
    h1 "Welcome to Dunder Mifflin!";
    p  [
        "Dunder Mifflin Inc. (stock symbol "; strong 'DMI'; ") ";
        q:to/END/;
            is a micro-cap regional paper and office
            supply distributor with an emphasis on servicing
            small-business clients.
        END
    ];
];
```

DESCRIPTION
===========

Key features of the module are:

  * HTML tags are implemented as raku functions: `div, h1, p` and so on

  * parens `()` are optional in raku function calls

  * HTML tag attributes are passed as raku named arguments

  * HTML tag inners (e.g. the Str in `h1`) are passed as raku positional arguments

  * the raku Pair syntax is used for each attribute i.e. `:name<value>`

  * multiple `@inners` are passed as a literal Array `[]` – div contains h1 and p

  * the raku parser looks at functions from the inside out, so `strong` is evaluated before `p`, before `div` and so on

  * semicolon `;` is used as the Array literal separator to suppress nesting of tags

Normally the items in a raku literal Array are comma `,` separated. Raku precedence considers that `div [h1 x, p y];` is equivalent to `div( h1(x, p(y) ) );` … so the p tag is embedded within the h1 tag unless parens are used to clarify. But replace the comma `,` with a semi colon `;` and predisposition to nest is reversed. So `div [h1 x; p y];` is equivalent to `div( h1(x), p(y) )`. Boy that Larry Wall was smart!

The raku example also shows the power of the raku **Q-lang** at work:

  * double quotes `""` interpolate their contents

  * curlies denote an embedded code block `"{fn x}"`

  * tilde `~` is for Str concatenation

  * the heredoc form `q:to/END/;` can be used for verbatim text blocks

This module generally returns `Str` values to be string concatenated and included in an HTML content/text response.

It also defines a programmatic API for the use of HTML tags for raku functional coding and so is offered as a basis for sister modules that preserve the API, but have a different technical implementation such as a MemoizedDOM.



The Tagged Role provides an HTML method so that the consuming class behaves like a standard HTML tag that can be provided with inner and attr attributes

### method HTML

```raku
method HTML() returns Mu
```

Shun html escape even though inner is Str No opener, closer required

### has Str $.theme-color

<amber azure blue cyan fuchsia green indigo jade lime orange pink pumpkin purple red violet yellow> (pico theme)

### has Str $.bold-color

one from <aqua black blue fuchsia gray green lime maroon navy olive purple red silver teal white yellow> (basic css)

### method style

```raku
method style() returns Mu
```

optional grid style from https://cssgrid-generator.netlify.app/

package EXPORT::DEFAULT
-----------------------

put in all the @components as functions viz. https://docs.raku.org/language/modules#Exporting_and_selective_importing

