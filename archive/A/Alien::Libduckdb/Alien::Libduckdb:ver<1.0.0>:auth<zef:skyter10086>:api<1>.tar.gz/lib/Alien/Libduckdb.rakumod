#| Alien::Libduckdb -- build and locate the DuckDB C library (libduckdb)
#| from source, so that a NativeCall binding can depend on it.
#|
#| Public API (all exported):
#|   duckdb-version()          upstream version this module builds (default 2.0.0)
#|   prefix()                  private install prefix
#|   lib-dir()                 directory holding the shared library
#|   include-dir()             directory holding duckdb.h / duckdb_v2.h
#|   shared-lib()              absolute path of the shared library (IO::Path)
#|   lib()                     what to hand to NativeCall `is native(...)`
#|   installed()               is a matching build present?
#|   config()                  Hash with everything above
#|   cflags() / ldflags()      flags for a C/C++ build
#|   ensure-installed()        build on demand (used by consumers)
#|   build-from-source()      full control (force / clean / jobs)
#|
#| Environment:
#|   ALIEN_LIBDUCKDB_VERSION, ALIEN_LIBDUCKDB_ROOT, ALIEN_LIBDUCKDB_PREFIX,
#|   ALIEN_LIBDUCKDB_SRC, ALIEN_LIBDUCKDB_JOBS, ALIEN_LIBDUCKDB_CC/_CXX
unit module Alien::Libduckdb;

use Alien::Libduckdb::Spec;
use Alien::Libduckdb::Builder;

our $MODULE-VERSION = '1.0.0';

#| Version of *this* module (not of libduckdb).
our sub version(--> Str) is export { $MODULE-VERSION }

#| Version of libduckdb that this module builds / expects.
our sub duckdb-version(--> Str) is export { spec-duckdb-version() }

#| Root of the private install tree (per-version subdirectory).
our sub prefix(--> IO::Path) is export { spec-prefix() }

our sub lib-dir(--> IO::Path) is export { spec-lib-dir() }

our sub include-dir(--> IO::Path) is export { spec-include-dir() }

#| Absolute path of the built shared library; an undefined IO::Path when the
#| library has not been built yet.  Always check .defined / installed().
our sub shared-lib(--> IO::Path) is export { spec-find-shared-lib() }

#| True when a library built for the requested upstream version *and* this
#| platform is present.
our sub installed(--> Bool) is export { spec-installed() }

#| What to pass to NativeCall:  sub ... is native(Alien::Libduckdb::lib())
#| Resolution order: absolute path (preferred, unambiguous) -> bare name,
#| which lets the OS loader search its usual paths.
our sub lib(--> Str) is export
{
    my $path = shared-lib();
    $path.defined ?? $path.absolute !! spec-shared-name();
}

our sub config(--> Hash) is export
{
    my $path  = shared-lib();
    my $is-win = spec-is-win();
    my %cfg =
        version   => duckdb-version(),
        module    => $MODULE-VERSION,
        platform  => spec-platform-tag(),
        prefix    => prefix().absolute,
        lib_dir   => lib-dir().absolute,
        include   => include-dir().absolute,
        installed => installed(),
        shared    => spec-shared-name(),
        is_win    => $is-win;

    %cfg<lib> = $path.absolute if $path.defined;
    %cfg
}

our sub cflags(--> Str) is export { '-I' ~ include-dir().absolute }

our sub ldflags(--> Str) is export
{
    my $dir = lib-dir().absolute;
    spec-is-win()
        ?? "-L$dir -lduckdb"
        !! "-L$dir -lduckdb -Wl,-rpath,$dir";
}

#| Convenience wrapper: build only if needed.
our sub ensure-installed(Bool :$force = False, Bool :$verbose = True --> Bool) is export
{
    return True if !$force && installed();
    build-libduckdb(:$force, :$verbose);
}

#| Short alias, reads better inside consumer setup code.  Deliberately NOT
#| called `build`: a distribution's Build.pm must be free to declare its own
#| `sub build`, and an exported symbol of the same name would clash.
our sub build-from-source(
    Bool :$force = False,
    Bool :$clean = False,
    Bool :$verbose = True,
    Int  :$jobs,
    --> Bool
) is export
{
    Alien::Libduckdb::Builder::build-libduckdb(:$force, :$clean, :$verbose, :$jobs);
}
