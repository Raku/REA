#| Internal helper library for Alien::Libduckdb.
#|
#| Everything in here is deliberately dependency-free: the public module
#| (Alien::Libduckdb) and the builder (Alien::Libduckdb::Builder) both use it,
#| and the builder must be loadable from Build.pm before the distribution is
#| installed, so no third-party modules are allowed here.
#|
#| All exported names carry a `spec-` prefix so that they never collide with
#| the public API exported by Alien::Libduckdb itself.
unit module Alien::Libduckdb::Spec;

#| libduckdb release this module knows how to build.
our $DEFAULT-DUCKDB-VERSION = '2.0.0';

#| Minimum CMake we are willing to drive.
our $MIN-CMAKE-VERSION = v3.15;

#========================================================================
# Environment overrides
#========================================================================
#| ALIEN_LIBDUCKDB_VERSION      upstream tag to build (default 2.0.0)
#| ALIEN_LIBDUCKDB_ROOT         root of the private install tree
#| ALIEN_LIBDUCKDB_PREFIX       exact install prefix (wins over ROOT)
#| ALIEN_LIBDUCKDB_SRC          use an existing source tree instead of cloning
#| ALIEN_LIBDUCKDB_GIT          alternative clone URL
#| ALIEN_LIBDUCKDB_JOBS         parallelism for the build
#| ALIEN_LIBDUCKDB_CC / _CXX    compiler override (Windows mainly)

our sub spec-duckdb-version(--> Str) is export
{
    with %*ENV<ALIEN_LIBDUCKDB_VERSION> {
        return $_ if .chars;
    }
    $DEFAULT-DUCKDB-VERSION
}

our sub spec-is-win(--> Bool) is export { so $*DISTRO.is-win }

our sub spec-is-mac(--> Bool) is export { so $*DISTRO.name ~~ /darwin|macos|mac/ }

#| The file name produced by the CMake `duckdb` shared-library target.
#| On Windows the official build drops the `lib` prefix; both spellings are
#| accepted on lookup because MinGW toolchains may emit either.
our sub spec-shared-name(--> Str) is export
{
    spec-is-win() ?? 'duckdb.dll' !! 'libduckdb.so'
}

our sub spec-shared-candidates(--> List) is export
{
    spec-is-win()
        ?? ('duckdb.dll', 'libduckdb.dll')
        !! ('libduckdb.so', 'libduckdb.so.1')
}

our sub spec-static-candidates(--> List) is export
{
    spec-is-win()
        ?? ('duckdb.lib', 'libduckdb.dll.a', 'libduckdb.a')
        !! ('libduckdb_static.a', 'libduckdb.a')
}

our sub spec-platform-tag(--> Str) is export
{
    my $os = spec-is-win() ?? 'win' !! (spec-is-mac() ?? 'mac' !! 'linux');
    my $hw = try { $*KERNEL.hardware.Str } // 'unknown';
    $os ~ '-' ~ $hw
}

#========================================================================
# Directory layout
#========================================================================
our sub spec-root(--> IO::Path) is export
{
    with %*ENV<ALIEN_LIBDUCKDB_ROOT> {
        return .IO if .chars;
    }

    if spec-is-win()
    {
        my $la = %*ENV<LOCALAPPDATA>;
        my $base = ($la.defined && $la.chars)
            ?? $la.IO
            !! $*HOME.add('AppData/Local');
        return $base.add('Alien-Libduckdb');
    }

    return $*HOME.add('Library/Application Support/Alien-Libduckdb')
        if spec-is-mac();

    my $xdg = %*ENV<XDG_DATA_HOME>;
    my $base = ($xdg.defined && $xdg.chars)
        ?? $xdg.IO
        !! $*HOME.add('.local/share');
    $base.add('Alien-Libduckdb');
}

#| Root of everything this module owns: <root>/<duckdb-version>/
our sub spec-prefix(--> IO::Path) is export
{
    with %*ENV<ALIEN_LIBDUCKDB_PREFIX> {
        return .IO if .chars;
    }
    spec-root().add(spec-duckdb-version());
}

#| Where the shared library lives.  Windows puts DLLs in bin/ (that is the
#| directory the loader searches and where runtime DLLs get copied).
our sub spec-lib-dir(--> IO::Path) is export
{
    spec-is-win() ?? spec-prefix().add('bin') !! spec-prefix().add('lib');
}

our sub spec-include-dir(--> IO::Path) is export { spec-prefix().add('include') }

#| Source checkout location.
our sub spec-src-dir(--> IO::Path) is export
{
    with %*ENV<ALIEN_LIBDUCKDB_SRC> {
        return .IO if .chars;
    }
    spec-root().add('src').add('duckdb-' ~ spec-duckdb-version());
}

#| Out-of-tree CMake build directory.
our sub spec-build-dir(--> IO::Path) is export
{
    spec-root().add('build').add('duckdb-' ~ spec-duckdb-version());
}

#| Log directory for the last build attempt.
our sub spec-log-dir(--> IO::Path) is export { spec-prefix().add('logs') }

#| Marker file recording what was installed; its content is the proof of a
#| successful build and is checked on every load.
our sub spec-marker(--> IO::Path) is export { spec-prefix().add('.alientag') }

#========================================================================
# State queries
#========================================================================
our sub spec-find-shared-lib(--> IO::Path) is export
{
    my $dir = spec-lib-dir();
    return IO::Path unless $dir.d;

    for spec-shared-candidates() -> $name
    {
        my $p = $dir.add($name);
        return $p if $p.e && $p.f;
    }
    IO::Path
}

#| True only when the prefix holds a library built for *this* upstream version
#| on *this* platform.  A marker from another version/arch does not count, so a
#| version switch triggers a rebuild instead of silently binding the wrong ABI.
our sub spec-installed(--> Bool) is export
{
    my $marker = spec-marker();
    return False unless $marker.e && $marker.f;

    my $tag = try { $marker.slurp.trim } // '';
    return False unless $tag.contains('version=' ~ spec-duckdb-version());
    return False unless $tag.contains('platform=' ~ spec-platform-tag());

    so spec-find-shared-lib().defined;
}

#| Raw value of the PATH environment variable.
#|
#| Looked up case-insensitively on purpose: Windows stores the variable as
#| `Path`, and depending on how Rakudo was started `%*ENV<PATH>` can come back
#| undefined even though the variable exists.  `%*ENV<PATH> // ''` would then
#| silently yield an empty search path.
our sub spec-env-path(--> Str)
{
    for %*ENV.keys -> $k
    {
        next unless $k.uc eq 'PATH';
        my $v = %*ENV{$k};
        return $v if $v.defined && $v.chars;
    }
    ''
}

#| Cheap pre-flight: is a usable toolchain on PATH?
our sub spec-find-in-path(Str $exe --> IO::Path) is export
{
    my @names = spec-is-win() ?? ($exe, "$exe.exe", "$exe.bat", "$exe.cmd") !! ($exe,);
    my $sep  = spec-is-win() ?? ';' !! ':';

    for spec-env-path().split($sep) -> $dir
    {
        my $clean = $dir.trim.subst(/^ '"' | '"' $/, '');
        next unless $clean.chars;
        for @names -> $name
        {
            my $p = $clean.IO.add($name);
            return $p if $p.e && $p.f;
        }
    }
    IO::Path
}

our sub spec-source-url(--> Str) is export
{
    with %*ENV<ALIEN_LIBDUCKDB_GIT> {
        return $_ if .chars;
    }
    'https://github.com/duckdb/duckdb.git'
}

our sub spec-archive-url(--> Str) is export
{
    'https://github.com/duckdb/duckdb/archive/refs/tags/v'
        ~ spec-duckdb-version() ~ '.tar.gz'
}
