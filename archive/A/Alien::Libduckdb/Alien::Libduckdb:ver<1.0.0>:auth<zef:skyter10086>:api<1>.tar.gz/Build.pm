#| zef build hook.
#|
#| zef looks for a top-level Build.pm in the distribution, `require`s it,
#| instantiates it and calls `.build($path)`.  Verified against zef 1.1.4:
#|
#|     require Build; Build.new.build(<dist path as Str>)
#|
#| Consequences for this file:
#|   * `class Build` is mandatory -- `unit module Build` makes zef die with
#|     "You cannot create an instance of this type (Build)".
#|   * `build` takes ONE positional argument (the distribution path, a Str).
#|     `build($dist, %args)` dies with "Too few positionals passed; expected
#|     3 arguments but got 2".
#|   * The lib directory is pushed onto the repo chain at compile time via
#|     `use lib`, otherwise `use Alien::Libduckdb` cannot be resolved while
#|     zef compiles this file from the distribution root.
#|
#| Design notes:
#|   * Compiling DuckDB takes 5-20 minutes; a failure here must be loud,
#|     hence the exception just propagates and aborts the install.
#|   * Already-installed prefixes short-circuit, so re-running `zef install`
#|     is cheap.
#|   * `use Alien::Libduckdb::Builder;` must NOT be done here: its exported
#|     exception class `X::Alien::Libduckdb::Build` also brings in the short
#|     name `Build`, which collides with `class Build` below
#|     ("Redeclaration of symbol 'Build'").  `build-libduckdb` is not
#|     exported either, so it is called by its full name -- Builder is
#|     already loaded through `use Alien::Libduckdb`.
use lib $?FILE.IO.parent.child('lib').absolute;

use Alien::Libduckdb;

class Build
{
    #| Called by zef right before installation.  $path is the distribution
    #| root (a Str); zef runs with that directory as the working directory.
    method build($path)
    {
        note "Alien::Libduckdb: building libduckdb {duckdb-version()}";
        Alien::Libduckdb::Builder::build-libduckdb(:verbose(True));
        note "Alien::Libduckdb: libduckdb ready at {shared-lib().absolute}";
    }

    #| Optional hint for tooling that asks whether a build is already in place.
    method is-built(--> Bool)
    {
        installed();
    }
}
