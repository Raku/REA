#| Alien::Libduckdb -- build and locate the DuckDB C library (libduckdb)
#| from source, so that a NativeCall binding can depend on it.
#|
#| Public API (all exported):
#|   duckdb-version()          upstream version this module builds (default 2.0.0)
#|   prefix()                  private install prefix
#|   lib-dir()                 directory holding the shared library
#|   include-dir()             directory holding duckdb.h / duckdb_v2.h
#|   shared-lib()              absolute path of the shared library (IO::Path)
#|   lib()                     what to hand to NativeCall `is native(...)`
#|   installed()               is a matching build present?
#|   config()                  Hash with everything above
#|   cflags() / ldflags()      flags for a C/C++ build
#|   ensure-installed()        install on demand (used by consumers)
#|   build-from-source()      force a source build (cmake + toolchain)
#|   install-prebuilt()       install the published shared-library archive
#|   source-kind()            'prebuilt' or 'source', from the install marker
#|
#| Installation strategy
#| =====================
#| `ensure-installed` / `build-libduckdb` try the prebuilt archive published
#| by upstream first (`duckdb-shared-libs-<os>-<arch>.tar.gz`): it lands in
#| seconds and needs no toolchain.  Every candidate is smoke-tested out of
#| process (NativeCall -> duckdb_library_version) before it is accepted, so a
#| missing runtime dependency, a glibc/musl mismatch or a wrong CPU
#| architecture silently degrades into the source build instead of producing
#| a library that explodes on first use.
#|
#| Environment:
#|   ALIEN_LIBDUCKDB_VERSION, ALIEN_LIBDUCKDB_ROOT, ALIEN_LIBDUCKDB_PREFIX,
#|   ALIEN_LIBDUCKDB_SRC, ALIEN_LIBDUCKDB_JOBS, ALIEN_LIBDUCKDB_CC/_CXX,
#|   ALIEN_LIBDUCKDB_PREBUILT=0       skip the download (source only)
#|   ALIEN_LIBDUCKDB_PREBUILT_ONLY=1  never fall back to a source build
#|   ALIEN_LIBDUCKDB_SOURCE_ONLY=1    alias for PREBUILT=0
#|   ALIEN_LIBDUCKDB_KEEP_SOURCE=1    keep the checkout after a source build
unit module Alien::Libduckdb;

use Alien::Libduckdb::Spec;
use Alien::Libduckdb::Builder;

our $MODULE-VERSION = '1.1.0';

#| Version of *this* module (not of libduckdb).
our sub version(--> Str) is export { $MODULE-VERSION }

#| Version of libduckdb that this module builds / expects.
our sub duckdb-version(--> Str) is export { spec-duckdb-version() }

#| Root of the private install tree (per-version subdirectory).
our sub prefix(--> IO::Path) is export { spec-prefix() }

our sub lib-dir(--> IO::Path) is export { spec-lib-dir() }

our sub include-dir(--> IO::Path) is export { spec-include-dir() }

#| Absolute path of the built shared library; an undefined IO::Path when the
#| library has not been built yet.  Always check .defined / installed().
our sub shared-lib(--> IO::Path) is export { spec-find-shared-lib() }

#| True when a library built for the requested upstream version *and* this
#| platform is present.
our sub installed(--> Bool) is export { spec-installed() }

#| What to pass to NativeCall:  sub ... is native(Alien::Libduckdb::lib())
#| Resolution order: absolute path (preferred, unambiguous) -> bare name,
#| which lets the OS loader search its usual paths.
our sub lib(--> Str) is export
{
    my $path = shared-lib();
    $path.defined ?? $path.absolute !! spec-shared-name();
}

our sub config(--> Hash) is export
{
    my $path  = shared-lib();
    my $is-win = spec-is-win();
    my %cfg =
        version   => duckdb-version(),
        module    => $MODULE-VERSION,
        platform  => spec-platform-tag(),
        prefix    => prefix().absolute,
        lib_dir   => lib-dir().absolute,
        include   => include-dir().absolute,
        installed => installed(),
        shared    => spec-shared-name(),
        is_win    => $is-win,
        source_kind    => source-kind(),
        prebuilt_asset => prebuilt-asset();

    %cfg<lib> = $path.absolute if $path.defined;
    %cfg
}

our sub cflags(--> Str) is export { '-I' ~ include-dir().absolute }

our sub ldflags(--> Str) is export
{
    my $dir = lib-dir().absolute;
    spec-is-win()
        ?? "-L$dir -lduckdb"
        !! "-L$dir -lduckdb -Wl,-rpath,$dir";
}

#| Convenience wrapper: install only if needed, prebuilt first.
our sub ensure-installed(
    Bool :$force = False,
    Bool :$verbose = True,
    Bool :$source-only = False,
    --> Bool
) is export
{
    return True if !$force && installed();
    build-libduckdb(:$force, :$verbose, :$source-only);
}

#| Short alias, reads better inside consumer setup code.  Deliberately NOT
#| called `build`: a distribution's Build.pm must be free to declare its own
#| `sub build`, and an exported symbol of the same name would clash.
#|
#| Note: this always compiles from source (cmake + toolchain).  Use
#| `ensure-installed` for the normal "prebuilt if possible" behaviour.
our sub build-from-source(
    Bool :$force = False,
    Bool :$clean = False,
    Bool :$verbose = True,
    Int  :$jobs,
    --> Bool
) is export
{
    Alien::Libduckdb::Builder::build-libduckdb(
        :$force, :$clean, :$verbose, :$jobs, :source-only);
}

#| Install the prebuilt shared-library archive published by upstream, without
#| any fallback.  Returns False when the asset is missing for this platform,
#| cannot be downloaded, or does not load.  `ensure-installed` is the usual
#| entry point; this one exists for callers that want the fast path only.
our sub install-prebuilt(
    Bool :$force = False,
    Bool :$verbose = True,
    --> Bool
) is export
{
    return True if !$force && installed();

    return False unless Alien::Libduckdb::Builder::install-prebuilt(:$force, :$verbose);

    my $lib = shared-lib();
    return False unless $lib.defined;
    return False unless Alien::Libduckdb::Builder::verify-loadable($lib, :$verbose);

    Alien::Libduckdb::Builder::write-marker(
        :kind<prebuilt>,
        :detail(prebuilt-url()),
        :compiler('n/a'),
        :generator(prebuilt-asset()));

    installed();
}

#| Release asset this platform would download, '' when upstream publishes
#| nothing for the combination.
our sub prebuilt-asset(--> Str) is export { spec-prebuilt-asset() }

our sub prebuilt-url(--> Str) is export { spec-prebuilt-url() }

#| Whether the installed library came from the prebuilt archive or a source
#| build.  'unknown' when nothing is installed (or the marker predates the
#| field).
our sub source-kind(--> Str) is export
{
    my %info := spec-marker-info();
    return 'unknown' unless %info.elems;
    (%info<source_kind> // 'unknown');
}
