#| Internal helper library for Alien::Libduckdb.
#|
#| Everything in here is deliberately dependency-free: the public module
#| (Alien::Libduckdb) and the builder (Alien::Libduckdb::Builder) both use it,
#| and the builder must be loadable from Build.pm before the distribution is
#| installed, so no third-party modules are allowed here.
#|
#| All exported names carry a `spec-` prefix so that they never collide with
#| the public API exported by Alien::Libduckdb itself.
unit module Alien::Libduckdb::Spec;

#| libduckdb release this module knows how to build.
our $DEFAULT-DUCKDB-VERSION = '2.0.0';

#| Minimum CMake we are willing to drive.
our $MIN-CMAKE-VERSION = v3.15;

#========================================================================
# Environment overrides
#========================================================================
#| ALIEN_LIBDUCKDB_VERSION      upstream tag to build (default 2.0.0)
#| ALIEN_LIBDUCKDB_ROOT         root of the private install tree
#| ALIEN_LIBDUCKDB_PREFIX       exact install prefix (wins over ROOT)
#| ALIEN_LIBDUCKDB_SRC          use an existing source tree instead of cloning
#| ALIEN_LIBDUCKDB_GIT          alternative clone URL
#| ALIEN_LIBDUCKDB_JOBS         parallelism for the build
#| ALIEN_LIBDUCKDB_CC / _CXX    compiler override (Windows mainly)

our sub spec-duckdb-version(--> Str) is export
{
    with %*ENV<ALIEN_LIBDUCKDB_VERSION> {
        return $_ if .chars;
    }
    $DEFAULT-DUCKDB-VERSION
}

our sub spec-is-win(--> Bool) is export { so $*DISTRO.is-win }

our sub spec-is-mac(--> Bool) is export { so $*DISTRO.name ~~ /darwin|macos|mac/ }

#| The file name produced by the CMake `duckdb` shared-library target.
#| On Windows the official build drops the `lib` prefix; both spellings are
#| accepted on lookup because MinGW toolchains may emit either.
our sub spec-shared-name(--> Str) is export
{
    spec-is-win() ?? 'duckdb.dll' !! 'libduckdb.so'
}

our sub spec-shared-candidates(--> List) is export
{
    spec-is-win()
        ?? ('duckdb.dll', 'libduckdb.dll')
        !! ('libduckdb.so', 'libduckdb.so.1')
}

our sub spec-static-candidates(--> List) is export
{
    spec-is-win()
        ?? ('duckdb.lib', 'libduckdb.dll.a', 'libduckdb.a')
        !! ('libduckdb_static.a', 'libduckdb.a')
}

our sub spec-platform-tag(--> Str) is export
{
    my $os = spec-is-win() ?? 'win' !! (spec-is-mac() ?? 'mac' !! 'linux');
    my $hw = try { $*KERNEL.hardware.Str } // 'unknown';
    $os ~ '-' ~ $hw
}

#========================================================================
# Directory layout
#========================================================================
our sub spec-root(--> IO::Path) is export
{
    with %*ENV<ALIEN_LIBDUCKDB_ROOT> {
        return .IO if .chars;
    }

    if spec-is-win()
    {
        my $la = %*ENV<LOCALAPPDATA>;
        my $base = ($la.defined && $la.chars)
            ?? $la.IO
            !! $*HOME.add('AppData/Local');
        return $base.add('Alien-Libduckdb');
    }

    return $*HOME.add('Library/Application Support/Alien-Libduckdb')
        if spec-is-mac();

    my $xdg = %*ENV<XDG_DATA_HOME>;
    my $base = ($xdg.defined && $xdg.chars)
        ?? $xdg.IO
        !! $*HOME.add('.local/share');
    $base.add('Alien-Libduckdb');
}

#| Root of everything this module owns: <root>/<duckdb-version>/
our sub spec-prefix(--> IO::Path) is export
{
    with %*ENV<ALIEN_LIBDUCKDB_PREFIX> {
        return .IO if .chars;
    }
    spec-root().add(spec-duckdb-version());
}

#| Where the shared library lives.  Windows puts DLLs in bin/ (that is the
#| directory the loader searches and where runtime DLLs get copied).
our sub spec-lib-dir(--> IO::Path) is export
{
    spec-is-win() ?? spec-prefix().add('bin') !! spec-prefix().add('lib');
}

our sub spec-include-dir(--> IO::Path) is export { spec-prefix().add('include') }

#| Source checkout location.
our sub spec-src-dir(--> IO::Path) is export
{
    with %*ENV<ALIEN_LIBDUCKDB_SRC> {
        return .IO if .chars;
    }
    spec-root().add('src').add('duckdb-' ~ spec-duckdb-version());
}

#| Out-of-tree CMake build directory.
our sub spec-build-dir(--> IO::Path) is export
{
    spec-root().add('build').add('duckdb-' ~ spec-duckdb-version());
}

#| Log directory for the last build attempt.
our sub spec-log-dir(--> IO::Path) is export { spec-prefix().add('logs') }

#| Marker file recording what was installed; its content is the proof of a
#| successful build and is checked on every load.
our sub spec-marker(--> IO::Path) is export { spec-prefix().add('.alientag') }

#========================================================================
# State queries
#========================================================================
our sub spec-find-shared-lib(--> IO::Path) is export
{
    my $dir = spec-lib-dir();
    return IO::Path unless $dir.d;

    for spec-shared-candidates() -> $name
    {
        my $p = $dir.add($name);
        return $p if $p.e && $p.f;
    }
    IO::Path
}

#| True only when the prefix holds a library built for *this* upstream version
#| on *this* platform.  A marker from another version/arch does not count, so a
#| version switch triggers a rebuild instead of silently binding the wrong ABI.
our sub spec-installed(--> Bool) is export
{
    my $marker = spec-marker();
    return False unless $marker.e && $marker.f;

    my $tag = try { $marker.slurp.trim } // '';
    return False unless $tag.contains('version=' ~ spec-duckdb-version());
    return False unless $tag.contains('platform=' ~ spec-platform-tag());

    so spec-find-shared-lib().defined;
}

#| The marker as a plain Hash (one `key=value` per line).  Empty when nothing
#| has been installed yet; consumers use it to tell a prebuilt install from a
#| source build without re-deriving the state.
our sub spec-marker-info(--> Hash) is export
{
    my $marker = spec-marker();
    return %() unless $marker.e && $marker.f;

    my $text = try { $marker.slurp } // '';
    my %info;
    for $text.lines -> $line
    {
        next unless $line.contains('=');
        my ($k, $v) = $line.split('=', 2);
        next unless $k.defined;
        my $key = $k.trim;
        %info{$key} = ($v // '').trim if $key.chars;
    }
    %info
}

#| Raw value of the PATH environment variable.
#|
#| Looked up case-insensitively on purpose: Windows stores the variable as
#| `Path`, and depending on how Rakudo was started `%*ENV<PATH>` can come back
#| undefined even though the variable exists.  `%*ENV<PATH> // ''` would then
#| silently yield an empty search path.
our sub spec-env-path(--> Str)
{
    for %*ENV.keys -> $k
    {
        next unless $k.uc eq 'PATH';
        my $v = %*ENV{$k};
        return $v if $v.defined && $v.chars;
    }
    ''
}

#| Cheap pre-flight: is a usable toolchain on PATH?
our sub spec-find-in-path(Str $exe --> IO::Path) is export
{
    my @names = spec-is-win() ?? ($exe, "$exe.exe", "$exe.bat", "$exe.cmd") !! ($exe,);
    my $sep  = spec-is-win() ?? ';' !! ':';

    for spec-env-path().split($sep) -> $dir
    {
        my $clean = $dir.trim.subst(/^ '"' | '"' $/, '');
        next unless $clean.chars;
        for @names -> $name
        {
            my $p = $clean.IO.add($name);
            return $p if $p.e && $p.f;
        }
    }
    IO::Path
}

our sub spec-source-url(--> Str) is export
{
    with %*ENV<ALIEN_LIBDUCKDB_GIT> {
        return $_ if .chars;
    }
    'https://github.com/duckdb/duckdb.git'
}

our sub spec-archive-url(--> Str) is export
{
    'https://github.com/duckdb/duckdb/archive/refs/tags/v'
        ~ spec-duckdb-version() ~ '.tar.gz'
}

#========================================================================
# Prebuilt release assets
#========================================================================
#| GitHub publishes a set of `duckdb-shared-libs-<os>-<arch>.tar.gz` archives
#| next to every tag; each one is flat and contains the shared library plus
#| the five public headers.  Installing one takes seconds instead of the
#| 5-20 minutes a source build needs, so it is tried first by default.
#|
#| Switches (all optional):
#|   ALIEN_LIBDUCKDB_PREBUILT=0       never download, go straight to source
#|   ALIEN_LIBDUCKDB_PREBUILT_ONLY=1  never fall back to a source build
#|   ALIEN_LIBDUCKDB_SOURCE_ONLY=1    alias for PREBUILT=0

#| Read a boolean-ish environment variable without caring about the name's
#| case (Windows stores them upper-cased, POSIX as written).  Returns
#| 'yes' / 'no' / '' when unset, so callers can tell "off" from "default".
our sub spec-env-tri(Str $name --> Str)
{
    my %truthy = set <1 yes true on y>;
    my %falsy  = set <0 no false off n>;

    for %*ENV.keys -> $k
    {
        next unless $k.uc eq $name.uc;
        my $v = (%*ENV{$k} // '').trim.lc;
        return 'yes' if %truthy{$v};
        return 'no'  if %falsy{$v};
        return 'yes';
    }
    ''
}

our sub spec-prebuilt-enabled(--> Bool) is export
{
    return False if spec-env-tri('ALIEN_LIBDUCKDB_SOURCE_ONLY') eq 'yes';
    spec-env-tri('ALIEN_LIBDUCKDB_PREBUILT') ne 'no'
}

our sub spec-prebuilt-only(--> Bool) is export
{
    spec-env-tri('ALIEN_LIBDUCKDB_PREBUILT_ONLY') eq 'yes'
}

#| Normalised CPU architecture as used in the release asset names.
our sub spec-arch(--> Str) is export
{
    my $hw = try { $*KERNEL.hardware.Str } // '';
    return 'x86_64'  if $hw ~~ /:i x86_64 | amd64 /;
    return 'aarch64' if $hw ~~ /:i aarch64 | arm64 /;
    $hw
}

#| musl-based distros need the `-musl` asset; a glibc build will not load.
our sub spec-is-musl(--> Bool) is export
{
    return False if spec-is-win() || spec-is-mac();
    return True if '/etc/alpine-release'.IO.e;
    so '/lib'.IO.add('ld-musl-' ~ spec-arch() ~ '.so.1').e;
}

#| Release asset base name for this version and platform, '' when GitHub
#| ships no archive for the combination (the builder then falls back to
#| source automatically).
our sub spec-prebuilt-asset(--> Str) is export
{
    my $arch = spec-arch();
    my $suffix = $arch eq 'x86_64'  ?? 'amd64'
              !! $arch eq 'aarch64' ?? 'arm64'
              !! '';
    return '' unless $suffix.chars;

    return "duckdb-shared-libs-windows-$suffix" if spec-is-win();
    return "duckdb-shared-libs-osx-$suffix"     if spec-is-mac();
    "duckdb-shared-libs-linux-$suffix" ~ (spec-is-musl() ?? '-musl' !! '');
}

our sub spec-prebuilt-supported(--> Bool) is export { so spec-prebuilt-asset().chars }

our sub spec-prebuilt-url(--> Str) is export
{
    my $asset = spec-prebuilt-asset();
    return '' unless $asset.chars;
    'https://github.com/duckdb/duckdb/releases/download/v'
        ~ spec-duckdb-version() ~ '/' ~ $asset ~ '.tar.gz'
}

#| Scratch area for the downloaded archive and its unpacked contents.
our sub spec-prebuilt-dir(--> IO::Path) is export
{
    spec-root().add('prebuilt').add('duckdb-' ~ spec-duckdb-version())
}
