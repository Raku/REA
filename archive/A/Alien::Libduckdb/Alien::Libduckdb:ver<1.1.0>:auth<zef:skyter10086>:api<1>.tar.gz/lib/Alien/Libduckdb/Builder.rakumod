#| Source build driver for Alien::Libduckdb.
#|
#| Responsibilities:
#|   * fetch the DuckDB source tree (git clone --depth 1, or a tarball when
#|     git is unavailable)
#|   * configure it with CMake, per platform
#|   * build only the shared library (shell / tests / benchmarks off)
#|   * harvest libduckdb.* + duckdb.h into the private prefix
#|   * on Windows, copy the MinGW runtime DLLs the library links against
#|     next to it, so that NativeCall can load it without touching PATH
#|
#| DuckDB 2.0 vendors every third-party dependency inside the repo, so the
#| clone needs no `--recurse-submodules`.  (DuckDB 1.x did use submodules;
#| the code below passes the flag only when a .gitmodules file is present.)
unit module Alien::Libduckdb::Builder;

use Alien::Libduckdb::Spec;

class X::Alien::Libduckdb::Build is Exception is export
{
    has Str $.step;
    has Str $.detail;

    method message(--> Str)
    {
        my $msg = "Alien::Libduckdb: build failed during <{$!step // 'unknown'}>";
        $msg ~= " -- $!detail" if $!detail.defined;
        $msg;
    }
}

#========================================================================
# Small filesystem / process helpers
#========================================================================
our sub ensure-dir(IO::Path $p --> IO::Path)
{
    return $p if $p.d;
    my $parent = $p.parent;
    ensure-dir($parent) if $parent ne $p && !$parent.d;
    $p.mkdir unless $p.d;
    $p
}

our sub blank-line(--> Str) { '' }

our sub run-logged(@cmd, IO::Path $log-dir, Str $tag, Bool :$verbose --> Bool)
{
    ensure-dir($log-dir);

    my $out-path = $log-dir.add("$tag.log");
    my $err-path = $log-dir.add("$tag.err.log");

    my $out = $out-path.open(:w);
    my $err = $err-path.open(:w);
    $out.say('# ' ~ @cmd.join(' '));
    $out.flush;

    say "  > {@cmd.join(' ')}" if $verbose;
    my $started = now;

    my $proc = try run @cmd, :out($out), :err($err);
    unless $proc.defined
    {
        $out.close;
        $err.close;
        return False;
    }
    # Rakudo builds in the wild differ: some expose Proc.wait, others only
    # Proc.exitcode (which blocks until the child has exited anyway).
    if $proc.^can('wait') { $proc.wait } else { $proc.exitcode }

    $out.close;
    $err.close;

    my $code = $proc.exitcode // -1;
    say "  < exit {$code} in {(now - $started).Num.round(0.1)}s" if $verbose;
    $code == 0;
}

our sub log-tail(IO::Path $log-dir, Str $tag, Int $n = 25 --> Str)
{
    my @parts;
    for $log-dir.add("$tag.err.log"), $log-dir.add("$tag.log") -> $f
    {
        next unless $f.e && $f.f;
        my @lines = try { $f.lines } // ();
        next unless @lines;
        @parts.push: "-- {$f.basename}\n" ~ @lines.tail($n).join("\n");
    }
    @parts.join("\n\n");
}

our sub find-artifacts(IO::Path $root, Regex $pattern, Int $max-depth = 5 --> List)
{
    my @found;
    my sub walk(IO::Path $dir, Int $depth)
    {
        return if $depth > $max-depth;
        my $here = $dir.IO;
        return unless $here.d;

        my @entries = try { $here.dir.map({ $_.IO }).eager } // ();

        for @entries -> $e
        {
            if $e.d
            {
                next if $e.basename eq '.git' or $e.basename eq 'CMakeFiles';
                walk($e, $depth + 1);
            }
            elsif $e.basename ~~ $pattern
            {
                @found.push($e);
            }
        }
    }
    walk($root, 0);
    @found
}

our sub copy-into(IO::Path $src, IO::Path $dest-dir --> Bool)
{
    ensure-dir($dest-dir);
    my $target = $dest-dir.add($src.basename);
    try { $target.unlink if $target.e };
    so try { $src.copy($target).defined };
}

our sub cpu-jobs(--> Int)
{
    with %*ENV<ALIEN_LIBDUCKDB_JOBS> {
        my $n = .Int;
        return $n if $n > 0;
    }
    my $cores = try { $*KERNEL.cpu-cores } // 4;
    $cores > 0 ?? $cores !! 4;
}

#========================================================================
# Source acquisition
#========================================================================
our sub prepare-source(IO::Path $explicit, Bool :$verbose, IO::Path :$log-dir --> IO::Path)
{
    return $explicit if $explicit.defined && $explicit.d;

    my $dir = spec-src-dir();
    return $dir if $dir.d && $dir.add('CMakeLists.txt').e;

    ensure-dir($dir.parent);

    my $tag = 'v' ~ spec-duckdb-version();

    if $dir.d
    {
        say "  removing incomplete source tree at $dir" if $verbose;
        try { $dir.rmtree };
    }

    my $git = spec-find-in-path('git');
    if $git.defined
    {
        my @cmd = ($git.absolute, 'clone', '--depth', '1', '--branch', $tag,
                   spec-source-url(), $dir.absolute);
        my $ok = run-logged(@cmd, $log-dir, 'clone', :$verbose);
        unless $ok
        {
            die X::Alien::Libduckdb::Build.new(
                :step<fetch-source>,
                :detail("git clone $tag failed\n" ~ log-tail($log-dir, 'clone')));
        }

        # 1.x trees need submodules; 2.x vendors everything.  Detect instead
        # of guessing so the same code path works for older tags.
        if $dir.add('.gitmodules').e
        {
            say "  initialising submodules" if $verbose;
            my $sub-ok = run-logged(
                [$git.absolute, '-C', $dir.absolute, 'submodule', 'update',
                 '--init', '--recursive', '--depth', '1'],
                $log-dir, 'submodule', :$verbose);
            unless $sub-ok
            {
                die X::Alien::Libduckdb::Build.new(
                    :step<fetch-source>,
                    :detail("git submodule update failed\n" ~ log-tail($log-dir, 'submodule')));
            }
        }
        return $dir;
    }

    # No git: fall back to the GitHub tarball.  Works because the archive
    # contains the vendored third_party tree.
    my $curl = spec-find-in-path('curl');
    my $url  = spec-archive-url();
    my $tmp  = $dir.parent.add("duckdb-{$tag}.tar.gz");
    ensure-dir($dir.parent);

    if $curl.defined
    {
        say "  downloading $url" if $verbose;
        my $ok = run-logged(
            [$curl.absolute, '-fL', '--retry', '3', '-o', $tmp.absolute, $url],
            $log-dir, 'download', :$verbose);
        unless $ok
        {
            die X::Alien::Libduckdb::Build.new(
                :step<fetch-source>,
                :detail("curl download failed\n" ~ log-tail($log-dir, 'download')));
        }
    }
    else
    {
        die X::Alien::Libduckdb::Build.new(
            :step<preflight>,
            :detail('neither git nor curl is on PATH; cannot fetch the DuckDB sources'));
    }

    my $tar = spec-find-in-path('tar');
    unless $tar.defined
    {
        die X::Alien::Libduckdb::Build.new(
            :step<preflight>, :detail('tar not found on PATH; cannot unpack the archive'));
    }

    say "  unpacking to {$dir.parent}" if $verbose;
    my $ok = run-logged(
        [$tar.absolute, '-xzf', $tmp.absolute, '-C', $dir.parent.absolute],
        $log-dir, 'unpack', :$verbose);
    unless $ok
    {
        die X::Alien::Libduckdb::Build.new(
            :step<fetch-source>,
            :detail("tar extraction failed\n" ~ log-tail($log-dir, 'unpack')));
    }

    # GitHub names the root directory "duckdb-<version>".
    my $extracted = $dir.parent.add('duckdb-' ~ spec-duckdb-version());
    if $extracted.d && $extracted.absolute ne $dir.absolute
    {
        try { $dir.rmtree if $dir.d };
        try { $extracted.rename($dir) };
    }

    unless $dir.add('CMakeLists.txt').e
    {
        die X::Alien::Libduckdb::Build.new(
            :step<fetch-source>,
            :detail("no CMakeLists.txt under {$dir.absolute} after unpacking"));
    }
    $dir;
}

#========================================================================
# Toolchain detection
#========================================================================
our sub pick-generator(Str $requested, Bool :$verbose --> Str)
{
    return $requested if $requested.defined && $requested.chars;

    if spec-find-in-path('ninja').defined
    {
        return 'Ninja';
    }
    unless spec-is-win()
    {
        return 'Unix Makefiles';
    }
    die X::Alien::Libduckdb::Build.new(
        :step<preflight>,
        :detail('Windows builds need Ninja (cmake --install or winget install Ninja-build.Ninja); '
                ~ 'MSBuild generators are not supported by this builder'));
}

our sub pick-compiler(Str $requested, Str $env-name, @fallbacks --> IO::Path)
{
    with %*ENV{$env-name}
    {
        my $p = .IO;
        return $p if .chars && $p.e;
    }
    if $requested.defined && $requested.chars
    {
        my $p = $requested.IO;
        return $p if $p.e;
        my $found = spec-find-in-path($requested);
        return $found if $found.defined;
        die X::Alien::Libduckdb::Build.new(
            :step<preflight>, :detail("compiler '$requested' not found"));
    }
    for @fallbacks -> $name
    {
        my $p = spec-find-in-path($name);
        return $p if $p.defined;
    }
    IO::Path
}

#========================================================================
# Windows runtime DLL handling
#========================================================================
my %SYSTEM-DLLS = set <
    kernel32.dll user32.dll gdi32.dll advapi32.dll shell32.dll ole32.dll
    oleaut32.dll ws2_32.dll wsock32.dll msvcrt.dll ucrtbase.dll
    ntdll.dll bcrypt.dll crypt32.dll secur32.dll iphlpapi.dll psapi.dll
    dbghelp.dll version.dll winmm.dll shlwapi.dll comdlg32.dll
    userenv.dll powrprof.dll setupapi.dll mpr.dll netapi32.dll
    api-ms-win-crt-runtime-l1-1-0.dll rpcrt4.dll
>;

#| Copy the non-system DLLs that the freshly built duckdb.dll imports.
#| llvm-mingw / MinGW builds link against libc++.dll, libunwind.dll and
#| libwinpthread-1.dll; without them next to the library, LoadLibrary fails
#| with "The specified module could not be found".
our sub copy-windows-runtime-deps(IO::Path $dll, IO::Path $compiler-bin, Bool :$verbose --> List)
{
    my @copied;
    return @copied unless spec-is-win();

    my $objdump = spec-find-in-path('objdump');
    unless $objdump.defined
    {
        say "  ! objdump not found; skipping runtime DLL discovery" if $verbose;
        return @copied;
    }

    my $proc = try run $objdump.absolute, '-p', $dll.absolute, :out, :err;
    return @copied unless $proc.defined;
    # Rakudo builds in the wild differ: some expose Proc.wait, others only
    # Proc.exitcode (which blocks until the child has exited anyway).
    if $proc.^can('wait') { $proc.wait } else { $proc.exitcode }

    my $text = try { $proc.out.slurp(:close) } // '';
    my @deps = $text.lines
        .grep({ .contains('DLL Name:') })
        .map({ .subst(/ .* 'DLL Name:' \s* /, '').trim })
        .grep({ .chars && !%SYSTEM-DLLS{.lc} && !.lc.starts-with('api-ms-') });

    my $dest = spec-lib-dir();
    ensure-dir($dest);

    for @deps -> $dep
    {
        my $candidate = $compiler-bin.add($dep);
        unless $candidate.e
        {
            # llvm-mingw keeps runtimes in <prefix>/bin, which is $compiler-bin;
            # a GCC toolchain may have them in <prefix>/lib or nearby.
            my $alt = $compiler-bin.parent.add('bin').add($dep);
            $candidate = $alt if $alt.e;
        }
        next unless $candidate.e && $candidate.f;
        if copy-into($candidate, $dest)
        {
            @copied.push($dep);
            say "  + runtime {$dep}" if $verbose;
        }
    }
    @copied
}

#========================================================================
# Source build (the fallback path)
#========================================================================
#| Configure and compile DuckDB from a source checkout.  This is the slow
#| path: it needs cmake plus a working C/C++ toolchain and takes anywhere
#| from 5 to 20 minutes.  Throws X::Alien::Libduckdb::Build on failure; the
#| public entry point wraps it in a try so a failed prebuilt attempt can
#| still fall back here.
our sub build-from-source-libduckdb(
    Bool :$force = False,
    Bool :$clean = False,
    Bool :$keep-source = False,
    Bool :$verbose = True,
    Int  :$jobs,
    Str  :$generator,
    Str  :$cc,
    Str  :$cxx,
    IO::Path :$source,
    --> Bool
)
{
    my $version = spec-duckdb-version();
    my $prefix  = spec-prefix();
    my $log-dir = spec-log-dir();

    if !$force && spec-installed()
    {
        say "Alien::Libduckdb: libduckdb $version already installed in $prefix" if $verbose;
        return True;
    }

    my $cmake = spec-find-in-path('cmake');
    unless $cmake.defined
    {
        die X::Alien::Libduckdb::Build.new(
            :step<preflight>,
            :detail('cmake not found on PATH; install CMake 3.15 or newer'));
    }

    say "Alien::Libduckdb: building libduckdb $version for {spec-platform-tag()}" if $verbose;
    say "  prefix: $prefix" if $verbose;

    ensure-dir($prefix);

    my $src = prepare-source($source, :$verbose, :$log-dir);

    my $build-dir = spec-build-dir();
    if $clean && $build-dir.d
    {
        say "  cleaning $build-dir" if $verbose;
        try { $build-dir.rmtree };
    }
    ensure-dir($build-dir);

    my $gen = pick-generator($generator, :$verbose);

    my @configure = ($cmake.absolute, '-S', $src.absolute, '-B', $build-dir.absolute,
                     '-G', $gen,
                     '-DCMAKE_BUILD_TYPE=Release',
                     '-DBUILD_SHELL=OFF',
                     '-DBUILD_UNITTESTS=OFF',
                     '-DBUILD_BENCHMARKS=OFF',
                     '-DCMAKE_POSITION_INDEPENDENT_CODE=ON');

    my $c-compiler = IO::Path;
    my $cxx-compiler = IO::Path;

    if spec-is-win()
    {
        $c-compiler   = pick-compiler($cc,  'CC',  <gcc clang>);
        $cxx-compiler = pick-compiler($cxx, 'CXX', <g++ clang++>);

        unless $c-compiler.defined && $cxx-compiler.defined
        {
            die X::Alien::Libduckdb::Build.new(
                :step<preflight>,
                :detail('no C/C++ compiler found on PATH (install llvm-mingw, MinGW-w64, '
                        ~ 'or set ALIEN_LIBDUCKDB_CC / ALIEN_LIBDUCKDB_CXX)'));
        }
        @configure.push: '-DCMAKE_C_COMPILER='   ~ $c-compiler.absolute;
        @configure.push: '-DCMAKE_CXX_COMPILER=' ~ $cxx-compiler.absolute;
        say "  compiler: {$c-compiler.absolute}" if $verbose;
    }

    say "  configuring ($gen)" if $verbose;
    my $conf-ok = run-logged(@configure, $log-dir, 'configure', :$verbose);
    unless $conf-ok
    {
        die X::Alien::Libduckdb::Build.new(
            :step<configure>,
            :detail("cmake configure failed\n" ~ log-tail($log-dir, 'configure')));
    }

    my $n = $jobs // cpu-jobs();
    say "  compiling with $n job(s) -- this takes a while" if $verbose;
    my $build-ok = run-logged(
        [$cmake.absolute, '--build', $build-dir.absolute, '--config', 'Release',
         '--parallel', $n.Str],
        $log-dir, 'build', :$verbose);

    unless $build-ok
    {
        die X::Alien::Libduckdb::Build.new(
            :step<compile>,
            :detail("cmake --build failed\n" ~ log-tail($log-dir, 'build')));
    }

    #--------------------------------------------------------------------
    # Harvest: shared library
    #--------------------------------------------------------------------
    my $shared-name = spec-shared-name();
    my @candidates = spec-shared-candidates();
    my @known;
    for @candidates -> $n
    {
        @known.push: $build-dir.add('src').add($n);
        @known.push: $build-dir.add('Release').add('src').add($n);
        @known.push: $build-dir.add('src').add('Release').add($n);
    }

    my $lib = @known.first({ $_.e && $_.f });
    unless $lib.defined
    {
        for @candidates -> $n
        {
            my $hit = find-artifacts($build-dir, /^ $n $/, 6).first({ $_.f });
            if $hit.defined
            {
                $lib = $hit;
                last;
            }
        }
    }
    unless $lib.defined
    {
        die X::Alien::Libduckdb::Build.new(
            :step<harvest>,
            :detail("build succeeded but none of {@candidates.join(', ')} was found under {$build-dir.absolute}"));
    }

    # MinGW emits libduckdb.dll while MSVC emits duckdb.dll; downstream code
    # always loads the canonical name, so normalise on the way in.
    my $lib-dest = spec-lib-dir();
    ensure-dir($lib-dest);
    my $target = $lib-dest.add($shared-name);
    try { $target.unlink if $target.e };
    unless try { $lib.copy($target).defined }
    {
        die X::Alien::Libduckdb::Build.new(
            :step<harvest>, :detail("could not copy {$lib.absolute} into {$target.absolute}"));
    }
    say "  installed {$target}" if $verbose;

    # On Windows also stash the import library, so downstream dists can link
    # against it if they ever need to.
    if spec-is-win()
    {
        for spec-static-candidates() -> $name
        {
            my $hit = find-artifacts($build-dir, /^ $name $/, 6).first({ $_.f });
            next unless $hit.defined;
            copy-into($hit, $prefix.add('lib'));
            say "  installed import lib {$name}" if $verbose;
            last;
        }
        copy-windows-runtime-deps($lib-dest.add($lib.basename), $c-compiler.parent, :$verbose);
    }

    #--------------------------------------------------------------------
    # Harvest: headers
    #--------------------------------------------------------------------
    my $include-src = $src.add('src/include');
    my $include-dest = spec-include-dir();
    my $headers = 0;
    if $include-src.d
    {
        for $include-src.dir -> $h
        {
            next unless $h.f && $h.extension eq 'h';
            $headers++ if copy-into($h, $include-dest);
        }
    }
    unless $headers
    {
        die X::Alien::Libduckdb::Build.new(
            :step<harvest>, :detail("no headers found under {$include-src.absolute}"));
    }
    say "  installed $headers header file(s)" if $verbose;

    #--------------------------------------------------------------------
    # Marker
    #--------------------------------------------------------------------
    my $marker = spec-marker();
    my $compiler-desc = spec-is-win()
        ?? ($c-compiler.defined ?? $c-compiler.absolute !! 'unknown')
        !! 'system';
    $marker.spurt: join("\n",
        "version="     ~ $version,
        "platform="    ~ spec-platform-tag(),
        "built="       ~ DateTime.now.utc.Str,
        "prefix="      ~ $prefix.absolute,
        "compiler="    ~ $compiler-desc,
        "generator="   ~ $gen,
        "source_kind=source",
        "source="      ~ $src.absolute,
        '') ;

    unless spec-installed()
    {
        die X::Alien::Libduckdb::Build.new(
            :step<verify>,
            :detail("post-install verification failed: " ~ spec-find-shared-lib().absolute));
    }
    say "  verified {spec-find-shared-lib().absolute}" if $verbose;

    if !$keep-source
    {
        # Keep build/ (incremental rebuilds) but drop the checkout, which is
        # the bulk of the disk usage (~1.5 GB with objects).
        if !%*ENV<ALIEN_LIBDUCKDB_KEEP_SOURCE>
        {
            say "  removing source tree {$src.absolute} (set ALIEN_LIBDUCKDB_KEEP_SOURCE=1 to keep)" if $verbose;
            try { $src.rmtree };
        }
    }

    say "Alien::Libduckdb: done -- libduckdb $version installed in $prefix" if $verbose;
    True;
}

#========================================================================
# Prebuilt install (the fast path)
#========================================================================

#| Spawn a throw-away Rakudo process that loads the installed library through
#| NativeCall and calls duckdb_library_version().  Doing this out of process
#| keeps a broken library from taking the builder down with it, and it is the
#| only reliable way to catch a missing runtime dependency -- the MSVC
#| redistributable on Windows, a newer glibc on Linux, a musl/glibc mismatch,
#| or the wrong CPU architecture.
our sub verify-loadable(IO::Path $lib, Bool :$verbose --> Bool)
{
    my $log-dir = spec-log-dir();
    ensure-dir($log-dir);

    # NativeCall is happiest with forward slashes on every platform; embedding
    # the path literally also avoids handing a backslash-escape to the parser.
    my $posix = $lib.absolute.subst(/\\/, '/', :g);
    my $probe = $log-dir.add('probe-load.raku');
    $probe.spurt:
        'use NativeCall;' ~ "\n"
        ~ 'sub duckdb_library_version(--> Str) is native(' ~ "'" ~ $posix ~ "'" ~ ') ' ~ '{ * }' ~ "\n"
        ~ 'my $v = duckdb_library_version();' ~ "\n"
        ~ 'print($v.defined ?? $v !! "nil");' ~ "\n";

    my $proc = try run $*EXECUTABLE.absolute, $probe.absolute, :out, :err;
    unless $proc.defined
    {
        say "  ! could not spawn a probe process to load $lib" if $verbose;
        return False;
    }
    if $proc.^can('wait') { $proc.wait } else { $proc.exitcode }

    my $out  = (try { $proc.out.slurp(:close) }) // '';
    my $err  = (try { $proc.err.slurp(:close) }) // '';
    my $code = $proc.exitcode // -1;

    $log-dir.add('probe-load.log').spurt:
        "lib=$posix\nexit=$code\n--- stdout ---\n$out\n--- stderr ---\n$err\n";

    if $code == 0 && $out.trim.chars
    {
        say "  loaded ok, reports $out.trim()" if $verbose;
        return True;
    }

    my $why = ($err.trim.lines.first // '').trim;
    say "  ! library failed to load (exit $code)" ~ ($why.chars ?? " -- $why" !! '') if $verbose;
    False;
}

#| curl first, wget second: curl ships with Windows 10+ and is on every
#| halfway modern Linux/macOS.
our sub download-file(Str $url, IO::Path $dest, Bool :$verbose --> Bool)
{
    my $log-dir = spec-log-dir();
    ensure-dir($dest.parent);

    my $curl = spec-find-in-path('curl');
    if $curl.defined
    {
        say "  downloading $url" if $verbose;
        my $ok = run-logged(
            [$curl.absolute, '-fL', '--retry', '3', '--connect-timeout', '20',
             '-o', $dest.absolute, $url],
            $log-dir, 'prebuilt-download', :$verbose);
        return True if $ok && $dest.e && $dest.s > 0;
        say "  ! curl download failed\n{log-tail($log-dir, 'prebuilt-download')}" if $verbose;
    }

    my $wget = spec-find-in-path('wget');
    if $wget.defined
    {
        say "  downloading $url (wget)" if $verbose;
        my $ok = run-logged(
            [$wget.absolute, '--tries=3', '--timeout=60', '-O', $dest.absolute, $url],
            $log-dir, 'prebuilt-download-wget', :$verbose);
        return True if $ok && $dest.e && $dest.s > 0;
    }

    say "  ! could not fetch $url with curl or wget" if $verbose;
    False;
}

#| Download the published shared-library archive and lay it out in the same
#| prefix a source build would populate.  Returns False instead of throwing:
#| the caller must be free to fall back to a source build.
our sub install-prebuilt(Bool :$verbose = True, Bool :$force = False --> Bool)
{
    my $log-dir = spec-log-dir();
    my $work    = spec-prebuilt-dir();
    my $version = spec-duckdb-version();

    unless spec-prebuilt-supported()
    {
        say "  no prebuilt asset is published for {spec-platform-tag()}" if $verbose;
        return False;
    }

    my $asset = spec-prebuilt-asset();
    my $url   = spec-prebuilt-url();

    ensure-dir($work);
    my $archive = $work.add("$asset.tar.gz");
    try { $archive.unlink if $force && $archive.e };

    if $archive.e && $archive.s > 0
    {
        say "Alien::Libduckdb: reusing cached $archive" if $verbose;
    }
    else
    {
        say "Alien::Libduckdb: fetching prebuilt libduckdb $version ($asset)" if $verbose;
        return False unless download-file($url, $archive, :$verbose);
    }

    my $tar = spec-find-in-path('tar');
    unless $tar.defined
    {
        say "  ! tar is not on PATH; cannot unpack $asset" if $verbose;
        return False;
    }

    my $stage = $work.add('unpacked');
    try { $stage.rmtree if $stage.d };
    ensure-dir($stage);

    unless run-logged([$tar.absolute, '-xzf', $archive.absolute, '-C', $stage.absolute],
                      $log-dir, 'prebuilt-unpack', :$verbose)
    {
        say "  ! could not unpack $asset\n{log-tail($log-dir, 'prebuilt-unpack')}" if $verbose;
        return False;
    }

    # The archives are flat today, but walk a few levels so a future layout
    # change does not silently break the fast path.
    my $lib-src;
    for spec-shared-candidates() -> $name
    {
        my $hit = find-artifacts($stage, /^ $name $/, 4).first({ $_.f });
        if $hit.defined { $lib-src = $hit; last }
    }
    unless $lib-src.defined
    {
        say "  ! no shared library found inside $asset" if $verbose;
        return False;
    }

    my $lib-dest = spec-lib-dir();
    ensure-dir($lib-dest);
    my $target = $lib-dest.add(spec-shared-name());
    try { $target.unlink if $target.e };
    unless try { $lib-src.copy($target).defined }
    {
        say "  ! could not copy {$lib-src.absolute} to {$target.absolute}" if $verbose;
        return False;
    }
    say "  installed {$target}" if $verbose;

    my $inc-dest = spec-include-dir();
    ensure-dir($inc-dest);
    my $headers = 0;
    for find-artifacts($stage, /\.h$/, 4) -> $h
    {
        $headers++ if copy-into($h, $inc-dest);
    }
    unless $headers
    {
        say "  ! no headers found inside $asset" if $verbose;
        return False;
    }
    say "  installed $headers header file(s)" if $verbose;

    # Windows archives also ship duckdb.lib, which downstream C shims (such as
    # the one DB::DuckDB compiles) may want to link against.
    if spec-is-win()
    {
        for spec-static-candidates() -> $name
        {
            my $hit = find-artifacts($stage, /^ $name $/, 4).first({ $_.f });
            next unless $hit.defined;
            if copy-into($hit, spec-lib-dir())
            {
                say "  installed import lib {$name}" if $verbose;
            }
            last;
        }
    }

    True;
}

our sub write-marker(Str :$kind, Str :$detail, Str :$compiler, Str :$generator)
{
    spec-marker().spurt: join("\n",
        "version="     ~ spec-duckdb-version(),
        "platform="    ~ spec-platform-tag(),
        "built="       ~ DateTime.now.utc.Str,
        "prefix="      ~ spec-prefix().absolute,
        "compiler="    ~ ($compiler // 'n/a'),
        "generator="   ~ ($generator // 'n/a'),
        "source_kind=" ~ $kind,
        "source="      ~ ($detail // ''),
        '');
}

#| Wipe whatever a failed prebuilt attempt left behind, so the prefix never
#| looks half-installed and the source build starts from a clean slate.
our sub discard-partial-install()
{
    my $lib = spec-find-shared-lib();
    try { $lib.unlink if $lib.defined && $lib.e };

    my $inc = spec-include-dir();
    if $inc.d
    {
        for $inc.dir -> $f
        {
            next unless $f.f && $f.extension eq 'h';
            try { $f.unlink };
        }
    }
    try { spec-marker().unlink if spec-marker().e };
}

#========================================================================
# Public entry point: prebuilt first, source as the fallback
#========================================================================
our sub build-libduckdb(
    Bool :$force = False,
    Bool :$clean = False,
    Bool :$keep-source = False,
    Bool :$verbose = True,
    Int  :$jobs,
    Str  :$generator,
    Str  :$cc,
    Str  :$cxx,
    IO::Path :$source,
    Bool :$source-only = False,
    --> Bool
) is export
{
    my $version = spec-duckdb-version();
    my $prefix  = spec-prefix();

    if !$force && spec-installed()
    {
        say "Alien::Libduckdb: libduckdb $version already installed in $prefix" if $verbose;
        return True;
    }

    ensure-dir($prefix);

    # An explicit source checkout means the caller wants exactly that tree,
    # so the prebuilt shortcut is skipped.
    my $want-prebuilt = !$source-only && !$source.defined && spec-prebuilt-enabled();
    my @failures;

    #--------------------------------------------------------------------
    # 1. Prebuilt archive -- seconds instead of minutes
    #--------------------------------------------------------------------
    if $want-prebuilt
    {
        # `try` around a Bool-returning call yields Any on failure, which
        # loses the reason; a CATCH block keeps the exception object.
        my $ok = False;
        my $error;
        {
            $ok = install-prebuilt(:$verbose, :$force);
            CATCH { default { $error = $_ } }
        }

        my $note;

        if $error.defined
        {
            $note = 'error: ' ~ (($error.message.lines.first) // 'unknown');
        }
        elsif $ok
        {
            my $lib = spec-find-shared-lib();
            if $lib.defined && verify-loadable($lib, :$verbose)
            {
                write-marker(:kind<prebuilt>, :detail(spec-prebuilt-url()),
                             :compiler('n/a'), :generator(spec-prebuilt-asset()));
                unless spec-installed()
                {
                    die X::Alien::Libduckdb::Build.new(
                        :step<verify>,
                        :detail("prebuilt install did not verify: {$lib.absolute}"));
                }
                say "Alien::Libduckdb: prebuilt libduckdb $version installed in $prefix ({spec-prebuilt-asset()})" if $verbose;
                return True;
            }
            $note = 'downloaded, but the library does not load on this system';
        }
        else
        {
            $note = 'download or unpack failed';
        }

        @failures.push("prebuilt: $note");
        say "  ! prebuilt path unavailable -- $note" if $verbose;
        discard-partial-install();
    }
    elsif $verbose
    {
        my $why = $source-only ?? 'source-only requested'
               !! $source.defined ?? 'explicit source tree given'
               !! 'disabled by ALIEN_LIBDUCKDB_PREBUILT';
        say "Alien::Libduckdb: skipping the prebuilt path ($why)" if $verbose;
    }

    if spec-prebuilt-only()
    {
        die X::Alien::Libduckdb::Build.new(
            :step<prebuilt-only>,
            :detail("ALIEN_LIBDUCKDB_PREBUILT_ONLY is set, but the prebuilt path failed: "
                    ~ (@failures.join('; ') || 'no asset attempted')));
    }

    #--------------------------------------------------------------------
    # 2. Source build -- slow, but always available
    #--------------------------------------------------------------------
    say "Alien::Libduckdb: falling back to a source build of libduckdb $version" if $verbose && @failures.elems;

    my $built = False;
    my $build-error;
    {
        $built = build-from-source-libduckdb(
            :$force, :$clean, :$keep-source, :$verbose, :$jobs,
            :$generator, :$cc, :$cxx, :$source);
        CATCH { default { $build-error = $_ } }
    }

    if $build-error.defined
    {
        my $prefix-note = @failures.elems
            ?? "prebuilt path also failed (" ~ @failures.join('; ') ~ ")\n"
            !! '';
        note $prefix-note ~ $build-error.message;
        die X::Alien::Libduckdb::Build.new(
            :step<build>, :detail($prefix-note ~ $build-error.message));
    }

    # Even a source build gets the out-of-process smoke test: it is the only
    # check that proves the harvested library is actually loadable.
    my $lib = spec-find-shared-lib();
    if $lib.defined && !verify-loadable($lib, :$verbose)
    {
        die X::Alien::Libduckdb::Build.new(
            :step<verify>,
            :detail("the library built fine but does not load: {$lib.absolute}\n"
                    ~ log-tail(spec-log-dir(), 'probe-load')));
    }

    $built;
}
