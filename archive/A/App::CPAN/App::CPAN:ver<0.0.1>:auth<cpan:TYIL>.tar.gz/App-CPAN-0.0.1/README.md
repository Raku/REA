NAME
====

App::CPAN

AUTHOR
======

Patrick Spek <p.spek@tyil.work>

VERSION
=======

0.0.0

Description
===========

Tools to build a local CPAN database and to retrieve updates from CPAN.

The intention of this module is to serve as a possible backend for CPAN interfaces. The features I intend this module to have include:

- Get information of modules on CPAN - Get regular updates of new modules on CPAN - Keep a (local) copy of CPAN module information, possible stored in a PostgreSQL database - Should be able to keep Perl 5 and Perl 6 modules seperate (but can also keep information on both if this is desired)

Installation
============

Install this module through [zef](https://github.com/ugexe/zef):

```sh
zef install App::CPAN
```

License
=======

This module is distributed under the terms of the AGPL-3.0.

