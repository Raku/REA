[![Actions Status](https://github.com/skaji/raku-Acme-Test-Module-Zef/workflows/test/badge.svg)](https://github.com/skaji/raku-Acme-Test-Module-Zef/actions)

NAME
====

Acme::Test::Module::Zef - blah blah blah

SYNOPSIS
========

```raku
use Acme::Test::Module::Zef;
```

DESCRIPTION
===========

Acme::Test::Module::Zef is ...

AUTHOR
======

Shoichi Kaji <skaji@cpan.org>

COPYRIGHT AND LICENSE
=====================

Copyright 2021 Shoichi Kaji

This library is free software; you can redistribute it and/or modify it under the Artistic License 2.0.

