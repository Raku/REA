panda --notests --nodeps --force install .
