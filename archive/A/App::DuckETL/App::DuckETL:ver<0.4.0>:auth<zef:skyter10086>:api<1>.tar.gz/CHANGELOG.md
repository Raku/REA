# Changelog

## 0.4.0 — 2026-10-31

M0–M3 全部里程碑。

### Engine

- SQL-first pipeline: `source` (CSV / Parquet / JSON / table / SQL), `sql`, `assert`,
  `sink` (table / Parquet / CSV)。
- Transactional runs with rollback; staged-file + rename for file sinks.
- Run history in a separate DuckDB file (`_etl.runs`, `_etl.steps`, `_etl.watermarks`).
- Incremental watermarks for table sinks (`append` / `upsert`); updated only after
  commit and file installation.
- Partitioned Parquet sinks (`partition_by`) with staging-directory replacement.
- DuckDB extension loading via pipeline `extensions`.
- Cooperative cancellation via `duckdb_interrupt`; `canceled` status recorded.

### TUI

- Dashboard / Sources / Pipeline / Run screens.
- Pipeline draft editor: add/delete steps, field forms, enum toggles, inline editor,
  `$VISUAL`/`$EDITOR` for SQL, atomic save with validation.
- Run monitoring, log, per-step SQL, preview (LIMIT 100).
- `--isolated` runs the pipeline in a `ducketl worker` child process; worker crash
  leaves the TUI running and marks the run failed.

### CLI

- `ducketl run`, `tui`, `worker`, `extensions`, `validate`, `list`, `show`, `version`.
- `ducketl worker` speaks JSONL on stdout and accepts `cancel` on stdin.

### Tests

- 252 tests across 10 files: SQL scanning, validation, planner SQL, execution,
  rollback, atomic files, CLI, TUI rendering/form logic, watermark/partition/
  extension behavior, isolated worker cancel and crash handling.
