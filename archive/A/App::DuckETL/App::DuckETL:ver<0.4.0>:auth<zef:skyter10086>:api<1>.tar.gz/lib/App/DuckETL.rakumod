unit module App::DuckETL;

our $VERSION = '0.4.0';
