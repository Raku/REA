use JSON::Fast;

#| Run a pipeline in a child `ducketl worker` process that owns the database.
#|
#| Events arrive as single-line JSON on stdout; `cancel` is written to the
#| worker's stdin.  A crashed or killed worker only ends this run: the TUI
#| keeps its own state and reports a failed run.
unit class App::DuckETL::IsolatedRun;

has Str $.pipeline-path is required;
has Str $.database is required;
has Str $.history is required;
has Int $.threads;
has Str $.memory-limit;
has Bool $.keep-temp = False;
#| Worker entry point.  Defaults to the running program (bin/ducketl); tests
#| can point at the script explicitly.
has Str $.program;

has Lock $!lock .= new;
has @!events;
has Bool $!finished = False;
has %!result;
has Bool $!started = False;
has Bool $!saw-result = False;
has $!proc;
has $!done = Promise.new;
has Int $!exit-code = -1;
has Int $!signal = 0;

method start(--> Nil) {
    return if $!started;
    $!started = True;

    my Str $lib = $?FILE.IO.parent.parent.parent.Str;
    my Str $program = $!program.defined ?? $!program !! $*PROGRAM.Str;
    my @command =
        $*EXECUTABLE.Str, "-I{$lib}", $program, 'worker', $!pipeline-path,
        '--db', $!database, '--history', $!history,
    ;
    @command.append: '--threads', $!threads.Str if $!threads.defined;
    @command.append: '--memory-limit', $!memory-limit
        if $!memory-limit.defined && $!memory-limit.chars;
    @command.push: '--keep-temp' if $!keep-temp;

    my $proc = Proc::Async.new(|@command, :w);
    $!proc = $proc;
    $proc.stdout.lines.tap: -> $line { self!handle-line($line) };
    $proc.stderr.lines.tap: -> $line {
        $!lock.protect({ @!events.push({ type => 'worker-log', line => $line }) });
    };

    start {
        my Int $code = -1;
        try {
            my $finished-proc = await $proc.start;
            $code = $finished-proc.exitcode;
            $!signal = $finished-proc.signal;
            CATCH { default { $code = -1 } }
        }
        $!lock.protect({
            $!exit-code = $code;
            unless $!saw-result {
                %!result = %(
                    status => 'failed',
                    error  => $!signal != 0
                        ?? "worker killed by signal {$!signal}"
                        !! "worker exited with code {$code}",
                );
                @!events.push({ type => 'internal-finish', result => %!result });
                $!saw-result = True;
            }
            $!finished = True;
        });
        $!done.keep($code);
    };
    Nil;
}

method !handle-line(Str $line --> Nil) {
    return unless $line.trim.chars;
    my $parsed = try { from-json($line) };
    unless $parsed ~~ Hash && $parsed<type>.defined {
        $!lock.protect({
            @!events.push({ type => 'worker-log', line => $line });
        });
        return;
    }
    my %event = $parsed;
    $!lock.protect({
        @!events.push(%event);
        if %event<type> eq 'internal-finish' {
            %!result = %event<result> // %( status => 'failed', error => 'worker returned no result' );
            $!saw-result = True;
        }
        elsif %event<type> eq 'worker-error' {
            %!result = %(
                status => 'failed',
                error  => (%event<error> // 'worker failed').Str,
            );
            $!saw-result = True;
            @!events.push({ type => 'internal-finish', result => %!result });
        }
    });
}

method drain(--> List) {
    $!lock.protect({ my @out = @!events; @!events = (); @out.List });
}

method cancel(--> Nil) {
    my $proc = $!proc;
    return if $!finished || !$proc.defined;
    try { $proc.say("cancel") }
}

method kill(--> Nil) {
    return if $!finished || !$!proc.defined;
    try { $!proc.kill(9) }
}

method finished(--> Bool) { $!finished }
method result(--> Hash) { %!result }
method exit-code(--> Int) { $!exit-code }

method wait(--> Hash) {
    await $!done;
    %!result;
}
