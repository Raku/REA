unit module App::DuckETL;

our $VERSION = '0.6.0';
