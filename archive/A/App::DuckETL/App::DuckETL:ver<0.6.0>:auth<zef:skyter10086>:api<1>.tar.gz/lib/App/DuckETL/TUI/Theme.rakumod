#| Colours and text attributes for the TUI.
#|
#| Every helper here is pure: it wraps a string in SGR escapes and returns it,
#| so the renderer stays testable and nothing writes to the terminal.  Set
#| `NO_COLOR` (or `DUCKETL_MONO=1`) to get plain text for dumb terminals and
#| captured output.
unit module App::DuckETL::TUI::Theme;

my constant %PALETTE =
    accent  => (86, 204, 242),
    focus   => (86, 204, 242),
    title   => (166, 227, 255),
    text    => (226, 232, 240),
    dim     => (128, 140, 158),
    border  => (62, 72, 88),
    success => (104, 211, 145),
    warning => (235, 192, 110),
    error   => (238, 120, 120),
    sel-fg  => (12, 18, 28),
    sel-bg  => (86, 204, 242),
    sel-bg-dim => (40, 48, 62),
    ;

my constant $RESET = "\e[0m";

#| True when output should stay plain.
our sub mono(--> Bool) {
    %*ENV<NO_COLOR>:exists || (%*ENV<DUCKETL_MONO> // '') eq '1';
}

our sub fg(Str:D $role --> Str) {
    my ($r, $g, $b) = %PALETTE{$role} // %PALETTE<text>;
    "\e[38;2;{$r};{$g};{$b}m";
}

our sub bg(Str:D $role --> Str) {
    my ($r, $g, $b) = %PALETTE{$role} // %PALETTE<text>;
    "\e[48;2;{$r};{$g};{$b}m";
}

#| Paint $text with the foreground colour of $role.
our sub paint(Str:D $role, Str:D $text --> Str) is export {
    return $text if $text eq '' || mono();
    fg($role) ~ $text ~ $RESET;
}

#| Paint $text as one highlighted row (selection bar).
our sub paint-selected(Str:D $text --> Str) is export {
    return $text if mono();
    bg('sel-bg') ~ fg('sel-fg') ~ $text ~ $RESET;
}

#| Paint $text as the selected row of an unfocused pane.
our sub paint-muted-selected(Str:D $text --> Str) is export {
    return $text if mono();
    bg('sel-bg-dim') ~ fg('text') ~ $text ~ $RESET;
}

#| Role for a run/step status value.
our sub status-role(Str:D $status --> Str) is export {
    given $status.lc {
        when 'ok' | 'succeeded' | 'passed' { 'success' }
        when 'failed' | 'error'            { 'error' }
        when 'canceled' | 'cancelled'      { 'warning' }
        when 'running' | 'pending'         { 'accent' }
        default                            { 'text' }
    }
}
