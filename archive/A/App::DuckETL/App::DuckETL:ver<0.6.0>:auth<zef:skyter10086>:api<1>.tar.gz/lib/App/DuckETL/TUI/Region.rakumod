#| A rectangle of the alternate screen, borders included.
#|
#| The TUI draws its own frames (box drawing + colours) and uses Terminal::UI
#| only for the alternate screen and key input, so layout is expressed as
#| plain rectangles instead of Terminal::UI frames and panes.
unit class App::DuckETL::TUI::Region;

has Int $.top is required;
has Int $.left is required;
has Int $.width is required;
has Int $.height is required;
has Str $.title = '';

#| Width available inside the border.
method inner-width(--> Int) { $!width - 2 }

#| Height available inside the border.
method inner-height(--> Int) { $!height - 2 }

#| First screen row of the content area.
method first-row(--> Int) { $!top + 1 }

#| First screen column of the content area.
method first-col(--> Int) { $!left + 1 }
