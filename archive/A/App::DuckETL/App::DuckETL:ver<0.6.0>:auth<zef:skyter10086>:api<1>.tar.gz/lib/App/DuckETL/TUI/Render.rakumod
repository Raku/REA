unit module App::DuckETL::TUI::Render;

# Pure text rendering for the TUI.  Nothing here touches a terminal, a
# database or mutable state: functions take plain values and return strings or
# lists of strings.  That keeps layout (including CJK widths) testable without
# a PTY.

my %wide-cache;

#| Display width of one character: control characters count as 0, East Asian
#| wide characters as 2, everything else as 1.
our sub char-width(Str:D $c --> Int) is export {
    return 0 if $c.ord < 32;
    return 1 if $c.chars > 1;
    %wide-cache{$c} //= $c.uniprops('W').grep(* eq 'W').elems;
    %wide-cache{$c} ?? 2 !! 1;
}

#| Display width of a string.
our sub text-width(Str:D $s --> Int) is export {
    my $w = 0;
    $w += char-width($_) for $s.comb;
    $w;
}

#| Clip or pad a string to exactly $w display columns.
our sub fit(Str $s, Int $w --> Str) is export {
    return '' if $w <= 0;
    my $str = ($s // '').subst(/<[\r\n\t]>/, ' ', :g);
    my $out = '';
    my $used = 0;
    for $str.comb -> $c {
        my $cw = char-width($c);
        last if $used + $cw > $w;
        $out ~= $c;
        $used += $cw;
    }
    $out ~ (' ' x ($w - $used));
}

#| Clip or left-pad a string to exactly $w display columns.
our sub fit-right(Str $s, Int $w --> Str) is export {
    return '' if $w <= 0;
    my $str = ($s // '').subst(/<[\r\n\t]>/, ' ', :g);
    my $text = '';
    my $used = 0;
    for $str.comb -> $c {
        my $cw = char-width($c);
        last if $used + $cw > $w;
        $text ~= $c;
        $used += $cw;
    }
    (' ' x ($w - $used)) ~ $text;
}

#| Clip $s to at most $w display columns (no padding).
our sub clip(Str $s, Int $w --> Str) is export {
    return '' if $w <= 0;
    my $str = ($s // '').subst(/<[\r\n\t]>/, ' ', :g);
    my $out = '';
    my $used = 0;
    for $str.comb -> $c {
        my $cw = char-width($c);
        last if $used + $cw > $w;
        $out ~= $c;
        $used += $cw;
    }
    $out;
}

#| Clip $s to $w display columns, marking the cut with an ellipsis.  Pads
#| short strings, so the result is always exactly $w columns wide.
our sub elide(Str $s, Int $w --> Str) is export {
    return '' if $w <= 0;
    my $str = ($s // '').subst(/<[\r\n\t]>/, ' ', :g);
    return fit($str, $w) if text-width($str) <= $w;
    return '…' if $w == 1;
    my $out = '';
    my $used = 0;
    for $str.comb -> $c {
        my $cw = char-width($c);
        last if $used + $cw > $w - 1;
        $out ~= $c;
        $used += $cw;
    }
    $out ~ (' ' x ($w - 1 - $used)) ~ '…';
}

#| Column widths: at least $min cells each, shrunk from the widest column
#| until the total fits $budget.
my sub fit-widths(@natural, Int $budget, Int :$min = 3 --> List) {
    my @cols = @natural.map({ max($min, $_) });
    my Int $total = @cols.sum;
    while $total > $budget {
        my $widest = @cols.max;
        last if $widest <= $min;
        my $i = @cols.first($widest, :k);
        @cols[$i] = $widest - 1;
        $total--;
    }
    @cols;
}

#| A rows-of-cells table with a header, a rule and an optional selection
#| marker.  Columns are sized from their content, so ids and names are not cut
#| in half; a column never gets narrower than 3 columns.  `:widths` forces
#| explicit column widths.  `:height` limits the number of data rows and
#| `:offset` selects the first row.
our sub table-lines(
    @headers,
    @rows,
    Int :$width!,
    Int :$select = -1,
    Int :$offset = 0,
    Int :$height = 0,
    :@align,
    :@widths,
    --> List
) is export {
    my @heads = @headers.map({ $_.defined ?? $_.Str !! '' });
    my $n = @heads.elems;
    return () unless $n;

    my $marker = 2;
    my $cell-space = $width - $marker - ($n - 1);
    return (('─' x $width),) if $cell-space < $n;

    # Natural width per column: the widest header or cell.
    my @natural = (@widths.defined && @widths.elems == $n)
        ?? @widths.List
        !! (0 ..^ $n).map: -> $i {
            my $m = text-width(@heads[$i]);
            for @rows -> $row {
                my $v = $row.List[$i];
                $m = max($m, text-width($v.defined ?? $v.Str !! ''));
            }
            $m;
        };

    my @cols = fit-widths(@natural, $cell-space);
    if @cols.sum > $cell-space {
        # Too many columns for the width: go back to an even split.
        my $base = $cell-space div $n;
        @cols = $base xx $n;
        @cols[0] += $cell-space - $base * $n;
    }
    else {
        @cols[*-1] += $cell-space - @cols.sum;
    }

    my &cell = -> Int $i, $value {
        my $str = $value.defined ?? $value.Str !! '';
        (@align[$i].defined && @align[$i] eq 'right')
            ?? fit-right($str, @cols[$i])
            !! elide($str, @cols[$i]);
    };

    my @out;
    @out.push: '  ' ~ (0 ..^ $n).map({ cell($^i, @heads[$i]) }).join(' ');
    @out.push: '─' x $width;

    my @view = @rows.List;
    my $start = $offset max 0;
    my $stop = $height > 0 ?? min(@view.elems, $start + $height) !! @view.elems;
    my $i = $start;
    while $i < $stop {
        my @row = @view[$i].List;
        my $mark = $i == $select ?? '> ' !! '  ';
        my @cells;
        for 0 ..^ $n -> $c {
            @cells.push: cell($c, @row[$c]);
        }
        @out.push: $mark ~ @cells.join(' ');
        $i++;
    }
    @out.List;
}

#| A content-sized table for one-shot output: header, rule and rows, without
#| the selection column.  Columns keep their natural width; `:max-width`
#| shrinks them when the terminal is narrow.
our sub plain-table(@headers, @rows, Int :$max-width = 0, :@align --> List) is export {
    my @heads = @headers.map({ $_.defined ?? $_.Str !! '' });
    my $n = @heads.elems;
    return () unless $n;

    my @natural = (0 ..^ $n).map: -> $i {
        my $m = text-width(@heads[$i]);
        for @rows -> $row {
            my @cells = $row.List;
            my $v = @cells[$i];
            $m = max($m, text-width($v.defined ?? $v.Str !! ''));
        }
        $m;
    };
    my Int $budget = $max-width > 0 ?? max($n, $max-width - ($n - 1)) !! @natural.sum;
    my @cols = fit-widths(@natural, $budget, min => 1);

    my &cell = -> Int $i, $value {
        my $str = $value.defined ?? $value.Str !! '';
        (@align[$i].defined && @align[$i] eq 'right')
            ?? fit-right($str, @cols[$i])
            !! elide($str, @cols[$i]);
    };

    my @out;
    @out.push: (0 ..^ $n).map({ cell($^i, @heads[$i]) }).join(' ');
    @out.push: '─' x text-width(@out[0]);
    for @rows -> $row {
        my @cells = $row.List;
        @out.push: (0 ..^ $n).map({ cell($^i, @cells[$i]) }).join(' ');
    }
    @out.List;
}

#| Thousands separator: 1234567 -> "1,234,567".
our sub comma(Int $n --> Str) is export {
    my $neg = $n < 0;
    my $digits = $n.abs.Str;
    my $out = '';
    while $digits.chars > 3 {
        $out = ',' ~ $digits.substr(* - 3) ~ $out;
        $digits = $digits.substr(0, * - 3);
    }
    ($neg ?? '-' !! '') ~ $digits ~ $out;
}

#| Seconds as `HH:MM:SS`, or `MM:SS` below one hour.
our sub duration(Real $seconds --> Str) is export {
    my Int $total = ($seconds max 0).Int;
    my $h = $total div 3600;
    my $m = ($total % 3600) div 60;
    my $s = $total % 60;
    $h > 0
        ?? sprintf('%02d:%02d:%02d', $h, $m, $s)
        !! sprintf('%02d:%02d', $m, $s);
}

#| Rows per second, e.g. "12.3k/s".
our sub rate(Int $rows, Real $seconds --> Str) is export {
    return '-' if $seconds <= 0;
    my $r = $rows / $seconds;
    return comma($r.Int) ~ '/s' if $r < 10_000;
    return sprintf('%.1fk/s', $r / 1_000) if $r < 1_000_000;
    sprintf('%.1fM/s', $r / 1_000_000);
}

#| Status lines for the right-hand run panel.  Keys: pipeline, run_id,
#| status, elapsed, rows, rate, step, error.
our sub status-lines(%run, Int :$width! --> List) is export {
    my $label = 9;
    my $value = $width - $label - 1;
    my @out;
    my &line = -> Str $k, Str $v {
        @out.push: fit($k, $label) ~ ' ' ~ elide($v, $value);
    };
    line('pipeline', (%run<pipeline> // '-').Str);
    line('run', (%run<run_id> // '-').Str);
    line('status', (%run<status> // 'idle').Str);
    line('elapsed', duration(%run<elapsed> // 0));
    line('rows', comma((%run<rows> // 0).Int));
    line('rate', (%run<rate> // '-').Str);
    line('step', (%run<step> // '-').Str);
    if (%run<error> // '').chars {
        @out.push: '';
        @out.push: fit('error', $label);
        for (%run<error>.Str).lines -> $l {
            @out.push: fit($l, $width);
        }
    }
    @out.List;
}
