#| Tiny text charts for the TUI: sparklines, horizontal bars and range
#| labels.  Everything is pure and returns strings, so charts are testable
#| without a terminal and stay inside the panel width.
unit module App::DuckETL::TUI::Chart;

my constant @BLOCKS = <▁ ▂ ▃ ▄ ▅ ▆ ▇ █>;

#| Sparkline for a series: one block per value, scaled from min to max.
#| `:width` keeps only the newest values.
our sub sparkline(@values, Int :$width = 0 --> Str) is export {
    my @v = @values.map({ $_.Real });
    return '' unless @v;
    @v = @v.tail($width) if $width > 0 && @v.elems > $width;
    my $min = @v.min;
    my $max = @v.max;
    my $span = $max - $min;
    # A flat series still gets a readable mid-level line.
    return @BLOCKS[3] x @v.elems if $span == 0;
    @v.map({ @BLOCKS[(($^value - $min) / $span * 7).round.Int] }).join;
}

#| Horizontal bar: $value of $max scaled into $width cells.
our sub bar(Real $value, Real $max, Int $width --> Str) is export {
    return '' if $width <= 0;
    return '░' x $width if $max <= 0;
    my Real $ratio = $value / $max;
    $ratio = 0 if $ratio < 0;
    $ratio = 1 if $ratio > 1;
    my Int $fill = ($ratio * $width).round.Int;
    $fill = 1 if $value > 0 && $fill == 0;
    $fill = $width if $fill > $width;
    ('█' x $fill) ~ ('░' x ($width - $fill));
}

#| "min–max" label for a series, in plain integers with separators.
our sub range-label(@values --> Str) is export {
    return '-' unless @values;
    my @v = @values.map({ $_.Real.Int });
    my $lo = @v.min;
    my $hi = @v.max;
    $lo == $hi ?? comma($lo) !! comma($lo) ~ '–' ~ comma($hi);
}

#| Thousands separator: 1234567 -> "1,234,567".
my sub comma(Int $n --> Str) {
    my $neg = $n < 0;
    my $digits = $n.abs.Str;
    my $out = '';
    while $digits.chars > 3 {
        $out = ',' ~ $digits.substr(* - 3) ~ $out;
        $digits = $digits.substr(0, * - 3);
    }
    ($neg ?? '-' !! '') ~ $digits ~ $out;
}

#| Seconds as a compact duration: 0.032s, 1.4s, 2m03s.
our sub seconds(Real $value --> Str) is export {
    return '-' if $value < 0;
    return sprintf('%.3fs', $value) if $value < 1;
    return sprintf('%.1fs', $value) if $value < 60;
    my Int $total = $value.Int;
    sprintf('%dm%02ds', $total div 60, $total % 60);
}
