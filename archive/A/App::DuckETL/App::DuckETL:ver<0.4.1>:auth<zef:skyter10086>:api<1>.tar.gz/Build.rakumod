use v6.d;

# No compilation step is required for this distribution.  The hook exists so
# `zef build` reports success instead of treating an empty build result as a
# failure.
class Build {
    method build($dist --> Bool:D) { True }
}
