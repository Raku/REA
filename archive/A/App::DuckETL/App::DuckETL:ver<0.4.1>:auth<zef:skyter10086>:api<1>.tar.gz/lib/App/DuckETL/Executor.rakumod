use App::DuckETL::Pipeline;
use App::DuckETL::Planner;
use App::DuckETL::Duck;
use App::DuckETL::Store;
use App::DuckETL::SQL;
use DB::DuckDB::Native;

unit class App::DuckETL::Executor;

has App::DuckETL::Pipeline $.pipeline is required;
has App::DuckETL::Duck $.duck is required;
has App::DuckETL::Store $.store is required;
has Str $.run-id;
has Bool $.keep-temp = False;
has &.event;

has DB::DuckDB::Connection $!job-conn;
has Bool $!cancel-requested = False;

#| Ask the running job to stop.  DuckDB executes the query on the job
#| connection; `duckdb_interrupt` makes it fail within milliseconds.  Safe to
#| call from another thread, and before the first step has started.
method cancel(--> Nil) {
    return if $!cancel-requested;
    $!cancel-requested = True;
    my $conn = $!job-conn;
    return unless $conn.defined;
    try { duckdb-interrupt($conn.handle) }
}

method canceled(--> Bool) { $!cancel-requested }

method run(--> Hash) {
    my $run-id = $!run-id // self!new-run-id;
    my $started-at = DateTime.now.Str;
    my $run-start = now;
    my $planner = App::DuckETL::Planner.new(pipeline => $!pipeline);
    my $conn = $!duck.connection;
    $!job-conn = $conn;
    my @steps = $!pipeline.steps.List;
    my @temps;       # { name, kind }
    my @renames;     # { temp, target, dir? }
    my @watermarks;  # { step-id, column, quoted }
    my @results;
    my $total-rows = 0;
    my $last-rows = 0;
    my $error;

    $!store.start-run($run-id, $!pipeline.name, @steps, $started-at);
    self!emit({
        type => 'run-start', run_id => $run-id, pipeline => $!pipeline.name,
        steps => @steps.elems, started_at => $started-at,
    });

    my $in-tx = False;
    {
        for $!pipeline.extensions -> $extension {
            $conn.execute('load ' ~ $extension);
        }
        $conn.execute('begin');
        $in-tx = True;

        for @steps.kv -> $i, $step {
            if $!cancel-requested {
                $error = 'canceled by user';
                last;
            }
            my $step-start = now;
            my $step-started-at = DateTime.now.Str;
            $!store.start-step($run-id, $step.id, $step-started-at);
            self!emit({
                type => 'step-start', run_id => $run-id, step_id => $step.id,
                step_type => $step.type, index => $i + 1, total => @steps.elems,
            });

            my %plan;
            my $rows = 0;
            my $step-sql = '';
            my $step-error;
            {
                $planner.watermark-value =
                    $step.type eq 'sink' && ($step.watermark // '').chars
                        ?? $!store.watermark($!pipeline.name, $step.id, $step.watermark)
                        !! '';
                %plan = $planner.plan-step($step);
                $step-sql = %plan<sql> // '';

                given %plan<kind> {
                    when 'query' {
                        $conn.execute(%plan<sql>, |(%plan<args> // ()));
                        $rows = $conn.query(%plan<rows-sql>).value.Int;
                        @temps.push({
                            name => %plan<table>,
                            kind => %plan<materialize> ?? 'table' !! 'view',
                        });
                        $last-rows = $rows;
                    }
                    when 'assert' {
                        my $res = $conn.query(%plan<sql>);
                        my $row = $res.row;
                        $res.free;
                        die "assert '{$step.id}' returned no rows"
                            unless $row.defined && $row.elems;
                        my $actual = $row[0];
                        die self!assert-message($step, $actual)
                            unless self!compare($actual, %plan<expect>, %plan<op>);
                        $rows = 1;
                    }
                    when 'table-sink' {
                        $conn.execute('create schema if not exists ' ~ quote-ident(%plan<schema>));
                        given %plan<mode> {
                            when 'replace' {
                                $step-sql = $planner.create-as-sql(%plan<quoted>, %plan<source>);
                            }
                            when 'append' {
                                if $!duck.table-exists(%plan<target>) {
                                    $step-sql = $planner.append-sql(%plan<quoted>, %plan<source>);
                                }
                                else {
                                    $step-sql = $planner.create-as-sql(%plan<quoted>, %plan<source>);
                                }
                            }
                            when 'upsert' {
                                unless $!duck.table-exists(%plan<target>) {
                                    $conn.execute(
                                        $planner.upsert-create-sql(
                                            %plan<quoted>, %plan<source>,
                                        ),
                                        |(%plan<args> // ()),
                                    );
                                }
                                my @columns = $!duck.table-columns(%plan<target>);
                                die "target '{%plan<target>}' has no columns"
                                    unless @columns.elems;
                                my %column-set = @columns.map({ $_.lc => True });
                                my @missing = %plan<key>.grep({ !%column-set{$_.lc} });
                                die "upsert key column(s) not found in target: {@missing.join(', ')}"
                                    if @missing;
                                my $index = quote-ident(
                                    '_ducketl_' ~ %plan<table> ~ '_'
                                    ~ %plan<key>.join('_') ~ '_uidx',
                                );
                                $conn.execute(
                                    'create unique index if not exists ' ~ $index
                                    ~ ' on ' ~ %plan<quoted>
                                    ~ ' (' ~ %plan<key>.map({ quote-ident($_) }).join(', ') ~ ')',
                                );
                                $step-sql = $planner.upsert-sql(
                                    %plan<quoted>, %plan<key>, @columns, %plan<source>,
                                );
                            }
                        }
                        $conn.execute($step-sql, |(%plan<args> // ()));
                        $rows = $conn.query(%plan<rows-sql>, |(%plan<args> // ())).value.Int;
                        $total-rows += $rows;
                        $last-rows = $rows;
                        if ($step.watermark // '').chars {
                            @watermarks.push({
                                step-id => $step.id,
                                column  => $step.watermark,
                                quoted  => %plan<quoted>,
                            });
                        }
                    }
                    when 'partition-sink' {
                        my $parent = %plan<target>.IO.parent;
                        $parent.mkdir unless $parent.e;
                        $conn.execute(%plan<sql>);
                        @renames.push({
                            temp => %plan<temp>, target => %plan<target>, dir => True,
                        });
                        $rows = $conn.query(%plan<rows-sql>).value.Int;
                        $total-rows += $rows;
                        $last-rows = $rows;
                    }
                    when 'file-sink' {
                        my $parent = %plan<target>.IO.parent;
                        $parent.mkdir unless $parent.e;
                        $conn.execute(%plan<sql>);
                        @renames.push({ temp => %plan<temp>, target => %plan<target> });
                        $rows = $conn.query(%plan<rows-sql>).value.Int;
                        $total-rows += $rows;
                        $last-rows = $rows;
                    }
                    default {
                        die "unknown plan kind '{%plan<kind>}'";
                    }
                }
                CATCH {
                    default {
                        $step-error = $_;
                    }
                }
            }

            my $duration = ((now - $step-start) * 1000).Int;
            if $step-error.defined {
                my $canceled = $!cancel-requested;
                my $msg = $canceled ?? 'canceled by user' !! self!error-text($step-error);
                my $status = $canceled ?? 'canceled' !! 'failed';
                $!store.finish-step(
                    $run-id, $step.id, $status, DateTime.now.Str,
                    $rows, :sql($step-sql), :error($msg),
                );
                @results.push({
                    id => $step.id, type => $step.type, status => $status,
                    rows => $rows, duration_ms => $duration, error => $msg,
                });
                self!emit({
                    type => 'step-finish', run_id => $run-id, step_id => $step.id,
                    step_type => $step.type, status => $status, rows => $rows,
                    duration_ms => $duration, error => $msg,
                });
                $error = $step-error;
                last;
            }

            $!store.finish-step(
                $run-id, $step.id, 'ok', DateTime.now.Str,
                $rows, :sql($step-sql),
            );
            @results.push({
                id => $step.id, type => $step.type, status => 'ok',
                rows => $rows, duration_ms => $duration,
            });
            self!emit({
                type => 'step-finish', run_id => $run-id, step_id => $step.id,
                step_type => $step.type, status => 'ok', rows => $rows,
                duration_ms => $duration,
            });
        }

        if !$error.defined && $!cancel-requested {
            $error = 'canceled by user';
        }
        if !$error.defined {
            $conn.execute('commit');
            $in-tx = False;
        }
        CATCH {
            default {
                $error = $_;
            }
        }
    }

    if $error.defined {
        if $in-tx { try $conn.execute('rollback') }
        self!delete-temp-files(@renames) unless $!keep-temp;
    }
    else {
        for @renames -> %rename {
            {
                if %rename<dir> {
                    self!install-directory(%rename<temp>, %rename<target>);
                }
                else {
                    rename(%rename<temp>, %rename<target>);
                }
                CATCH {
                    default {
                        $error = $_;
                    }
                }
            }
            last if $error.defined;
        }
        if $error.defined {
            self!delete-temp-files(@renames);
        }
        else {
            # Watermarks advance only after the data commit (and file install)
            # succeeded, so a failed run is retried instead of skipped.
            for @watermarks -> %watermark {
                {
                    my $value = $conn.query(
                        'select cast(max(' ~ quote-ident(%watermark<column>)
                        ~ ') as varchar) from ' ~ %watermark<quoted>,
                    ).value;
                    if $value.defined && $value.Str.chars {
                        $!store.set-watermark(
                            $!pipeline.name, %watermark<step-id>,
                            %watermark<column>, $value.Str, DateTime.now.Str,
                        );
                    }
                }
                CATCH {
                    default {
                        $error = $_;
                    }
                }
                last if $error.defined;
            }
        }
    }

    unless $!keep-temp {
        for @temps.reverse -> %temp {
            try $conn.execute(
                'drop ' ~ (%temp<kind> eq 'view' ?? 'view' !! 'table')
                ~ ' if exists ' ~ %temp<name>,
            );
        }
    }

    my $duration = ((now - $run-start) * 1000).Int;
    my $canceled = $!cancel-requested && ($error.defined || $in-tx);
    my $status = $canceled ?? 'canceled' !! ($error.defined ?? 'failed' !! 'ok');
    my $message = $canceled ?? 'canceled by user'
        !! ($error.defined ?? self!error-text($error) !! '');
    my $rows-total = $total-rows || $last-rows;

    $!store.finish-run($run-id, $status, DateTime.now.Str, $rows-total, :error($message));
    self!emit({
        type => 'run-finish', run_id => $run-id, pipeline => $!pipeline.name,
        status => $status, rows => $rows-total, duration_ms => $duration,
        error => $message,
    });

    {
        run_id => $run-id,
        pipeline => $!pipeline.name,
        status => $status,
        rows => $rows-total,
        duration_ms => $duration,
        error => $message,
        steps => @results.List,
    };
}

method !new-run-id(--> Str) {
    my $now = DateTime.now;
    my $stamp = sprintf(
        '%04d%02d%02d-%02d%02d%02d',
        $now.year, $now.month, $now.day, $now.hour, $now.minute, $now.second,
    );
    $stamp ~ '-' ~ (^100000).pick.fmt('%05d');
}

method !compare($actual, $expected, Str:D $op --> Bool) {
    return $expected.defined ?? False !! True unless $actual.defined;
    return False unless $expected.defined;

    if $actual ~~ Bool && $expected ~~ Bool {
        return $op eq 'eq' ?? $actual == $expected
            !! $op eq 'ne' ?? $actual != $expected
            !! False;
    }

    if $actual ~~ Numeric && $expected ~~ Numeric {
        given $op {
            when 'eq'  { $actual == $expected }
            when 'ne'  { $actual != $expected }
            when 'lt'  { $actual <  $expected }
            when 'lte' { $actual <= $expected }
            when 'gt'  { $actual >  $expected }
            when 'gte' { $actual >= $expected }
            default    { False }
        }
    }
    else {
        my $a = $actual.Str;
        my $e = $expected.Str;
        given $op {
            when 'eq'  { $a eq $e }
            when 'ne'  { $a ne $e }
            when 'lt'  { $a lt $e }
            when 'lte' { $a le $e }
            when 'gt'  { $a gt $e }
            when 'gte' { $a ge $e }
            default    { False }
        }
    }
}

method !assert-message(App::DuckETL::Pipeline::Step $step, $actual --> Str) {
    my $got = $actual.defined ?? $actual.raku !! 'NULL';
    "assert '{$step.id}' failed: expected {$step.op} {$step.expect.raku}, got {$got}";
}

method !delete-temp-files(@renames --> Nil) {
    for @renames -> %rename {
        my $temp = %rename<temp>.IO;
        if $temp.d {
            try $temp.rmtree;
        }
        elsif $temp.e {
            $temp.unlink;
        }
    }
}

method !install-directory(Str $temp, Str $target --> Nil) {
    my $target-path = $target.IO;
    my Str $backup = $target ~ '.old-' ~ $*PID ~ '-' ~ (^1000000).pick;
    my Bool $had = $target-path.e;
    $target-path.rename($backup) if $had;

    my Bool $installed = False;
    try {
        $temp.IO.rename($target);
        $installed = True;
    }
    unless $installed {
        if $had && !$target-path.e {
            try { $backup.IO.rename($target) }
        }
        die "cannot install partition directory {$target}";
    }
    try { $backup.IO.rmtree } if $had && $backup.IO.e;
}

method !error-text($e --> Str) {
    my $msg = try { $e.message };
    $msg = $e.Str unless $msg.defined && $msg.chars;
    $msg;
}

method !emit(Hash $event --> Nil) {
    return unless &!event;
    try { &!event($event) };
}
