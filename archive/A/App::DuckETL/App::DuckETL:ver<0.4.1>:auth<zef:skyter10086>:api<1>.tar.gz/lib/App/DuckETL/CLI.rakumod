use JSON::Fast;
use App::DuckETL;
use App::DuckETL::Config;
use App::DuckETL::Pipeline;
use App::DuckETL::Duck;
use App::DuckETL::Store;
use App::DuckETL::Executor;

unit module App::DuckETL::CLI;

our sub main(@args --> Int) {
    my %parsed = parse-args(@args);
    my @pos = |%parsed<positional>;
    my %opt = %parsed<options>;
    my $command = @pos.shift // '';

    return 0 if %opt<help>;

    given $command {
        when '' { say usage(); return 0 }
        when 'run'      { return cmd-run(@pos, %opt) }
        when 'worker'   { return cmd-worker(@pos, %opt) }
        when 'tui'      { return cmd-tui(@pos, %opt) }
        when 'extensions' { return cmd-extensions(@pos, %opt) }
        when 'validate' { return cmd-validate(@pos, %opt) }
        when 'list'     { return cmd-list(@pos, %opt) }
        when 'show'     { return cmd-show(@pos, %opt) }
        when 'version'  { say 'ducketl ' ~ $App::DuckETL::VERSION; return 0 }
        when 'help'     { say usage(); return 0 }
        default {
            err "unknown command '{$command}'";
            err usage();
            return 2;
        }
    }
    CATCH {
        default {
            err .message;
            return 1;
        }
    }
}

sub usage(--> Str) {
    q:to/USAGE/;
    ducketl — SQL-first ETL on DuckDB

    Usage:
      ducketl run <pipeline.json> [options]
      ducketl tui [pipeline.json] [options]
      ducketl worker <pipeline.json> [options]   # JSONL events on stdout, "cancel" on stdin
      ducketl extensions [--json]
      ducketl validate <pipeline.json>
      ducketl list [--history PATH] [--limit N] [--json]
      ducketl show <run-id> [--history PATH] [--json]
      ducketl version
      ducketl help

    Run options:
      --db PATH             data database (default: pipeline database or :memory:)
      --history PATH        run-history database
      --threads N           DuckDB threads
      --memory-limit SIZE   e.g. 2GB
      --keep-temp           keep temp tables/views and staged files for debugging
      --json                print the run result as JSON
      --quiet               suppress per-step progress

    TUI:
      ducketl tui [pipeline.json] [--db PATH] [--history PATH]
                                  [--threads N] [--memory-limit SIZE] [--isolated]
    --isolated runs the pipeline in a worker process that owns the database;
    catalog and preview are disabled while it runs.
    Keys: 1/2/3 screens, Tab focus, j/k move, Enter open, r run,
          c cancel, p preview, [ ] switch pipeline, R reload, q quit.
    USAGE
}

sub resolve-runtime(%opt, $pipeline --> Hash) {
    my $config = App::DuckETL::Config.load;

    my $db-path;
    if %opt<db>.defined {
        $db-path = option-value(%opt<db>, '--db');
    }
    elsif %opt<database>.defined {
        $db-path = option-value(%opt<database>, '--database');
    }
    elsif $pipeline.database.defined && $pipeline.database.chars {
        $db-path = $pipeline.resolve-path($pipeline.database);
    }
    else {
        $db-path = $config.database.defined && $config.database.chars
            ?? $config.expand-path($config.database)
            !! ':memory:';
    }
    $db-path = $config.expand-path($db-path) unless $db-path eq ':memory:';

    my $history = %opt<history>.defined
        ?? $config.expand-path(option-value(%opt<history>, '--history'))
        !! $config.history-path;
    $history = $config.expand-path($history) unless $history eq ':memory:';

    if $db-path ne ':memory:' && $history ne ':memory:'
        && $db-path.IO.absolute eq $history.IO.absolute {
        die 'the data database and the history database must be different files';
    }

    my $threads = %opt<threads>.defined
        ?? option-value(%opt<threads>, '--threads').Int
        !! ($pipeline.defaults<threads>.defined ?? $pipeline.defaults<threads>.Int !! $config.threads);
    my $memory = %opt<memory-limit>.defined
        ?? option-value(%opt<memory-limit>, '--memory-limit')
        !! ($pipeline.defaults<memory_limit>.defined ?? $pipeline.defaults<memory_limit>.Str !! $config.memory-limit);

    %( database => $db-path, history => $history,
       threads => $threads, memory => $memory );
}

sub cmd-run(@pos, %opt --> Int) {
    check-options(%opt, 'run', <db database history threads memory-limit keep-temp json quiet help>);
    err usage() unless @pos.elems;
    my $pipeline-path = @pos[0];

    my $pipeline = App::DuckETL::Pipeline.load($pipeline-path);
    my %runtime = resolve-runtime(%opt, $pipeline);
    my $db-path = %runtime<database>;
    my $history = %runtime<history>;
    my $threads = %runtime<threads>;
    my $memory = %runtime<memory>;

    my $duck;
    my $store;
    LEAVE {
        $store.close if $store.defined;
        $duck.close if $duck.defined;
    }

    my %db-opts = path => $db-path;
    %db-opts<threads> = $threads if $threads.defined;
    %db-opts<memory-limit> = $memory if $memory.defined && $memory.chars;
    $duck = App::DuckETL::Duck.new(|%db-opts);
    $store = App::DuckETL::Store.new(path => $history);

    my $quiet = so %opt<quiet>;
    my &event = -> %e {
        unless $quiet {
            given %e<type> {
                when 'step-start' {
                    $*ERR.say("  [{ %e<index> }/{ %e<total> }] { %e<step_id> } ({ %e<step_type> }) ...");
                }
                when 'step-finish' {
                    my $tail = %e<status> eq 'ok'
                        ?? "{ %e<rows> } rows, { fmt-ms(%e<duration_ms>) }"
                        !! "FAILED: { %e<error> }";
                    $*ERR.say("      { %e<status> } — {$tail}");
                }
            }
        }
    };

    my %result = App::DuckETL::Executor.new(
        pipeline  => $pipeline,
        duck      => $duck,
        store     => $store,
        keep-temp => so %opt<keep-temp>,
        event     => &event,
    ).run;

    if %opt<json> {
        say to-json(%result, :pretty);
    }
    elsif %result<status> eq 'ok' {
        say "ok {%result<pipeline>} — {%result<rows>} rows in {fmt-ms(%result<duration_ms>)} (run {%result<run_id>})";
    }
    else {
        err "failed {%result<pipeline>}: {%result<error>}";
    }

    %result<status> eq 'ok' ?? 0 !! 1;
}

sub cmd-tui(@pos, %opt --> Int) {
    check-options(%opt, 'tui', <db database history threads memory-limit isolated help>);
    die 'tui takes at most one pipeline argument' if @pos.elems > 1;
    die 'ducketl tui requires an interactive terminal' unless $*IN.t;

    my $config = App::DuckETL::Config.load;

    my $database;
    if %opt<db>.defined {
        $database = $config.expand-path(option-value(%opt<db>, '--db'));
    }
    elsif %opt<database>.defined {
        $database = $config.expand-path(option-value(%opt<database>, '--database'));
    }

    my $history = %opt<history>.defined
        ?? $config.expand-path(option-value(%opt<history>, '--history'))
        !! $config.expand-path($config.history-path);
    $history = ':memory:' if $history eq ':memory:';

    if $database.defined && $database ne ':memory:' && $history ne ':memory:'
        && $database.IO.absolute eq $history.IO.absolute {
        die 'the data database and the history database must be different files';
    }

    my $threads = %opt<threads>.defined
        ?? option-value(%opt<threads>, '--threads').Int
        !! $config.threads;
    my $memory = %opt<memory-limit>.defined
        ?? option-value(%opt<memory-limit>, '--memory-limit')
        !! $config.memory-limit;

    my %args =
        config         => $config,
        base-dir       => $*CWD.Str,
        history        => $history,
        start-pipeline => @pos.elems ?? @pos[0].Str !! Str,
    ;
    %args<database> = $database if $database.defined;
    %args<threads> = $threads if $threads.defined;
    %args<memory-limit> = $memory if $memory.defined;
    %args<isolated> = so %opt<isolated>;

    # `Terminal::UI` is only needed by this command; keep the other commands
    # working when the TUI is not installed.
    require App::DuckETL::TUI;
    ::('App::DuckETL::TUI').new(|%args).run;
    0;
}

sub cmd-worker(@pos, %opt --> Int) {
    check-options(%opt, 'worker', <db database history threads memory-limit keep-temp help>);
    err usage() unless @pos.elems;

    my $out = $*OUT;
    my &emit = -> %event {
        try {
            $out.put(to-json(%event, :!pretty));
            $out.flush;
        }
    };

    my $pipeline;
    my %runtime;
    my $error;
    {
        $pipeline = App::DuckETL::Pipeline.load(@pos[0]);
        %runtime = resolve-runtime(%opt, $pipeline);
        CATCH {
            default {
                $error = .message;
            }
        }
    }
    if $error.defined {
        emit(%( type => 'worker-error', error => $error ));
        $*ERR.say($error);
        return 1;
    }

    my $duck;
    my $store;
    my $executor;
    my %result;
    {
        my %db-opts = path => %runtime<database>;
        %db-opts<threads> = %runtime<threads> if %runtime<threads>.defined;
        %db-opts<memory-limit> = %runtime<memory>
            if %runtime<memory>.defined && %runtime<memory>.chars;
        $duck = App::DuckETL::Duck.new(|%db-opts);
        $store = App::DuckETL::Store.new(path => %runtime<history>);
        $executor = App::DuckETL::Executor.new(
            pipeline  => $pipeline,
            duck      => $duck,
            store     => $store,
            keep-temp => so %opt<keep-temp>,
            event     => &emit,
        );
        start {
            for $*IN.lines -> $line {
                $executor.cancel if $line.trim eq 'cancel';
            }
        }
        %result = $executor.run;
        CATCH {
            default {
                $error = .message;
            }
        }
    }

    # Release both database files before telling the UI the run is finished:
    # the UI reopens history as soon as it sees this event.
    try { $store.close } if $store.defined;
    try { $duck.close } if $duck.defined;

    if $error.defined {
        emit(%( type => 'worker-error', error => $error ));
        $*ERR.say($error);
        return 1;
    }
    emit(%( type => 'internal-finish', result => %result ));
    %result<status> eq 'ok' ?? 0 !! 1;
}

sub cmd-extensions(@pos, %opt --> Int) {
    check-options(%opt, 'extensions', <json help>);
    die 'extensions does not take positional arguments' if @pos.elems;

    my $duck = App::DuckETL::Duck.new;
    LEAVE { try $duck.close }
    my @rows = $duck.session.query(
        'select extension_name, loaded, installed, install_mode, description'
        ~ ' from duckdb_extensions() order by extension_name',
    ).hashes.List;

    if %opt<json> {
        say to-json(@rows.List, :pretty);
        return 0;
    }

    say sprintf('%-22s %-8s %-10s %-10s %s',
        'EXTENSION', 'LOADED', 'INSTALLED', 'MODE', 'DESCRIPTION');
    for @rows -> %row {
        say sprintf('%-22s %-8s %-10s %-10s %s',
            %row<extension_name> // '',
            (%row<loaded> ?? 'yes' !! 'no'),
            (%row<installed> ?? 'yes' !! 'no'),
            %row<install_mode> // '-',
            %row<description> // '',
        );
    }
    0;
}

sub cmd-validate(@pos, %opt --> Int) {
    check-options(%opt, 'validate', ('help',));
    err usage() unless @pos.elems;
    my $pipeline = App::DuckETL::Pipeline.load(@pos[0]);
    say "ok: {$pipeline.name} ({$pipeline.steps.elems} steps)";
    0;
}

sub cmd-list(@pos, %opt --> Int) {
    check-options(%opt, 'list', <history limit json help>);
    die 'list does not take positional arguments' if @pos.elems;

    my $config = App::DuckETL::Config.load;
    my $history = %opt<history>.defined
        ?? $config.expand-path(option-value(%opt<history>, '--history'))
        !! $config.history-path;
    my $limit = %opt<limit>.defined
        ?? option-value(%opt<limit>, '--limit').Int
        !! 20;
    die '--limit must be positive' unless $limit > 0;

    my $store = App::DuckETL::Store.new(path => $history);
    LEAVE { $store.close }
    my @runs = $store.recent-runs($limit);

    if %opt<json> {
        say to-json(@runs.List, :pretty);
        return 0;
    }

    if !@runs.elems {
        say 'no runs';
        return 0;
    }

    say sprintf('%-30s %-22s %-9s %12s  %-19s', 'RUN', 'PIPELINE', 'STATUS', 'ROWS', 'STARTED');
    for @runs -> %run {
        say sprintf(
            '%-30s %-22s %-9s %12s  %-19s',
            truncate(%run<run_id>, 30),
            truncate(%run<pipeline>, 22),
            %run<status>,
            %run<rows> // 0,
            short-time(%run<started_at>),
        );
    }
    0;
}

sub cmd-show(@pos, %opt --> Int) {
    check-options(%opt, 'show', <history json help>);
    err usage() unless @pos.elems;

    my $config = App::DuckETL::Config.load;
    my $history = %opt<history>.defined
        ?? $config.expand-path(option-value(%opt<history>, '--history'))
        !! $config.history-path;

    my $store = App::DuckETL::Store.new(path => $history);
    LEAVE { $store.close }
    my %detail = $store.run-detail(@pos[0]);
    die "run '{@pos[0]}' not found" unless %detail.elems;

    if %opt<json> {
        say to-json(%detail, :pretty);
        return 0;
    }

    my %run = %detail<run>;
    say "run      {%run<run_id>}";
    say "pipeline {%run<pipeline>}";
    say "status   {%run<status>}";
    say "rows     {%run<rows> // 0}";
    say "started  {%run<started_at>}";
    say "finished {%run<finished_at> // '-'}";
    say "error    {%run<error> // '-'}" if %run<error>.defined && %run<error>.chars;
    say '';
    say sprintf('%-16s %-8s %-9s %10s  %-19s', 'STEP', 'TYPE', 'STATUS', 'ROWS', 'FINISHED');
    for %detail<steps>.List -> %step {
        say sprintf(
            '%-16s %-8s %-9s %10s  %-19s',
            truncate(%step<step_id>, 16),
            %step<step_type>,
            %step<status>,
            %step<rows> // 0,
            short-time(%step<finished_at>),
        );
        if %step<error>.defined && %step<error>.chars {
            say "    error: {%step<error>}";
        }
    }
    0;
}

sub parse-args(@args --> Hash) {
    my @pos;
    my %opt;
    my @rest = @args.List;

    while @rest.elems {
        my $arg = @rest.shift;
        if $arg eq '--' {
            @pos.append: @rest;
            last;
        }
        if $arg ~~ /^ '--' (<-[=]>+) '=' (.*) $/ {
            %opt{~$0} = ~$1;
            next;
        }
        if $arg ~~ /^ '--' (.+) $/ {
            my $name = ~$0;
            if @rest.elems && @rest[0] !~~ /^ '-'/ {
                %opt{$name} = @rest.shift;
            }
            else {
                %opt{$name} = True;
            }
            next;
        }
        if $arg ~~ /^ '-' (<[A..Z a..z]>) $/ {
            %opt{~$0} = True;
            next;
        }
        @pos.push($arg);
    }

    { positional => @pos.List, options => %opt };
}

sub check-options(%opt, Str $command, @allowed --> Nil) {
    my %allowed = @allowed.map({ $_ => True });
    for %opt.keys -> $name {
        next if %allowed{$name};
        die "unknown option --{$name} for '{$command}'";
    }
}

sub option-value($value, Str $name --> Str) {
    die "{$name} needs a value" if $value ~~ Bool;
    $value.Str;
}

sub fmt-ms(Int $ms --> Str) {
    return "{$ms}ms" if $ms < 1000;
    sprintf('%.2fs', $ms / 1000);
}

sub short-time($value --> Str) {
    return '-' unless $value.defined;
    my $s = $value.Str;
    $s.chars > 19 ?? $s.substr(0, 19) !! $s;
}

sub truncate($value, Int $width --> Str) {
    my $s = ($value // '').Str;
    $s.chars > $width ?? $s.substr(0, $width - 1) ~ '…' !! $s;
}

sub err(Str $message --> Nil) {
    $*ERR.say($message);
}
