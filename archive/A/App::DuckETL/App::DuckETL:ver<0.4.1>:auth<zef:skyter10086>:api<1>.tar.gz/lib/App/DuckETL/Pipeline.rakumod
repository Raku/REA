use JSON::Fast;
use App::DuckETL::SQL;
use App::DuckETL::X::Pipeline;

unit class App::DuckETL::Pipeline;

class Step {
    has Str $.id;
    has Str $.type;
    has Str $.format;
    has $.path;
    has Str $.table;
    has %.options;
    has Str $.sql;
    has $.expect;
    has Str $.op = 'eq';
    has Str $.target;
    has Str $.mode = 'replace';
    has @.key;
    has Str $.watermark;
    has @.partition_by;
    has Str $.description;
    has Bool $.materialize = True;

    method from-hash(%h, Str :$where --> Step) {
        my %allowed = <
            id type format path table options sql expect op target mode key
            watermark partition_by description materialize
        >.Set;
        my @unknown = %h.keys.grep({ !%allowed{$_} });
        die App::DuckETL::X::Pipeline.new(
            message => "unknown field(s) in {$where}: {@unknown.sort.join(', ')}",
        ) if @unknown;

        my $materialize = %h<materialize>:exists ?? %h<materialize> !! True;
        die App::DuckETL::X::Pipeline.new(
            message => "{$where}.materialize must be a boolean",
        ) unless $materialize ~~ Bool;
        my $key = %h<key>.defined ?? %h<key> !! [];
        my $options = %h<options>.defined ?? %h<options> !! {};
        my $partition = %h<partition_by>.defined ?? %h<partition_by> !! [];
        die App::DuckETL::X::Pipeline.new(
            message => "{$where}.partition_by must be a non-empty array",
        ) if %h<partition_by>:exists && !($partition ~~ Positional && $partition.elems);

        self.new(
            id          => (%h<id> // '').Str,
            type        => (%h<type> // '').Str,
            format      => %h<format>.defined ?? %h<format>.Str !! Str,
            path        => %h<path>,
            table       => %h<table>.defined ?? %h<table>.Str !! Str,
            options     => $options,
            sql         => %h<sql>.defined ?? %h<sql>.Str !! Str,
            expect      => %h<expect>,
            op          => (%h<op> // 'eq').Str,
            target      => %h<target>.defined ?? %h<target>.Str !! Str,
            mode        => (%h<mode> // 'replace').Str,
            key         => $key.list,
            watermark   => %h<watermark>.defined ?? %h<watermark>.Str !! Str,
            partition_by => $partition.list,
            description => %h<description>.defined ?? %h<description>.Str !! Str,
            materialize => $materialize,
        );
    }
}

has Str $.name;
has Str $.description;
has Str $.database;
has %.defaults;
has @.steps;
has @.extensions;
has Str $.path;
has Str $.base-dir;

method load($path --> App::DuckETL::Pipeline) {
    my $file = $path.IO;
    die App::DuckETL::X::Pipeline.new(message => "pipeline file not found: {$path}")
        unless $file.f;

    my $data;
    {
        $data = from-json($file.slurp);
        CATCH {
            default {
                die App::DuckETL::X::Pipeline.new(
                    message => "invalid JSON in {$path}: {.message}",
                );
            }
        }
    }
    self.from-data(
        $data,
        path     => $file.absolute,
        base-dir => $file.parent.absolute,
    );
}

#| Build and validate a pipeline from already-decoded JSON data.  Used by the
#| TUI to run an unsaved draft; `load` is the file-backed wrapper.
method from-data($data, Str :$path = '<draft>', Str :$base-dir = '.' --> App::DuckETL::Pipeline) {
    die App::DuckETL::X::Pipeline.new(message => "pipeline root must be an object: {$path}")
        unless $data ~~ Hash;

    my $name = ($data<name> // $path.IO.basename.subst(/\.json$/, '')).Str;
    my %defaults = $data<defaults>.defined ?? $data<defaults> !! {};
    my $raw-extensions = $data<extensions> // [];
    die App::DuckETL::X::Pipeline.new(
        message => "pipeline '{$name}': extensions must be an array",
    ) unless $raw-extensions ~~ Positional;
    my @extensions = $raw-extensions.map({ $_.Str });

    my @steps;
    my $raw-steps = $data<steps> // [];
    die App::DuckETL::X::Pipeline.new(message => "pipeline '{$name}' has no steps")
        unless $raw-steps ~~ Positional && $raw-steps.elems;

    for $raw-steps.kv -> $i, $raw {
        die App::DuckETL::X::Pipeline.new(
            message => "steps[{$i}] must be an object",
        ) unless $raw ~~ Hash;
        @steps.push: Step.from-hash($raw, where => "steps[{$i}]");
    }

    my %allowed = <name description database defaults steps version extensions>.Set;
    my @unknown = $data.keys.grep({ !%allowed{$_} });
    die App::DuckETL::X::Pipeline.new(
        message => "unknown top-level field(s): {@unknown.sort.join(', ')}",
    ) if @unknown;

    my $p = self.new(
        :$name,
        description => $data<description>.defined ?? $data<description>.Str !! Str,
        database    => $data<database>.defined ?? $data<database>.Str !! Str,
        :%defaults,
        :@steps,
        :@extensions,
        :$path,
        :$base-dir,
    );
    $p.validate;
    $p;
}

method validate(--> Nil) {
    die App::DuckETL::X::Pipeline.new(message => 'pipeline name must not be empty')
        unless $!name.chars;

    for @!extensions -> $extension {
        die App::DuckETL::X::Pipeline.new(
            message => "invalid extension name '{$extension}'",
        ) unless $extension ~~ /^ <[A..Z a..z 0..9 _ -]>+ $/;
    }

    my %known;          # lower-case id -> canonical id
    my %produced;       # id -> True, only source and sql steps
    my @ordered;
    for @!steps.kv -> $i, $step {
        my $where = "steps[{$i}] ('{$step.id}')";
        validate-step($step, :$where);

        my $lc = $step.id.lc;
        die App::DuckETL::X::Pipeline.new(
            message => "{$where}: duplicate step id (ids are case-insensitive)",
        ) if %known{$lc};
        %known{$lc} = $step.id;
        @ordered.push($step);
    }

    for @ordered -> $step {
        my @refs;
        if $step.type eq 'sql' || $step.type eq 'assert' {
            @refs = step-refs($step.sql, %known);
        }
        elsif $step.type eq 'source' && ($step.format // '') eq 'sql' {
            @refs = step-refs($step.sql, %known);
        }

        for @refs -> $ref {
            die App::DuckETL::X::Pipeline.new(
                message => "step '{$step.id}' references '{$ref}', which is not an earlier data step",
            ) unless %produced{$ref};
        }

        %produced{$step.id} = True if $step.type eq 'source' || $step.type eq 'sql';
    }
}

my sub validate-step(Step $step, Str :$where) {
    my %types = <source sql assert sink>.Set;
    die App::DuckETL::X::Pipeline.new(message => "{$where}: unknown type '{$step.type}'")
        unless %types{$step.type};

    unless $step.id ~~ /^ <[A..Z a..z _]> <[A..Z a..z 0..9 _]>* $/ {
        die App::DuckETL::X::Pipeline.new(
            message => "{$where}: id must match [A-Za-z_][A-Za-z0-9_]*",
        );
    }

    if $step.type eq 'source' {
        my %formats = <csv parquet json table sql>.Set;
        die App::DuckETL::X::Pipeline.new(message => "{$where}: source needs a format")
            unless $step.format.defined && $step.format.chars;
        die App::DuckETL::X::Pipeline.new(
            message => "{$where}: unsupported source format '{$step.format}'",
        ) unless %formats{$step.format};

        given $step.format {
            when 'csv' | 'parquet' | 'json' {
                die App::DuckETL::X::Pipeline.new(message => "{$where}: source needs path")
                    unless $step.path.defined;
                validate-source-path($step.path, :$where);
            }
            when 'table' {
                my $target = $step.table.defined && $step.table.chars
                    ?? $step.table !! $step.path.defined ?? $step.path.Str !! '';
                die App::DuckETL::X::Pipeline.new(message => "{$where}: table source needs a table name")
                    unless $target.chars;
                my $ok = try { split-target($target); True };
                die App::DuckETL::X::Pipeline.new(
                    message => "{$where}: invalid table name '{$target}'",
                ) unless $ok;
            }
            when 'sql' {
                die App::DuckETL::X::Pipeline.new(message => "{$where}: sql source needs sql")
                    unless $step.sql.defined && $step.sql.trim.chars;
            }
        }
    }
    elsif $step.type eq 'sql' {
        die App::DuckETL::X::Pipeline.new(message => "{$where}: sql step needs sql")
            unless $step.sql.defined && $step.sql.trim.chars;
    }
    elsif $step.type eq 'assert' {
        die App::DuckETL::X::Pipeline.new(message => "{$where}: assert needs sql")
            unless $step.sql.defined && $step.sql.trim.chars;
        die App::DuckETL::X::Pipeline.new(message => "{$where}: assert needs expect")
            unless $step.expect.defined;
        my %ops = <eq ne lt lte gt gte>.Set;
        die App::DuckETL::X::Pipeline.new(message => "{$where}: unsupported assert op '{$step.op}'")
            unless %ops{$step.op};
    }
    elsif $step.type eq 'sink' {
        die App::DuckETL::X::Pipeline.new(message => "{$where}: sink needs target")
            unless $step.target.defined && $step.target.chars;

        my %modes = <replace append upsert>.Set;
        die App::DuckETL::X::Pipeline.new(message => "{$where}: unsupported sink mode '{$step.mode}'")
            unless %modes{$step.mode};

        if is-file-target($step.target) {
            die App::DuckETL::X::Pipeline.new(
                message => "{$where}: watermark needs a table sink",
            ) if $step.watermark.defined && $step.watermark.chars;
            die App::DuckETL::X::Pipeline.new(
                message => "{$where}: file sinks only support append/replace semantics; omit mode",
            ) unless $step.mode eq 'replace';
        }
        elsif is-directory-target($step.target) {
            die App::DuckETL::X::Pipeline.new(
                message => "{$where}: partitioned sinks only support replace mode",
            ) unless $step.mode eq 'replace';
            die App::DuckETL::X::Pipeline.new(
                message => "{$where}: directory sink needs partition_by",
            ) unless $step.partition_by.elems;
            my %seen;
            for $step.partition_by -> $column {
                die App::DuckETL::X::Pipeline.new(
                    message => "{$where}: invalid partition column '{$column}'",
                ) unless $column ~~ /^ <[A..Z a..z _]> <[A..Z a..z 0..9 _]>* $/;
                die App::DuckETL::X::Pipeline.new(
                    message => "{$where}: duplicate partition column '{$column}'",
                ) if %seen{$column.lc}++;
            }
            die App::DuckETL::X::Pipeline.new(
                message => "{$where}: watermark cannot be combined with partition_by",
            ) if $step.watermark.defined && $step.watermark.chars;
        }
        else {
            my $ok = try { split-target($step.target); True };
            die App::DuckETL::X::Pipeline.new(
                message => "{$where}: invalid table target '{$step.target}'",
            ) unless $ok;
            die App::DuckETL::X::Pipeline.new(
                message => "{$where}: partition_by needs a directory target",
            ) if $step.partition_by.elems;
            if $step.watermark.defined && $step.watermark.chars {
                die App::DuckETL::X::Pipeline.new(
                    message => "{$where}: watermark needs append or upsert mode",
                ) if $step.mode eq 'replace';
                die App::DuckETL::X::Pipeline.new(
                    message => "{$where}: invalid watermark column '{$step.watermark}'",
                ) unless $step.watermark ~~ /^ <[A..Z a..z _]> <[A..Z a..z 0..9 _]>* $/;
            }
        }

        if $step.mode eq 'upsert' && !is-file-target($step.target) {
            die App::DuckETL::X::Pipeline.new(message => "{$where}: upsert needs key")
                unless $step.key.elems;
            my %seen;
            for $step.key -> $key {
                die App::DuckETL::X::Pipeline.new(
                    message => "{$where}: invalid key column '{$key}'",
                ) unless $key ~~ /^ <[A..Z a..z _]> <[A..Z a..z 0..9 _]>* $/;
                die App::DuckETL::X::Pipeline.new(
                    message => "{$where}: duplicate key column '{$key}'",
                ) if %seen{$key.lc}++;
            }
        }
        elsif $step.key.elems {
            die App::DuckETL::X::Pipeline.new(
                message => "{$where}: key is only valid for an upsert table sink",
            );
        }
    }
}

my sub validate-source-path($path, Str :$where) {
    if $path ~~ Positional {
        die App::DuckETL::X::Pipeline.new(message => "{$where}: source path list is empty")
            unless $path.elems;
        for $path.list -> $p {
            die App::DuckETL::X::Pipeline.new(message => "{$where}: source path must be a string")
                unless $p ~~ Str && $p.chars;
        }
    }
    elsif !($path ~~ Str && $path.chars) {
        die App::DuckETL::X::Pipeline.new(message => "{$where}: source path must be a string");
    }
}

method step(Str:D $id) {
    @!steps.first({ $_.id eq $id });
}

method resolve-path(Str:D $path --> Str) {
    return $path if $path.starts-with('/');
    if $path.starts-with('~/') {
        my $home = %*ENV<HOME> // '';
        return $home ~ '/' ~ $path.substr(2);
    }
    $!base-dir ~ '/' ~ $path;
}

method to-hash(--> Hash) {
    my @steps = @!steps.map({
        %(
            id          => .id,
            type        => .type,
            format      => .format,
            path        => .path,
            table       => .table,
            options     => .options,
            sql         => .sql,
            expect      => .expect,
            op          => .op,
            target      => .target,
            mode        => .mode,
            key         => .key,
            watermark   => .watermark,
            partition_by => .partition_by,
            description => .description,
            materialize => .materialize,
        )
    });
    %(
        name        => $!name,
        description => $!description,
        database    => $!database,
        defaults    => %!defaults,
        extensions  => @!extensions.List,
        steps       => @steps.List,
    );
}
