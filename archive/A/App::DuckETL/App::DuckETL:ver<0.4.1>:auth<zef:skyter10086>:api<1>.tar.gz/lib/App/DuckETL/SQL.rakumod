unit module App::DuckETL::SQL;

# SQL fragments shared by the planner and the executor.  Everything here is
# pure: no database handle, no I/O.

our sub quote-ident(Str:D $name --> Str) is export {
    '"' ~ $name.subst('"', '""', :g) ~ '"';
}

multi sub sql-literal(Bool:D $value --> Str) is export {
    $value ?? 'true' !! 'false';
}

multi sub sql-literal(Numeric:D $value --> Str) is export {
    $value.Str;
}

multi sub sql-literal(Str:D $value --> Str) is export {
    "'" ~ $value.subst("'", "''", :g) ~ "'";
}

multi sub sql-literal(Positional:D $value --> Str) is export {
    '[' ~ $value.map({ sql-literal($_) }).join(', ') ~ ']';
}

multi sub sql-literal($value --> Str) is export {
    die "unsupported SQL literal: {$value.raku}";
}

#| Return `(schema, table)` for a pipeline target.  Only `table` and
#| `schema.table` are accepted; identifiers are restricted to the conservative
#| ASCII set so quoting can remain a pure formality.
our sub split-target(Str:D $target --> List) is export {
    unless $target ~~ /^ <[A..Z a..z _]> <[A..Z a..z 0..9 _]>* [ '.' <[A..Z a..z _]> <[A..Z a..z 0..9 _]>* ]? $/ {
        die "invalid table target '{$target}'; expected table or schema.table";
    }
    my @parts = $target.split('.');
    @parts.elems == 1 ?? ('main', @parts[0]) !! (@parts[0], @parts[1]);
}

our sub qualified-target(Str:D $target --> Str) is export {
    my ($schema, $table) = split-target($target);
    quote-ident($schema) ~ '.' ~ quote-ident($table);
}

our sub is-file-target(Str:D $target --> Bool) is export {
    so $target ~~ /:i \. (parquet | csv) $/;
}

#| Partitioned sinks write a directory, so their target is a path rather than
#| a `table` / `schema.table` name.  A slash, `~`, or leading `.` disambiguates.
our sub is-directory-target(Str:D $target --> Bool) is export {
    $target.contains('/') || $target.starts-with('~') || $target.starts-with('.');
}

our sub file-format(Str:D $target --> Str) is export {
    $target ~~ /:i \. (parquet | csv) $/ or die "unsupported file target '{$target}'";
    ~$0.lc;
}

# ---------------------------------------------------------------------------
# Step references
#
# A sql/assert step refers to the output of an earlier step by writing its id
# where a table would go:  `from extract`.  The planner creates a temp object
# named `_etl_<id>`, so references must be rewritten.  A blind token replace
# is wrong (`extract(year from x)` is a function, not a table), so this scanner
# tracks clause context, parentheses and function calls.

my %clause-end = <where group having order limit qualify window union except intersect>;
my $state-keywords = (%clause-end, <from join>).Set;
my $table-modifiers = <lateral only>.Set;
# Keywords after which `(` starts a subquery/group rather than a function call.
my $paren-non-function = <
    from join where on in and or not select as by into values lateral using
    exists case when then else end all any some
>.Set;

my sub scan-sql(Str:D $sql, &on-table --> Str) {
    my $out = '';
    my $i = 0;
    my $n = $sql.chars;
    my @frames;
    @frames.push: %( :function(False), :in-from(False), :expect-table(False) );
    my Str $prev-kind = '';
    my Str $prev-token = '';

    while $i < $n {
        my $ch = $sql.substr($i, 1);

        # Whitespace and comments are copied verbatim and do not disturb the
        # last significant token.
        if $ch ~~ /\s/ {
            $out ~= $ch;
            $i++;
            next;
        }
        if $i + 1 < $n && $sql.substr($i, 2) eq '--' {
            my $end = $sql.index("\n", $i) // $n;
            $out ~= $sql.substr($i, $end - $i);
            $i = $end;
            next;
        }
        if $i + 1 < $n && $sql.substr($i, 2) eq '/*' {
            my $end = $sql.index('*/', $i + 2);
            $end = $end.defined ?? $end + 2 !! $n;
            $out ~= $sql.substr($i, $end - $i);
            $i = $end;
            next;
        }

        # String and quoted-identifier literals are opaque.
        if $ch eq "'" || $ch eq '"' {
            my $quote = $ch;
            my $start = $i++;
            while $i < $n {
                my $c = $sql.substr($i, 1);
                if $c eq $quote {
                    if $i + 1 < $n && $sql.substr($i + 1, 1) eq $quote {
                        $i += 2;
                        next;
                    }
                    $i++;
                    last;
                }
                $i++;
            }
            $out ~= $sql.substr($start, $i - $start);
            $prev-kind = 'literal';
            $prev-token = '';
            next;
        }

        # Identifiers / keywords.
        if $ch ~~ /<[A..Z a..z _ $]>/ {
            my $start = $i;
            $i++;
            while $i < $n && $sql.substr($i, 1) ~~ /<[A..Z a..z 0..9 _ $]>/ {
                $i++;
            }
            my $token = $sql.substr($start, $i - $start);
            my $lc = $token.lc;
            my $frame = @frames[*-1];

            if $lc eq 'from' && !$frame<function> {
                $frame{'in-from'} = True;
                $frame{'expect-table'} = True;
                $out ~= $token;
            }
            elsif $lc eq 'join' && !$frame<function> {
                $frame{'in-from'} = True;
                $frame{'expect-table'} = True;
                $out ~= $token;
            }
            elsif %clause-end{$lc} && !$frame<function> {
                $frame{'in-from'} = False;
                $frame{'expect-table'} = False;
                $out ~= $token;
            }
            elsif $frame<expect-table> && !$frame<function> && $table-modifiers{$lc} {
                # `from lateral (select ...)`: keep waiting for the table.
                $out ~= $token;
            }
            elsif $frame<expect-table> && !$frame<function> {
                $frame{'expect-table'} = False;
                $out ~= &on-table($token);
            }
            else {
                $out ~= $token;
            }

            if $state-keywords{$lc} || %clause-end{$lc} || $table-modifiers{$lc} {
                $prev-kind = 'keyword';
            }
            else {
                $prev-kind = 'ident';
            }
            $prev-token = $token;
            next;
        }

        # Numbers and everything else are copied; only parentheses and commas
        # need state changes.
        if $ch eq '(' {
            my $is-function = $prev-kind eq 'ident'
                && !$paren-non-function{$prev-token.lc};
            @frames[*-1]{'expect-table'} = False;
            @frames.push: %( :function($is-function), :in-from(False), :expect-table(False) );
            $out ~= $ch;
            $prev-kind = 'punct';
            $prev-token = $ch;
            $i++;
            next;
        }
        if $ch eq ')' {
            @frames.pop if @frames.elems > 1;
            $out ~= $ch;
            $prev-kind = 'punct';
            $prev-token = $ch;
            $i++;
            next;
        }
        if $ch eq ',' {
            my $frame = @frames[*-1];
            $frame{'expect-table'} = True if $frame<in-from> && !$frame<function>;
            $out ~= $ch;
            $prev-kind = 'punct';
            $prev-token = $ch;
            $i++;
            next;
        }

        $out ~= $ch;
        $prev-kind = 'punct';
        $prev-token = $ch;
        $i++;
    }

    $out;
}

#| All step ids referenced from table positions, in first-seen order.
#| `%known` maps lower-case step id to its canonical spelling.
our sub step-refs(Str:D $sql, %known --> List) is export {
    my @refs;
    scan-sql($sql, -> $token {
        my $id = %known{$token.lc};
        @refs.push($id) if $id.defined;
        $token;
    });
    @refs.unique.List;
}

#| Rewrite table-position step ids to their temp object names.  A reference to
#| a step that has not produced a table yet is a forward reference and dies.
our sub rewrite-step-refs(Str:D $sql, %tables, %known --> Str) is export {
    scan-sql($sql, -> $token {
        my $id = %known{$token.lc};
        if $id.defined {
            die "step references '{$id}' before that step has produced data"
                unless %tables{$id}:exists;
            %tables{$id};
        }
        else {
            $token;
        }
    });
}
