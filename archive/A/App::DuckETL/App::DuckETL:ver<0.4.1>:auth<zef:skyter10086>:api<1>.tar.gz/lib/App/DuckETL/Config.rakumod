use JSON::Fast;

unit class App::DuckETL::Config;

has Str $.history-path;
has Str $.database;
has Int $.threads;
has Str $.memory-limit;

method default-data-dir(--> Str) {
    my $xdg = %*ENV<XDG_DATA_HOME>;
    return $xdg if $xdg.defined && $xdg.chars;
    my $home = %*ENV<HOME> // '.';
    $home ~ '/.local/share';
}

method default-history-path(--> Str) {
    self.default-data-dir ~ '/ducketl/history.duckdb';
}

method load(--> App::DuckETL::Config) {
    my $config-path = self!config-path;
    my %file;
    if $config-path.IO.f {
        {
            %file = from-json($config-path.IO.slurp);
            CATCH {
                default {
                    die "invalid config file {$config-path}: {.message}";
                }
            }
        }
    }

    my $history = %*ENV<DUCKETL_HISTORY>
        // %file<history> // self.default-history-path;
    my $database = %*ENV<DUCKETL_DB> // %file<database>;
    my $threads = %*ENV<DUCKETL_THREADS> // %file<threads>;
    my $memory = %*ENV<DUCKETL_MEMORY_LIMIT> // %file<memory_limit>;

    self.new(
        history-path => $history.Str,
        database     => $database.defined ?? $database.Str !! Str,
        threads      => $threads.defined ?? $threads.Int !! Int,
        memory-limit => $memory.defined ?? $memory.Str !! Str,
    );
}

method !config-path(--> Str) {
    my $xdg = %*ENV<XDG_CONFIG_HOME>;
    my $base = $xdg.defined && $xdg.chars
        ?? $xdg
        !! ((%*ENV<HOME> // '.') ~ '/.config');
    $base ~ '/ducketl/config.json';
}

method expand-path(Str:D $path --> Str) {
    return $path unless $path.starts-with('~/');
    my $home = %*ENV<HOME> // '';
    $home ~ '/' ~ $path.substr(2);
}
