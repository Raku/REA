use App::DuckETL::Executor;
use App::DuckETL::Pipeline;

#| Run an executor on a background thread and let the UI poll its events.
#|
#| The executor emits events synchronously from the job thread, so they are
#| queued here and drained by the UI; no pane or future object is shared with
#| the job.  `cancel` is delegated to the executor, which interrupts the
#| DuckDB job connection.
unit class App::DuckETL::Run;

has App::DuckETL::Pipeline $.pipeline is required;
has App::DuckETL::Duck $.duck is required;
has App::DuckETL::Store $.store is required;
has Bool $.keep-temp = False;

has Lock $!lock .= new;
has @!events;
has $!executor;
has $!thread;
has Bool $!started = False;
has Bool $!finished = False;
has %!result;

method start(--> Nil) {
    return if $!started;
    $!started = True;
    $!executor = App::DuckETL::Executor.new(
        pipeline  => $!pipeline,
        duck      => $!duck,
        store     => $!store,
        keep-temp => $!keep-temp,
        event     => -> %e {
            $!lock.protect({ @!events.push(%e) });
        },
    );
    $!thread = start {
        my %res;
        {
            %res = $!executor.run;
            CATCH {
                default {
                    %res = { status => 'failed', error => .message };
                }
            }
        }
        $!lock.protect({
            %!result = %res;
            @!events.push({ type => 'internal-finish', result => %res });
            $!finished = True;
        });
    };
    Nil;
}

#| Drain queued events.  Safe to call from the UI thread.
method drain(--> List) {
    $!lock.protect({ my @out = @!events; @!events = (); @out.List });
}

method cancel(--> Nil) {
    $!executor.cancel if $!executor.defined;
}

method finished(--> Bool) { $!finished }

method result(--> Hash) { %!result }

#| Block until the job thread returns; used by tests and orderly shutdown.
method wait(--> Hash) {
    await $!thread if $!thread.defined;
    %!result;
}
