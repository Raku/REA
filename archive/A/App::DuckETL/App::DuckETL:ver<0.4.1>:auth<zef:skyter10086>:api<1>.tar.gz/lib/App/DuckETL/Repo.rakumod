#| Spec strings for the repositories this process loads modules from.
#|
#| A child `raku` process starts with the default repository chain, so any
#| checkout passed with `-I`, and any repository `zef` created for an install
#| (including its staging repository), has to be named explicitly.
unit module App::DuckETL::Repo;

sub repo-includes(--> List) is export {
    my @specs;
    for $*REPO.repo-chain -> $repo {
        my Str $spec = do {
            my $name = $repo.^name;
            $name eq 'CompUnit::Repository::Installation' ?? "inst#{$repo.prefix}"
            !! $name eq 'CompUnit::Repository::FileSystem' ?? $repo.prefix.Str
            !! $name eq 'CompUnit::Repository::Staging'
                ?? "CompUnit::Repository::Staging#name({$repo.name})#{$repo.prefix}"
            !! '';
        };
        @specs.push: $spec if $spec.chars;
    }
    @specs.unique.List;
}
