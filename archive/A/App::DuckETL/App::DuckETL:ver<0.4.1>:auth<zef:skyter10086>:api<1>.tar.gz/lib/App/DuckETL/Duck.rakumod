use DB::DuckDB;
use App::DuckETL::SQL;

unit class App::DuckETL::Duck;

has Str $.path = ':memory:';
has Int $.threads;
has Str $.memory-limit;

has DB::DuckDB $!db;
has DB::DuckDB::Connection $!connection;
has DB::DuckDB::Connection $!session;
has Bool $!closed = False;

submethod TWEAK {
    if $!path ne ':memory:' {
        my $parent = $!path.IO.parent;
        $parent.mkdir unless $parent.e;
    }
    my %options = path => $!path;
    %options<threads> = $!threads if $!threads.defined;
    %options<memory-limit> = $!memory-limit if $!memory-limit.defined;
    $!db = DB::DuckDB.new(|%options);
    # Open both connections from the constructing thread: the job thread and
    # the UI thread then only use handles, never race on lazy initialization.
    $!connection = $!db.connect;
    $!session = $!db.session;
}

method connection(--> DB::DuckDB::Connection) {
    die 'database is closed' if $!closed;
    $!connection;
}

method session(--> DB::DuckDB::Connection) {
    die 'database is closed' if $!closed;
    $!session;
}

method query(Str:D $sql, *@args) {
    self.connection.query($sql, |@args);
}

method execute(Str:D $sql, *@args --> Int) {
    self.connection.execute($sql, |@args);
}

method count(Str:D $table --> Int) {
    self.query('select count(*) from ' ~ quote-ident($table)).value.Int;
}

method table-exists(Str:D $target --> Bool) {
    my ($schema, $table) = split-target($target);
    my $n = self.query(
        'select count(*) from information_schema.tables where table_schema = ? and table_name = ?',
        $schema, $table,
    ).value.Int;
    $n > 0;
}

method table-columns(Str:D $target --> List) {
    my ($schema, $table) = split-target($target);
    self.query(
        'select column_name from information_schema.columns'
        ~ ' where table_schema = ? and table_name = ? order by ordinal_position',
        $schema, $table,
    ).arrays.map(*.head.Str).List;
}

method catalog(--> List) {
    # UI-only read: use the session connection so browsing never observes the
    # job transaction's temp tables or blocks a running step.
    self.session.query(
        'select table_schema, table_name, table_type from information_schema.tables'
        ~ " where table_schema not in ('information_schema', 'pg_catalog')"
        ~ ' order by table_schema, table_name',
    ).arrays.List;
}

#| Run a read-only query with a hard row limit and return names + rows as
#| plain Raku data.  Never call this for an unbounded query.
method preview(Str:D $sql, Int:D $limit = 100 --> Hash) {
    my $clean = $sql.trim.subst(/ ';' \s* $/, '');
    my $res = self.session.query('select * from (' ~ $clean ~ ') limit ' ~ $limit);
    my @names = $res.names.List;
    my @rows = $res.arrays.List;
    $res.free;
    { :@names, :@rows };
}

method close(--> Nil) {
    return if $!closed;
    $!closed = True;
    $!db.close;
}

submethod DESTROY {
    try { self.close };
}
