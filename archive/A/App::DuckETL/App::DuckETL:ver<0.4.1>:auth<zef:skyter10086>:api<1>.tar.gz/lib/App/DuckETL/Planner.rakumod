use App::DuckETL::Pipeline;
use App::DuckETL::SQL;
use DB::DuckDB::Parquet;

unit class App::DuckETL::Planner;

has App::DuckETL::Pipeline $.pipeline is required;

has %!tables;    # canonical step id -> quoted temp object name
has %!kinds;     # canonical step id -> table | view
has %!known;     # lower-case step id -> canonical id
has Str $!last-data;

#| Last committed watermark value for the sink being planned.  Set by the
#| executor before planning a sink step; empty means a full load.
has Str $.watermark-value is rw = '';

submethod TWEAK {
    %!known = $!pipeline.steps.map({ $_.id.lc => $_.id });
}

method reset(--> Nil) {
    %!tables = ();
    %!kinds = ();
    $!last-data = Str;
}

method temp-name(Str:D $id --> Str) {
    quote-ident('_etl_' ~ $id);
}

method last-data(--> Str) { $!last-data }

method plan-step(App::DuckETL::Pipeline::Step $step --> Hash) {
    given $step.type {
        when 'source' {
            my ($select, @args) = self!source-select($step);
            self!produce($step, $select, |@args);
        }
        when 'sql' {
            my $select = rewrite-step-refs($step.sql, %!tables, %!known);
            self!produce($step, $select);
        }
        when 'assert' {
            {
                kind      => 'assert',
                step-id   => $step.id,
                sql       => rewrite-step-refs($step.sql, %!tables, %!known),
                op        => $step.op,
                expect    => $step.expect,
            };
        }
        when 'sink' {
            self!sink-plan($step);
        }
        default {
            die "unknown step type '{$step.type}'";
        }
    }
}

method !produce(App::DuckETL::Pipeline::Step $step, Str:D $select, *@args --> Hash) {
    my $name = self.temp-name($step.id);
    my $kind = $step.materialize ?? 'table' !! 'view';
    my $sql = 'create or replace temp ' ~ $kind ~ ' ' ~ $name ~ ' as ' ~ $select;
    %!tables{$step.id} = $name;
    %!kinds{$step.id} = $kind;
    $!last-data = $step.id;

    {
        kind         => 'query',
        step-id      => $step.id,
        table        => $name,
        materialize  => $step.materialize,
        sql          => $sql,
        rows-sql     => 'select count(*) from ' ~ $name,
        args         => @args.List,
    };
}

method !source-select(App::DuckETL::Pipeline::Step $step --> List) {
    given $step.format {
        when 'csv' | 'parquet' | 'json' {
            my ($path-arg, @args) = self!path-argument($step.path);
            my @options = self!option-sql($step.options);
            my $function = $step.format eq 'csv'
                ?? 'read_csv_auto'
                !! $step.format eq 'parquet'
                    ?? 'read_parquet'
                    !! 'read_json_auto';
            my @call = $path-arg, |@options;
            return ('select * from ' ~ $function ~ '(' ~ @call.join(', ') ~ ')', |@args);
        }
        when 'table' {
            my $target = $step.table.defined && $step.table.chars
                ?? $step.table !! $step.path.Str;
            return ('select * from ' ~ qualified-target($target),);
        }
        when 'sql' {
            my $select = rewrite-step-refs($step.sql, %!tables, %!known);
            return ($select,);
        }
        default {
            die "unknown source format '{$step.format}'";
        }
    }
}

method !path-argument($path --> List) {
    if $path ~~ Positional {
        my @resolved = $path.map({ $!pipeline.resolve-path($_.Str) }).List;
        return ('?', @resolved[0]) if @resolved.elems == 1;
        my $args = '[' ~ ('?' xx @resolved.elems).join(', ') ~ ']';
        return ($args, |@resolved);
    }
    my $resolved = $!pipeline.resolve-path($path.Str);
    return ('?', $resolved);
}

method !option-sql(%options --> List) {
    my @pairs;
    for %options.keys.sort -> $key {
        unless $key ~~ /^ <[A..Z a..z _]> <[A..Z a..z 0..9 _]>* $/ {
            die "invalid source option name '{$key}'";
        }
        my $value = %options{$key};
        die "source option '{$key}' must have a value" unless $value.defined;
        @pairs.push: $key ~ ' = ' ~ sql-literal($value);
    }
    @pairs.List;
}

method !sink-plan(App::DuckETL::Pipeline::Step $step --> Hash) {
    die "sink '{$step.id}' has no input step" unless $!last-data.defined;
    my $source = %!tables{$!last-data};

    if $step.partition_by.elems {
        return self!partition-sink-plan($step, $source);
    }

    if is-file-target($step.target) {
        my $format = file-format($step.target);
        my $target = $!pipeline.resolve-path($step.target);
        my $temp = $target ~ '.tmp-' ~ $*PID ~ '-' ~ (^1000000).pick;
        my $sql;
        if $format eq 'parquet' {
            my %opts = :sql, compression => ($step.options<compression> // 'zstd').Str;
            %opts<row-group-size> = $step.options<row_group_size>.Int
                if $step.options<row_group_size>.defined;
            $sql = parquet-copy-sql($temp, 'select * from ' ~ $source, |%opts);
        }
        else {
            $sql = self!csv-copy-sql($temp, 'select * from ' ~ $source, $step.options);
        }

        return {
            kind     => 'file-sink',
            step-id  => $step.id,
            format   => $format,
            target   => $target,
            temp     => $temp,
            sql      => $sql,
            rows-sql => 'select count(*) from ' ~ $source,
        };
    }

    my @args;
    my Str $derive = $source;
    if ($step.watermark // '').chars && $!watermark-value.chars {
        $derive = '(select * from ' ~ $source
            ~ ' where ' ~ quote-ident($step.watermark) ~ ' > ?)';
        @args.push($!watermark-value);
    }

    my ($schema, $table) = split-target($step.target);
    my $quoted = quote-ident($schema) ~ '.' ~ quote-ident($table);
    {
        kind     => 'table-sink',
        step-id  => $step.id,
        schema   => $schema,
        table    => $table,
        target   => $schema ~ '.' ~ $table,
        quoted   => $quoted,
        mode     => $step.mode,
        key      => $step.key.List,
        watermark => ($step.watermark // '').Str,
        source   => $derive,
        args     => @args.List,
        rows-sql => 'select count(*) from ' ~ $derive,
    };
}

method !partition-sink-plan(App::DuckETL::Pipeline::Step $step, Str:D $source --> Hash) {
    my $target = $!pipeline.resolve-path($step.target);
    my $temp = $target ~ '.tmp-' ~ $*PID ~ '-' ~ (^1000000).pick;
    my %options = $step.options;
    my @unknown = %options.keys.grep({ $_ ne 'compression' });
    die "unknown partitioned sink option(s): {@unknown.sort.join(', ')}" if @unknown;

    my Str $compression = (%options<compression> // 'zstd').Str;
    die "invalid parquet compression '{$compression}'"
        unless $compression ~~ /^ <[A..Z a..z 0..9 _ -]>+ $/;

    my Str $columns = $step.partition_by.map({ quote-ident($_) }).join(', ');
    my Str $sql = 'copy (select * from ' ~ $source ~ ') to ' ~ sql-literal($temp)
        ~ ' (format parquet, partition_by (' ~ $columns ~ ')'
        ~ ', compression ' ~ $compression ~ ')';

    {
        kind     => 'partition-sink',
        step-id  => $step.id,
        target   => $target,
        temp     => $temp,
        dir      => True,
        columns  => $step.partition_by.List,
        sql      => $sql,
        rows-sql => 'select count(*) from ' ~ $source,
    };
}

method !csv-copy-sql(Str:D $target, Str:D $select, %options --> Str) {
    my $allowed = <header delim delimiter quote escape>.Set;
    my @unknown = %options.keys.grep({ !$allowed{$_} });
    die "unknown CSV sink option(s): {@unknown.sort.join(', ')}" if @unknown;

    my $header = %options<header> // True;
    die 'CSV sink option header must be a boolean' unless $header ~~ Bool;
    my $delim = %options<delimiter> // %options<delim> // ',';

    my @opts = 'format csv';
    @opts.push: 'header ' ~ ($header ?? 'true' !! 'false');
    @opts.push: 'delimiter ' ~ sql-literal($delim.Str);
    @opts.push: 'quote ' ~ sql-literal(%options<quote>.Str) if %options<quote>.defined;
    @opts.push: 'escape ' ~ sql-literal(%options<escape>.Str) if %options<escape>.defined;

    'copy (' ~ $select ~ ') to ' ~ sql-literal($target)
        ~ ' (' ~ @opts.join(', ') ~ ')';
}

method create-as-sql(Str:D $quoted, Str:D $source --> Str) {
    'create or replace table ' ~ $quoted ~ ' as select * from ' ~ $source;
}

method append-sql(Str:D $quoted, Str:D $source --> Str) {
    'insert into ' ~ $quoted ~ ' by name select * from ' ~ $source;
}

method upsert-create-sql(Str:D $quoted, Str:D $source --> Str) {
    'create table ' ~ $quoted ~ ' as select * from ' ~ $source ~ ' where 1 = 0';
}

method upsert-sql(Str:D $quoted, @keys, @columns, Str:D $source --> Str) {
    my %key = @keys.map({ $_.lc => True });
    my %columns = @columns.map({ $_.lc => True });
    my @missing = @keys.grep({ !%columns{$_.lc} });
    die "upsert key column(s) not found in target: {@missing.join(', ')}" if @missing;

    my $conflict = @keys.map({ quote-ident($_) }).join(', ');
    my @updates = @columns.grep({ !%key{$_.lc} }).map({
        quote-ident($_) ~ ' = excluded.' ~ quote-ident($_)
    });

    my $tail = @updates.elems
        ?? 'do update set ' ~ @updates.join(', ')
        !! 'do nothing';
    'insert into ' ~ $quoted ~ ' by name select * from ' ~ $source
        ~ ' on conflict (' ~ $conflict ~ ') ' ~ $tail;
}
