unit module App::DuckETL::TUI::Draft;

# Pure helpers for the editable pipeline draft.  The TUI keeps drafts as plain
# JSON-shaped hashes; everything here turns those hashes into form fields or
# into the canonical pipeline JSON (and never touches a terminal or database).

my @TYPES = <source sql assert sink>;
my @FORMATS = <csv parquet json table sql>;
my @MODES = <replace append upsert>;
my @OPS = <eq ne lt lte gt gte>;

our sub enum-values(Str $key --> List) is export {
    given $key {
        when 'type'   { @TYPES.List }
        when 'format' { @FORMATS.List }
        when 'mode'   { @MODES.List }
        when 'op'     { @OPS.List }
        default       { () }
    }
}

#| Next (or previous) value of an enum field; unknown values start at the
#| first entry.
our sub cycle-enum(Str $key, $value, Int $step = 1 --> Str) is export {
    my @values = enum-values($key);
    return '' unless @values;
    my Str $current = $value.defined ?? $value.Str !! '';
    my $index = @values.first($current, :k);
    my Int $next = $index.defined ?? ($index + $step) !! 0;
    $next = $next % @values.elems;
    $next += @values.elems if $next < 0;
    @values[$next];
}

our sub field-kind(Str $key --> Str) is export {
    given $key {
        when 'expect'      { 'int' }
        when 'materialize' { 'bool' }
        when 'key' | 'partition_by' | 'extensions' { 'list' }
        when 'sql'         { 'sql' }
        when 'options'     { 'json' }
        when 'type' | 'format' | 'mode' | 'op' { 'enum' }
        default            { 'text' }
    }
}

#| Fields shown for one step, in form order.  Conditional fields follow the
#| step's type/format/mode so the form never asks for meaningless values.
our sub field-specs(%step --> List) is export {
    my Str $type = (%step<type> // 'source').Str;
    my @fields = ('id', 'type');

    given $type {
        when 'source' {
            @fields.push: 'format';
            my Str $format = (%step<format> // 'csv').Str;
            given $format {
                when 'csv' | 'parquet' | 'json' {
                    @fields.push: 'path';
                    @fields.push: 'options';
                }
                when 'table' { @fields.push: 'table' }
                when 'sql'   { @fields.push: 'sql' }
            }
        }
        when 'sql'    { @fields.push: 'sql' }
        when 'assert' { @fields.push: 'sql'; @fields.push: 'expect'; @fields.push: 'op' }
        when 'sink' {
            @fields.push: 'target';
            @fields.push: 'mode';
            my Str $mode = (%step<mode> // 'replace').Str;
            @fields.push: 'key' if $mode eq 'upsert';
            @fields.push: 'watermark' unless $mode eq 'replace';
            @fields.push: 'partition_by' if $mode eq 'replace';
        }
    }
    @fields.push: 'description';
    @fields.push: 'materialize';
    @fields.List;
}

#| One-line description used in the step table.
our sub step-summary(%step --> Str) is export {
    my Str $type = (%step<type> // '').Str;
    my Str $text;
    given $type {
        when 'source' {
            my Str $format = (%step<format> // '').Str;
            my $where = %step<path> ~~ Positional
                ?? %step<path>.join(', ')
                !! (%step<path> // %step<table> // '');
            $text = $format ~ ' ' ~ $where.Str;
        }
        when 'sql'    { $text = (%step<sql> // '').Str }
        when 'assert' {
            $text = 'expect ' ~ (%step<op> // 'eq') ~ ' ' ~ (%step<expect> // '').Str;
        }
        when 'sink' {
            my @parts = (%step<target> // '').Str, (%step<mode> // 'replace').Str;
            @parts.push: 'key ' ~ %step<key>.join(',') if %step<key> ~~ Positional;
            @parts.push: 'wm ' ~ %step<watermark> if (%step<watermark> // '').chars;
            @parts.push: 'by ' ~ %step<partition_by>.join(',')
                if %step<partition_by> ~~ Positional && %step<partition_by>.elems;
            $text = @parts.join(' ');
        }
        default { $text = '' }
    }
    $text.subst(/<[\r\n\t]>/, ' ', :g);
}

our sub default-step(Str:D $id, Str:D $type = 'source' --> Hash) is export {
    my %step = id => $id, type => $type, materialize => True;
    given $type {
        when 'source' { %step<format> = 'csv'; %step<path> = ''; %step<options> = %() }
        when 'sql' | 'assert' { %step<sql> = '' }
        when 'sink' { %step<target> = ''; %step<mode> = 'replace' }
    }
    %step;
}

our sub next-step-id(@steps --> Str) is export {
    my %used = @steps.map({ (($_<id> // '')).lc => True });
    my Int $n = 1;
    loop {
        my Str $id = 'step' ~ $n;
        return $id unless %used{$id};
        $n++;
    }
}

my sub text-value($value --> Str) {
    $value.defined ?? $value.Str !! '';
}

#| Strip a draft step down to the keys the pipeline format accepts, dropping
#| defaults and values that belong to another type/format.
our sub clean-step(%step --> Hash) is export {
    my Str $type = (%step<type> // 'source').Str;
    my %out;
    %out<id> = text-value(%step<id>);
    %out<type> = $type;

    given $type {
        when 'source' {
            my Str $format = (%step<format> // 'csv').Str;
            %out<format> = $format;
            given $format {
                when 'csv' | 'parquet' | 'json' {
                    my $path = %step<path>;
                    if $path ~~ Positional {
                        %out<path> = $path.List if $path.elems;
                    }
                    elsif $path.defined && $path.Str.chars {
                        %out<path> = $path.Str;
                    }
                    if %step<options> ~~ Hash && %step<options>.elems {
                        %out<options> = %step<options>;
                    }
                }
                when 'table' {
                    my Str $table = text-value(%step<table>);
                    $table = text-value(%step<path>) unless $table.chars;
                    %out<table> = $table;
                }
                when 'sql' {
                    %out<sql> = text-value(%step<sql>);
                }
            }
        }
        when 'sql' {
            %out<sql> = text-value(%step<sql>);
        }
        when 'assert' {
            %out<sql> = text-value(%step<sql>);
            %out<expect> = %step<expect> if %step<expect>.defined;
            my Str $op = (%step<op> // 'eq').Str;
            %out<op> = $op unless $op eq 'eq';
        }
        when 'sink' {
            %out<target> = text-value(%step<target>);
            my Str $mode = (%step<mode> // 'replace').Str;
            %out<mode> = $mode unless $mode eq 'replace';
            if $mode eq 'upsert' && %step<key> ~~ Positional && %step<key>.elems {
                %out<key> = %step<key>.List;
            }
            if %step<watermark>.defined && %step<watermark>.Str.chars {
                %out<watermark> = %step<watermark>.Str;
            }
            if %step<partition_by> ~~ Positional && %step<partition_by>.elems {
                %out<partition_by> = %step<partition_by>.List;
            }
        }
    }

    if %step<description>.defined && %step<description>.Str.chars {
        %out<description> = %step<description>.Str;
    }
    if %step<materialize>.defined && %step<materialize> ~~ Bool && !%step<materialize> {
        %out<materialize> = False;
    }
    %out;
}

#| Canonical JSON-ready pipeline hash for a draft.
our sub pipeline-data(%draft --> Hash) is export {
    my %data;
    %data<name> = text-value(%draft<name>);
    my Str $database = text-value(%draft<database>);
    %data<database> = $database if $database.chars;
    my $extensions = %draft<extensions>;
    if $extensions ~~ Positional && $extensions.elems {
        %data<extensions> = $extensions.List;
    }
    %data<steps> = (%draft<steps> // ()).map({ clean-step($_) }).List;
    %data;
}
