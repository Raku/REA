use DB::DuckDB;

unit class App::DuckETL::Store;

has Str $.path is required;

has DB::DuckDB $!db;
has DB::DuckDB::Connection $!conn;
has Bool $!closed = False;
has Lock $!lock .= new;

submethod TWEAK {
    if $!path ne ':memory:' {
        my $parent = $!path.IO.parent;
        $parent.mkdir unless $parent.e;
    }
    $!db = DB::DuckDB.new(path => $!path);
    $!conn = $!db.connect;
    self!init-schema;
}

method !init-schema(--> Nil) {
    $!conn.execute('create schema if not exists _etl');
    $!conn.execute(q:to/SQL/);
        create table if not exists _etl.runs (
            run_id     varchar primary key,
            pipeline   varchar not null,
            started_at timestamp not null,
            finished_at timestamp,
            status     varchar not null,
            rows       bigint default 0,
            error      varchar
        )
        SQL
    $!conn.execute(q:to/SQL/);
        create table if not exists _etl.steps (
            run_id     varchar not null,
            step_id    varchar not null,
            step_type  varchar not null,
            ordinal    integer not null,
            status     varchar not null,
            started_at timestamp,
            finished_at timestamp,
            rows       bigint default 0,
            sql        varchar,
            error      varchar,
            primary key (run_id, step_id)
        )
        SQL
    $!conn.execute(q:to/SQL/);
        create table if not exists _etl.watermarks (
            pipeline    varchar not null,
            step_id     varchar not null,
            column_name varchar not null,
            value       varchar,
            updated_at  timestamp,
            primary key (pipeline, step_id, column_name)
        )
        SQL
}

#| Record a run and its pending steps in one transaction.
method start-run(Str:D $run-id, Str:D $pipeline, @steps, Str:D $started-at --> Nil) {
    $!lock.lock;
    LEAVE $!lock.unlock;
    $!conn.execute('begin');
    {
        $!conn.execute(
            'insert into _etl.runs(run_id, pipeline, started_at, status, rows)'
            ~ ' values (?, ?, cast(? as timestamp), ?, 0)',
            $run-id, $pipeline, $started-at, 'running',
        );
        for @steps.kv -> $order, $step {
            $!conn.execute(
                'insert into _etl.steps(run_id, step_id, step_type, ordinal, status)'
                ~ ' values (?, ?, ?, ?, ?)',
                $run-id, $step.id, $step.type, $order, 'pending',
            );
        }
        $!conn.execute('commit');
        CATCH {
            default {
                try $!conn.execute('rollback');
                .rethrow;
            }
        }
    }
}

method start-step(Str:D $run-id, Str:D $step-id, Str:D $started-at, Str :$sql --> Nil) {
    $!lock.lock;
    LEAVE $!lock.unlock;
    $!conn.execute(
        'update _etl.steps set status = ?, started_at = cast(? as timestamp), sql = ?'
        ~ ' where run_id = ? and step_id = ?',
        'running', $started-at, $sql, $run-id, $step-id,
    );
}

method finish-step(Str:D $run-id, Str:D $step-id, Str:D $status,
                   Str:D $finished-at, Int:D $rows, Str :$sql, Str :$error --> Nil) {
    $!lock.lock;
    LEAVE $!lock.unlock;
    $!conn.execute(
        'update _etl.steps set status = ?, finished_at = cast(? as timestamp),'
        ~ ' rows = ?, sql = coalesce(?, sql), error = ?'
        ~ ' where run_id = ? and step_id = ?',
        $status, $finished-at, $rows,
        ($sql.defined ?? $sql !! Str), ($error.defined ?? $error !! Str),
        $run-id, $step-id,
    );
}

method finish-run(Str:D $run-id, Str:D $status, Str:D $finished-at,
                  Int:D $rows, Str :$error --> Nil) {
    $!lock.lock;
    LEAVE $!lock.unlock;
    $!conn.execute(
        'update _etl.runs set status = ?, finished_at = cast(? as timestamp),'
        ~ ' rows = ?, error = ? where run_id = ?',
        $status, $finished-at, $rows, ($error.defined ?? $error !! Str), $run-id,
    );
}

#| Mark a run abandoned by a crashed worker: only rows still `running` change.
method fail-run(Str:D $run-id, Str:D $message, Str:D $finished-at --> Nil) {
    $!lock.lock;
    LEAVE $!lock.unlock;
    $!conn.execute(
        'update _etl.steps set status = ?, finished_at = cast(? as timestamp), error = ?'
        ~ ' where run_id = ? and status = ?',
        'failed', $finished-at, $message, $run-id, 'running',
    );
    $!conn.execute(
        'update _etl.runs set status = ?, finished_at = cast(? as timestamp), error = ?'
        ~ ' where run_id = ? and status = ?',
        'failed', $finished-at, $message, $run-id, 'running',
    );
}

method recent-runs(Int:D $limit = 20 --> List) {
    $!lock.lock;
    LEAVE $!lock.unlock;
    $!conn.query(
        'select run_id, pipeline, started_at, finished_at, status, rows, error'
        ~ ' from _etl.runs order by started_at desc limit ?',
        $limit,
    ).hashes.List;
}

method run-detail(Str:D $run-id --> Hash) {
    $!lock.lock;
    LEAVE $!lock.unlock;
    my @runs = $!conn.query(
        'select run_id, pipeline, started_at, finished_at, status, rows, error'
        ~ ' from _etl.runs where run_id = ?', $run-id,
    ).hashes.List;
    return Hash unless @runs.elems;

    my @steps = $!conn.query(
        'select step_id, step_type, ordinal, status, started_at, finished_at,'
        ~ ' rows, sql, error from _etl.steps where run_id = ? order by ordinal',
        $run-id,
    ).hashes.List;

    { run => @runs[0], steps => @steps };
}

method watermarks(Str:D $pipeline --> List) {
    $!lock.lock;
    LEAVE $!lock.unlock;
    $!conn.query(
        'select step_id, column_name, value, updated_at from _etl.watermarks'
        ~ ' where pipeline = ? order by step_id, column_name', $pipeline,
    ).hashes.List;
}

method watermark(Str:D $pipeline, Str:D $step-id, Str:D $column --> Str) {
    $!lock.lock;
    LEAVE $!lock.unlock;
    my $value = $!conn.query(
        'select value from _etl.watermarks'
        ~ ' where pipeline = ? and step_id = ? and column_name = ?',
        $pipeline, $step-id, $column,
    ).value;
    $value.defined ?? $value.Str !! '';
}

method set-watermark(Str:D $pipeline, Str:D $step-id, Str:D $column,
                     Str:D $value, Str:D $updated-at --> Nil) {
    $!lock.lock;
    LEAVE $!lock.unlock;
    $!conn.execute(
        'insert into _etl.watermarks(pipeline, step_id, column_name, value, updated_at)'
        ~ ' values (?, ?, ?, ?, cast(? as timestamp))'
        ~ ' on conflict (pipeline, step_id, column_name) do update set'
        ~ ' value = excluded.value, updated_at = excluded.updated_at',
        $pipeline, $step-id, $column, $value, $updated-at,
    );
}

method close(--> Nil) {
    return if $!closed;
    $!closed = True;
    $!db.close;
}

submethod DESTROY {
    try { self.close };
}
