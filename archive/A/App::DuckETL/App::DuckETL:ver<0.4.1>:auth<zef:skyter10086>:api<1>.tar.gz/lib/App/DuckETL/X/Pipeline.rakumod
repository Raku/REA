unit class App::DuckETL::X::Pipeline is Exception;

has Str $.message;

method gist(--> Str) {
    'pipeline error: ' ~ ($!message // 'unknown pipeline error');
}
