use Terminal::UI;
use JSON::Fast;
use App::DuckETL::Config;
use App::DuckETL::Pipeline;
use App::DuckETL::Duck;
use App::DuckETL::Store;
use App::DuckETL::Run;
use App::DuckETL::IsolatedRun;
use App::DuckETL::SQL;
use App::DuckETL::TUI::Render;
use App::DuckETL::TUI::Draft;

#| M1/M2 TUI: Dashboard, Sources, Pipeline (editable draft) and Run.  The UI
#| thread only reads snapshots and renders text; execution happens on a
#| background thread owned by App::DuckETL::Run.
unit class App::DuckETL::TUI;

has App::DuckETL::Config $.config is required;
has Str $.base-dir = '.';
has Str $.database;                 # --db override, already expanded
has Str $.history;                  # --history override, already expanded
has Int $.threads;
has Str $.memory-limit;
has Str $.start-pipeline;
has Bool $.isolated = False;

has Str $!history-str = '';

my @SCREEN-ORDER = <dashboard sources pipeline run>;
my %SCREEN-TITLE = dashboard => 'Dashboard', sources => 'Sources',
    pipeline => 'Pipeline', run => 'Run';

has Terminal::UI $!ui;
has %!panes;
has %!layout;
has Lock $!state-lock .= new;
has Bool $!dirty = True;
has Bool $!running = False;
has Bool $!shut = False;
has Bool $!suspend = False;
has $!ticker;

has App::DuckETL::Store $!store;
has %!ducks;            # db path -> App::DuckETL::Duck
has %!loaded;           # pipeline path -> App::DuckETL::Pipeline

has @!pipelines;        # { path, name }
has Int $!pipeline-index = 0;
has @!catalog;          # { schema, table, type }
has @!runs;             # recent-run hashes
has @!nav-items;
has Int $!nav-index = 0;
has Int $!nav-offset = 0;
has Str $!focus = 'content';

has Str $!screen = 'dashboard';
has Int $!content-index = 0;
has Int $!content-offset = 0;
has Int $!detail-offset = 0;
has Int $!detail-max = 0;
has %!preview;
has Str $!preview-title = '';
has %!run-detail;

has $!run;              # App::DuckETL::Run
has Str $!run-id = '';
has Str $!run-status = 'idle';
has Instant $!run-start;
has Instant $!run-finished;
has Real $!run-elapsed = 0;
has Int $!run-rows = 0;
has Int $!last-second = -1;
has Str $!current-step = '-';
has @!steps;
has @!log;
has Str $!message = '';
has Str $!selected-step = '';

# --- M2 draft editing ------------------------------------------------------
has %!draft;            # name, database, steps (JSON-shaped hashes)
has Str $!draft-path = '';
has Bool $!draft-dirty = False;
has Int $!form-index = 0;
has %!edit;             # { mode => 'input', action, field, label, text, cursor }
has %!confirm;          # { action, index, path, id }
has Str $!catalog-db = '';

method run(--> Nil) {
    die 'ducketl tui requires an interactive terminal' unless $*IN.t;

    my $history-path = $!history.defined ?? $!history !! $!config.history-path;
    $history-path = $!config.expand-path($history-path) unless $history-path eq ':memory:';
    $!history-str = $history-path;
    $!store = App::DuckETL::Store.new(path => $history-path);
    LEAVE { self!shutdown }

    self!load-pipelines;
    self!load-runs;
    self!load-catalog;
    self!build-nav;

    $!ui = Terminal::UI.new;
    my $screen = $!ui.add-screen;
    die "terminal too small: {$screen.cols}x{$screen.rows} (need at least 50x10)"
        if $screen.cols < 50 || $screen.rows < 10;
    $screen.init($!ui);

    self!build-layout;
    $!focus = %!panes<nav> ?? 'nav' !! 'content';
    self!paint-all;
    self!start-ticker;
    $!running = True;

    while $!running {
        my $key = $!ui.get-key;
        last unless $key.defined;
        next if $key eq '';
        for self!split-keys($key) -> $one {
            $!state-lock.protect({ self!handle-key($one) });
        }
        self!render if $!dirty;
    }
}

#| Terminal::UI returns a whole read() chunk for plain text (for example
#| "extract" or several "j"s) and a named key for escape sequences.  Split
#| raw chunks so every character reaches the key handler.
method !split-keys(Str $key --> List) {
    state $named = <
        Enter Up Down Left Right Home End PageUp PageDown Tab Untab Delete
        Insert Esc F1 F2 F3 F4 F5 F6 F7 F8 F9 F10 F11 F12
    >.Set;
    return ($key,) if $key.chars <= 1 || $named{$key};
    $key.comb.map({
        when "\r" | "\n"     { 'Enter' }
        when "\t"            { 'Tab' }
        when "\c[127]" | "\b" { 'Delete' }
        default              { .Str }
    }).List;
}

# ---------------------------------------------------------------------------
# Lifecycle

method !start-ticker(--> Nil) {
    $!ticker = Supply.interval(0.1).tap: -> $ {
        unless $!shut {
            try { self!tick }
            if $! {
                my $message = 'ui error: ' ~ $!.message;
                $!state-lock.protect({ self!notify($message) });
            }
        }
    };
}

method !tick(--> Nil) {
    return if $!shut || $!suspend || !$!ui.defined;
    $!state-lock.protect({
        unless $!shut || $!suspend {
            if $!run.defined {
                my @events = $!run.drain;
                self!apply-events(@events) if @events;
                if $!run.finished {
                    my @rest = $!run.drain;
                    self!apply-events(@rest) if @rest;
                    $!run = Nil;
                    $!dirty = True;
                }
                else {
                    $!run-elapsed = self!elapsed;
                    my $second = $!run-elapsed.Int;
                    if $second != $!last-second {
                        $!last-second = $second;
                        $!dirty = True;
                    }
                }
            }

            if $!ui.screen.cols != %!layout<cols> || $!ui.screen.rows != %!layout<rows> {
                self!build-layout;
                $!dirty = True;
            }

            if $!dirty {
                self!paint-all;
                $!dirty = False;
            }
        }
    });
}

method !render(--> Nil) {
    return if $!shut;
    $!state-lock.protect({
        self!paint-all;
        $!dirty = False;
    });
}

method !shutdown(--> Nil) {
    return if $!shut;
    $!shut = True;
    $!running = False;

    if $!run.defined && !$!run.finished {
        $!run.cancel;
        my $deadline = now + 3;
        until $!run.finished || now > $deadline {
            sleep 0.05;
        }
        if !$!run.finished && $!run.can('kill') {
            try { $!run.kill }
        }
    }

    try { $!ui.shutdown } if $!ui.defined;
    try { $!store.close } if $!store.defined;
    for %!ducks.values -> $duck {
        try { $duck.close }
    }
}

# ---------------------------------------------------------------------------
# Layout

method !build-layout(--> Nil) {
    my $screen = $!ui.screen;
    my Int $cols = $screen.cols;
    my Int $rows = $screen.rows;
    if $cols < 50 || $rows < 10 {
        $!message = "terminal too small: {$cols}x{$rows}";
        return;
    }

    for $screen.frames -> $frame {
        $screen.remove-frame($frame);
    }

    my Int $footer-h = 3;
    my Int $main-h = $rows - $footer-h;
    my Int $nav-w = $cols >= 110 ?? 26 !! 0;
    my Int $status-w = $cols >= 80 ?? min(34, $cols div 4) !! 0;
    my Int $center-w = $cols - $nav-w - $status-w;

    my %panes;
    if $nav-w {
        my $frame = $screen.add-frame(
            top => 1, left => 1, width => $nav-w, height => $main-h, name => 'nav',
        );
        %panes<nav> = $frame.add-pane;
    }

    my Int $left = $nav-w + 1;
    my $center = $screen.add-frame(
        top => 1, left => $left, width => $center-w, height => $main-h, name => 'main',
    );
    my Int $inner = $main-h - 3;
    my Int $content-h = max(2, ($inner * 6) div 10);
    my Int $detail-h = $inner - $content-h;
    if $detail-h < 2 {
        $detail-h = 2;
        $content-h = max(2, $inner - 2);
    }
    my @panes = $center.add-panes(heights => [$content-h, $detail-h]);
    %panes<content> = @panes[0];
    %panes<detail> = @panes[1];

    if $status-w {
        my $frame = $screen.add-frame(
            top => 1, left => $left + $center-w, width => $status-w,
            height => $main-h, name => 'status',
        );
        %panes<status> = $frame.add-pane;
    }

    my $footer = $screen.add-frame(
        top => $main-h + 1, left => 1, width => $cols, height => 3, name => 'footer',
    );
    %panes<footer> = $footer.add-pane;

    %!panes = %panes;
    %!layout = %( cols => $cols, rows => $rows, narrow => $nav-w == 0 );
    $screen.refresh;
    $!dirty = True;
}

# ---------------------------------------------------------------------------
# Keys

method !handle-key(Str $key --> Nil) {
    if %!edit<mode> eq 'input' {
        self!handle-input($key);
        return;
    }
    if %!confirm.elems {
        self!handle-confirm($key);
        return;
    }

    given $key {
        when 'q' | "\c[3]" {
            if %!draft.elems && $!draft-dirty {
                %!confirm = %( action => 'quit' );
                $!dirty = True;
            }
            else {
                $!running = False;
            }
            return;
        }
        when '1' { self!switch-screen('dashboard'); return }
        when '2' { self!switch-screen('sources'); return }
        when '3' { self!switch-screen('run'); return }
        when '4' { self!switch-screen('pipeline'); return }
        when 'r' | 'F2' { self!start-run; return }
        when 'c' | 'F3' { self!cancel-run; return }
        when 'p' { self!preview-selected; return }
        when 'R' { self!reload-all; return }
        when '[' { self!cycle-pipeline(-1); return }
        when ']' { self!cycle-pipeline(1); return }
        when 'j' | 'Down' { self!move(1); return }
        when 'k' | 'Up' { self!move(-1); return }
        when 'Tab' { self!focus-next(1); return }
        when 'Untab' { self!focus-next(-1); return }
        when 'Enter' { self!activate; return }
        when 'a' { self!add-step; return }
        when 'd' { self!request-delete-step; return }
        when 'e' { self!edit-sql; return }
        when 's' { self!save; return }
        when 'o' { self!request-open; return }
        when 'n' { self!request-new; return }
        when 'Esc' {
            $!selected-step = '';
            $!detail-offset = 0;
            $!message = '';
            $!dirty = True;
            return;
        }
    }
}

method !switch-screen(Str $screen --> Nil) {
    return unless $screen eq any(@SCREEN-ORDER);
    $!screen = $screen;
    $!content-index = 0;
    $!content-offset = 0;
    $!detail-offset = 0;
    $!selected-step = '';
    $!form-index = 0;
    $!focus = %!panes<content> ?? 'content' !! $!focus;
    $!dirty = True;
}

method !focusable(--> List) {
    ('nav', 'content', 'detail').grep({ %!panes{$_}.defined }).List;
}

method !focus-next(Int $step --> Nil) {
    my @order = self!focusable;
    return unless @order.elems;
    my $i = @order.first($!focus, :k) // 0;
    $i = ($i + $step) % @order.elems;
    $i += @order.elems if $i < 0;
    $!focus = @order[$i];
    $!form-index = 0 if $!focus eq 'detail' && $!screen eq 'pipeline';
    $!dirty = True;
}

method !move(Int $step --> Nil) {
    given $!focus {
        when 'nav' {
            my Int $count = @!nav-items.grep({ !.<header> }).elems;
            return unless $count;
            $!nav-index = min($count - 1, max(0, $!nav-index + $step));
        }
        when 'content' {
            my %model = self!content-model;
            my Int $count = %model<entries>.elems;
            return unless $count;
            $!content-index = min($count - 1, max(0, $!content-index + $step));
            $!form-index = 0;
            $!detail-offset = 0;
        }
        when 'detail' {
            if $!screen eq 'pipeline' && %!draft.elems {
                my @fields = self!form-fields;
                return unless @fields;
                $!form-index = min(@fields.elems - 1, max(0, $!form-index + $step));
            }
            else {
                $!detail-offset = min($!detail-max, max(0, $!detail-offset - $step));
            }
        }
    }
    $!dirty = True;
}

method !activate(--> Nil) {
    given $!focus {
        when 'nav' { self!activate-nav }
        when 'content' { self!activate-content }
        when 'detail' { self!edit-selected-field if $!screen eq 'pipeline' }
        default { }
    }
    $!dirty = True;
}

method !nav-selected(--> Hash) {
    my @selectable = @!nav-items.grep({ !.<header> }).List;
    return %() unless @selectable.elems;
    @selectable[min($!nav-index, @selectable.elems - 1)];
}

method !activate-nav(--> Nil) {
    my %item = self!nav-selected;
    return unless %item.elems;
    given %item<kind> {
        when 'screen' { self!switch-screen(%item<value>) }
        when 'pipeline' {
            $!pipeline-index = %item<index>;
            $!selected-step = '';
            $!catalog-db = '';
            self!load-catalog;
            self!build-nav;
            self!switch-screen('sources');
            self!notify("pipeline: {%item<label>}");
        }
        when 'table' {
            self!switch-screen('sources');
            $!content-index = 0;
            self!show-preview(
                'select * from ' ~ qualified-target(%item<value>),
                %item<value>,
            );
        }
    }
}

method !activate-content(--> Nil) {
    my %model = self!content-model;
    my $entry = %model<entries>[$!content-index];
    return without $entry;
    given $!screen {
        when 'dashboard' { self!open-run($entry<value>) }
        when 'sources' { self!preview-entry($entry) }
        when 'pipeline' {
            if %!draft.elems {
                $!form-index = 0;
                $!detail-offset = 0;
                $!focus = 'detail';
            }
            else {
                my $index = @!pipelines.first({ .<path> eq $entry<value> }, :k);
                $!pipeline-index = $index if $index.defined;
                self!open-draft($entry<value>);
            }
        }
        when 'run' {
            $!selected-step = ($entry<value> // '').Str;
            $!detail-offset = 0;
        }
    }
}

# ---------------------------------------------------------------------------
# Data loading

method !load-pipelines(Bool :$keep-current = False --> Nil) {
    my $current-path = @!pipelines.elems ?? @!pipelines[$!pipeline-index]<path> !! '';
    my $base = $!base-dir.IO;
    my @found;
    @found.append: $base.dir.grep({ .f && .basename.ends-with('.json') }) if $base.d;
    for 'pipelines', 'examples/pipelines' -> $sub {
        my $dir = $base.add($sub);
        @found.append: $dir.dir.grep({ .f && .basename.ends-with('.json') }) if $dir.d;
    }
    if $!start-pipeline.defined && $!start-pipeline.chars {
        my $explicit = $!start-pipeline.IO.absolute;
        @found.push($explicit.IO);
        die "pipeline not found: {$explicit}" unless $explicit.IO.e;
    }

    my %seen;
    my @list;
    for @found -> $path {
        my $abs = $path.absolute;
        next if %seen{$abs}++;
        my $pipeline = %!loaded{$abs};
        unless $pipeline.defined {
            $pipeline = try { App::DuckETL::Pipeline.load($abs) };
            if $! {
                my $msg = $!.message;
                die "cannot load pipeline {$abs}: {$msg}"
                    if $!start-pipeline.defined
                    && $abs eq $!start-pipeline.IO.absolute;
                next;
            }
            %!loaded{$abs} = $pipeline;
        }
        @list.push(%( path => $abs, name => $pipeline.name ));
    }

    @!pipelines = @list.sort({ .<name> }).List;
    if @!pipelines.elems {
        my Str $want = $keep-current ?? $current-path !! ($!start-pipeline.defined ?? $!start-pipeline.IO.absolute !! '');
        my Int $index = 0;
        if $want.chars {
            my $found = @!pipelines.first({ .<path> eq $want }, :k);
            $index = $found if $found.defined;
        }
        $!pipeline-index = $index;
    }
    else {
        $!pipeline-index = 0;
    }
}

method !current-pipeline(--> App::DuckETL::Pipeline) {
    my $meta = @!pipelines[$!pipeline-index];
    return Nil without $meta;
    %!loaded{$meta<path>} // Nil;
}

method !db-path-for($pipeline --> Str) {
    return $!database if $!database.defined && $!database.chars;
    if $pipeline.defined && $pipeline.database.defined && $pipeline.database.chars {
        return $pipeline.resolve-path($pipeline.database);
    }
    my $database = $!config.database;
    return ':memory:' unless $database.defined && $database.chars;
    $!config.expand-path($database);
}

method !duck-for(Str $path, $pipeline? --> App::DuckETL::Duck) {
    return %!ducks{$path} if %!ducks{$path}:exists;
    my %options = path => $path;
    my $threads = self!pipeline-threads($pipeline);
    %options<threads> = $threads if $threads.defined;
    my $memory = self!pipeline-memory($pipeline);
    %options<memory-limit> = $memory if $memory.defined && $memory.chars;
    my $duck = App::DuckETL::Duck.new(|%options);
    %!ducks{$path} = $duck;
    $duck;
}

method !load-catalog(--> Nil) {
    @!catalog = ();
    return if $!isolated;
    my $pipeline = self!current-pipeline;
    my Str $path = $!catalog-db.chars ?? $!catalog-db !! self!db-path-for($pipeline);
    return if $path ne ':memory:' && !$path.IO.e;
    my $duck = try { self!duck-for($path, $pipeline) };
    unless $duck.defined {
        self!notify('catalog: ' ~ ($!.message // 'cannot open database'));
        return;
    }
    my $rows = try { $duck.catalog };
    unless $rows.defined {
        self!notify('catalog: ' ~ ($!.message // 'query failed'));
        return;
    }
    my @entries = $rows.map({
        %( schema => .[0].Str, table => .[1].Str, type => .[2].Str )
    });
    @!catalog = @entries.List;
    self!build-nav;
}

method !load-runs(--> Nil) {
    return unless $!store.defined;
    my $runs = try { $!store.recent-runs(20) };
    unless $runs.defined {
        self!notify('history: ' ~ ($!.message // 'query failed'));
        return;
    }
    @!runs = $runs.List;
}

method !reload-all(--> Nil) {
    self!load-pipelines(:keep-current);
    self!load-catalog;
    self!load-runs;
    self!build-nav;
    $!message = 'reloaded';
    $!dirty = True;
}

method !cycle-pipeline(Int $step --> Nil) {
    return unless @!pipelines.elems;
    my Int $n = @!pipelines.elems;
    $!pipeline-index = ($!pipeline-index + $step) % $n;
    $!pipeline-index += $n if $!pipeline-index < 0;
    $!selected-step = '';
    self!load-catalog;
    self!build-nav;
    self!notify('pipeline: ' ~ @!pipelines[$!pipeline-index]<name>);
}

# ---------------------------------------------------------------------------
# Running

method !start-run(--> Nil) {
    if $!run.defined && !$!run.finished {
        self!notify('a run is already active (c to cancel)');
        return;
    }

    my $pipeline;
    my Str $source-path = '';
    if $!screen eq 'pipeline' && %!draft.elems {
        $pipeline = self!draft-pipeline;
        return unless $pipeline.defined;
        $source-path = $!draft-path;
        if $!isolated && ($!draft-dirty || !$source-path.chars) {
            self!notify('save the draft before running an isolated worker');
            return;
        }
    }
    else {
        $pipeline = self!current-pipeline;
        unless $pipeline.defined {
            self!notify('no pipeline found; pass one on the command line');
            return;
        }
        my $meta = @!pipelines[$!pipeline-index];
        $source-path = ($meta<path> // '').Str if $meta;
    }

    my $path = self!db-path-for($pipeline);
    $!catalog-db = $path;

    if $!isolated {
        unless $source-path.chars {
            self!notify('an isolated run needs a saved pipeline file');
            return;
        }
        if $!history-str eq ':memory:' {
            self!notify('isolated mode needs a history file, not :memory:');
            return;
        }
        self!close-store;
        $!run = App::DuckETL::IsolatedRun.new(
            pipeline-path => $source-path,
            database      => $path,
            history       => $!history-str,
            threads       => self!pipeline-threads($pipeline),
            memory-limit  => self!pipeline-memory($pipeline),
        );
        self!prepare-run-ui($pipeline);
        my $started = try { $!run.start; True };
        unless $started {
            my Str $message = $!.message;
            $!run = Nil;
            self!open-store;
            self!notify('worker: ' ~ $message);
            return;
        }
        self!notify('isolated worker started; catalog disabled until it exits');
        return;
    }

    my $duck = try { self!duck-for($path, $pipeline) };
    unless $duck.defined {
        self!notify('database: ' ~ ($!.message // "cannot open {$path}"));
        return;
    }

    $!run = App::DuckETL::Run.new(
        :$pipeline, :$duck, store => $!store,
    );
    self!prepare-run-ui($pipeline);
    $!run.start;
}

method !prepare-run-ui($pipeline --> Nil) {
    @!steps = $pipeline.steps.map({
        %(
            id => .id, type => .type, status => 'pending', rows => 0,
            duration_ms => 0, sql => '', error => '',
        )
    }).List;
    $!run-id = '';
    $!run-status = 'starting';
    $!run-start = now;
    $!run-finished = Instant;
    $!run-elapsed = 0;
    $!run-rows = 0;
    $!last-second = -1;
    $!current-step = '-';
    $!selected-step = '';
    $!detail-offset = 0;
    @!log = ();
    @!log.push("starting {$pipeline.name}");
    self!switch-screen('run');
    $!message = '';
}

method !pipeline-threads($pipeline --> Mu) {
    $!threads
        // ($pipeline.defined && $pipeline.defaults<threads>.defined
            ?? $pipeline.defaults<threads>.Int !! $!config.threads);
}

method !pipeline-memory($pipeline --> Mu) {
    $!memory-limit
        // ($pipeline.defined && $pipeline.defaults<memory_limit>.defined
            ?? $pipeline.defaults<memory_limit>.Str !! $!config.memory-limit);
}

method !close-store(--> Nil) {
    return unless $!store.defined;
    try { $!store.close }
    $!store = Nil;
}

method !open-store(--> Nil) {
    return if $!store.defined || !$!history-str.chars;
    $!store = App::DuckETL::Store.new(path => $!history-str);
}

method !cancel-run(--> Nil) {
    unless $!run.defined && !$!run.finished {
        self!notify('no active run');
        return;
    }
    $!run.cancel;
    $!run-status = 'canceling';
    self!notify('cancel requested');
}

method !apply-events(@events --> Nil) {
    for @events -> %event {
        given %event<type> {
            when 'run-start' {
                $!run-id = (%event<run_id> // '').Str;
                $!run-status = 'running';
                self!log-line("run {$!run-id}: {%event<pipeline>} ({ %event<steps> } steps)");
            }
            when 'step-start' {
                my $i = @!steps.first({ .<id> eq %event<step_id> }, :k);
                if $i.defined {
                    @!steps[$i]{'status'} = 'running';
                }
                $!current-step = "{%event<index>}/{%event<total>} {%event<step_id>}";
                self!log-line("[{%event<index>}/{%event<total>}] {%event<step_id>} ({%event<step_type>}) ...");
            }
            when 'step-finish' {
                my $i = @!steps.first({ .<id> eq %event<step_id> }, :k);
                if $i.defined {
                    @!steps[$i]{'status'} = (%event<status> // 'failed').Str;
                    @!steps[$i]{'rows'} = (%event<rows> // 0).Int;
                    @!steps[$i]{'duration_ms'} = (%event<duration_ms> // 0).Int;
                    @!steps[$i]{'error'} = (%event<error> // '').Str;
                }
                $!run-rows = (%event<rows> // $!run-rows).Int;
                $!current-step = "{%event<step_id>} {%event<status>}";
                my $tail = %event<status> eq 'ok'
                    ?? "{%event<rows>} rows, {%event<duration_ms>}ms"
                    !! (%event<error> // %event<status>).Str;
                self!log-line("      {%event<status>} — {$tail}");
            }
            when 'run-finish' {
                $!run-status = (%event<status> // 'failed').Str;
                $!run-rows = (%event<rows> // $!run-rows).Int;
                $!run-elapsed = self!elapsed;
                $!run-finished = now;
                self!log-line(
                    "run {%event<status>}: {%event<rows>} rows in {%event<duration_ms>}ms",
                );
                self!load-runs;
                self!load-catalog;
            }
            when 'internal-finish' {
                my %result = %event<result> // %();
                self!open-store if $!isolated;
                $!run-status = (%result<status> // $!run-status).Str;
                $!run-rows = %result<rows>.Int if %result<rows>.defined;
                $!run-elapsed = self!elapsed;
                $!run-finished = now;
                if (%result<error> // '').chars {
                    self!log-line('run error: ' ~ %result<error>);
                }
                if $!run-status ne 'ok' {
                    my Str $status = $!run-status eq 'canceled' ?? 'canceled' !! 'failed';
                    for @!steps -> $step {
                        next unless $step<status> eq 'running';
                        $step<status> = $status;
                        $step<error> = (%result<error> // $!run-status).Str;
                    }
                }
                if $!isolated && $!run-status eq 'failed'
                    && $!run-id.chars && $!store.defined {
                    try {
                        $!store.fail-run(
                            $!run-id,
                            (%result<error> // 'worker failed').Str,
                            DateTime.now.Str,
                        );
                    }
                }
                self!load-runs;
            }
            when 'run-error' {
                $!run-status = 'failed';
                self!log-line('run error: ' ~ (%event<error> // 'unknown'));
            }
        }
        $!dirty = True;
    }
}

method !elapsed(--> Real) {
    return 0 without $!run-start;
    (now - $!run-start).Real;
}

method !log-line(Str $line --> Nil) {
    @!log.push($line);
    @!log.shift while @!log.elems > 500;
}

method !notify(Str $message --> Nil) {
    $!message = $message;
    self!log-line('! ' ~ $message);
    $!dirty = True;
}

# ---------------------------------------------------------------------------
# Models

method !build-nav(--> Nil) {
    my @items;
    @items.push(%( header => 'Screens' ));
    for @SCREEN-ORDER -> $screen {
        @items.push(%(
            kind => 'screen', value => $screen, label => %SCREEN-TITLE{$screen},
        ));
    }
    @items.push(%( header => 'Pipelines' ));
    for @!pipelines.kv -> $index, $pipeline {
        @items.push(%(
            kind => 'pipeline', index => $index, value => $pipeline<path>,
            label => $pipeline<name>,
        ));
    }
    @items.push(%( header => 'Catalog' ));
    my Int $tables = 0;
    for @!catalog -> %table {
        last if $tables >= 200;
        $tables++;
        my $name = %table<schema> ~ '.' ~ %table<table>;
        @items.push(%( kind => 'table', value => $name, label => $name ));
    }
    @!nav-items = @items;
    my Int $count = @items.grep({ !.<header> }).elems;
    $!nav-index = $count ?? min($!nav-index, $count - 1) !! 0;
}

method !content-model(--> Hash) {
    given $!screen {
        when 'dashboard' {
            my @entries = @!runs.map({
                %(
                    kind => 'run',
                    value => (.<run_id> // '').Str,
                    cells => [
                        short-id(.<run_id>),
                        (.<pipeline> // '-').Str,
                        (.<status> // '-').Str,
                        comma((.<rows> // 0).Int),
                        short-time(.<started_at>),
                    ],
                )
            }).List;
            return %( headers => <RUN PIPELINE STATUS ROWS STARTED>, entries => @entries );
        }
        when 'sources' {
            my @entries;
            for @!catalog -> %table {
                my $name = %table<schema> ~ '.' ~ %table<table>;
                @entries.push(%(
                    kind => 'table', value => $name,
                    cells => ['table', $name, %table<type>],
                ));
            }
            my $pipeline = self!current-pipeline;
            if $pipeline.defined {
                for $pipeline.steps.grep({ .type eq 'source' }) -> $step {
                    my $path = $step.path ~~ Positional
                        ?? $step.path.join(', ')
                        !! ($step.path // $step.table // '');
                    @entries.push(%(
                        kind => 'source', value => $step.id, step => $step,
                        cells => ['source', $step.id, ($step.format // '') ~ ' ' ~ $path],
                    ));
                }
            }
            return %( headers => <KIND NAME DETAIL>, entries => @entries.List );
        }
        when 'pipeline' {
            unless %!draft.elems {
                my @entries = @!pipelines.map({
                    %(
                        kind => 'file',
                        value => .<path>,
                        cells => [ .<name>, .<path> ],
                    )
                }).List;
                return %( headers => <PIPELINE PATH>, entries => @entries );
            }
            my @entries = %!draft<steps>.pairs.map({
                %(
                    kind => 'step',
                    value => .value<id>,
                    cells => [
                        (.key + 1).Str,
                        (.value<id> // '').Str,
                        (.value<type> // '').Str,
                        step-summary(.value),
                    ],
                )
            }).List;
            return %( headers => <# STEP TYPE DETAIL>, entries => @entries );
        }
        when 'run' {
            my @entries = @!steps.pairs.map({
                %(
                    kind => 'step', value => .value<id>,
                    cells => [
                        (.key + 1).Str,
                        .value<id>,
                        .value<type>,
                        .value<status>,
                        comma((.value<rows> // 0).Int),
                        (.value<duration_ms> // 0) > 0
                            ?? sprintf('%.2fs', .value<duration_ms> / 1000)
                            !! '-',
                    ],
                )
            }).List;
            return %( headers => <# STEP TYPE STATUS ROWS TIME>, entries => @entries );
        }
    }
    %( headers => (), entries => () );
}

method !status-model(--> Hash) {
    my $pipeline = self!current-pipeline;
    my $name = $pipeline.defined ?? $pipeline.name !! '-';
    my $rows = $!run-rows;
    %(
        pipeline => $name,
        run_id   => $!run-id.chars ?? $!run-id !! '-',
        status   => $!run-status,
        elapsed  => $!run-elapsed,
        rows     => $rows,
        rate     => $rows > 0 ?? rate($rows, $!run-elapsed) !! '-',
        step     => $!current-step,
        error    => '',
    );
}

# ---------------------------------------------------------------------------
# Painting

method !paint-pane($pane, @lines --> Nil) {
    return without $pane;
    my Int $width = $pane.width;
    my Int $height = $pane.height;
    return if $width <= 0 || $height <= 0;
    $pane.clear;
    my Int $count = min(@lines.elems, $height);
    for ^$count -> $i {
        $pane.put(fit(@lines[$i], $width), :!scroll-ok);
    }
}

method !paint-all(--> Nil) {
    return unless %!panes;
    self!paint-nav;
    self!paint-content;
    self!paint-detail;
    self!paint-status;
    self!paint-footer;
}

method !paint-nav(--> Nil) {
    my $pane = %!panes<nav>;
    return without $pane;

    my @selectable = @!nav-items.grep({ !.<header> }).List;
    my Int $index = @selectable.elems ?? min($!nav-index, @selectable.elems - 1) !! 0;
    my $selected = @selectable.elems ?? @selectable[$index] !! Nil;

    my @all;
    for @!nav-items -> %item {
        if %item<header> {
            @all.push('── ' ~ %item<header>);
            next;
        }
        my $mark = ($!focus eq 'nav' && %item === $selected) ?? '> ' !! '  ';
        my $indent = %item<kind> eq 'screen' ?? '' !! '  ';
        @all.push($mark ~ $indent ~ (%item<label> // ''));
    }

    my Int $height = $pane.height;
    my Int $max-offset = max(0, @all.elems - $height);
    my Int $offset = min($!nav-offset, $max-offset);
    my Int $selected-line = @!nav-items.first({ $_ === $selected }, :k) // 0;
    $offset = $selected-line if $selected-line < $offset;
    $offset = $selected-line - $height + 1 if $selected-line >= $offset + $height;
    $offset = max(0, min($offset, $max-offset));
    $!nav-offset = $offset;

    my @view = @all[$offset ..^ min(@all.elems, $offset + $height)];
    self!paint-pane($pane, @view);
}

method !paint-content(--> Nil) {
    my $pane = %!panes<content>;
    return without $pane;
    my Int $width = $pane.width;
    my Int $height = $pane.height;

    my @lines;
    if %!layout<narrow> {
        my $pipeline = self!current-pipeline;
        my $name = %!draft.elems ?? (%!draft<name> // 'draft').Str
            !! ($pipeline.defined ?? $pipeline.name !! '-');
        @lines.push(fit("ducketl · {%SCREEN-TITLE{$!screen}} · pipeline: {$name}  ([ ] switch)", $width));
    }
    @lines.push(head-line(%SCREEN-TITLE{$!screen}, $width));

    my %model = self!content-model;
    my Int $rows-height = max(0, $height - @lines.elems - 2);
    my Int $count = %model<entries>.elems;
    my Int $offset = $!content-offset;
    if $count && $rows-height > 0 {
        $offset = min($offset, max(0, $count - $rows-height));
        $offset = $!content-index if $!content-index < $offset;
        $offset = $!content-index - $rows-height + 1 if $!content-index >= $offset + $rows-height;
        $offset = max(0, min($offset, max(0, $count - $rows-height)));
    }
    $!content-offset = $offset;

    my @cells = %model<entries>.map(*.<cells>);
    @lines.append(table-lines(
        %model<headers>, @cells,
        width => $width, select => ($!focus eq 'content' ?? $!content-index !! -1),
        offset => $offset, height => $rows-height,
    ));
    self!paint-pane($pane, @lines);
}

method !detail-lines(--> List) {
    my $pane = %!panes<detail>;
    my Int $width = $pane.defined ?? $pane.width !! 80;
    my Int $height = $pane.defined ?? $pane.height !! 10;
    my @lines;

    given $!screen {
        when 'pipeline' {
            unless %!draft.elems {
                @lines.push('No draft. Press n for a new pipeline, or Enter a file to open it.');
                return @lines.List;
            }
            my Str $name = (%!draft<name> // 'untitled').Str;
            @lines.push(head-line(
                'Draft ' ~ $name ~ ($!draft-dirty ?? ' *' !! ''), $width,
            ));
            my @fields = self!form-fields;
            my Int $window = max(3, min(@fields.elems, $height - 5));
            my Int $start = min($!detail-offset, max(0, @fields.elems - $window));
            $start = $!form-index if $!form-index < $start;
            $start = $!form-index - $window + 1 if $!form-index >= $start + $window;
            $start = max(0, min($start, max(0, @fields.elems - $window)));
            $!detail-offset = $start;
            my Int $stop = min(@fields.elems, $start + $window);
            for @fields[$start ..^ $stop].kv -> $i, %field {
                my Int $index = $start + $i;
                my $mark = ($!focus eq 'detail' && $index == $!form-index) ?? '> ' !! '  ';
                @lines.push(fit(
                    $mark ~ fit((%field<label> // '').Str, 13) ~ ' '
                    ~ self!field-display(%field), $width));
            }
            my %step = %!draft<steps>[$!content-index] // %();
            if (%step<sql> // '').chars {
                @lines.push(fit('SQL (' ~ (%*ENV<EDITOR> // 'vi') ~ ' via e)', $width));
                for (%step<sql>.Str).lines -> $line {
                    @lines.push(fit('  ' ~ $line, $width));
                }
            }
            @lines.push(fit('a add  d delete  s save  e editor  r run', $width));
        }
        when 'dashboard' {
            my %run = %!run-detail<run> // %();
            unless %run.elems {
                @lines.push('Select a run in Dashboard and press Enter.');
                return @lines.List;
            }
            @lines.push(head-line('Run ' ~ short-id(%run<run_id>), $width));
            @lines.push(fit(
                "pipeline {%run<pipeline>}  status {%run<status>}"
                ~ "  rows {comma((%run<rows> // 0).Int)}", $width));
            @lines.push(fit(
                "started {%run<started_at> // '-'}  finished {%run<finished_at> // '-'}",
                $width));
            if (%run<error> // '').chars {
                @lines.push(fit('error: ' ~ %run<error>, $width));
            }
            my @rows = (%!run-detail<steps> // ()).map({
                [ .<step_id>, .<step_type>, .<status>, comma((.<rows> // 0).Int) ]
            });
            @lines.append(table-lines(
                <STEP TYPE STATUS ROWS>, @rows,
                width => $width, height => max(0, $height - @lines.elems - 2),
            ));
        }
        when 'sources' {
            my @names = (%!preview<names> // ()).List;
            unless @names.elems {
                @lines.push('No preview. Select a table or source and press p.');
                return @lines.List;
            }
            @lines.push(head-line($!preview-title, $width));
            my Int $columns = min(@names.elems, max(1, ($width - 2) div 9));
            my @headers = @names[0 ..^ $columns];
            my @rows = (%!preview<rows> // ()).map({
                [ |.[0 ..^ $columns] ]
            });
            @lines.append(table-lines(
                @headers, @rows,
                width => $width, height => max(0, $height - @lines.elems - 2),
            ));
        }
        when 'run' {
            if $!selected-step.chars {
                my %step = @!steps.first({ .<id> eq $!selected-step }) // %();
                @lines.push(head-line('Step ' ~ $!selected-step, $width));
                @lines.push(fit('type   ' ~ (%step<type> // '-'), $width));
                @lines.push(fit('status ' ~ (%step<status> // '-'), $width));
                @lines.push(fit('rows   ' ~ comma((%step<rows> // 0).Int), $width));
                for (%step<sql> // '').lines -> $line {
                    @lines.push(fit($line, $width));
                }
                for (%step<error> // '').lines -> $line {
                    @lines.push(fit('error: ' ~ $line, $width));
                }
            }
            else {
                @lines.push(head-line('Log', $width));
                @lines.append(@!log);
            }
        }
    }
    @lines.List;
}

method !paint-detail(--> Nil) {
    my $pane = %!panes<detail>;
    return without $pane;
    my @all = self!detail-lines;
    my Int $height = $pane.height;
    my Int $max-offset = max(0, @all.elems - $height);
    $!detail-max = $max-offset;
    my Int $offset = min($!detail-offset, $max-offset);
    $!detail-offset = $offset;

    my Int $start;
    if $!screen eq 'pipeline' {
        $start = 0;
    }
    elsif $!screen eq 'run' && !$!selected-step.chars {
        $start = max(0, @all.elems - $height - $offset);
    }
    else {
        $start = min($offset, $max-offset);
    }
    my @view = @all[$start ..^ min(@all.elems, $start + $height)];
    self!paint-pane($pane, @view);
}

method !paint-status(--> Nil) {
    my $pane = %!panes<status>;
    if $pane.defined {
        my @lines = head-line('Run', $pane.width);
        @lines.append(status-lines(self!status-model, width => $pane.width));
        self!paint-pane($pane, @lines);
        return;
    }
    # Narrow layout: fold the run summary into the footer.
}

method !paint-footer(--> Nil) {
    my $pane = %!panes<footer>;
    return without $pane;
    my Int $width = $pane.width;
    my Str $text;
    if %!confirm.elems {
        $text = self!confirm-text;
    }
    elsif %!edit<mode> eq 'input' {
        $text = self!input-text;
    }
    elsif $!message.chars {
        $text = $!message;
    }
    else {
        $text = self!hint-text;
    }
    self!paint-pane($pane, [$text]);
}

method !hint-text(--> Str) {
    if $!screen eq 'pipeline' {
        return 'Pipeline  a add  d delete  Enter edit  e editor  s save  o open'
            ~ '  n new  r run  Tab focus  q quit';
    }
    if %!panes<status>.defined {
        return '1 dash  2 sources  3 run  4 pipeline  Tab focus  j/k move'
            ~ '  Enter open  r run  c cancel  p preview  [ ] pipeline  R reload  q quit';
    }
    my %status = self!status-model;
    "{%status<status>}  {%status<step>}  {comma(%status<rows>.Int)} rows"
        ~ '  |  r run  c cancel  p preview  4 pipeline  q quit';
}

method !input-text(--> Str) {
    my Str $text = (%!edit<text> // '').Str;
    my Int $cursor = min((%!edit<cursor> // 0).Int, $text.chars);
    my Str $before = $text.substr(0, $cursor);
    my Str $after = $text.substr($cursor);
    (%!edit<label> // 'input').Str ~ ': ' ~ $before ~ '|' ~ $after
        ~ '   Enter ok  Esc cancel';
}

method !confirm-text(--> Str) {
    given (%!confirm<action> // '').Str {
        when 'delete-step' {
            "Delete step '{%!confirm<id> // ''}'? y/n";
        }
        when 'quit'  { 'Unsaved draft changes. Quit? y/n' }
        when 'new'   { 'Discard draft and start a new pipeline? y/n' }
        when 'open'  { 'Discard draft and open the pipeline file? y/n' }
        default      { 'Confirm? y/n' }
    }
}

# ---------------------------------------------------------------------------
# Draft editing (M2)

method !form-fields(--> List) {
    return () unless %!draft.elems;
    my @fields = (
        %( scope => 'pipeline', key => 'name', label => 'name' ),
        %( scope => 'pipeline', key => 'database', label => 'database' ),
        %( scope => 'pipeline', key => 'extensions', label => 'extensions' ),
    );
    my $step = %!draft<steps>[$!content-index];
    if $step.defined {
        for field-specs($step) -> $key {
            @fields.push(%(
                scope => 'step', index => $!content-index, key => $key, label => $key,
            ));
        }
    }
    @fields.List;
}

method !field-value(%field --> Mu) {
    given (%field<scope> // '').Str {
        when 'pipeline' { %!draft{%field<key>} }
        when 'step' {
            my %step = %!draft<steps>[%field<index>] // %();
            if %field<key> eq 'materialize' && !(%step<materialize>:exists) {
                return True;
            }
            %step{%field<key>};
        }
        default { Any }
    }
}

method !set-field-value(%field, $value --> Nil) {
    given (%field<scope> // '').Str {
        when 'pipeline' {
            if $value.defined {
                %!draft{%field<key>} = $value;
            }
            else {
                %!draft{%field<key>}:delete;
            }
        }
        when 'step' {
            my $step = %!draft<steps>[%field<index>];
            if $value.defined {
                $step{%field<key>} = $value;
            }
            else {
                $step{%field<key>}:delete;
            }
        }
    }
}

method !field-display(%field --> Str) {
    my $value = self!field-value(%field);
    given field-kind((%field<key> // '').Str) {
        when 'json' {
            return '(empty)' unless $value ~~ Hash && $value.elems;
            return to-json($value, :!pretty);
        }
        when 'bool' { return (so $value) ?? 'true' !! 'false' }
        when 'list' {
            return ($value ~~ Positional)
                ?? $value.join(', ')
                !! ($value.defined ?? $value.Str !! '');
        }
        default { return ($value.defined) ?? $value.Str !! '' }
    }
}

method !step-draft(App::DuckETL::Pipeline::Step $step --> Hash) {
    my %hash =
        id          => $step.id,
        type        => $step.type,
        materialize => $step.materialize,
    ;
    %hash<format> = $step.format if $step.format.defined;
    %hash<path> = $step.path if $step.path.defined;
    %hash<table> = $step.table if $step.table.defined;
    %hash<sql> = $step.sql if $step.sql.defined;
    %hash<expect> = $step.expect if $step.expect.defined;
    %hash<op> = $step.op if $step.op.defined;
    %hash<target> = $step.target if $step.target.defined;
    %hash<mode> = $step.mode if $step.mode.defined;
    %hash<key> = $step.key.List if $step.key.elems;
    %hash<watermark> = $step.watermark if $step.watermark.defined;
    %hash<partition_by> = $step.partition_by.List if $step.partition_by.elems;
    %hash<description> = $step.description if $step.description.defined;
    %hash<options> = $step.options if $step.options.elems;
    %hash;
}

method !new-draft(--> Nil) {
    %!draft = %( name => 'untitled', database => '', extensions => [], steps => [] );
    $!draft-path = '';
    $!draft-dirty = False;
    $!content-index = 0;
    $!content-offset = 0;
    $!detail-offset = 0;
    $!form-index = 0;
    %!edit = ();
    %!confirm = ();
    $!catalog-db = '';
    $!screen = 'pipeline';
    $!focus = 'content';
    $!message = 'new draft';
    $!dirty = True;
}

method !request-new(--> Nil) {
    if %!draft.elems && $!draft-dirty {
        %!confirm = %( action => 'new' );
        $!dirty = True;
        return;
    }
    self!new-draft;
}

method !open-draft(Str $path --> Nil) {
    my Str $abs = $path.IO.absolute;
    my $pipeline = %!loaded{$abs};
    unless $pipeline.defined {
        $pipeline = try { App::DuckETL::Pipeline.load($abs) };
        if $! {
            self!notify('cannot open ' ~ $abs ~ ': ' ~ $!.message);
            return;
        }
        %!loaded{$abs} = $pipeline;
    }
    %!draft = %(
        name       => $pipeline.name,
        database   => ($pipeline.database // '').Str,
        extensions => $pipeline.extensions.List,
        steps      => $pipeline.steps.map({ self!step-draft($_) }).Array,
    );
    $!draft-path = $abs;
    $!draft-dirty = False;
    $!screen = 'pipeline';
    $!content-index = 0;
    $!content-offset = 0;
    $!detail-offset = 0;
    $!form-index = 0;
    %!edit = ();
    %!confirm = ();
    $!focus = 'content';
    $!catalog-db = self!db-path-for($pipeline);
    self!load-catalog;
    self!notify('opened ' ~ $abs);
    $!dirty = True;
}

method !request-open(--> Nil) {
    my $meta = @!pipelines[$!pipeline-index];
    unless $meta {
        self!notify('no pipeline file selected');
        return;
    }
    if %!draft.elems && $!draft-dirty {
        %!confirm = %( action => 'open', path => $meta<path> );
        $!dirty = True;
        return;
    }
    self!open-draft($meta<path>);
}

method !add-step(--> Nil) {
    unless $!screen eq 'pipeline' {
        self!notify('switch to the Pipeline screen (4) to add steps');
        return;
    }
    self!new-draft unless %!draft.elems;
    my Str $id = next-step-id(%!draft<steps>);
    %!draft<steps>.push: default-step($id);
    $!content-index = %!draft<steps>.elems - 1;
    $!content-offset = 0;
    $!form-index = 0;
    $!detail-offset = 0;
    self!draft-changed;
}

method !request-delete-step(--> Nil) {
    unless $!screen eq 'pipeline' && %!draft.elems {
        self!notify('open the Pipeline screen (4) first');
        return;
    }
    my $step = %!draft<steps>[$!content-index];
    return without $step;
    %!confirm = %(
        action => 'delete-step',
        index  => $!content-index,
        id     => ($step<id> // '').Str,
    );
    $!dirty = True;
}

method !delete-step(Int $index --> Nil) {
    return unless %!draft.elems && %!draft<steps>.elems;
    %!draft<steps>.splice($index, 1);
    $!content-index = max(0, min($index, %!draft<steps>.elems - 1));
    $!form-index = 0;
    $!detail-offset = 0;
    self!draft-changed;
}

method !draft-changed(--> Nil) {
    $!draft-dirty = True;
    $!message = '';
    $!dirty = True;
}

method !clamp-form-index(--> Nil) {
    my @fields = self!form-fields;
    $!form-index = @fields.elems ?? min($!form-index, @fields.elems - 1) !! 0;
}

method !ensure-step-defaults(Int $index --> Nil) {
    my $step = %!draft<steps>[$index];
    return without $step;
    given ($step<type> // 'source').Str {
        when 'source' {
            $step<format> //= 'csv';
            given ($step<format> // 'csv').Str {
                when 'csv' | 'parquet' | 'json' {
                    $step<path> //= '';
                    $step<options> //= %();
                }
                when 'table' { $step<table> //= '' }
                when 'sql'   { $step<sql> //= '' }
            }
        }
        when 'sql'    { $step<sql> //= '' }
        when 'assert' { $step<sql> //= ''; $step<op> //= 'eq' }
        when 'sink'   { $step<target> //= ''; $step<mode> //= 'replace' }
    }
}

method !edit-selected-field(--> Nil) {
    unless $!screen eq 'pipeline' && %!draft.elems {
        self!notify('open the Pipeline screen (4) to edit fields');
        return;
    }
    my @fields = self!form-fields;
    return unless @fields;
    $!form-index = min($!form-index, @fields.elems - 1);
    my %field = @fields[$!form-index];

    given field-kind((%field<key> // '').Str) {
        when 'enum' {
            my $next = cycle-enum(%field<key>, self!field-value(%field));
            self!set-field-value(%field, $next);
            self!ensure-step-defaults(%field<index>.Int) if %field<scope> eq 'step';
            self!clamp-form-index;
            self!draft-changed;
        }
        when 'bool' {
            self!set-field-value(%field, !so self!field-value(%field));
            self!draft-changed;
        }
        default {
            my $value = self!field-value(%field);
            my Str $text =
                $value ~~ Positional ?? $value.join(', ')
                !! ($value.defined ?? $value.Str !! '');
            %!edit = %(
                mode   => 'input',
                action => 'field',
                field  => %field,
                label  => (%field<label> // 'value').Str,
                text   => $text,
                cursor => $text.chars,
            );
            $!dirty = True;
        }
    }
}

method !handle-input(Str $key --> Nil) {
    given $key {
        when 'Enter' {
            self!commit-input;
            return;
        }
        when 'Esc' {
            %!edit = ();
            $!dirty = True;
            return;
        }
        when 'Delete' | 'Backspace' | "\b" | "\c[127]" {
            my Int $cursor = (%!edit<cursor> // 0).Int;
            if $cursor > 0 {
                my Str $text = (%!edit<text> // '').Str;
                %!edit<text> = $text.substr(0, $cursor - 1) ~ $text.substr($cursor);
                %!edit<cursor> = $cursor - 1;
            }
        }
        when 'Left' {
            %!edit<cursor> = max(0, (%!edit<cursor> // 0).Int - 1);
        }
        when 'Right' {
            %!edit<cursor> = min(
                (%!edit<text> // '').Str.chars,
                (%!edit<cursor> // 0).Int + 1,
            );
        }
        when 'Home' { %!edit<cursor> = 0 }
        when 'End'   { %!edit<cursor> = (%!edit<text> // '').Str.chars }
        default {
            my Str $text = $key.Str;
            if $text.chars && $text.ord >= 32 && $text !~~ /<:Cc>/ {
                my Int $cursor = (%!edit<cursor> // 0).Int;
                my Str $current = (%!edit<text> // '').Str;
                %!edit<text> = $current.substr(0, $cursor)
                    ~ $text ~ $current.substr($cursor);
                %!edit<cursor> = $cursor + $text.chars;
            }
        }
    }
    $!dirty = True;
}

method !commit-input(--> Nil) {
    if (%!edit<action> // '') eq 'save-path' {
        my Str $path = (%!edit<text> // '').Str.trim;
        %!edit = ();
        if $path.chars {
            self!save-draft($path);
        }
        else {
            self!notify('save path required');
        }
        return;
    }

    my %field = %!edit<field> // %();
    my Str $text = (%!edit<text> // '').Str;
    my $value;

    given field-kind((%field<key> // '').Str) {
        when 'int' {
            if !$text.chars {
                $value = Any;
            }
            elsif $text ~~ /^ '-'? \d+ $/ {
                $value = $text.Int;
            }
            else {
                self!notify('expect must be an integer');
                return;
            }
        }
        when 'list' {
            $value = $text.split(',').map(*.trim).grep(*.chars).List;
        }
        when 'json' {
            if !$text.trim.chars {
                $value = %();
            }
            else {
                my $parsed = try { from-json($text) };
                if $! {
                    self!notify('options must be valid JSON');
                    return;
                }
                unless $parsed ~~ Hash {
                    self!notify('options must be a JSON object');
                    return;
                }
                $value = $parsed;
            }
        }
        default { $value = $text }
    }

    self!set-field-value(%field, $value);
    %!edit = ();
    self!clamp-form-index;
    self!draft-changed;
}

method !handle-confirm(Str $key --> Nil) {
    given $key {
        when 'y' | 'Y' {
            my %action = %!confirm;
            %!confirm = ();
            self!run-confirm(%action);
            return;
        }
        when 'n' | 'N' | 'Esc' {
            %!confirm = ();
            $!message = '';
            $!dirty = True;
            return;
        }
    }
}

method !run-confirm(%action --> Nil) {
    given (%action<action> // '').Str {
        when 'quit' { $!running = False }
        when 'new'  { self!new-draft }
        when 'open' { self!open-draft(%action<path>) }
        when 'delete-step' { self!delete-step(%action<index>.Int) }
    }
}

method !save(--> Nil) {
    unless %!draft.elems {
        self!notify('no draft to save');
        return;
    }
    if $!draft-path.chars {
        self!save-draft($!draft-path);
        return;
    }
    my Str $slug = (%!draft<name> // 'pipeline').Str;
    $slug = $slug.subst(/<-[A..Z a..z 0..9 _ -]>/, '-', :g);
    $slug = 'pipeline' unless $slug.chars;
    my Str $path = $!base-dir.IO.add('pipelines').add($slug ~ '.json').Str;
    %!edit = %(
        mode   => 'input',
        action => 'save-path',
        label  => 'save as',
        text   => $path,
        cursor => $path.chars,
    );
    $!dirty = True;
}

method !save-draft(Str $path --> Nil) {
    my %data = pipeline-data(%!draft);
    my $target = $path.IO.absolute.IO;
    my Str $target-str = $target.Str;
    my Str $temp = $target-str ~ '.tmp-' ~ $*PID ~ '-' ~ (^1000000).pick;

    {
        $target.parent.mkdir unless $target.parent.e;
        $temp.IO.spurt(to-json(%data, :pretty));
        CATCH {
            default {
                self!notify('save failed: ' ~ .message);
                $temp.IO.unlink if $temp.IO.e;
                return;
            }
        }
    }

    my $pipeline = try { App::DuckETL::Pipeline.load($temp) };
    if $! {
        my Str $message = $!.message;
        $temp.IO.unlink if $temp.IO.e;
        self!notify('save failed: ' ~ $message);
        return;
    }

    my Bool $moved = False;
    try {
        $temp.IO.rename($target.Str);
        $moved = True;
    }
    unless $moved {
        $temp.IO.unlink if $temp.IO.e;
        self!notify("save failed: cannot rename {$temp}");
        return;
    }

    $!draft-path = $target.Str;
    $!draft-dirty = False;
    %!loaded{$target.Str} = $pipeline;

    self!load-pipelines(:keep-current);
    unless @!pipelines.first({ .<path> eq $target.Str }) {
        @!pipelines.push(%( path => $target.Str, name => $pipeline.name ));
        @!pipelines = @!pipelines.sort({ .<name> }).List;
    }
    my $index = @!pipelines.first({ .<path> eq $target.Str }, :k);
    $!pipeline-index = $index if $index.defined;
    $!catalog-db = self!db-path-for($pipeline);
    self!load-catalog;
    self!build-nav;
    self!notify('saved ' ~ $target.Str);
}

method !draft-pipeline(--> App::DuckETL::Pipeline) {
    my %data = pipeline-data(%!draft);
    my Str $path = $!draft-path.chars ?? $!draft-path !! '<draft>';
    my Str $base = $!draft-path.chars
        ?? $!draft-path.IO.parent.absolute
        !! $!base-dir.IO.absolute;
    my $pipeline = try {
        App::DuckETL::Pipeline.from-data(%data, :$path, base-dir => $base);
    };
    if $! {
        self!notify('invalid draft: ' ~ $!.message);
        return Nil;
    }
    $pipeline;
}

method !edit-sql(--> Nil) {
    unless $!screen eq 'pipeline' && %!draft.elems {
        self!notify('open the Pipeline screen (4) to edit SQL');
        return;
    }
    my $step = %!draft<steps>[$!content-index];
    unless $step {
        self!notify('select a step first');
        return;
    }
    my Str $sql = ($step<sql> // '').Str;
    my Str $editor = '';
    for <VISUAL EDITOR> -> $variable {
        my $value = %*ENV{$variable};
        if $value.defined && $value.Str.trim.chars {
            $editor = $value.Str.trim;
            last;
        }
    }
    $editor = 'vi' unless $editor.chars;
    my @command = $editor.words;
    @command = ('vi') unless @command.elems;

    my $tmp = $*TMPDIR.add("ducketl-sql-{$*PID}-{(^1000000).pick}.sql");
    $tmp.spurt($sql);
    my Int $status = -1;

    my Str $editor-error = self!with-editor(-> {
        my $proc = try { run |@command, $tmp.Str };
        if $proc.defined {
            $status = $proc.exitcode;
        }
    });

    my Str $new = $tmp.e ?? $tmp.slurp !! $sql;
    $tmp.unlink if $tmp.e;
    if $status != 0 {
        self!notify(
            "editor exited {$status}; SQL unchanged"
            ~ ($editor-error.chars ?? ": {$editor-error}" !! '')
        );
        return;
    }
    $step<sql> = $new;
    self!draft-changed;
    self!notify('SQL updated');
}

method !with-editor(&code --> Str) {
    $!suspend = True;
    try { $!ui.input.shutdown }
    try { $!ui.screen.shutdown }

    my $error;
    {
        code();
        CATCH { default { $error = .message } }
    }

    try { $!ui.screen.init($!ui) }
    self!build-layout;
    $!suspend = False;
    $!dirty = True;
    self!paint-all;
    $!dirty = False;
    ($error // '').Str;
}

# ---------------------------------------------------------------------------
# Small formatting helpers used by the models

sub short-id($value --> Str) {
    my $id = $value.defined ?? $value.Str !! '';
    $id.chars > 21 ?? $id.substr(0, 21) !! $id;
}

sub short-time($value --> Str) {
    return '-' without $value;
    my $text = $value.Str;
    $text.chars > 19 ?? $text.substr(0, 19) !! $text;
}

method !source-preview-sql(App::DuckETL::Pipeline::Step $step --> Str) {
    my $format = $step.format // '';
    given $format {
        when 'csv' | 'parquet' | 'json' {
            my $pipeline = self!current-pipeline;
            my $function = $format eq 'csv'
                ?? 'read_csv_auto'
                !! $format eq 'parquet' ?? 'read_parquet' !! 'read_json_auto';
            my $argument;
            if $step.path ~~ Positional {
                $argument = '[' ~ $step.path.map({
                    sql-literal($pipeline.resolve-path($_.Str))
                }).join(', ') ~ ']';
            }
            else {
                $argument = sql-literal($pipeline.resolve-path($step.path.Str));
            }
            return 'select * from ' ~ $function ~ '(' ~ $argument ~ ')';
        }
        when 'table' {
            my $target = $step.table.defined && $step.table.chars
                ?? $step.table !! $step.path.Str;
            return 'select * from ' ~ qualified-target($target);
        }
        when 'sql' {
            return $step.sql // '';
        }
    }
    '';
}

method !show-preview(Str $sql, Str $title --> Nil) {
    return unless $sql.chars;
    if $!isolated {
        self!notify('isolated mode: the worker owns the database; preview disabled');
        return;
    }
    my $pipeline = self!current-pipeline;
    my $duck = try { self!duck-for(self!db-path-for($pipeline), $pipeline) };
    unless $duck.defined {
        self!notify('preview: ' ~ ($!.message // 'cannot open database'));
        return;
    }
    my %preview = try { $duck.preview($sql, 100) };
    if $! {
        self!notify('preview failed: ' ~ $!.message);
        return;
    }
    %!preview = %preview;
    $!preview-title = $title ~ ' (limit 100)';
    $!detail-offset = 0;
    $!dirty = True;
}

method !preview-entry(Hash $entry --> Nil) {
    my Str $sql;
    given $entry<kind> {
        when 'table' {
            $sql = 'select * from ' ~ qualified-target($entry<value>);
        }
        when 'source' {
            $sql = self!source-preview-sql($entry<step>);
        }
        default {
            self!notify('nothing to preview');
            return;
        }
    }
    unless $sql.chars {
        self!notify('this source cannot be previewed directly');
        return;
    }
    self!show-preview($sql, $entry<value>);
}

method !preview-selected(--> Nil) {
    unless $!screen eq 'sources' {
        self!notify('switch to Sources (2) to preview');
        return;
    }
    my %model = self!content-model;
    my $entry = %model<entries>[$!content-index];
    unless $entry {
        self!notify('nothing selected');
        return;
    }
    self!preview-entry($entry);
}

method !open-run(Str $run-id --> Nil) {
    unless $!store.defined {
        self!notify('history is locked by the isolated worker');
        return;
    }
    my %detail = try { $!store.run-detail($run-id) };
    if $! {
        self!notify('history: ' ~ $!.message);
        return;
    }
    unless %detail.elems {
        self!notify('run not found: ' ~ $run-id);
        return;
    }
    %!run-detail = %detail;
    $!detail-offset = 0;
    $!dirty = True;
}
