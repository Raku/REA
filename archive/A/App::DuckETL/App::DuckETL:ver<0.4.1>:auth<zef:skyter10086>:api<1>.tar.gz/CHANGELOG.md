# Changelog

## 0.4.1 — 2026-11-01

### 修复

- `tui --isolated` 的 worker 子进程不再假设 `$?FILE` 旁边就是 `lib/`。模块从仓库加载
  （`sources/<sha>` 布局）时，或 `bin/ducketl` 是安装后的 sh/bat 包装脚本时，旧代码让 worker
  直接退出：`zef install` 的测试阶段因此报 `worker exited with code 1`，装好的 `ducketl tui
  --isolated` 也起不来。worker 现在复用脚本所属 checkout 的 `lib/` 加当前进程的 repository
  链；没有脚本路径时用 `-e 'use App::DuckETL::CLI; ...'` 引导。
- `tui` 以外的命令不再加载 `Terminal::UI`：CLI 只在 `tui` 分支里 `require` TUI，没装 TUI 时
  `run` / `worker` / `validate` / `list` / `show` 照常可用。
- 新增 `App::DuckETL::Repo`（`repo-includes`）：把当前进程的 repository 链（checkout、安装
  仓库、`zef` 的 staging 仓库）转成子进程的 `-I` 参数，`IsolatedRun` 与 CLI 测试共用。

### 安装

- README 补充：依赖装在默认 `site` 仓库以外（`RAKULIB` 指定）时，要用
  `zef install --install-to=inst#/path/to/repo .`，否则安装预编译阶段会报
  `Could not find Terminal::UI`。
- README 补充：Windows 上 `DB::DuckDB` 0.9.1 归档里的中文文件名会让 `zef` 解压阶段报
  `Malformed UTF-8 near bytes ...`，需要先解包再从目录安装该依赖。

## 0.4.0 — 2026-10-31

M0–M3 全部里程碑。

### Engine

- SQL-first pipeline: `source` (CSV / Parquet / JSON / table / SQL), `sql`, `assert`,
  `sink` (table / Parquet / CSV)。
- Transactional runs with rollback; staged-file + rename for file sinks.
- Run history in a separate DuckDB file (`_etl.runs`, `_etl.steps`, `_etl.watermarks`).
- Incremental watermarks for table sinks (`append` / `upsert`); updated only after
  commit and file installation.
- Partitioned Parquet sinks (`partition_by`) with staging-directory replacement.
- DuckDB extension loading via pipeline `extensions`.
- Cooperative cancellation via `duckdb_interrupt`; `canceled` status recorded.

### TUI

- Dashboard / Sources / Pipeline / Run screens.
- Pipeline draft editor: add/delete steps, field forms, enum toggles, inline editor,
  `$VISUAL`/`$EDITOR` for SQL, atomic save with validation.
- Run monitoring, log, per-step SQL, preview (LIMIT 100).
- `--isolated` runs the pipeline in a `ducketl worker` child process; worker crash
  leaves the TUI running and marks the run failed.

### CLI

- `ducketl run`, `tui`, `worker`, `extensions`, `validate`, `list`, `show`, `version`.
- `ducketl worker` speaks JSONL on stdout and accepts `cancel` on stdin.

### Tests

- 252 tests across 10 files: SQL scanning, validation, planner SQL, execution,
  rollback, atomic files, CLI, TUI rendering/form logic, watermark/partition/
  extension behavior, isolated worker cancel and crash handling.
