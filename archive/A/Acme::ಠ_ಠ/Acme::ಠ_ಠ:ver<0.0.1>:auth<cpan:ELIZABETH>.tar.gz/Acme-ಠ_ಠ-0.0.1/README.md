[![Build Status](https://travis-ci.org/lizmat/Acme-_-.svg?branch=master)](https://travis-ci.org/lizmat/Acme-_-)

NAME
====

Acme::ಠ_ಠ - send warnings with ಠ_ಠ

SYNOPSIS
========

    use Acme::ಠ_ಠ;

    ಠ_ಠ 'you did something dumb';

DESCRIPTION
===========

Acme::ಠ_ಠ serves as a test of unicode module names.

FUNCTIONS
=========

ಠ_ಠ
---

Behaves identically to "warn".

AUTHOR
======

Elizabeth Mattijsen <liz@wenzperl.nl>

Source can be located at: https://github.com/lizmat/Acme-_-.git . Comments and Pull Requests are welcome.

COPYRIGHT AND LICENSE
=====================

Copyright 2018 Elizabeth Mattijsen

Re-imagined from Perl 5 as part of the CPAN Butterfly Plan.

This library is free software; you can redistribute it and/or modify it under the Artistic License 2.0.

