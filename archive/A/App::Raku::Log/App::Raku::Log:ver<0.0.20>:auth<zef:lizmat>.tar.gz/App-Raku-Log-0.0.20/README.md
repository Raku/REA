[![Actions Status](https://github.com/lizmat/App-Raku-Log/workflows/test/badge.svg)](https://github.com/lizmat/App-Raku-Log/actions)

NAME
====

App::Raku::Log - Cro application for presenting Raku IRC logs

SYNOPSIS
========

```raku
$ ./start

$ ./start logs base
```

DESCRIPTION
===========

App::Raku::Log is ...

AUTHOR
======

Elizabeth Mattijsen <liz@wenzperl.nl>

Source can be located at: https://github.com/lizmat/App-Raku-Log . Comments and Pull Requests are welcome.

COPYRIGHT AND LICENSE
=====================

Copyright 2021 Elizabeth Mattijsen

This library is free software; you can redistribute it and/or modify it under the Artistic License 2.0.

