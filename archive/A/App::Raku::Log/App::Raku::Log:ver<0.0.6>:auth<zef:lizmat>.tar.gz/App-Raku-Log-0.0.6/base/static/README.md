To compile styles do:

```
npm install
npm run styles-release
```
