Vroom::Reveal
=======

Vroom::Reveal translates Vroom-format files to Reveal.js format.

Installation
============

* Using zef (a module management tool bundled with Rakudo Star):

```
    zef update && zef install ANTLR4
```

## Testing

To run tests:

```
    prove -e perl6
```

## Author

Jeffrey Goff, DrForr on #perl6, https://github.com/drforr/

## License

Artistic License 2.0
