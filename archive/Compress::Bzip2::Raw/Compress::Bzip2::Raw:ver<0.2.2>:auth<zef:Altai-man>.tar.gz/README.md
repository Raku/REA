P6-Compress-Bzip2-Raw  [![Build Status](https://travis-ci.org/Altai-man/perl6-Compress-Bzip2-Raw.svg?branch=master)](https://travis-ci.org/Altai-man/perl6-Compress-Bzip2-Raw)
====================

Low-level interface to bzip2. Bzip2 library must be installed in the system. Support of Windows and OS X is still needed. Contributions are welcome.
