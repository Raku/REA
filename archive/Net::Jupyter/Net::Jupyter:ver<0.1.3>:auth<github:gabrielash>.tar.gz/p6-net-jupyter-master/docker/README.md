## Docker Images 

add perl6 jupyter kernel

based on jupyter images

1. base-notebook
2. all-spark-notebook

