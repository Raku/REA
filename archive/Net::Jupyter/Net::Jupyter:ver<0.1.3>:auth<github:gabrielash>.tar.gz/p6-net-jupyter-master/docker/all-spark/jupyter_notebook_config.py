# uncomment and edit
# c.NotebookApp.ip = '192.168.1.0/24'
#c.NotebookApp.token = 'REPLACE THIS WITH lowercase HEXADECIMAL STRING (48 digits)'



