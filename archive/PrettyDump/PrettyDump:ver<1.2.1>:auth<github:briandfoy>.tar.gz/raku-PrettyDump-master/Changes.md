
* 1.2.1 - 2021-01-12
	* rename the repo to raku-PrettyDump, with many other "perl6" instances changed
	* Dump Travis CI
	* Hash keys are now in sorted order (Github #7, Xliff), so serialization tests should pass

* 1.7.1
