[![Build Status](https://travis-ci.org/kalkin/Net-XMPP.svg?branch=master)](https://travis-ci.org/kalkin/Net-XMPP)

NAME
====

Net::XMPP - an XMPP client module

SYNOPSIS
========

    use Net::XMPP;

DESCRIPTION
===========

Currently does the initial connection for you, and then allows you to send and receive stanzas.
