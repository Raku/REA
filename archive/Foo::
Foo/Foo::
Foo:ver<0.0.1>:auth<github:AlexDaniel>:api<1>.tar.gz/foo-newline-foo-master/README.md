## `Foo::
Foo`

A module with a newline in its name.
