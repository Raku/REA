# Game-Numeric

Numerical Analysis package for games and other things.
