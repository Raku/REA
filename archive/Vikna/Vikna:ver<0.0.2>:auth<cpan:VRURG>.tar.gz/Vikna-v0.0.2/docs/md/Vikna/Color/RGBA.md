NAME
====



`Vikna::Color::RGBA` - a role for RGB with alpha representation of a color

DESCRIPTION
===========



Only defines stringification of the object into RGBA quadruplet.

SEE ALSO
========

[`Vikna`](https://github.com/vrurg/raku-Vikna/blob/v0.0.2/docs/md/Vikna.md), [`Vikna::Manual`](https://github.com/vrurg/raku-Vikna/blob/v0.0.2/docs/md/Vikna/Manual.md), [`Vikna::Color`](https://github.com/vrurg/raku-Vikna/blob/v0.0.2/docs/md/Vikna/Color.md)

AUTHOR
======

Vadim Belman <vrurg@cpan.org>

