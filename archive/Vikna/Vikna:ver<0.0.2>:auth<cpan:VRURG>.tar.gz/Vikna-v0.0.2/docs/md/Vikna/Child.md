NAME
====



`Vikna::Child` - child rol

DESCRIPTION
===========



Very simplistic role only defining `$.parent` attribute, `set-parent` and `has-parent` methods.

Requires `id` method from the consuming class.

SEE ALSO
========

[`Vikna`](https://github.com/vrurg/raku-Vikna/blob/v0.0.2/docs/md/Vikna.md), [`Vikna::Manual`](https://github.com/vrurg/raku-Vikna/blob/v0.0.2/docs/md/Vikna/Manual.md)

AUTHOR
======



Vadim Belman <vrurg@cpan.org>

