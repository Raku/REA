Vikna CLASSES AND ROLES
=======================

  * [`Vikna::App`](https://github.com/vrurg/raku-Vikna/blob/v0.0.1/docs/md/Vikna/App.md)

  * [`Vikna::Border`](https://github.com/vrurg/raku-Vikna/blob/v0.0.1/docs/md/Vikna/Border.md)

  * [`Vikna::Button`](https://github.com/vrurg/raku-Vikna/blob/v0.0.1/docs/md/Vikna/Button.md)

  * [`Vikna::Canvas`](https://github.com/vrurg/raku-Vikna/blob/v0.0.1/docs/md/Vikna/Canvas.md)

  * [`Vikna::CAttr`](https://github.com/vrurg/raku-Vikna/blob/v0.0.1/docs/md/Vikna/CAttr.md)

  * [`Vikna::Child`](https://github.com/vrurg/raku-Vikna/blob/v0.0.1/docs/md/Vikna/Child.md)

  * [`Vikna::Color`](https://github.com/vrurg/raku-Vikna/blob/v0.0.1/docs/md/Vikna/Color.md)

  * [`Vikna::Color::Index`](https://github.com/vrurg/raku-Vikna/blob/v0.0.1/docs/md/Vikna/Color/Index.md)

  * [`Vikna::Color::Named`](https://github.com/vrurg/raku-Vikna/blob/v0.0.1/docs/md/Vikna/Color/Named.md)

  * [`Vikna::Color::RGB`](https://github.com/vrurg/raku-Vikna/blob/v0.0.1/docs/md/Vikna/Color/RGB.md)

  * [`Vikna::Color::RGBA`](https://github.com/vrurg/raku-Vikna/blob/v0.0.1/docs/md/Vikna/Color/RGBA.md)

  * [`Vikna::CommandHandling`](https://github.com/vrurg/raku-Vikna/blob/v0.0.1/docs/md/Vikna/CommandHandling.md)

  * [`Vikna::Coord`](https://github.com/vrurg/raku-Vikna/blob/v0.0.1/docs/md/Vikna/Coord.md)

  * [`Vikna::Desktop`](https://github.com/vrurg/raku-Vikna/blob/v0.0.1/docs/md/Vikna/Desktop.md)

  * [`Vikna::Elevatable`](https://github.com/vrurg/raku-Vikna/blob/v0.0.1/docs/md/Vikna/Elevatable.md)

  * [`Vikna::EventEmitter`](https://github.com/vrurg/raku-Vikna/blob/v0.0.1/docs/md/Vikna/EventEmitter.md)

  * [`Vikna::EventHandling`](https://github.com/vrurg/raku-Vikna/blob/v0.0.1/docs/md/Vikna/EventHandling.md)

  * [`Vikna::Events`](https://github.com/vrurg/raku-Vikna/blob/v0.0.1/docs/md/Vikna/Events.md)

  * [`Vikna::Focusable`](https://github.com/vrurg/raku-Vikna/blob/v0.0.1/docs/md/Vikna/Focusable.md)

  * [`Vikna::InputLine`](https://github.com/vrurg/raku-Vikna/blob/v0.0.1/docs/md/Vikna/InputLine.md)

  * [`Vikna::Label`](https://github.com/vrurg/raku-Vikna/blob/v0.0.1/docs/md/Vikna/Label.md)

  * [`Vikna::Object`](https://github.com/vrurg/raku-Vikna/blob/v0.0.1/docs/md/Vikna/Object.md)

  * [`Vikna::OS`](https://github.com/vrurg/raku-Vikna/blob/v0.0.1/docs/md/Vikna/OS.md)

  * [`Vikna::OS::unix`](https://github.com/vrurg/raku-Vikna/blob/v0.0.1/docs/md/Vikna/OS/unix.md)

  * [`Vikna::Parent`](https://github.com/vrurg/raku-Vikna/blob/v0.0.1/docs/md/Vikna/Parent.md)

  * [`Vikna::Point`](https://github.com/vrurg/raku-Vikna/blob/v0.0.1/docs/md/Vikna/Point.md)

  * [`Vikna::PointerTarget`](https://github.com/vrurg/raku-Vikna/blob/v0.0.1/docs/md/Vikna/PointerTarget.md)

  * [`Vikna::Rect`](https://github.com/vrurg/raku-Vikna/blob/v0.0.1/docs/md/Vikna/Rect.md)

  * [`Vikna::Screen`](https://github.com/vrurg/raku-Vikna/blob/v0.0.1/docs/md/Vikna/Screen.md)

  * [`Vikna::Screen::ANSI`](https://github.com/vrurg/raku-Vikna/blob/v0.0.1/docs/md/Vikna/Screen/ANSI.md)

  * [`Vikna::Scrollable`](https://github.com/vrurg/raku-Vikna/blob/v0.0.1/docs/md/Vikna/Scrollable.md)

  * [`Vikna::Test`](https://github.com/vrurg/raku-Vikna/blob/v0.0.1/docs/md/Vikna/Test.md)

  * [`Vikna::Test::App`](https://github.com/vrurg/raku-Vikna/blob/v0.0.1/docs/md/Vikna/Test/App.md)

  * [`Vikna::Test::OS`](https://github.com/vrurg/raku-Vikna/blob/v0.0.1/docs/md/Vikna/Test/OS.md)

  * [`Vikna::Test::Screen`](https://github.com/vrurg/raku-Vikna/blob/v0.0.1/docs/md/Vikna/Test/Screen.md)

  * [`Vikna::TextScroll`](https://github.com/vrurg/raku-Vikna/blob/v0.0.1/docs/md/Vikna/TextScroll.md)

  * [`Vikna::Tracer`](https://github.com/vrurg/raku-Vikna/blob/v0.0.1/docs/md/Vikna/Tracer.md)

  * [`Vikna::WAttr`](https://github.com/vrurg/raku-Vikna/blob/v0.0.1/docs/md/Vikna/WAttr.md)

  * [`Vikna::Widget`](https://github.com/vrurg/raku-Vikna/blob/v0.0.1/docs/md/Vikna/Widget.md)

  * [`Vikna::Widget::Group`](https://github.com/vrurg/raku-Vikna/blob/v0.0.1/docs/md/Vikna/Widget/Group.md)

  * [`Vikna::Widget::GroupMember`](https://github.com/vrurg/raku-Vikna/blob/v0.0.1/docs/md/Vikna/Widget/GroupMember.md)

  * [`Vikna::Window`](https://github.com/vrurg/raku-Vikna/blob/v0.0.1/docs/md/Vikna/Window.md)

  * [`Vikna::X`](https://github.com/vrurg/raku-Vikna/blob/v0.0.1/docs/md/Vikna/X.md)

AUTHOR
======



Vadim Belman <vrurg@cpan.org>

