# Getopt-Kinoko
A command line parsing tool which written in Perl6
