NAME
====

Zef::Reporter - blah blah blah

SYNOPSIS
========

    use Zef::Reporter;

DESCRIPTION
===========

Zef::Reporter is ...

AUTHOR
======

Breno G. de Oliveira <garu@cpan.org>

COPYRIGHT AND LICENSE
=====================

Copyright 2017 Breno G. de Oliveira

This library is free software; you can redistribute it and/or modify it under the Artistic License 2.0.
