This is a YAML parser written in pure-perl6. It aims at being feature complete
(though there still a few features left to implement). Patches are welcome.
