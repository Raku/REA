# JsonC

Using NativeCall this module binds to the popular json-c library, offering a different
approach to JSON handling in Perl6.

In adition to the traditional `to-json` and `from-json` routines this module provides
a `JSON` class.

See the `t/00-basic.t` for some examples.
