# CHANGELOG

  - **v0.0.2**
    
      - Added default marshalling for [`Version`](https://docs.raku.org/type/Version), and [`QuantHash`](https://docs.raku.org/type/QuantHash)es
    
      - Implicit JSONification now reports a problem for some problematic types

  - **v0.0.1**
    
      - First release

# SEE ALSO

  - [`README`](README.md)

  - [`INDEX`](INDEX.md)
