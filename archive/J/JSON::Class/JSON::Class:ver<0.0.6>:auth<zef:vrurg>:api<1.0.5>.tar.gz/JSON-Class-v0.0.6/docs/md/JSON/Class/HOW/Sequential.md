# NAME

`JSON::Class::HOW::Sequential`

# SEE ALSO

  - [`JSON::Class`](../../Class.md)

  - [`JSON::Class::Details`](../Details.md)

  - [`JSON::Class::SequenceHOW`](../SequenceHOW.md)

  - [`JSON::Class::Sequence`](../Sequence.md)

  - [`INDEX`](../../../../../INDEX.md)

# COPYRIGHT

(c) 2023, Vadim Belman <vrurg@cpan.org>

# LICENSE

Artistic License 2.0

See the [*LICENSE*](../../../../../LICENSE) file in this distribution.
