/* foo */

var x  = 2;