use JSON::Fast:ver<0.21+>:auth<zef:timo>;

my constant $s = 2;
my proto pretty-json($, :$indent, :$first) {*}
multi pretty-json(Cool:D $d, :$indent = 0, :$first = 0) {
    (' ' x $first) ~ to-json($d)
}
multi pretty-json(Positional:D $d, :$indent = 0, :$first = 0) {
    (' ' x $first)
      ~ "\["
      ~ ($d
          ?? $d.map({
                 "\n"
                   ~ pretty-json($_, :indent($indent + $s), :first($indent + $s))
             }).join(",") ~ "\n" ~ (' ' x $indent)
          !! ' ')
      ~ ']'
}
multi pretty-json(Associative:D $d, :$indent = 0, :$first = 0) {
    (' ' x $first)
      ~ "\{"
      ~ ($d
          ?? $d.map({
                 "\n"
                   ~ pretty-json(.key, :first($indent + $s))
                   ~ ' : '
                   ~ pretty-json(.value, :indent($indent + $s))
             }).join(",") ~ "\n" ~ (' ' x $indent)
          !! ' '
        )
      ~ '}'
}

multi pretty-json(Mu:U $, :$indent, :$first) {
    'null'  # UNCOVERABLE
}
multi pretty-json(Mu:D $s, :$indent, :$first) {
    die "Can't serialize an object of type " ~ $s.^name;
}

sub EXPORT() {
    BEGIN Map.new:
      '&to-json'   => &pretty-json,
      '&from-json' => &from-json
}

# vim: expandtab shiftwidth=4
