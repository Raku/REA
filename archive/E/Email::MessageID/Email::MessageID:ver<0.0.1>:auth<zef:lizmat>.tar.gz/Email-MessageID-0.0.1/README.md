[![Actions Status](https://github.com/lizmat/Email-MessageID/actions/workflows/linux.yml/badge.svg)](https://github.com/lizmat/Email-MessageID/actions) [![Actions Status](https://github.com/lizmat/Email-MessageID/actions/workflows/macos.yml/badge.svg)](https://github.com/lizmat/Email-MessageID/actions) [![Actions Status](https://github.com/lizmat/Email-MessageID/actions/workflows/windows.yml/badge.svg)](https://github.com/lizmat/Email-MessageID/actions)

NAME
====

Email::MessageID - Generate world unique message-ids

SYNOPSIS
========

```raku
use Email::MessageID;

# bare ID
say message-id;

# for use in an email header
say message-id(:header);
```

DESCRIPTION
===========

The `Email::MessageID` distribution provides an algorithm to create unique strings (ID) for a given host / user combination.

EXPORTED SUBROUTINES
====================

message-id
----------

The `message-id` subroutine returns a unique string for a given host and user (specified as named arguments).

The default value for the `:host` named argument is `Kernel.hostname`.

The default value for the `:user` named argument is a random string created from several different random sources.

The default value for the `:header` named argument is False. If specified with a trueish value, will generate a string that can be used verbatim in an email header.

CREDITS
=======

Algorithm scooped from Perl's [Email::MessageID](https://metacpan.org/pod/Email::MessageID) by Aaron Crane, Pali and Ricardo Signes.

AUTHOR
======

Elizabeth Mattijsen <liz@raku.rocks>

Source can be located at: https://codeberg.org/lizmat/Email-MessageID . Comments and Pull Requests are welcome.

If you like this module, or what I'm doing more generally, committing to a [small sponsorship](https://github.com/sponsors/lizmat/) would mean a great deal to me!

COPYRIGHT AND LICENSE
=====================

Copyright 2026 Elizabeth Mattijsen

This library is free software; you can redistribute it and/or modify it under the Artistic License 2.0.

