use v6.*;

my constant @chars = eager flat "A".."F", "a".."f", "0".."9";

sub generate-key() {
    (nano, @chars.roll( (3..9).roll ).join, $*PID).join(".")
}

my sub message-id(
  :$host = Kernel.hostname,
  :$user = generate-key,
  :$header
) is export {
    my $id := "$user@$host";
    $header ?? "Message-ID: <$id>" !! $id
}

# vim: expandtab shiftwidth=4
