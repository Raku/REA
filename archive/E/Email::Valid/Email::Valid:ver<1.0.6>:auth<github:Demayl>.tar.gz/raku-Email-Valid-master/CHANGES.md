### 1.0.5
- fix installing error: wrong lib path after renaming
### 1.0.4
- fix IP addresses ending with 0 reported as invalid
