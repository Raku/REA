### ECMA262Regex

This module allows you parsing ECMA262 regex notation and use it in Perl 6.
