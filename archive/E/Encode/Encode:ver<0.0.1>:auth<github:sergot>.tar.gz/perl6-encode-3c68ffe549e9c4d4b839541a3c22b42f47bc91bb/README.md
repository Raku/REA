Encode
============

Character encodings in Perl 6
