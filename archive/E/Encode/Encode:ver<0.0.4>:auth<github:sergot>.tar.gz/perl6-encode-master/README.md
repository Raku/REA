Encode [![test](https://github.com/sergot/perl6-encode/actions/workflows/test.yml/badge.svg)](https://github.com/sergot/perl6-encode/actions/workflows/test.yml)
============

Character encodings in Perl 6
