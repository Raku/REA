Encode [![Build Status](https://travis-ci.org/sergot/perl6-encode.svg?branch=master)](https://travis-ci.org/sergot/perl6-encode)
============

Character encodings in Perl 6
