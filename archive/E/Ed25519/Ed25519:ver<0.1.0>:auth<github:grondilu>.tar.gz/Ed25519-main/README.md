# Ed25519
Ed25519 in [raku](http://raku.org)

References
----------

* [RFC 8032](http://www.rfc-editor.org/info/rfc8032)
