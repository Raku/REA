use v6.*;

sub EXPORT(*@keys) {
    @keys = %*ENV.keys unless @keys;

    # Proxy for scalar keys
    sub as-scalar($name is copy) is raw {
        $name = $name.substr(1) if $name.starts-with('$');

        # re-containerize with default Nil
        %*ENV{$name} := my $value is default(Nil) = %*ENV{$name};

        Proxy.new(
          FETCH => -> $ { $value },
          STORE => -> $, \new-value {
              %*ENV{$name}:delete if new-value === Nil;
              $value = new-value
          }
        )
    }

    # Proxy for array keys
    sub as-array($name is copy) is raw {
        $name = $name.substr(1);
        my $sep  := $*DISTRO.path-sep;
        my @parts = %*ENV{$name}.split($sep);

        %*ENV{$name} := Proxy.new(
          FETCH => -> $ {
              %*ENV{$name}:exists ?? @parts.join($sep) !! Nil
          },
          STORE => -> $, \new-value {
              if new-value === Nil {
                  %*ENV{$name}:delete;
                  @parts = ();
                  Nil
              }
              else {
                  @parts = new-value.split($sep)
              }
          }
        );

        @parts
    }

    Map.new: @keys.map: -> $name {
        Pair.new(
          $name,
          $name.starts-with('@') ?? as-array($name) !! as-scalar($name)
        )
    }
}

# vim: expandtab shiftwidth=4
