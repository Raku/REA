class IRC::Client::Plugin::NickServ
-----------------------------------

The IRC::Client::Plugin to deal with NickServ interaction.

### method irc-n376

```perl6
method irc-n376(
    $e
) returns Mu
```

Identify with NickServ. This is done on IRC code 376 (end of MOTD), since this is what most servers accept as the earliest time to start interacting with the server.

