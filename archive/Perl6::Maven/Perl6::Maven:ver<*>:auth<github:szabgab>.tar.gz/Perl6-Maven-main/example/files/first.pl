use v6;

say "Hello World";

