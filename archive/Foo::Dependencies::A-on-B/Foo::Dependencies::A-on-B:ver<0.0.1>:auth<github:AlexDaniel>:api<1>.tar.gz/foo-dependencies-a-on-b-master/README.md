## Foo::Dependencies::A-on-B

A module that depends on another module that depends on this module.
