# Cucumis Sextus ToDo List

* more debug output if selected
* document diag(), allow suppression of it
* continuation lines in steps?
* excetions from step should be reported neater
* named captures in step def regex
* document context information being carried between steps
* reporting when no features are found should be neater (so should prove6)
* we should have a comprehensive, standalone example in a subdir
* zef integration via  plugin?
* what does prove6 do around the 'lib'? does it auto-add it? if so then we
  should too. if not, does that mean prove6 could test the installed rather than
  the code from this repo if that line is missing?

