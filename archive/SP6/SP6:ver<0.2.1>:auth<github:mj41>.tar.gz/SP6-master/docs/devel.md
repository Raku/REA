Run tests
---------

    raku -Ilib t/vars.t

Run all tests
--------------

    prove -e'raku -Ilib' t/
