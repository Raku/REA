NAME
====

BinaryHeap - Array-based binary heap supporting heapsort

SYNOPSIS
========

```raku
use BinaryHeap;

my BinaryHeap::MinHeap $heap;
$heap.push(11, 42);
say $heap.pop; # OUTPUT: «11␤»
say $heap.top; # OUTPUT: «42␤»
```

DESCRIPTION
===========

    role BinaryHeap[&infix:<precedes> = * cmp * == Less] {}

Role `BinaryHeap` stores values in an implicit binary tree that satisfies the **heap property**: the value of a node never `precedes` the value of its parent node.

Infix `precedes` defines a priority relation, such that the root of the tree, known as the [top](#method_top) of the heap, has a priority higher than or equal to all other nodes of the tree. The default relation defines a *min-heap*, i.e. the top value compares `Less` than or `Same` as every other value on the heap.

Module `BinaryHeap` provides two classes that do the binary heap [role](#constant_GenHeap):

  * `class BinaryHeap::MaxHeap does GenHeap[* cmp * == More]`

    In a *max-heap*, a child node never compares `More` than its parent node.

  * `class BinaryHeap::MinHeap does GenHeap[* cmp * == Less]`

    In a *min-heap*, a child node never compares `Less` than its parent node.

*Deprecated:* these classes are parameterizable with a custom three-way comparison operator. For example, the following code constrains lexical variable `$heap` to a *max-heap* that compares objects by their `.key`:

    my BinaryHeap::MaxHeap[*.value cmp *.value] $heap;

This parameterization is deprecated because it relies on Rakudo-specific internals. There are two alternatives for defining a binary heap with a custom comparator. The first is to define a custom class, for example:

    use BinaryHeap 'GenHeap';

    my class MaxHeap does GenHeap[*.value cmp *.value == More] {}

A concise alternative is to use a dynamic object factory:

    my $max-heap = max-heap(*.value cmp *.value);

In many cases, an uninitialized binary heap can be approached as if it were an empty heap. Methods that may add values to the heap autovivify an uninitialized invocant, which means they can only be called on a *container* that is constrained to (or stores) a *class* type. For example:

    my MaxHeap $heap;
    say $heap.values;      # OUTPUT: «()␤»
    say $heap.replace(42); # OUTPUT: «Nil␤»
    say $heap.top;         # OUTPUT: «42␤»

EXPORTS
=======

    use BinaryHeap <GenHeap &heapsort>;

Module `BinaryHeap` optionally exports the role that implements a binary heap, along with some useful subroutines. The specialized `&infix:<eqv>` candidate is a mandatory export, and only `&heapsort` is exported by default.

constant GenHeap
----------------

In API version 1 this is just an alias for `role BinaryHeap`. The fully qualified name of the role may change in a future API version, but `GenHeap` defines a stable alias that can be used in signatures and class definitions.

class MaxHeap
-------------

The short name of `class BinaryHeap::MaxHeap`.

class MinHeap
-------------

The short name of `class BinaryHeap::MinHeap`.

infix eqv
---------

Defined as:

    multi sub infix:<eqv>(GenHeap \a, GenHeap \b --> Bool:D)

Returns `True` if and only if the two heaps are of the same type and contain equivalent [values](#method_values). Note that a class is a different type than a role, so `GenHeap.new eqv GenHeap` returns `False`, not because role `GenHeap` is undefined, but because `GenHeap.new` returns an instance of a *class* with the same name as the role.

sub heapsort
------------

Defined as:

    proto sub heapsort(|) is export(:DEFAULT, :heapsort)
    multi sub heapsort(@array, :$reverse)
    multi sub heapsort(&comparator, @array, :$reverse)

Sorts and returns the `@array`, using a custom three-way `&comparator` if provided. By default the array is sorted in ascending order, but it is sorted in descending order if `:$reverse` is true. Hence, the following statements both put the elements of the array in descending order:

    heapsort @array, :reverse;
    heapsort -(* cmp *), @array;

Note that `heapsort` is not a [stable sort](https://en.wikipedia.org/wiki/Sorting_algorithm#Stability).

sub max-heap
------------

Defined as:

    proto sub max-heap(|) is export(:max-heap)
    multi sub max-heap(@values?)
    multi sub max-heap(&infix:<cmp>, @values?)

Returns a custom `GenHeap[* cmp * == More]` instance if called with a comparator. The provided values are stored on the heap.

The candidate that uses the default `&infix:<cmp>` is *deprecated* as it is just syntactic sugar for `BinaryHeap::MaxHeap.new`.

sub min-heap
------------

Defined as:

    proto sub min-heap(|) is export(:min-heap)
    multi sub min-heap(@values?)
    multi sub min-heap(&infix:<cmp>, @values?)

Returns a custom `GenHeap[* cmp * == Less]` instance if called with a comparator. The provided values are stored on the heap.

The candidate that uses the default `&infix:<cmp>` is *deprecated* as it is just syntactic sugar for `BinaryHeap::MinHeap.new`.

METHODS
=======

method Bool
-----------

Defined as:

    multi method Bool(::?CLASS:D: --> Bool:D)

Returns `True` if the heap contains at least one value, and `False` if the heap is empty.

method clone
------------

Defined as:

    multi method clone(::?CLASS:D:)

Returns a clone of the heap.

method consume
--------------

Defined as:

    method consume( --> Seq:D)

Returns a `Seq` that generates values by removing them from the top of the heap. If no values are inserted into the heap before the `Seq` is exhausted, the values will be in ascending order if called on a *min-heap*, in descending order if called on a *max-heap*.

method elems
------------

Defined as:

    multi method elems(::?CLASS:D:)

Returns the number of values on the heap. 

method gist
-----------

Defined as:

    multi method gist(::?CLASS:D:)

Returns the gist of the array underlying the heap.

method heapify
--------------

Defined as:

    method heapify(@array --> ::?CLASS:D)

Constructs a new heap based on the *provided* array, whose elements are put in heap order. This method is *deprecated* because it breaks encapsulation; use `.new(@array)` to create a heap with a type constraint on elements.

method new
----------

Conceptually defined as:

    method new(+values --> ::?CLASS:D)

Constructs a new heap storing the provided values. If values are provided as a single, non-itemized array, the type constraint of the array applies to all values on the heap.

method of
---------

Defined as:

    method of()

Returns the type constraint for the values on the heap. Returns `Mu` by default, but a heap can be constrained to a specific element type by calling `.new` with a type-constrained array.

method pop
----------

Defined as:

    method pop()

Removes the value stored at the [top](#method_top) of the heap and returns it, or returns a `Failure` if the heap is empty.

method push
-----------

Conceptually defined as:

    method push(**@values --> ::?CLASS:D)

Inserts the provided values into the heap and returns the modified heap. Autovivifies the invocant if called on a container storing or defaulting to a class type object. For example:

    my BinaryHeap::MaxHeap $heap;
    $heap.push(42, 11);
    say $heap.pop; # OUTPUT: «42␤»
    say $heap.top; # OUTPUT: «11␤»

method push-pop
---------------

Defined as:

    method push-pop(Mu \value)

Functionally equivalent, but more efficient than a [push](#method_push) followed by a [pop](#method_pop). [Replaces the top](#method_replace) of the heap if it `precedes` the provided value; otherwise just returns the provided value.

method raku
-----------

Defined as:

    multi method raku(::?CLASS:D:)

Returns a string representation of the heap that can be `EVAL`ed to reconstruct the heap, provided it belongs to a named class. Used to compare the structural equivalence of heaps when the exported `&infix:eqv` candidate is not in scope.

method replace
--------------

Defined as:

    method replace(Mu \new)

Functionally equivalent, but more efficient than a [pop](#method_pop) followed by a [push](#method_push). Removes the [top](#method_top) of the heap and returns it after inserting the new value.

method sort
-----------

Defined as:

    method sort()

Returns an empty `Array` if called on an uninitialized heap. Otherwise sorts the underlying array in descending order if called on a *min-heap*, in ascending order if called on a *max-heap*. Replaces the underlying array with an empty copy and returns the sorted array.

method top
----------

Defined as:

    method top()

Returns the value stored at the top of the heap, or `Nil` if the heap is empty.

method values
-------------

Defined as:

    method values( --> Seq:D)

Returns a `Seq` of the values encountered during a breadth-first traversal of the heap.

SEE ALSO
========

  * [Binary heap - Wikipedia](https://en.wikipedia.org/wiki/Binary_heap)

  * [Heapsort - Wikipedia](https://en.wikipedia.org/wiki/Heapsort)

  * [Raku's built-in `sort` routine](https://docs.raku.org/routine/sort), which is faster than a [`heapsort`](#sub_heapsort) on Rakudo.

AUTHOR
======

Peter du Marchie van Voorthuysen

Source can be located at: https://github.com/dumarchie/raku-binaryheap

COPYRIGHT AND LICENSE
=====================

Copyright 2022-2026 Peter du Marchie van Voorthuysen

This library is free software; you can redistribute it and/or modify it under the Artistic License 2.0.

