# The EXPORT sub must be defined outside the module scope
sub EXPORT(**@keys) {
    my %EXPORT = ::<BinaryHeap>.WHO;
    if my @missing = @keys.grep({ %EXPORT{$_}:!exists }) {
        die "Trying to import from 'BinaryHeap', "
          ~ "but the following symbols are not exported: "
          ~ @missing.join(", ");
    }
    Map.new(@keys.map({ $_ => %EXPORT{$_} }))
}

unit module BinaryHeap;

# A heap is a binary tree that satisfies the heap invariant:
# the priority of a node never tops the priority of its parent node
proto sub infix:<tops>($, $) {*}

role GenHeap[&infix:<tops>] does Iterable is export {
    # The heap is represented by @!array[^$!elems];
    # the array may contain additional elements to accommodate a heapsort.
    has @!array;
    has int $!elems;
    has @!descent; # reusable node array for sift-down
    method !SET-SELF(@array, $elems = @array.elems) {
        @!array := @array;
        $!elems = $elems;
        if $!elems > 1 { # heapify array
            my int $pos = ($!elems - 2) div 2; # last internal node
            self!sift-down($pos--) while $pos >= 0;
        }
        self;
    }

    # Sift down with bounce to reduce the number of comparisons
    # Define a descent from a node at a given position, by selecting the top
    # priority child at each level. Then shorten the descent until the final
    # node can contain the value of the first node without violating the heap
    # condition. Then assign each node the value of its successor, and assign
    # the last node the value of the first node.
    method !sift-down(int $pos is copy --> Nil) {
        my $node := @!array[$pos];
        @!descent.BIND-POS(my int $depth, $node);

        my int $end = $!elems - 1;
        while ($pos = ($pos * 2) + 1) < $end {
            my \left  = @!array[$pos];
            my \right = @!array[$pos + 1];
            if right tops left {
                $pos += 1;
                @!descent.BIND-POS(++$depth, right);
            }
            else {
                @!descent.BIND-POS(++$depth, left);
            }
        }

        # at the deepest level there may be only one child
        if $pos == $end {
            @!descent.BIND-POS(++$depth, @!array[$pos]);
        }

        # shorten descent until the last node can hold the value of the first
        my $value = $node;
        while $depth > 0 && $value tops @!descent[$depth] {
            $depth--;
        }

        # shift values until we reach the final node of the descent
        $pos = 0;
        while $pos < $depth {
            my \child = @!descent[++$pos];
            $node  = child;
            $node := child;
        }

        # assign the original value of the first node to the final node
        $node = $value;
    }

    # Construct a heap with zero or more values
    proto method new(|) {*}
    multi method new() { self.CREATE }
    multi method new(**@values) {
        self.CREATE!SET-SELF(@values);
    }
    # A Slip is an Iterable that should slip even when itemized
    multi method new(Slip \values) {
        self.CREATE!SET-SELF(values.Array);
    }
    multi method new(Iterable \arg, Bool() :$in-place) {
        my @values;
        if arg.VAR !=== arg {
            @values = arg;
        }
        elsif arg ~~ Array|array {
            @values := $in-place ?? arg !! arg.clone;
        }
        else {
            @values := arg.Array;
        }
        self.CREATE!SET-SELF(@values);
    }

    # A heap has the type constraint of the underlying array
    proto method of() {*}
    multi method of(GenHeap:U:) { Mu }
    multi method of(GenHeap:D:) { @!array.of }

    # A clone should retain a constraint on element type
    multi method clone(GenHeap:D:) {
        self.CREATE!SET-SELF(@!array.clone, $!elems);
    }

    # Merge values into a heap
    proto method merge(|) {*}
    multi method merge(GenHeap:U $self is rw: |values) {
        $self = self.new(|values);
    }
    multi method merge(GenHeap:D: **@values is raw) {
        self!insert-iterable(@values);
    }
    multi method merge(GenHeap:D: Slip \values) {
        self!insert-iterable(values);
    }
    multi method merge(GenHeap:D: Iterable \arg) {
        arg.VAR === arg
          ?? self!insert-iterable(arg)
          !! self!insert(arg);
   }

    # Extract a single value from a heap
    proto method pop() {*}
    multi method pop(GenHeap:U:) {
        fail X::Cannot::Empty.new(:action<pop>, :what(self.^name));
    }
    multi method pop(GenHeap:D:) {
        $!elems > 0 ?? self.extract-one !! self.WHAT.pop;
    }
    method extract-one() is implementation-detail {
        $!elems > 1
          ?? self!swap(@!array[--$!elems])
          !! $!elems == 1 ?? @!array[--$!elems] !! IterationEnd;
    }
    method !swap(Mu \new) {
        my $node := @!array[0];
        my $value = $node;
        $node = new;
        self!sift-down(0);
        $value;
    }

    # Extract a Seq of values from a heap
    my class Extractor does Iterator {
        has $.heap;
        method pull-one() { $!heap.extract-one }
    }

    proto method extract(|) {*}
    multi method extract(GenHeap:U:) { Empty.Seq }
    multi method extract(GenHeap:D:) {
        Seq.new: Extractor.new(:heap(self));
    }
    multi method extract(\n) {
        self.extract.head(n);
    }

    # Insert values into a heap
    proto method push(|) {*}
    multi method push(GenHeap:U $self is rw: |values) {
        $self = self.CREATE.push(|values);
    }
    multi method push(GenHeap:D: **@values is raw) {
        self!insert-iterable(@values);
    }
    multi method push(GenHeap:D: Slip \values) {
        self!insert-iterable(values);
    }
    multi method push(GenHeap:D: Mu \value) {
        self!insert(value);
        self;
    }
    method !insert(Mu \value --> Nil) {
        # increment $!elems only if the value can be assigned to a node
        my $node := @!array.AT-POS($!elems);
        $node = value;

        # sift the provided value up from the new node
        my int $pos = $!elems++;
        while $pos > 0
          && value tops my \parent = @!array[$pos = ($pos - 1) div 2]
        {
            $node  = parent;
            $node := parent;
        }
        $node = value;
    }
    method !insert-iterable(\values) {
        self!insert($_) for values;
        self;
    }

    # Insert, then extract
    method push-pop(Mu \value) {
        self && @!array[0] tops value ?? self.replace(value) !! value;
    }

    # Replace the top of a heap (extract, then insert)
    proto method replace(|) {*}
    multi method replace(GenHeap:U $self is rw: Mu \new) {
        $self = self.CREATE;
        $self!insert(new);
    }
    multi method replace(GenHeap:D: Mu \new) {
        $!elems > 0
          ?? self!swap(new)
          !! self!insert(new);
    }

    # The actual heapsort implementation
    method extract-reverse is implementation-detail {
        while $!elems > 1 {
            my $node := @!array[--$!elems];
            $node = self.replace($node);
        }
        @!array;
    }

    multi method Bool(GenHeap:D: --> Bool:D) { $!elems > 0 }
    method top() { self ?? @!array[0] !! Nil }

    # Expose (number of) heap elements
    multi method elems(GenHeap:U: --> 0) { }
    multi method elems(GenHeap:D:) { $!elems }

    method AT-POS(\pos) is implementation-detail { @!array[pos] }

    my class Traversal does Iterator {
        has $.heap;
        has int $!pos;
        method pull-one() {
            $!pos < $!heap.elems ?? $!heap.AT-POS($!pos++) !! IterationEnd;
        }
    }
    method iterator() {
        Traversal.new(:heap(self));
    }

    method values() {
        self.Seq;
    }

    method list() {
        self.Seq.list;
    }

    method gist() {
        self.Seq.gist;
    }

    # Representation for core infix eqv
    multi method raku(GenHeap:D:) {
        my $default = "{self.^name}.new";
        $!elems ?? $default ~ @!array[^$!elems].raku !! $default;
    }
}

class MaxHeap does GenHeap[* cmp * == More] is export {}

class MinHeap does GenHeap[* cmp * == Less] is export {}

multi sub infix:<eqv>(GenHeap \a, GenHeap \b --> Bool:D) is export(:MANDATORY) {
    a.WHAT === b.WHAT && a.list eqv b.list;
}

# Heapsort
our proto heapsort(|) is export {*}
multi sub heapsort(@array, Bool() :$reverse) {
    my \Heap = $reverse ?? MinHeap !! MaxHeap;
    Heap.new(@array, :in-place).extract-reverse;
}
multi sub heapsort(&cmp, @array, Bool() :$reverse) {
    my &make-heap := $reverse ?? &min-heap !! &max-heap;
    make-heap(&cmp, @array, :in-place).extract-reverse;
}

# Dynamic heap factories
our proto max-heap(|) is export {*}
multi sub max-heap(&cmp, **@values) {
    max-heap(&cmp, @values, :in-place);
}
multi sub max-heap(&infix:<cmp>, Iterable \values, Bool() :$in-place) {
    GenHeap[* cmp * == More].new(values, :$in-place);
}

our proto min-heap(|) is export {*}
multi sub min-heap(&cmp, **@values) {
    min-heap(&cmp, @values, :in-place);
}
multi sub min-heap(&infix:<cmp>, Iterable \values, Bool() :$in-place) {
    GenHeap[* cmp * == Less].new(values, :$in-place);
}

=begin pod

=head1 NAME

BinaryHeap - Array-based binary heap supporting heapsort

=head1 SYNOPSIS

    use BinaryHeap <MinHeap>;

    my MinHeap $heap;
    $heap.push(11, 42);
    say $heap.pop; # OUTPUT: «11␤»
    say $heap.top; # OUTPUT: «42␤»

=head1 DESCRIPTION

Module C<BinaryHeap> implements a heap data structure and an (in-place)
C<heapsort> routine. The heap data structure is implemented by role C<GenHeap>,
which stores values in an implicit binary tree that satisfies the B<heap
property>: the priority of a node never I<tops> the priority of its parent. The
priority of the element at the top of a heap is greater than or equal to the
priority of all other elements in a I<max-heap>, and less than or equal to the
priority of all other elements in a I<min-heap>.

Module C<BinaryHeap> provides two classes that do the C<GenHeap> role using
Raku's built-in three-way comparison operator: C<MaxHeap> and C<MinHeap>. These
heaps do not distinguish between a heap element and its priority. The dynamic
C<max-heap> and C<min-heap> factories accept a custom comparator that may
define an element's priority differently.

An uninitialized heap can be manipulated as if it were an empty heap instance.
Methods that add values autovivify an uninitialized heap. For example:

    my MinHeap $heap;
    say $heap.values;      # OUTPUT: «()␤»
    say $heap.replace(42); # OUTPUT: «Nil␤»
    say $heap.top;         # OUTPUT: «42␤»

=head1 EXPORTS

    use BinaryHeap <GenHeap &heapsort>;

Apart from the mandatory C<&infix:<eqv>> candidate, the following symbols in the
C<BinaryHeap> namespace are all exported by default. To import specific symbols
only, provide a list of symbol names to `use`.

=head2 role GenHeap

    role GenHeap[&infix:<tops>] does Iterable { }

Implements the heap data structure. Infix C<tops> defines the heap invariant:
no child node has a priority that tops the priority of its parent. See the
implementations of C<MaxHeap> and C<MinHeap> for examples.

=head2 class MaxHeap

    class MaxHeap does GenHeap[* cmp * == More] { }

A I<max-heap> that uses Raku's built-in C<infix:<cmp>> to compare the priority
of elements.

=head2 class MinHeap

    class MinHeap does GenHeap[* cmp * == Less] { }

A I<min-heap> that uses Raku's built-in C<infix:<cmp>> to compare the priority
of elements.

=head2 infix eqv

Defined as:

    multi sub infix:<eqv>(GenHeap \a, GenHeap \b --> Bool:D)

Returns C<True> if and only if the two heaps are of the same type and contain
equivalent elements at each position.

=head2 sub heapsort

Defined as:

    multi sub heapsort(@values, Bool() :$reverse)
    multi sub heapsort(&comparator, @values, Bool() :$reverse)

Sorts the elements in-place and returns the array if C<@values> is an array;
otherwise sorts and returns the elements of a new C<Array>. Values are sorted
using the provided three-way C<&comparator> or Raku's built-in C<&infix:<cmp>>.

To sort in descending order, use the C<:reverse> adverb or negate the result of
C<&comparator>. For example, the following statements both return values in
descending order:

    heapsort @values, :reverse;
    heapsort -(* cmp *), @values;

Note that C<heapsort> is not a L<stable
sort|https://en.wikipedia.org/wiki/Sorting_algorithm#Stability>.

=head2 sub max-heap

Defined as:

    sub max-heap(&infix:<cmp>, +values, Bool() :$in-place)

Returns a custom C<GenHeap[* cmp * == More]> instance storing the provided
values. If C<values> is a single, non-itemized array, the C<:in-place> adverb
causes the array to be heapified in place. By default, an array is cloned before
heapification.

=head2 sub min-heap

Defined as:

    sub min-heap(&infix:<cmp>, +values, Bool() :$in-place)

Returns a custom C<GenHeap[* cmp * == Less]> instance storing the provided
values. If C<values> is a single, non-itemized array, the C<:in-place> adverb
causes the array to be heapified in place. By default, an array is cloned before
heapification.

=head1 METHODS

This section documents the methods provided by role C<GenHeap>.

=head2 method Bool

Returns C<True> if the heap contains at least one element, and C<False> if the
heap is empty.

=head2 method clone

Returns a clone of the heap.

=head2 method elems

Returns the number of elements in the heap.

=head2 method extract

Defined as:

    method extract($n?)

Returns a C<Seq> that generates values by popping elements from the heap until
C<$n> elements have been extracted or the heap is empty. If no values are pushed
onto the heap before the C<Seq> is exhausted, the values are produced in
non-decreasing order if called on a I<min-heap>, and in non-increasing order if
called on a I<max-heap>.

=head2 method gist

Returns the gist of the heap.

=head2 method iterator

Returns an iterator that produces the elements encountered in a breadth-first
traversal of the heap.

=head2 method list

Returns the elements encountered during a breadth-first traversal of the heap.

=head2 method merge

Defined as:

    method merge(+values)

Merges the provided values into the heap and returns the modified heap.
Autovivifies an uninitialized heap.

=head2 method new

Defined as:

    method new(+values, Bool() :$in-place)

Constructs a new heap containing the provided values. If C<values> is a single,
non-itemized array, the C<:in-place> adverb causes the array to be heapified in
place. By default, an array is cloned before heapification. In either case, the
array's type constraint applies to all elements in the heap.

=head2 method of

Returns the type constraint for the elements in the heap. Returns C<Mu> by
default, but a heap can be constrained to a specific element type by calling
C<.new> with a type-constrained array.

=head2 method pop

Removes the element at the top of the heap and returns it, or returns a
C<Failure> if the heap is empty.

=head2 method push

Defined as:

    method push(**@values)

Inserts the provided values into the heap and returns the modified heap.
Autovivifies an uninitialized heap.

=head2 method push-pop

Defined as:

    method push-pop(Mu \value)

Functionally equivalent to, but more efficient than C<.push(value)> followed by
C<.pop>. Replaces the top of the heap if its priority tops that of the provided
C<value>; otherwise just returns the provided C<value>.

=head2 method raku

Returns a string representation of the heap that can be C<EVAL>ed to reconstruct
the heap, provided it belongs to a named class. Used to compare the structural
equivalence of heaps when the exported C<&infix:eqv> candidate is not in scope.

=head2 method replace

Defined as:

    method replace(Mu \new)

Functionally equivalent to, but more efficient than C<.pop> followed by
C<.push(new)>. Replaces the element at the top of the heap with the C<new> value
and returns the old value. Returns C<Nil> if called on an empty heap.

=head2 method top

Returns the element stored at the top of the heap, or C<Nil> if the heap is
empty.

=head2 method values

Returns a C<Seq> of the elements encountered during a breadth-first traversal of
the heap.

=head1 SEE ALSO

=item L<Binary heap - Wikipedia|https://en.wikipedia.org/wiki/Binary_heap>

=item L<Heapsort - Wikipedia|https://en.wikipedia.org/wiki/Heapsort>

=item L<Raku's built-in C<sort> routine|https://docs.raku.org/routine/sort>

=head1 AUTHOR

Peter du Marchie van Voorthuysen

Source can be located at: https://github.com/dumarchie/raku-binaryheap

=head1 COPYRIGHT AND LICENSE

Copyright 2022-2026 Peter du Marchie van Voorthuysen

This library is free software; you can redistribute it and/or modify it under
the Artistic License 2.0.

=end pod
