-- sub query1($a)
SELECT $a;
-- sub query2($a)
SELECT $a;