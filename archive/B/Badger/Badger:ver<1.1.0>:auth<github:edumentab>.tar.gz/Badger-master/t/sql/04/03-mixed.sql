-- sub query($x, $y, :$a, :$b)
SELECT $x * $a + $y * $b;
