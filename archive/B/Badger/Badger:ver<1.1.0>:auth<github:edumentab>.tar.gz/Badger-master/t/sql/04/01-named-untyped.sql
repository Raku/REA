-- sub query-untyped(:$a)
SELECT $a + $a;
