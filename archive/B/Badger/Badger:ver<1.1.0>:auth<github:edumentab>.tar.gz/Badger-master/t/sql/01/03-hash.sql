-- sub base-query(--> %)
SELECT 1 AS result;