-- sub base-query(Int $a, $b --> +)
SELECT $a + $b;