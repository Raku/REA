-- sub query1()
SELECT 1;
-- sub query2()
SELECT 2;

-- sub query3()
-- note the whitespace before this
SELECT 3;
