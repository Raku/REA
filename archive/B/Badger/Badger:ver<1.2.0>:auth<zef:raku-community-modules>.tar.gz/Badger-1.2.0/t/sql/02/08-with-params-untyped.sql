-- sub base-query($a, $b --> $)
SELECT $a + $b;