# Bird's roadmap

* run in localhost mode ( will require ssh-bulk-test changes )

