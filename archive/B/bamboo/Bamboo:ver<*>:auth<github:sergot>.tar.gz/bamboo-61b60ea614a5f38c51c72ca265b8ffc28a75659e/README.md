# bamboo
Perl 6 dependency manager (bundler)

# TODO

- fix Panda::Installer's destdir
- add bin/bamboo init

