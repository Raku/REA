use v6;

role Bailador::Command {
    method run(:$app) { ... }
}
