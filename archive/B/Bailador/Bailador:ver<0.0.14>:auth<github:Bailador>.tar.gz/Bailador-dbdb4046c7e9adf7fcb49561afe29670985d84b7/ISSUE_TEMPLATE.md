If you have an issue with Bailador we would love to help you, but there are a few thing we would like to ask you to make it easier for us to help.

First of all, are you on the most recent release of Rakudo? We recommend upgrading and trying again.
Are you using the most recent version of Bailador?


Please include the version number of Rakudo (the output of perl6 -v), the version number of zef (zef info zef) and the Operating System.

If you have an installation problem please include the output of `zef install Bailador`.

Otherwise please describe the problem and include the files you feel we will need to reproduce the problem.

Put command between single backticks ``.

Put output and code snippets between triple-backticks:

```
code or output
```


Oh, and feel free to remove this template text from your issue :)
--------------------

