use v6.c;

role Bailador::Command {
    method run(:$app) { ... }
}
