use v6.c;

role Bailador::Template {
    method render(Str $template-name, @params) { ... }
}
