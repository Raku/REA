[![Build Status](https://travis-ci.org/mtw/Perl6-Bio-ViennaNGS.svg?branch=master)](https://travis-ci.org/mtw/Perl6-Bio-ViennaNGS)

# Perl6-Bio-ViennaNGS

This is a prototype port of Bio::ViennaNGS to Perl6.
