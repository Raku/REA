[![Build Status](https://travis-ci.org/mattn/p6-Growl-GNTP.svg?branch=master)](https://travis-ci.org/mattn/p6-Growl-GNTP)

NAME
====

Growl::GNTP - blah blah blah

SYNOPSIS
========

    use Growl::GNTP;

DESCRIPTION
===========

Growl::GNTP is ...

COPYRIGHT AND LICENSE
=====================

Copyright 2015 Yasuhiro Matsumoto <mattn.jp@gmail.com>

This library is free software; you can redistribute it and/or modify it under the Artistic License 2.0.
