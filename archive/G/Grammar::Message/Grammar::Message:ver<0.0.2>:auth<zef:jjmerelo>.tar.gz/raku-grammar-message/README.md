# Grammar::Message, a Raku module to make grammar and regex messages prettier [![Test-install distro](https://github.com/JJ/raku-grammar-message/actions/workflows/test.yaml/badge.svg)](https://github.com/JJ/raku-grammar-message/actions/workflows/test.yaml)

inspired by [Grammar::PrettyErrors](https://github.com/bduggan/p6-grammar-prettyerrors),
and ripping off the code used there for printing messages, prints error
 messages highlighting the line and, if possible, the position where it last
  worked.

## Installing

Do the usual

    zef install Grammar::Message

## Running

You will need to insert a variable assignment behind the match you are going
 to check

```perl6
my $str = (('a'..'z').rotor(3).map: *.join("")).join("\n");
my $saved-match; # Saves in situ
$str ~~ / m { $saved-match = $/} /; # Code right behind match you need printed
say pretty-message( "Found", $saved-match);
```

Will print

```
Found
  3 │ ghi
  4 │ jkl
  5 │▶ mno
        ^
  6 │ pqr
  7 │ stu
  8 │ vwx
```

with highlights for the matching line. 

```perl6
grammar G {
    token TOP { <letters>+ % \v}
    token letters { { $saved-match = $/} \w ** 3 }
}
$str .= subst( "m", "mm" );
G.parse( $str );
say pretty-message( "Some failure around here", $saved-match);
```

will print

```
Some failure around here
  4 │ jkl
  5 │ mmno
  6 │▶ pqr
     ^
  7 │ stu
  8 │ vwx

```

Take into account that the marked point will always be the best bet, and in any
case it will reflect the state of the `pos` attribute of the Match at the point
you saved it.
  
## See also

Code by Brian Duggan in 
[`Grammar::PrettyErrors`](https://github.com/bduggan/p6-grammar-prettyerrors
) is the origin of this code.

## License

(c) Brian Duggan, JJ Merelo

Respecting the original code license, this is also licensed under the
 Artistic license (included).
