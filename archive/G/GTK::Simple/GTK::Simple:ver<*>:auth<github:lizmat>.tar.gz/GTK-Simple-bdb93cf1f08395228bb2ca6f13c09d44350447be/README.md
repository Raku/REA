## GTK::Simple [![Build Status](https://travis-ci.org/perl6/gtk-simple.svg?branch=master)](https://travis-ci.org/perl6/gtk-simple)

Here be GTK::Simple, the simple GTK 3 bindings using NativeCall.

## Installation

This modules requires GTK3 library to be installed.

To install it on Debian Linux:
```
sudo apt-get install libgtk-3-dev
```
