                                # CHANGELOG

----
----
                                ## Table of Contents
[2022-02-20 v0.2.0](#2022-02-20-v020)  

----
# 2022-02-20 v0.2.0


*  add CHANGELOG.rakudoc

*  add link to offical GTK explanation for adding GTK to a Windows system

	*  remove the BUILD step and the *.dll files in the resources

	*  Rationale: a) the Windows build process did not work; b) GTK now has a recommended way to do this.

*  Rename all modules / files to new Raku versions

*  Add placeholder method for Entry

*  Modify README to reflect these changes

*  change CI to github actions





----
Rendered from CHANGELOG at 2022-02-20T18:12:52Z