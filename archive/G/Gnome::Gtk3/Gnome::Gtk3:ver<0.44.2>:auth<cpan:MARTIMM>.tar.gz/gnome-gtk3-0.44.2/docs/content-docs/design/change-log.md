---
title: Change log
nav_menu: default-nav
layout: sidebar
sidebar_menu: design-sidebar
change_notes: change-log-data
---

# The latest change log notes

{% assign todo-url = site.baseurl | append: "/content-docs/design/todo.html" %}
{% assign done-url = site.baseurl | append: "/content-docs/design/todo-done.html" %}

The latest release notes from all gnome Raku packages are noted here. See also the list of [todo]({{todo-url}}) notes and which [todo's are done]({{done-url}})

{% include changes-section.html %}
