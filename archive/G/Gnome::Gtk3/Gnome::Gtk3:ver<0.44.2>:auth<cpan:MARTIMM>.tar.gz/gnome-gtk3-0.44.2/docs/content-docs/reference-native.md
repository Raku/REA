---
title: References to the package modules
nav_menu: references-nav
sidebar_menu: references-native-sidebar
layout: sidebar
---
# Gnome::N Reference
