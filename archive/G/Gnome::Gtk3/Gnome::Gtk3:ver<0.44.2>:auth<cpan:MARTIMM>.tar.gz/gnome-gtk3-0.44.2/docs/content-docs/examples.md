---
title: Raku GTK+ Examples
#nav_title: Examples
nav_menu: example-nav
sidebar_menu: example-todo-viewer-sidebar
#layout: sidebar
---

# Examples

The purpose of this section is to show somewhat more elaborate programs. You can select several examples to study the Raku code and compare the screenshots when you have copied and run the example code.

The first example will be a todo viewer. Its task will be reading source files for special marker words like TODO, NOTE and REVIEW and display the lines in a list.
