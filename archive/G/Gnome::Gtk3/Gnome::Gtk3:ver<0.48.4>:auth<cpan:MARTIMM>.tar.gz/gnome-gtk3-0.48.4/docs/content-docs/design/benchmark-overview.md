---
title: Benchmark Overview
nav_menu: default-nav
sidebar_menu: design-sidebar
layout: sidebar
---

# Introduction

# Benchmark Tables

|Project Version|Raku Version|Sub Project|Test|Mean|Rps|Speedup|
|-|-|-|-|-|-|-|
|0.34.3|2020.10.109|Assistant|Method calls|0.00097|1033.47|9.86|
||||Native sub search|0.00955|104.77|-.--|
