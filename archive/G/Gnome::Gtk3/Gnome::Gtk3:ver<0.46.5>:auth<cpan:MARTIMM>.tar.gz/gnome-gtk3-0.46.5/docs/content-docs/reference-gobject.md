---
title: References to the GObject package modules
nav_menu: references-nav
sidebar_menu: references-gobject-sidebar
layout: sidebar
---
# Gnome::GObject Reference
