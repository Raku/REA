Gnome::Cairo::Path
==================

Creating paths and manipulating path data

Description
===========

    Paths are the most basic drawing tools and are primarily used to implicitly generate simple masks.

Synopsis
========

Declaration
-----------

    unit class Gnome::Cairo::Path;
    also is Gnome::N::TopLevelClassSupport;

Methods
=======

new
---

### :native-object

There is only one way to create a Path object and that is by importing a native object.

