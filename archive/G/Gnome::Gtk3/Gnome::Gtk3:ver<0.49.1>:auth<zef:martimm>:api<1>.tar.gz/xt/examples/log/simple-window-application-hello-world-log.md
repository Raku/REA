Elapsed time | User time| Kernel time | Cpu % | Notes
|--|--|--|--|--|
0:05.53 | 0.95 | 0.72 | 30%
0:04.57 | 0.94 | 0.72 | 36%
