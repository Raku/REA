Change log for the Getopt::Std Perl 6 module
============================================

0.1.0
-----

Initial public release.
