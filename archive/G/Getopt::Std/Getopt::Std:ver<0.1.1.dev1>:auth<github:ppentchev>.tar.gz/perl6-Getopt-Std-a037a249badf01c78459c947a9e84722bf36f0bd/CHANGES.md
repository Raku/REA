Change log for the Getopt::Std Perl 6 module
============================================

0.1.1.dev1 (not yet)
--------------------

- Add the Rakudo 2016.08 release to the ones tested at Travis CI.

0.1.0
-----

Initial public release.
