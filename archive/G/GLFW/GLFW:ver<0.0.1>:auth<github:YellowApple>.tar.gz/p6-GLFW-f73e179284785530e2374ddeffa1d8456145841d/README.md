# GLFW Perl 6 Wrapper

Very much a work in progress.  Thoroughly untested.  Use at your own
risk.

# License

something something same as GLFW something something or maybe Artistic
2.0 something something
