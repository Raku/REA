[![Actions Status](https://github.com/FCO/Grammar-Editor/actions/workflows/test.yml/badge.svg)](https://github.com/FCO/Grammar-Editor/actions)

NAME
====

Grammar::Editor - Interactive TUI for experimenting with Raku grammars

SYNOPSIS
========

```raku
# Run the TUI application
raku -I. bin/grammar-editor.raku

# Use as a library (module is a placeholder for future API)
use Grammar::Editor;
```

DESCRIPTION
===========

Grammar::Editor is a terminal-based interactive tool for exploring and debugging [Raku](https://raku.org) grammar rules. It provides a split-panel TUI where you can:

  * Write grammar rules in an editor panel

  * Type test input to parse against your grammar

  * See a visual trace of which rules matched and which failed

  * View the full match tree with captured values

The application uses [Selkie::UI](Selkie::UI) for the terminal interface and [Grammar::Extractor](Grammar::Extractor) for introspecting rule matching during parsing.

USAGE
=====

The main entry point is the `bin/grammar-editor.raku` script. Run it from the project root:

```shell
raku -I. bin/grammar-editor.raku
```

The interface has four toggleable panels:

    * `Grammar` — Edit your grammar rules

    * `Input` — Enter test strings to parse

    * `Trace` — Step-by-step rule matching trace

    * `Match` — Full parse tree with matches

AUTHOR
======

Fernando Correa de Oliveira <fco@cpan.org>

COPYRIGHT AND LICENSE
=====================

Copyright 2026 Fernando Correa de Oliveira

This library is free software; you can redistribute it and/or modify it under the Artistic License 2.0.

