unit module Grammar::Editor::Pane::Grammar;

use Selkie::UI;

sub grammar-pane($code is raw, $error is raw, %visible is raw) is export {
    my $init = q:to/END/;
    unit grammar MyGrammar;

    token TOP       { <letter>+ }
    token letter    { <vowel> || <consonant> }
    token vowel     { <[aeiou]> }
    token consonant { <[a..z] - vowel> }
    END
    $code = $init;
    Border :title<Grammar>, {
        .size: { %visible<GRAMMAR> ?? :flex !! 0 }
        MultiLineInput.focus.text($init).on-change: -> $, $text {
            $error = "";
            $code = $text
        }
    }
}
