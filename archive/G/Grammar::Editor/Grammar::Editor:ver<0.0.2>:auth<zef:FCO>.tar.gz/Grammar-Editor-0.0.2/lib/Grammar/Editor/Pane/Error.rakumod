unit module Grammar::Editor::Pane::Error;

use Selkie::UI;
use Grammar::Editor::Styles;

sub error-pane($error is raw) is export {
    Border :title<Error>, {
        .theme: border => $s-fail;
        .size: :fixed( $error ?? $error.split: "\n" !! 0 );
        given $error -> $text {
            Text :$text
        }
    }
}
