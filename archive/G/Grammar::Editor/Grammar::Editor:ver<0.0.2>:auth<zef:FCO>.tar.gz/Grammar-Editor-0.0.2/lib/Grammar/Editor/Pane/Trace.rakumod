unit module Grammar::Editor::Pane::Trace;

use Selkie::UI;
use Grammar::Editor::Trace;

sub trace-pane(@trace is raw, %visible is raw) is export {
    Border :title<Trace>, :size{ %visible<TRACE> ?? :flex !! 0 }, {
        my @items = @trace.list;
        ViewportedCardList {
            for @items -> $step {
                create $step;
            }
        }
    }
}
