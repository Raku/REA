unit module Grammar::Editor::Pane::Match;

use Grammar::Extractor;

sub match-pane($code is raw, $string is raw, $error is raw, @trace is raw) is export {
    CATCH { default { $error = .Str; return } }
    my $extractor = Grammar::Extractor.new: :$code;
    my $match;
    with $string {
        $match = $extractor.parse: $_;
        try @trace.shift;
        @trace.push: $extractor.step;
    }
    return $match
}
