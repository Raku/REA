unit module Grammar::Editor::Styles;

use Selkie::UI;

our $s-usual is export = Selkie::Style.new: :fg(0xEEEEEE), :bold;
our $s-match is export = Selkie::Style.new: :fg(0x33AA33), :bold;
our $s-fail  is export = Selkie::Style.new: :fg(0xAA3333), :bold;
