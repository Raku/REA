unit module Grammar::Editor::Trace;

use Selkie::UI;
use Grammar::Extractor;
use Grammar::Editor::Styles;

sub create(Grammar::Extractor::Step $step) is export {
    my $size = 0;
    if $step.children {
        Border :title($step.name), {
            $size += 2;
            VBox {
                for $step.children -> $child {
                    $size += create $child;
                }
            }
            .fixed: $size;
            .theme: :border($step.Bool ?? $s-match !! $s-fail);
        }
    } else {
        my $display = $step.str-or-missing;
        $size += 3;
        Border :title($step.name), :3size, {
            if $step.Bool {
                .theme: :border($s-match);
                RichText.content: [
                    %( :text<MATCH:>,   :style( $s-match ) ),
                    %( :text(" \"$display\""), :style($s-usual) ),
                ];
            } else {
                .theme: :border($s-fail);
                RichText.content: [
                    %( :text<FAIL:>,    :style( $s-fail ) ),
                    %( :text(" \"$display\""), :style($s-usual) ),
                ];
            }
        }
    }
    return $size
}
