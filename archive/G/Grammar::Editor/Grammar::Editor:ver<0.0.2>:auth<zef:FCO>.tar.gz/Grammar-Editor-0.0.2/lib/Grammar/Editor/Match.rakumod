unit module Grammar::Editor::Match;

use Selkie::UI;

multi match(Any:U $match, |) is export { }

multi match(Match:D $match, Str() :$title = "TOP" --> Int) is export {
    my $size = 2;
    Border :$title, {
        .theme: $*UI-APP.obj.theme;
        VBox {
            $size++;
            Text :text($match.Str), :size(:1fixed);
            if $match.hash {
                for $match.hash.kv -> $t, $m {
                    my @match = $m[];
                    for @match -> $m {
                        $size += match $m, :title($t)
                    }
                }
            }
            if $match.list {
                for $match.list.kv -> $title, $match {
                    $size += match $match, :$title
                }
            }
        }
        .size: :fixed($size);
    }
    $size
}
