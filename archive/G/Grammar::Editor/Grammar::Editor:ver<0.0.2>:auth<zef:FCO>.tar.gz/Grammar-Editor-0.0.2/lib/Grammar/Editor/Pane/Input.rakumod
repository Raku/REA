unit module Grammar::Editor::Pane::Input;

use Selkie::UI;

sub input-pane($string is raw, $error is raw, %visible is raw) is export {
    my $init = "a";
    $string = $init;
    Border :title<Input>, {
        .size: { %visible<INPUT> ?? :flex !! 0 }
        MultiLineInput.text($init).on-change: -> $, $text {
            $error = "";
            $string = $text
        }
    }
}
