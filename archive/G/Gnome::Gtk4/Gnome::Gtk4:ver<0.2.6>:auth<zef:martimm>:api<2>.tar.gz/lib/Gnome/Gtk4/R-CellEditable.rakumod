=comment Package: Gtk4, C-Source: celleditable
use v6.d;

#-------------------------------------------------------------------------------
#--[Module Imports]-------------------------------------------------------------
#-------------------------------------------------------------------------------

use NativeCall;



use Gnome::N::GlibToRakuTypes:api<2>;
use Gnome::N::GnomeRoutineCaller:api<2>;
use Gnome::N::N-Object:api<2>;
use Gnome::N::NativeLib:api<2>;


#-------------------------------------------------------------------------------
#--[Role Declaration]-----------------------------------------------------------
#-------------------------------------------------------------------------------

unit role Gnome::Gtk4::R-CellEditable:auth<github:MARTIMM>:api<2>;

#TM:1:_add_gtk_cell_editable_signal_types:
method _add_gtk_cell_editable_signal_types ( Str $class-name ) {
  self.add-signal-types( $class-name,
    :w0<editing-done remove-widget>,
  );
}


#-------------------------------------------------------------------------------
#--[Native Routine Definitions]-------------------------------------------------
#-------------------------------------------------------------------------------

my Hash $methods = %(

  #--[Methods]------------------------------------------------------------------
  editing-done => %(:is-symbol<gtk_cell_editable_editing_done>, :deprecated, :deprecated-version<4.10>, ),
  remove-widget => %(:is-symbol<gtk_cell_editable_remove_widget>, :deprecated, :deprecated-version<4.10>, ),
  start-editing => %(:is-symbol<gtk_cell_editable_start_editing>, :parameters([N-Object]), ),
);

#-------------------------------------------------------------------------------
# This method is recognized in class Gnome::N::TopLevelClassSupport.
method _do_gtk_cell_editable_fallback-v2 (
  Str $name, Bool $_fallback-v2-ok is rw,
  Gnome::N::GnomeRoutineCaller $routine-caller, @arguments, $native-object
) {
  if $methods{$name}:exists {
    $_fallback-v2-ok = True;
    return $routine-caller.call-native-sub(
      $name, @arguments, $methods, $native-object
    );
  }
}
