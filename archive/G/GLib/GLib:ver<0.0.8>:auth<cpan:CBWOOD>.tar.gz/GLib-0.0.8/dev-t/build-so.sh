gcc -I/usr/include/glib-2.0 -I/usr/lib/x86_64-linux-gnu/glib-2.0/include 00-struct-sizes.c -fPIC -Wno-deprecated-declarations -shared -o 00-struct-sizes.so
