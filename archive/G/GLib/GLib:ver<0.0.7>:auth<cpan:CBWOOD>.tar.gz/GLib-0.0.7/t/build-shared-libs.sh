gcc 00-struct-sizes.c -Wno-deprecated-declarations -I/usr/include/glib-2.0 -I/usr/lib/x86_64-linux-gnu/glib-2.0/include --shared -lglib-2.0
