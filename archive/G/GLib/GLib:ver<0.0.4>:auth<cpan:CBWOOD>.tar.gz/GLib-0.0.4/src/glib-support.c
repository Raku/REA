#include <glib-object.h>

void *
get_paramspec_types (void) {
    return g_param_spec_types;
}
