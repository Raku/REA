This sofware is a Bayesian Inference Learning package based on populations
or distributionpopulations (see the module Mathx::Stat) which has 
hypthetical loss functions (Bayes, disjoint and joint probabilities) together
with a minimax value algorithm based on Action and Startegy classes.

It is to be used in games and was built for speed not general OOP.
