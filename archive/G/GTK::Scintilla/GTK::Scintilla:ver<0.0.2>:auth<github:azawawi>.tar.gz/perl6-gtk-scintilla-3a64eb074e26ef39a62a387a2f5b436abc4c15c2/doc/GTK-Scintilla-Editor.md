Name
====

GTK::Scintilla::Editor - GTK Scintilla Editor Widget

Synopsis
========

TODO Add Synopsis ection documentation

Description
===========

TODO Add Description section documentation

Methods
=======

Long lines
----------

Please see [here](http://www.scintilla.org/ScintillaDoc.html#LongLines).

### set-edge-mode

### get-edge-mode

### set-edge-column

### get-edge-column

### set-edge-color

### get-edge-color

Zooming
-------

Please see [here](http://www.scintilla.org/ScintillaDoc.html#Zooming).

### zoom-in

### zoom-out

### set-zoom

### get-zoom
