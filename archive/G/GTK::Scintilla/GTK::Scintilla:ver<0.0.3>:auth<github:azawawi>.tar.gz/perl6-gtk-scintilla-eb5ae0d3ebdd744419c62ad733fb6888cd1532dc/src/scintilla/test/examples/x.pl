use strict;
while ( $r ) {
  printf ( "Example text \n" );
  sleep 1;
}