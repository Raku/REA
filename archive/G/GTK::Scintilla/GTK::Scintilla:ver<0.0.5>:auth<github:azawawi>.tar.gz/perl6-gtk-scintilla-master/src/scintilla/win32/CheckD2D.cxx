// This file is compiled to check whether Direct2D and DirectWrite headers are available.
#include <d2d1.h>
#include <dwrite.h>
