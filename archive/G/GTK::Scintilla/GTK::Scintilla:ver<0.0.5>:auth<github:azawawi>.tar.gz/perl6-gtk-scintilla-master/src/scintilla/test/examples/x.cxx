// A demonstration program
#include <stdio.h>
#if 0 /* */
#define DUMMY() \
	if (1);
#endif

#define M\

\
 
int main() {
	double x[] = {3.14159,6.02e23,1.6e-19,1.0+1};
	int y[] = {75,0113,0x4b};
	printf("hello world %d %g\n", y[0], x[0]);
}
