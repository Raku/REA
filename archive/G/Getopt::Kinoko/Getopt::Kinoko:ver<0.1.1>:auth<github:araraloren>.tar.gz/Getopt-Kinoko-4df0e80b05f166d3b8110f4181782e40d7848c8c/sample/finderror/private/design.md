
--system
--socket

--errno
--number
--comment

--socket-error-url
--system-error-url

--regex

--wget
--curl
--lwp
--html-downloader

Hex-number number string

list find update 

input[format] -> ** -> finder -> output
