Perl 6 GraphQL Server
=====================

Broke this out of the main GraphQL module. I'm not really using
it anymore, having switched from Bailador to Cro.

I'll add tests and documentation at some point..

Copyright © 2017 United States Government as represented by the
Administrator of the National Aeronautics and Space Administration.
No copyright is claimed in the United States under Title 17,
U.S.Code. All Other Rights Reserved.
