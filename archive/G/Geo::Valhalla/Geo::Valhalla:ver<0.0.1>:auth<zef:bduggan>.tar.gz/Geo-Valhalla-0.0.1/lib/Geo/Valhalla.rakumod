unit class Geo::Valhalla;
use Geo::Valhalla::Native;

has $.actor;
has Str $.conf is required;

submethod TWEAK {
  fail "Valhalla configuration file not found at {$!conf}" unless $!conf.IO.e;
  $!actor = valhalla_actor_create($!conf);
}

submethod DESTROY {
  valhalla_actor_destroy($!actor) if $!actor;
}

method route(*%req) {
   valhalla-route($!actor, %req);
}

=begin pod

=head1 NAME

Geo::Valhalla -- Interface to the Valhalla routing engine

=head1 SYNOPSIS

  use Geo::Valhalla;

  # Washington Square Park to Central Park, NYC
  my ($from-lat, $from-lon, $to-lat, $to-lon) = <40.7308 -73.9973 40.7648 -73.9808>;
  my $v = Geo::Valhalla.new;
  my $res = $v.route:
     locations => [
         { :lat($from-lat), :lon($from-lon), :type<break> },
         { :lat($to-lat),   :lon($to-lon),   :type<break> },
     ],
     costing => 'auto';
  say .<instruction> for $res<trip><legs>[0]<maneuvers><>;
  say 'time (minutes): ' ~ $res<trip><summary><time> div 60;
  say 'distance (km) : ' ~ $res<trip><summary><length>;

Output:

  Drive northwest on Washington Square North.
  Turn right onto 6th Avenue/Avenue of the Americas.
  Turn left onto Greenwich Avenue.
  Turn right onto 8th Avenue.
  Turn left onto West 15th Street.
  Turn right onto NY 9A North/11th Avenue/Joe DiMaggio Highway.
  Keep left to take NY 9A North/12th Avenue/Joe DiMaggio Highway.
  Take exit 7 on the right toward West 56th Street/West 57th Street.
  Turn right onto Broadway.
  Turn left onto West 56th Street.
  Your destination is on the right.
  time (minutes): 13
  distance (km) : 6.731

=head1 DESCRIPTION

This is a Raku interface to the L<Valhalla|https://github.com/valhalla/valhalla> routing engine.

It provides bindings similar to the L<bindings|https://github.com/valhalla/valhalla/tree/master/src/bindings> available for other languages.

This class provides a somewhat high level OO interface, while L<Geo::Valhalla::Native> provides a lower level functional interface.

This is pre-beta, everything is subject to change!

=head1 INSTALLATION

Valhalla provides a C++ API.  This module wraps that into a C API and then
uses Nativecall.  Installation varies depending on the system but in general
the only prerequisite should be the existence of libvalhalla.so, or .a, or .dylib
or the library extension for your system.  Then `zef install Geo::Valhalla` should do
all you need.  The github actions for this repository verify a complete installation,
so refer to that if all else fails.

=head1 AUTHOR

Brian Duggan

=end pod

