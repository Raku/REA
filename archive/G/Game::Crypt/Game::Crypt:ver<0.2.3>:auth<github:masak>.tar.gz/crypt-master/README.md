Crypt
=====

An adventure game written in Perl 6.
