# Grammar::Modelica

A Perl 6 Grammar for the [Modelica Language Specification 3.3 Revision 1](https://www.modelica.org/documents/ModelicaSpec33Revision1.pdf) (pdf).

The Grammar is mostly a direct translation of the concrete syntax specification found in Appendix B.

See the test files to get some idea of what is going on.

## TODO

  * make use of proto and more named parameters to make it more useful
  * more stuff by and by
