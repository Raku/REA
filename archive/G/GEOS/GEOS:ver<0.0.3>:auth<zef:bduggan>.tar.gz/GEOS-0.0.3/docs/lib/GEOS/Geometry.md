NAME
====

GEOS::Geometry - Base class for GEOS geometries

