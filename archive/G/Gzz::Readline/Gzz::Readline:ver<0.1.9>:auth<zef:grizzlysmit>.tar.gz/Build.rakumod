class Build {
    method build($dist-path) {
        # do build stuff to your module
        # which is located at $dist-path
        my IO::Path $CWD = $*CWD;
        my Str:D $path  = "/usr/lib/perl6/site/bin";
        my Str:D $local = "/usr/local";
        chdir($path.IO);
        my Proc $r = run 'raku',    '--doc=Man',  "Gzz::Readline.rakudoc",  :out;
        my $man-content = $r.out.slurp: :close;
        "$local/share/man".IO.mkdir();
        "$local/share/man/Gzz::Readline.1".IO.spurt($man-content);
        $r = run         'raku',    '--doc=HTML', "Gzz::Readline.rakudoc",  :out;
        my $html-content = $r.out.slurp: :close;
        "$local/share/html".IO.mkdir();
        "$local/share/html/Gzz::Readline.html".IO.spurt($html-content);

        $r = run         'apt-get', 'reinstall',  '--yes', "build-essential";
        $r = run         'apt-get', 'reinstall',  '--yes', "cmake";
        $r = run         'apt-get', 'reinstall',  '--yes', "make";
        $r = run         'apt-get', 'reinstall',  '--yes', "g++";
        chdir("build".IO);
        $r = run         'cmake', '..';
        $r = run         'make';
        $r = run         'make', 'all';
        $r = run         'make', 'package';

        my @debs =       dir('.', test => { "./$_".IO.f && $_ ~~ rx/ ^^ 'gzz_readline' .* '.deb' $$ / })
                                                              .sort( { 
                                                                        rx/ ^^ 'gzz_readline-' (\d+ [ \. \d+ [ \. \d ]? ]? ) '-' .* '.deb' $$ / 
                                                                            ?? Version.new($0) 
                                                                            !! Version.new('0.0.0')
                                                                     } );
        my $deb  =       @debs.pop();
        $r = run         'dpkg', '--install', "$deb";
        chdir($CWD);
    }
}


