const char *hello()
{
    return "Hello, World!\n";
}
